-- MySQL dump 10.14  Distrib 5.5.47-MariaDB, for Linux (x86_64)
--
-- Host: tierdb    Database: grouper
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `grouper`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `grouper` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `grouper`;

--
-- Temporary table structure for view `grouper_attr_asn_asn_attrdef_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_asn_attrdef_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_attrdef_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_asn_attrdef_v` (
  `name_of_attr_def_assigned_to` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `id_of_attr_def_assigned_to` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_asn_efmship_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_asn_efmship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_efmship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_asn_efmship_v` (
  `group_name` tinyint NOT NULL,
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_asn_group_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_asn_group_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_group_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_asn_group_v` (
  `group_name` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_asn_member_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_asn_member_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_member_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_asn_member_v` (
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_asn_mship_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_asn_mship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_mship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_asn_mship_v` (
  `group_name` tinyint NOT NULL,
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_asn_stem_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_asn_stem_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_stem_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_asn_stem_v` (
  `stem_name` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `stem_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `stem_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_attrdef_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_attrdef_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_attrdef_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_attrdef_v` (
  `name_of_attr_def_assigned_to` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def_assigned` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `id_of_attr_def_assigned_to` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_efmship_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_efmship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_efmship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_efmship_v` (
  `group_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_group_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_group_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_group_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_group_v` (
  `group_name` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_member_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_member_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_member_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_member_v` (
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_mship_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_mship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_mship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_mship_v` (
  `group_name` tinyint NOT NULL,
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_asn_stem_v`
--

DROP TABLE IF EXISTS `grouper_attr_asn_stem_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_stem_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_asn_stem_v` (
  `stem_name` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `stem_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `stem_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_attr_assign_action`
--

DROP TABLE IF EXISTS `grouper_attr_assign_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attr_assign_action` (
  `attribute_def_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `name` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attr_assn_act_def_id_idx` (`attribute_def_id`),
  CONSTRAINT `fk_attr_assn_attr_def_id` FOREIGN KEY (`attribute_def_id`) REFERENCES `grouper_attribute_def` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attr_assign_action`
--

LOCK TABLES `grouper_attr_assign_action` WRITE;
/*!40000 ALTER TABLE `grouper_attr_assign_action` DISABLE KEYS */;
INSERT INTO `grouper_attr_assign_action` VALUES ('da7ae804604741feb591dd47b6f352be','98ba1ea840d5404299ad811e5e2f1da2',1459816162355,0,'0484c4c31b4e4469a120821ddddf9ff2',1459816162355,'assign'),('240c728c9e2c42ccb4bd63fae71d8b28','2d05ad7ebd794bb79815228acd5fed54',1459816164270,0,'0f7cd113751f46f6b0f95653dd6f325d',1459816164270,'assign'),('dd528f792dd544938a2588848992e909','7bbeeff369ab4699bcbaf02e3beb0cd6',1459816163734,0,'340993371dc0497f80a6053beb40fe52',1459816163734,'assign'),('51f5a5e597fc4028824384b06614aba2','2addfdcfc0b843ab9bf3fa03fe141cc7',1459816165968,0,'3da21ec8d898406b9b7e805830782c48',1459816165968,'assign'),('b92c64af9edd4b7493d8c4b2a936cbd8','b9307b3c26ab440d91b270b950336d12',1459816162481,0,'449d095dcf4e466d97f89767c5ea21b6',1459816162481,'assign'),('c4777fa00d2e4f7aabc2184cf6023770','0865979fcb75478ea9394435359e8b9a',1459816164111,0,'4893e5881f5d49c9917da7615feebf1e',1459816164111,'assign'),('1f60e0aa563e441e86b646c79c66b6ff','73cbab28d09f47459ae272f0fc2a3479',1459816161420,0,'4bec2791320a4968b79705397e72ad80',1459816161420,'assign'),('3e4973476a6e4351a925503a921ad728','99ec6323827447ebb566a0adbdada197',1459816168417,0,'7dd02b274f3c4f3dbe277931a06bc9aa',1459816168417,'assign'),('98e846065291427bb67c498d8e70d8ec','d3070a409e5149a0b7bfeb8222f313ab',1459816168136,0,'9a0966321c5f4109a04f490e0b6236d1',1459816168136,'assign'),('c3540f2df6964cb9bbc9b974cf445d84','8159789da0a14cafbd09145afa025cd8',1459816161723,0,'9c65cb79f47246f0b16efcbc28fff250',1459816161723,'assign'),('af747ed516a548a6b22ca4020b5a67a0','9020c22117504dceb753bc010b2d0088',1459816167597,0,'b796316b96774a288bc842e51f9cca08',1459816167597,'assign'),('19faf0fca06b4aeb8a5cce52382a3f0e','00618952cb8b4705b94cd916a6713a4e',1459816165864,0,'b94d85f218fc429880af53502780c4a3',1459816165864,'assign'),('05ed0d9e4c5e4024a75c08aa08717579','35b82a4a0f7146248919176310137474',1459816164335,0,'be6656b9ea314c3786f7024884eb2ab3',1459816164335,'assign'),('2a9bd9fd21e34e56aca2c3f93bb68928','4804a077ec2c43899a5d981c4d45375f',1459816163956,0,'d02a510effc546e4aafc958453d3080d',1459816163956,'assign'),('a9cce636abf44507876f639467f74174','a194a2a1e2ad45e7b81b45c4f987e830',1459816167389,0,'d6a8882a75a3485baee64ea5255866cb',1459816167389,'assign'),('35ee03902f9049fea8520a4c47e57b54','cc9ba9ab69e64d0c9c9ba96f0f506ce4',1459816168594,0,'f2fcf4ee10ba4fe495e2ae04762a4e76',1459816168594,'assign');
/*!40000 ALTER TABLE `grouper_attr_assign_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_attr_assign_action_set`
--

DROP TABLE IF EXISTS `grouper_attr_assign_action_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attr_assign_action_set` (
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `depth` bigint(20) NOT NULL,
  `if_has_attr_assn_action_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_attr_assn_action_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_attr_assn_action_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_set_unq_idx` (`parent_attr_assn_action_id`,`if_has_attr_assn_action_id`,`then_has_attr_assn_action_id`),
  KEY `action_set_ifhas_idx` (`if_has_attr_assn_action_id`),
  KEY `action_set_then_idx` (`then_has_attr_assn_action_id`),
  CONSTRAINT `fk_attr_action_set_if` FOREIGN KEY (`if_has_attr_assn_action_id`) REFERENCES `grouper_attr_assign_action` (`id`),
  CONSTRAINT `fk_attr_action_set_parent` FOREIGN KEY (`parent_attr_assn_action_id`) REFERENCES `grouper_attr_assign_action_set` (`id`),
  CONSTRAINT `fk_attr_action_set_then` FOREIGN KEY (`then_has_attr_assn_action_id`) REFERENCES `grouper_attr_assign_action` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attr_assign_action_set`
--

LOCK TABLES `grouper_attr_assign_action_set` WRITE;
/*!40000 ALTER TABLE `grouper_attr_assign_action_set` DISABLE KEYS */;
INSERT INTO `grouper_attr_assign_action_set` VALUES (NULL,1459816165872,0,'017723bd984b4c879e200314a94e0a09',1459816165872,0,'b94d85f218fc429880af53502780c4a3','b94d85f218fc429880af53502780c4a3','017723bd984b4c879e200314a94e0a09','self'),(NULL,1459816161424,0,'10a3f634383242db826f8d46b6d71a22',1459816161424,0,'4bec2791320a4968b79705397e72ad80','4bec2791320a4968b79705397e72ad80','10a3f634383242db826f8d46b6d71a22','self'),(NULL,1459816164112,0,'20d9a7b124a24e6f9663b3d41b28c905',1459816164112,0,'4893e5881f5d49c9917da7615feebf1e','4893e5881f5d49c9917da7615feebf1e','20d9a7b124a24e6f9663b3d41b28c905','self'),(NULL,1459816168137,0,'25775809bca445f991d461d3f7536b86',1459816168137,0,'9a0966321c5f4109a04f490e0b6236d1','9a0966321c5f4109a04f490e0b6236d1','25775809bca445f991d461d3f7536b86','self'),(NULL,1459816167598,0,'2dec318c2e7247d39b3aec0ccfcfbe42',1459816167598,0,'b796316b96774a288bc842e51f9cca08','b796316b96774a288bc842e51f9cca08','2dec318c2e7247d39b3aec0ccfcfbe42','self'),(NULL,1459816168597,0,'3c37a5ff12f5415baea521959501a947',1459816168597,0,'f2fcf4ee10ba4fe495e2ae04762a4e76','f2fcf4ee10ba4fe495e2ae04762a4e76','3c37a5ff12f5415baea521959501a947','self'),(NULL,1459816163957,0,'3f4130e6f63948229f4086e7a144c0a0',1459816163957,0,'d02a510effc546e4aafc958453d3080d','d02a510effc546e4aafc958453d3080d','3f4130e6f63948229f4086e7a144c0a0','self'),(NULL,1459816164272,0,'41c9a815cb1e48f9b47e860ba2c05042',1459816164272,0,'0f7cd113751f46f6b0f95653dd6f325d','0f7cd113751f46f6b0f95653dd6f325d','41c9a815cb1e48f9b47e860ba2c05042','self'),(NULL,1459816162486,0,'47e4d6e8577e43ffbc78774d9ed88bf2',1459816162486,0,'449d095dcf4e466d97f89767c5ea21b6','449d095dcf4e466d97f89767c5ea21b6','47e4d6e8577e43ffbc78774d9ed88bf2','self'),(NULL,1459816167396,0,'6255905954654702a983ebc686c25ee8',1459816167396,0,'d6a8882a75a3485baee64ea5255866cb','d6a8882a75a3485baee64ea5255866cb','6255905954654702a983ebc686c25ee8','self'),(NULL,1459816165969,0,'64f282d78bd64a7aa63c565a9e69fd02',1459816165969,0,'3da21ec8d898406b9b7e805830782c48','3da21ec8d898406b9b7e805830782c48','64f282d78bd64a7aa63c565a9e69fd02','self'),(NULL,1459816161724,0,'83560d0a5bbd4e13889a93048dc7d687',1459816161724,0,'9c65cb79f47246f0b16efcbc28fff250','9c65cb79f47246f0b16efcbc28fff250','83560d0a5bbd4e13889a93048dc7d687','self'),(NULL,1459816164336,0,'844624ab432744928164e9aee56c17bc',1459816164336,0,'be6656b9ea314c3786f7024884eb2ab3','be6656b9ea314c3786f7024884eb2ab3','844624ab432744928164e9aee56c17bc','self'),(NULL,1459816168418,0,'a90e7ef39785487b912464b825064023',1459816168418,0,'7dd02b274f3c4f3dbe277931a06bc9aa','7dd02b274f3c4f3dbe277931a06bc9aa','a90e7ef39785487b912464b825064023','self'),(NULL,1459816162356,0,'ac55308969ef460d9b99fff54766cbbe',1459816162356,0,'0484c4c31b4e4469a120821ddddf9ff2','0484c4c31b4e4469a120821ddddf9ff2','ac55308969ef460d9b99fff54766cbbe','self'),(NULL,1459816163735,0,'f62d02fa6b334767868f68f27df17526',1459816163735,0,'340993371dc0497f80a6053beb40fe52','340993371dc0497f80a6053beb40fe52','f62d02fa6b334767868f68f27df17526','self');
/*!40000 ALTER TABLE `grouper_attr_assign_action_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_attr_assn_action_set_v`
--

DROP TABLE IF EXISTS `grouper_attr_assn_action_set_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_assn_action_set_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_assn_action_set_v` (
  `if_has_attr_assn_action_name` tinyint NOT NULL,
  `then_has_attr_assn_action_name` tinyint NOT NULL,
  `depth` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_if_has_name` tinyint NOT NULL,
  `parent_then_has_name` tinyint NOT NULL,
  `id` tinyint NOT NULL,
  `if_has_attr_assn_action_id` tinyint NOT NULL,
  `then_has_attr_assn_action_id` tinyint NOT NULL,
  `parent_attr_assn_action_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_def_name_set_v`
--

DROP TABLE IF EXISTS `grouper_attr_def_name_set_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_def_name_set_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_def_name_set_v` (
  `if_has_attr_def_name_name` tinyint NOT NULL,
  `then_has_attr_def_name_name` tinyint NOT NULL,
  `depth` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_if_has_name` tinyint NOT NULL,
  `parent_then_has_name` tinyint NOT NULL,
  `id` tinyint NOT NULL,
  `if_has_attr_def_name_id` tinyint NOT NULL,
  `then_has_attr_def_name_id` tinyint NOT NULL,
  `parent_attr_def_name_set_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_attr_def_priv_v`
--

DROP TABLE IF EXISTS `grouper_attr_def_priv_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_def_priv_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_attr_def_priv_v` (
  `subject_id` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `field_name` tinyint NOT NULL,
  `attribute_def_name` tinyint NOT NULL,
  `attribute_def_description` tinyint NOT NULL,
  `attribute_def_type` tinyint NOT NULL,
  `attribute_def_stem_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `field_id` tinyint NOT NULL,
  `immediate_membership_id` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_attribute_assign`
--

DROP TABLE IF EXISTS `grouper_attribute_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attribute_assign` (
  `attribute_assign_action_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_def_name_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `disabled_time` bigint(20) DEFAULT NULL,
  `enabled` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'T',
  `enabled_time` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `notes` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `attribute_assign_delegatable` varchar(15) COLLATE utf8_bin NOT NULL,
  `attribute_assign_type` varchar(15) COLLATE utf8_bin NOT NULL,
  `owner_attribute_assign_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_attribute_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_member_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_membership_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `disallowed` varchar(1) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_asgn_attr_name_idx` (`attribute_def_name_id`,`attribute_assign_action_id`),
  KEY `attr_asgn_own_asgn_idx` (`owner_attribute_assign_id`,`attribute_assign_action_id`),
  KEY `attr_asgn_own_def_idx` (`owner_attribute_def_id`,`attribute_assign_action_id`),
  KEY `attr_asgn_own_group_idx` (`owner_group_id`,`attribute_assign_action_id`),
  KEY `attr_asgn_own_mem_idx` (`owner_member_id`,`attribute_assign_action_id`),
  KEY `attr_asgn_own_mship_idx` (`owner_membership_id`,`attribute_assign_action_id`),
  KEY `attr_asgn_own_stem_idx` (`owner_stem_id`,`attribute_assign_action_id`),
  KEY `fk_attr_assign_action_id` (`attribute_assign_action_id`),
  CONSTRAINT `fk_attr_assign_action_id` FOREIGN KEY (`attribute_assign_action_id`) REFERENCES `grouper_attr_assign_action` (`id`),
  CONSTRAINT `fk_attr_assign_def_name_id` FOREIGN KEY (`attribute_def_name_id`) REFERENCES `grouper_attribute_def_name` (`id`),
  CONSTRAINT `fk_attr_assign_owner_assign_id` FOREIGN KEY (`owner_attribute_assign_id`) REFERENCES `grouper_attribute_assign` (`id`),
  CONSTRAINT `fk_attr_assign_owner_def_id` FOREIGN KEY (`owner_attribute_def_id`) REFERENCES `grouper_attribute_def` (`id`),
  CONSTRAINT `fk_attr_assign_owner_group_id` FOREIGN KEY (`owner_group_id`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_attr_assign_owner_member_id` FOREIGN KEY (`owner_member_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_attr_assign_owner_mship_id` FOREIGN KEY (`owner_membership_id`) REFERENCES `grouper_memberships` (`id`),
  CONSTRAINT `fk_attr_assign_owner_stem_id` FOREIGN KEY (`owner_stem_id`) REFERENCES `grouper_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attribute_assign`
--

LOCK TABLES `grouper_attribute_assign` WRITE;
/*!40000 ALTER TABLE `grouper_attribute_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_attribute_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_attribute_assign_value`
--

DROP TABLE IF EXISTS `grouper_attribute_assign_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attribute_assign_value` (
  `attribute_assign_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `value_integer` bigint(20) DEFAULT NULL,
  `value_floating` double DEFAULT NULL,
  `value_string` text COLLATE utf8_bin,
  `value_member_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_val_assign_idx` (`attribute_assign_id`),
  KEY `attribute_val_integer_idx` (`value_integer`),
  KEY `attribute_val_member_id_idx` (`value_member_id`),
  KEY `attribute_val_string_idx` (`value_string`(255)),
  CONSTRAINT `fk_attr_assign_value_assign_id` FOREIGN KEY (`attribute_assign_id`) REFERENCES `grouper_attribute_assign` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attribute_assign_value`
--

LOCK TABLES `grouper_attribute_assign_value` WRITE;
/*!40000 ALTER TABLE `grouper_attribute_assign_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_attribute_assign_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_attribute_def`
--

DROP TABLE IF EXISTS `grouper_attribute_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attribute_def` (
  `attribute_def_public` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `attribute_def_type` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT 'attr',
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `creator_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `description` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8_bin NOT NULL,
  `name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `multi_assignable` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `multi_valued` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `value_type` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT 'marker',
  `assign_to_attribute_def` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_attribute_def_assn` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_eff_membership` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_eff_membership_assn` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_group` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_group_assn` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_imm_membership` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_imm_membership_assn` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_member` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_member_assn` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_stem` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `assign_to_stem_assn` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'F',
  `id_index` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_def_id_index_idx` (`id_index`),
  UNIQUE KEY `attribute_def_name_idx` (`name`(255)),
  KEY `attribute_def_type_idx` (`attribute_def_type`),
  KEY `fk_attr_def_stem` (`stem_id`),
  CONSTRAINT `fk_attr_def_stem` FOREIGN KEY (`stem_id`) REFERENCES `grouper_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attribute_def`
--

LOCK TABLES `grouper_attribute_def` WRITE;
/*!40000 ALTER TABLE `grouper_attribute_def` DISABLE KEYS */;
INSERT INTO `grouper_attribute_def` VALUES ('F','attr','c8f2a547c8004d08aa1fa00df9d7a4d8',1459816164314,'65947ffd4e364921a42c465d94a78c09',1,1459816164362,'05ed0d9e4c5e4024a75c08aa08717579',NULL,'attributeDefLoaderDef','etc:attribute:attrLoader:attributeDefLoaderDef','F','F','6cd4d8196fe24d21acd51cdf8fcdb3cc','string','T','F','F','F','F','F','F','F','F','F','F','F',10009),('F','attr','578582bcb2f34cb8b89a44888a2d430c',1459816165835,'65947ffd4e364921a42c465d94a78c09',1,1459816165889,'19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'grouperLoaderLdapDef','etc:attribute:loaderLdap:grouperLoaderLdapDef','F','F','094308af1376466687416c49f1f6495f','marker','F','F','F','F','T','F','F','F','F','F','F','F',10010),('F','type','4e42f1e5a42f4b5b80f5604af7bf7022',1459816161354,'65947ffd4e364921a42c465d94a78c09',1,1459816161550,'1f60e0aa563e441e86b646c79c66b6ff',NULL,'externalSubjectInviteDef','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef','T','F','d5248b39d72f4fdcb730d1be03de4fbc','marker','F','F','F','F','F','F','F','F','F','F','T','F',10000),('F','type','fc2f092a364b44df9ad23b591e48c385',1459816164245,'65947ffd4e364921a42c465d94a78c09',1,1459816164287,'240c728c9e2c42ccb4bd63fae71d8b28',NULL,'attributeDefLoaderTypeDef','etc:attribute:attrLoader:attributeDefLoaderTypeDef','F','F','6cd4d8196fe24d21acd51cdf8fcdb3cc','marker','T','F','F','F','F','F','F','F','F','F','F','F',10008),('F','limit','79c891d54c214f9292c72ad42a500a21',1459816163921,'65947ffd4e364921a42c465d94a78c09',1,1459816163986,'2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'limitsDefInt','etc:attribute:permissionLimits:limitsDefInt','T','F','b6bc2fcd772146ee970347e496538926','integer','T','F','T','T','T','T','F','F','F','F','F','F',10006),('F','attr','038ff051b78649d7b942f1b7742ffa6b',1459816168556,'65947ffd4e364921a42c465d94a78c09',1,1459816168623,'35ee03902f9049fea8520a4c47e57b54',NULL,'legacyAttributeDef_grouperLoader','etc:legacy:attribute:legacyAttributeDef_grouperLoader','F','F','36792aa7956240feb1bb6025c56ff2f3','string','F','F','F','F','F','T','F','F','F','F','F','F',10016),('F','attr','99ec6323827447ebb566a0adbdada197',1459816168397,'65947ffd4e364921a42c465d94a78c09',1,1459816168491,'3e4973476a6e4351a925503a921ad728',NULL,'legacyGroupTypeDef_grouperLoader','etc:legacy:attribute:legacyGroupTypeDef_grouperLoader','F','F','36792aa7956240feb1bb6025c56ff2f3','marker','F','F','F','F','T','F','F','F','F','F','F','F',10015),('F','attr','36522194fa7049c4944f1023c14e20e0',1459816165925,'65947ffd4e364921a42c465d94a78c09',1,1459816165995,'51f5a5e597fc4028824384b06614aba2',NULL,'grouperLoaderLdapValueDef','etc:attribute:loaderLdap:grouperLoaderLdapValueDef','F','F','094308af1376466687416c49f1f6495f','string','F','F','F','F','F','T','F','F','F','F','F','F',10011),('T','attr','9d772a6399824b78a976fc55e413f791',1459816168114,'65947ffd4e364921a42c465d94a78c09',1,1459816168151,'98e846065291427bb67c498d8e70d8ec',NULL,'entitySubjectIdentifierDef','etc:attribute:entities:entitySubjectIdentifierDef','F','F','2eee186e51494f0a874fe61ff24b7192','string','F','F','F','F','T','F','F','F','F','F','F','F',10014),('F','attr','5c3bb10ded72439ea55f8add3380b0e0',1459816167358,'65947ffd4e364921a42c465d94a78c09',1,1459816167420,'a9cce636abf44507876f639467f74174',NULL,'grouperUserDataDef','etc:attribute:userData:grouperUserDataDef','F','F','cb1bfad6c8ed424d902b65d9ec275df0','marker','F','F','F','F','F','F','T','F','F','F','F','F',10012),('F','attr','d1f8d61e04f14a0a89dcaef2e5ae9e4f',1459816167515,'65947ffd4e364921a42c465d94a78c09',1,1459816167626,'af747ed516a548a6b22ca4020b5a67a0',NULL,'grouperUserDataValueDef','etc:attribute:userData:grouperUserDataValueDef','F','F','cb1bfad6c8ed424d902b65d9ec275df0','string','F','F','F','F','F','F','F','T','F','F','F','F',10013),('F','attr','94adf590110246f88e79f8d5edc90f92',1459816162425,'65947ffd4e364921a42c465d94a78c09',1,1459816162547,'b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'rulesAttrDef','etc:attribute:rules:rulesAttrDef','F','F','fc88a71ee4574ae7b0a550d72b5172d9','string','F','T','F','F','F','T','F','F','F','F','F','T',10004),('F','attr','0b48a27979d24cd892df9e63c7f1a418',1459816161655,'65947ffd4e364921a42c465d94a78c09',1,1459816161776,'c3540f2df6964cb9bbc9b974cf445d84',NULL,'externalSubjectInviteAttrDef','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef','F','F','d5248b39d72f4fdcb730d1be03de4fbc','string','F','F','F','F','F','F','F','F','F','F','F','T',10002),('F','limit','4a97bd0cc2b4401b97dda3d406b22cd4',1459816164074,'65947ffd4e364921a42c465d94a78c09',1,1459816164131,'c4777fa00d2e4f7aabc2184cf6023770',NULL,'limitsDefMarker','etc:attribute:permissionLimits:limitsDefMarker','T','F','b6bc2fcd772146ee970347e496538926','marker','T','F','T','T','T','T','F','F','F','F','F','F',10007),('F','type','789e4fc65110427582f443bccc7ed464',1459816162325,'65947ffd4e364921a42c465d94a78c09',1,1459816162386,'da7ae804604741feb591dd47b6f352be',NULL,'rulesTypeDef','etc:attribute:rules:rulesTypeDef','T','F','fc88a71ee4574ae7b0a550d72b5172d9','marker','T','F','F','F','T','F','F','F','F','F','T','F',10003),('F','limit','b772e0a603f34d7e8aa592f9fcaefd2f',1459816163707,'65947ffd4e364921a42c465d94a78c09',1,1459816163762,'dd528f792dd544938a2588848992e909',NULL,'limitsDef','etc:attribute:permissionLimits:limitsDef','T','F','b6bc2fcd772146ee970347e496538926','string','T','F','T','T','T','T','F','F','F','F','F','F',10005);
/*!40000 ALTER TABLE `grouper_attribute_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_attribute_def_name`
--

DROP TABLE IF EXISTS `grouper_attribute_def_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attribute_def_name` (
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `description` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8_bin NOT NULL,
  `name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_def_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `display_extension` varchar(128) COLLATE utf8_bin NOT NULL,
  `display_name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `id_index` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attr_def_name_id_index_idx` (`id_index`),
  UNIQUE KEY `attribute_def_name_name_idx` (`name`(255)),
  KEY `fk_attr_def_name_stem` (`stem_id`),
  KEY `fk_attr_def_name_def_id` (`attribute_def_id`),
  CONSTRAINT `fk_attr_def_name_def_id` FOREIGN KEY (`attribute_def_id`) REFERENCES `grouper_attribute_def` (`id`),
  CONSTRAINT `fk_attr_def_name_stem` FOREIGN KEY (`stem_id`) REFERENCES `grouper_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attribute_def_name`
--

LOCK TABLES `grouper_attribute_def_name` WRITE;
/*!40000 ALTER TABLE `grouper_attribute_def_name` DISABLE KEYS */;
INSERT INTO `grouper_attribute_def_name` VALUES ('ef9019dfd0ab460dbf99255d2eb91f78',1459816162682,1,1459816162704,'012b580866d74696a897403090f19239','subject source id to act as','ruleActAsSubjectSourceId','etc:attribute:rules:ruleActAsSubjectSourceId','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleActAsSubjectSourceId','etc:attribute:rules:ruleActAsSubjectSourceId',10013),('fe42467861024f97be880cd17c509fb1',1459816163365,1,1459816163388,'053cf760d670452caa0f5c5f588639a1','RuleThenEnum argument 0 to run when the rule fires (enum might need args)','ruleThenEnumArg0','etc:attribute:rules:ruleThenEnumArg0','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleThenEnumArg0','etc:attribute:rules:ruleThenEnumArg0',10029),('9b30d4ba08074e2191ff8bd06c074157',1459816166393,1,1459816166420,'07ab972cc5c0444d805e096596685432','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','grouperLoaderLdapPriority','etc:attribute:loaderLdap:grouperLoaderLdapPriority','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP scheduling priority','etc:attribute:loaderLdap:Grouper loader LDAP scheduling priority',10064),('a1c53a00cab74c4b99c889a175269101',1459816162891,1,1459816162917,'08468c13269a4236921d4b33d272bffb','when the check is a stem type, this is Stem.Scope ALL or SUB','ruleCheckStemScope','etc:attribute:rules:ruleCheckStemScope','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleCheckStemScope','etc:attribute:rules:ruleCheckStemScope',10017),('b5c5bac0e4644e918c0f400274a9c7c3',1459816166129,1,1459816166147,'0c5ed4a5aa354da6a527f811cd77f455','LDAP filter returns objects that have subjectIds or subjectIdentifiers and group name (if LDAP_GROUP_LIST)','grouperLoaderLdapFilter','etc:attribute:loaderLdap:grouperLoaderLdapFilter','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP filter','etc:attribute:loaderLdap:Grouper loader LDAP filter',10056),('384e7f3803dd4e88a3d979c0dbb3f97d',1459816168196,1,1459816168206,'0e8f891baffa4efb8c503f893937ed72','This overrides the subjectId of the entity','entitySubjectIdentifier','etc:attribute:entities:entitySubjectIdentifier','2eee186e51494f0a874fe61ff24b7192','98e846065291427bb67c498d8e70d8ec','entitySubjectIdentifier','etc:attribute:entities:entitySubjectIdentifier',10095),('e72f8e885d3b4c0799b5394134dced69',1459816163524,1,1459816163558,'0f9eb01722f5496d9aae62e828406837','T|F for if this rule is valid, or the reason, managed by hook automatically','ruleValid','etc:attribute:rules:ruleValid','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleValid','etc:attribute:rules:ruleValid',10032),('53353083cd3e4d82a586202045271442',1459816163341,1,1459816163354,'12dbd6f81fbc403e857ea8171ec087ee','RuleThenEnum to run when the rule fires','ruleThenEnum','etc:attribute:rules:ruleThenEnum','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleThenEnum','etc:attribute:rules:ruleThenEnum',10028),('3660dbcf1bf54570a27f8749eef1268d',1459816167437,1,1459816167455,'14088a5dcafc4c22870e9cb6f65f3998','Marks a group that has memberships which have attributes for user data','grouperUserData','etc:attribute:userData:grouperUserData','cb1bfad6c8ed424d902b65d9ec275df0','a9cce636abf44507876f639467f74174','Grouper user data','etc:attribute:userData:Grouper user data',10083),('8cb63a2bb2e44db2a79e928ce5ea7d3b',1459816166847,1,1459816166868,'1781bc622c7249029c32125733195f5e','JEXL expression language fragment that processes the subject string before passing it to the subject API (optional)','grouperLoaderLdapSubjectExpression','etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP subject expression','etc:attribute:loaderLdap:Grouper loader LDAP subject expression',10073),('23e831bdeb7e411bbd2b4313ec2813d2',1459816167639,1,1459816167660,'199926a8d27b4b079b07b5be2b1c6b8a','A list of group ids and metadata in json format that are the favorites for a user','grouperUserDataFavoriteGroups','etc:attribute:userData:grouperUserDataFavoriteGroups','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data favorite groups','etc:attribute:userData:Grouper user data favorite groups',10084),('029893a4cadc4eb78bf80e21516ace97',1459816163455,1,1459816163506,'1a1c5f5bf5064e5fbfc30d723a93ac35','RuleThenEnum argument 2 to run when the rule fires (enum might need args)','ruleThenEnumArg2','etc:attribute:rules:ruleThenEnumArg2','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleThenEnumArg2','etc:attribute:rules:ruleThenEnumArg2',10031),('fc0fb6d81b5647198e48d10e179402d0',1459816164605,1,1459816164633,'1c1293934a904003a4adcfdcafe4fd88','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','attributeLoaderPriority','etc:attribute:attrLoader:attributeLoaderPriority','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderPriority','etc:attribute:attrLoader:attributeLoaderPriority',10047),('1d659db0efdb4062a2192fefbe41f70b',1459816161941,1,1459816161973,'1e49b63b42bf443c93cd5119e5bc745a','email address this invite was sent to','externalSubjectEmailAddress','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectEmailAddress','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress',10004),('3740610bf1a74673bec8d40e5466184c',1459816164436,1,1459816164452,'1e858851f5a04d5d957d4ca242c3a520','Type of schedule.  Defaults to CRON if a cron schedule is entered, or START_TO_START_INTERVAL if an interval is entered','attributeLoaderScheduleType','etc:attribute:attrLoader:attributeLoaderScheduleType','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderScheduleType','etc:attribute:attrLoader:attributeLoaderScheduleType',10044),('fe34fa3bb2d845b087281d5d90bf8368',1459816166568,1,1459816166584,'20fc61b7fc8e4e889d1ce95b4d899cd1','JEXL expression that returns true or false to signify if an attribute (in GROUPS_FROM_ATTRIBUTES) is ok to use for a group.  attributeValue is the variable that is the value of the attribute.','grouperLoaderLdapAttributeFilterExpression','etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP attribute filter expression','etc:attribute:loaderLdap:Grouper loader LDAP attribute filter expression',10067),('904c09b6b5794498bda9fd1c64cd2198',1459816162215,1,1459816162227,'216aa4131e1e4233bdb1170ea3e2959a','email sent to user as invite','externalSubjectInviteEmail','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteEmail','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail',10009),('b94b0ff3f39140068fe1a54f64413594',1459816166355,1,1459816166374,'2699a3d8d58644c395293106c83b0695','How the deep in the subtree the search will take place.  Can be OBJECT_SCOPE, ONELEVEL_SCOPE, or SUBTREE_SCOPE (default)','grouperLoaderLdapSearchScope','etc:attribute:loaderLdap:grouperLoaderLdapSearchScope','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP search scope','etc:attribute:loaderLdap:Grouper loader LDAP search scope',10063),('6017ad626c1145609452065385b405d6',1459816167715,1,1459816167737,'276e5329b7a44fe396a3de5a951596ea','A list of group ids and metadata in json format that are the recently used groups for a user','grouperUserDataRecentGroups','etc:attribute:userData:grouperUserDataRecentGroups','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data recent groups','etc:attribute:userData:Grouper user data recent groups',10086),('6930ebdfd50a443593fd420d34f9fc74',1459816168691,0,1459816168691,'2834e8c199de44eda7c2f74c83c895d2',NULL,'legacyAttribute_grouperLoaderQuartzCron','etc:legacy:attribute:legacyAttribute_grouperLoaderQuartzCron','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderQuartzCron','etc:legacy:attribute:legacyAttribute_grouperLoaderQuartzCron',10101),('07aaefb56552435db6413591c2a0186e',1459816162724,1,1459816162748,'28a96a63bd374b03b076ce1615d6e954','when the check should be to see if rule should fire, enum: RuleCheckType','ruleCheckType','etc:attribute:rules:ruleCheckType','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleCheckType','etc:attribute:rules:ruleCheckType',10014),('189f028eb1c6410eaa9305f20ab29064',1459816168648,0,1459816168648,'2a6d00b79fe24950a14169967d9ae050',NULL,'legacyAttribute_grouperLoaderDbName','etc:legacy:attribute:legacyAttribute_grouperLoaderDbName','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderDbName','etc:legacy:attribute:legacyAttribute_grouperLoaderDbName',10098),('cff229a117bb426d94c1f4783b055920',1459816166030,1,1459816166108,'2b3af83bf1fe4868a942eb5c4b118685','Server ID that is configured in the grouper-loader.properties that identifies the connection information to the LDAP server','grouperLoaderLdapServerId','etc:attribute:loaderLdap:grouperLoaderLdapServerId','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP server ID','etc:attribute:loaderLdap:Grouper loader LDAP server ID',10055),('74973c00475442e7a7eb279b0d0b2795',1459816163806,1,1459816163822,'2bb97b35188345d69f54e9bbf2008553','An expression language limit has a value of an EL which evaluates to true or false','limitExpression','etc:attribute:permissionLimits:limitExpression','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','Expression','etc:attribute:permissionLimits:Expression',10034),('ff5c7720e0ae4e6c87e47618cacba8df',1459816163107,1,1459816163133,'2ce2cdca4b0040768a64021a88e8793c','expression language to run to see if the rule should run, or blank if should run always','ruleIfConditionEl','etc:attribute:rules:ruleIfConditionEl','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfConditionEl','etc:attribute:rules:ruleIfConditionEl',10022),('f4e8d347885d469aa092de93a557a2e2',1459816167675,1,1459816167695,'2ecf3496f4524f52b0001c4556b9ff80','A list of member ids and metadata in json format that are the favorites for a user','grouperUserDataFavoriteSubjects','etc:attribute:userData:grouperUserDataFavoriteSubjects','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data favorite subjects','etc:attribute:userData:Grouper user data favorite subjects',10085),('2013dba4ecb940b8bb5845e351ed4779',1459816167182,1,1459816167205,'2fa06802299b49d4b186fa96c52a077e','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_READ on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapGroupAttrReaders','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group attribute readers','etc:attribute:loaderLdap:Grouper loader LDAP group attribute readers',10081),('a87d5bef3f8b45a08c8c1853907a5f95',1459816168702,0,1459816168702,'31c7b8e6fc2048e884bd3facdc94e6de',NULL,'legacyAttribute_grouperLoaderIntervalSeconds','etc:legacy:attribute:legacyAttribute_grouperLoaderIntervalSeconds','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderIntervalSeconds','etc:legacy:attribute:legacyAttribute_grouperLoaderIntervalSeconds',10102),('c659c4ad06254a69ad2cb49f19fc4478',1459816166202,1,1459816166225,'32b726ca079d423cbb80130baee2e731','Location that constrains the subtree where the filter is applicable','grouperLoaderLdapSearchDn','etc:attribute:loaderLdap:grouperLoaderLdapSearchDn','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP search base DN','etc:attribute:loaderLdap:Grouper loader LDAP search base DN',10058),('ec4c66e9bdfe4206a088599b05bd9f08',1459816164821,1,1459816165018,'34f83b00843e4d8a914d6c32aa82510a','SQL query with at least the following column: action_name','attributeLoaderActionQuery','etc:attribute:attrLoader:attributeLoaderActionQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderActionQuery','etc:attribute:attrLoader:attributeLoaderActionQuery',10051),('d992665496bd470f9d047184e8caf337',1459816162108,1,1459816162135,'35113e2566d843338966edd60c435059','unique id in the email sent to the user','externalSubjectInviteUuid','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteUuid','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid',10007),('1bba4c47a615420fad39fb10d2af701a',1459816166748,1,1459816166773,'39cfeba33b784b2da20a99fb80f674d7','JEXL expression language fragment that evaluates to the group display name, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapGroupDisplayNameExpression','etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group display name expression','etc:attribute:loaderLdap:Grouper loader LDAP group display name expression',10071),('c00b64b63223480c8d991379caad5657',1459816166161,1,1459816166184,'3abd9f032c2c42318cd5e5e014c27a69','Quartz cron config string, e.g. every day at 8am is: 0 0 8 * * ?','grouperLoaderLdapQuartzCron','etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP quartz cron','etc:attribute:loaderLdap:Grouper loader LDAP quartz cron',10057),('323915da7e4745938a43442acdd43afa',1459816164764,1,1459816164804,'3bce1c3e4f76410c95ffa832ca202cbc','SQL query with at least the following columns: if_has_attr_name, then_has_attr_name','attributeLoaderAttrSetQuery','etc:attribute:attrLoader:attributeLoaderAttrSetQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderAttrSetQuery','etc:attribute:attrLoader:attributeLoaderAttrSetQuery',10050),('cc4092f92f8648ad88febca2803b5852',1459816165894,1,1459816165912,'3d4e0066247c4a8d806fd0465fa19264','Marks a group to be processed by the Grouper loader as an LDAP synced job','grouperLoaderLdap','etc:attribute:loaderLdap:grouperLoaderLdap','094308af1376466687416c49f1f6495f','19faf0fca06b4aeb8a5cce52382a3f0e','Grouper loader LDAP','etc:attribute:loaderLdap:Grouper loader LDAP',10053),('7dfd6f20794b4a5a8fdd969a44ed54f8',1459816162949,1,1459816162968,'4120ee09ca1d457b81744f71c1a0640a','when the check needs an arg, this is the arg0','ruleCheckArg0','etc:attribute:rules:ruleCheckArg0','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleCheckArg0','etc:attribute:rules:ruleCheckArg0',10018),('d3d7268b43794299808770f320638d6f',1459816166236,1,1459816166249,'44116f0e5923417fb0b3b660db88604b','Attribute name of the filter object result that holds the subject id.  Note, if you use \'dn\', and dn is not an attribute of the object, then the fully qualified object name will be used','grouperLoaderLdapSubjectAttribute','etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP subject attribute name','etc:attribute:loaderLdap:Grouper loader LDAP subject attribute name',10059),('e122a3becbfc47319f96990431825ec1',1459816167871,1,1459816167890,'4477e4a117514f2e900f7aff92c808ab','A list of attribute definition name ids and metadata in json format that are the recently used attribute definition names for a user','grouperUserDataRecentAttributeDefNames','etc:attribute:userData:grouperUserDataRecentAttributeDefNames','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data recent attribute definition names','etc:attribute:userData:Grouper user data recent attribute definition names',10090),('58e4bd301a9c4bbc856cf119801fa4ec',1459816166938,1,1459816166959,'45dd837ceb804d058a8701b473d00060','Comma separated subjectIds or subjectIdentifiers who will be allowed to READ the group membership.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapReaders','etc:attribute:loaderLdap:grouperLoaderLdapReaders','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group readers','etc:attribute:loaderLdap:Grouper loader LDAP group readers',10075),('0b7c9f116c6e460ea09a2fa20c0aebe6',1459816164470,1,1459816164522,'48190ef247ff41129988f08177726deb','If a CRON schedule type, this is the cron setting string from the quartz product to run a job daily, hourly, weekly, etc.  e.g. daily at 7am: 0 0 7 * * ?','attributeLoaderQuartzCron','etc:attribute:attrLoader:attributeLoaderQuartzCron','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderQuartzCron','etc:attribute:attrLoader:attributeLoaderQuartzCron',10045),('0468297809164a0dba777a0bd51761a4',1459816168759,0,1459816168759,'4bcf2e18aa6a4dfe9f75743111a1ae59',NULL,'legacyAttribute_grouperLoaderGroupTypes','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupTypes','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderGroupTypes','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupTypes',10105),('42fe5930327e41b3a115ce9012e5c2f9',1459816163298,1,1459816163321,'4d09c98da01e4d5389b4cee05c54fc19','expression language to run when the rule fires','ruleThenEl','etc:attribute:rules:ruleThenEl','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleThenEl','etc:attribute:rules:ruleThenEl',10027),('71be3c3a1ed7438fa03a9f603684b57d',1459816167143,1,1459816167170,'50c66205af3e4df1ae709ffcb9d33670','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT OUT of the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapOptouts','etc:attribute:loaderLdap:grouperLoaderLdapOptouts','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group optouts','etc:attribute:loaderLdap:Grouper loader LDAP group optouts',10080),('94d12e4826a44bb99a5060ddf560e544',1459816162399,1,1459816162413,'529d4487e5ed4a27b594fcdfb79bc439','is a rule','rule','etc:attribute:rules:rule','fc88a71ee4574ae7b0a550d72b5172d9','da7ae804604741feb591dd47b6f352be','rule','etc:attribute:rules:rule',10010),('ab69e171a3f94d74a462971922597b26',1459816167216,1,1459816167244,'5618f29e9f694d8da566f2ddaec01283','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_UPDATE on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapGroupAttrUpdaters','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group attribute updaters','etc:attribute:loaderLdap:Grouper loader LDAP group attribute updaters',10082),('431e2c4c3afa4fdebb2bcf81fbaff710',1459816161601,1,1459816161635,'56f40c1d055147e78669a1be50159c53','is an invite','externalSubjectInvite','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite','d5248b39d72f4fdcb730d1be03de4fbc','1f60e0aa563e441e86b646c79c66b6ff','externalSubjectInvite','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite',10000),('a02fbcaf641146609d471715e06b953a',1459816164383,1,1459816164399,'582bfa600ca340aebed67753e38a430d','Type of loader, e.g. ATTR_SQL_SIMPLE','attributeLoaderType','etc:attribute:attrLoader:attributeLoaderType','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderType','etc:attribute:attrLoader:attributeLoaderType',10042),('6c394b97dd7d4bb19f67fab033a9f2b6',1459816163573,1,1459816163616,'596537a994fe4969afb8b5b96f95a58e','T|F for if this rule daemon should run.  Default to true if blank and check and if are enums, false if not','ruleRunDaemon','etc:attribute:rules:ruleRunDaemon','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleRunDaemon','etc:attribute:rules:ruleRunDaemon',10033),('a089b5773113477798959c7c989c1670',1459816163046,1,1459816163079,'59a31621ed494f5e95710f2e44d45fdd','when the if part has an arg, this is owner of if, mutually exclusive with id','ruleIfOwnerName','etc:attribute:rules:ruleIfOwnerName','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfOwnerName','etc:attribute:rules:ruleIfOwnerName',10021),('60e1e6d55f3d4a9f85f17b789e64ed61',1459816163229,1,1459816163255,'5a2f5f08fbae41ff962d5142296866db','RuleIfConditionEnumArg1 if the if condition takes an argument, this is the second param','ruleIfConditionEnumArg1','etc:attribute:rules:ruleIfConditionEnumArg1','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfConditionEnumArg1','etc:attribute:rules:ruleIfConditionEnumArg1',10025),('791d5b11d1b947d1b7fbe63c8f7b60a0',1459816162635,1,1459816162663,'5cbfd85dfd054f3bb9ef6fab9d7db699','subject identifier to act as, mutually exclusive with id','ruleActAsSubjectIdentifier','etc:attribute:rules:ruleActAsSubjectIdentifier','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleActAsSubjectIdentifier','etc:attribute:rules:ruleActAsSubjectIdentifier',10012),('50f7eb6957804887bb1d70ad5359ce86',1459816168671,0,1459816168671,'5cebc34e1bdc49e1a3c616ec88c7ff7a',NULL,'legacyAttribute_grouperLoaderQuery','etc:legacy:attribute:legacyAttribute_grouperLoaderQuery','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderQuery','etc:legacy:attribute:legacyAttribute_grouperLoaderQuery',10100),('f8b45e1449bb4724ba6587b77b839dbd',1459816168791,0,1459816168791,'5e1c7a2dd9624015ad99837e5da79163',NULL,'legacyAttribute_grouperLoaderGroupQuery','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupQuery','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderGroupQuery','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupQuery',10107),('a4179ff316784682889dcbbeb5a19457',1459816164668,1,1459816164694,'60961ff002334628a502d78685638144','If empty, then orphans will be left alone (for attributeDefName and attributeDefNameSets).  If %, then all orphans deleted.  If a SQL like string, then only ones in that like string not in loader will be deleted','attributeLoaderAttrsLike','etc:attribute:attrLoader:attributeLoaderAttrsLike','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderAttrsLike','etc:attribute:attrLoader:attributeLoaderAttrsLike',10048),('9d90748df5764171beb921e16a331ebb',1459816166501,1,1459816166547,'644299b01bb54802ae883050a29f0a80','Attribute name of the filter object result that holds the group name (required for loader ldap type: LDAP_GROUPS_FROM_ATTRIBUTE)','grouperLoaderLdapGroupAttribute','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group attribute name','etc:attribute:loaderLdap:Grouper loader LDAP group attribute name',10066),('3b04114215324e6289c1c9be422e7e6c',1459816166291,1,1459816166309,'6a4bdf524d1242aabb6a2765da61655e','The type of subject ID.  This can be either: subjectId (most efficient), subjectIdentifier (2nd most efficient), or subjectIdOrIdentifier','grouperLoaderLdapSubjectIdType','etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP subject ID type','etc:attribute:loaderLdap:Grouper loader LDAP subject ID type',10061),('c66f39bfe9ca40278b54b0cac21c8159',1459816161891,1,1459816161916,'6b906f0d952b4c12a57c4b71d2e81001','number of millis since 1970 that this invite was issued','externalSubjectInviteDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate',10003),('77176320181c4d7b91ea95a91d490c63',1459816168774,0,1459816168774,'6ef48c395597459d9810bf0aac859903',NULL,'legacyAttribute_grouperLoaderGroupsLike','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupsLike','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderGroupsLike','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupsLike',10106),('99ec6323827447ebb566a0adbdada197',1459816168508,0,1459816168508,'704fbc4dc6da4a52afa502200ffd05ff',NULL,'legacyGroupType_grouperLoader','etc:legacy:attribute:legacyGroupType_grouperLoader','36792aa7956240feb1bb6025c56ff2f3','3e4973476a6e4351a925503a921ad728','legacyGroupType_grouperLoader','etc:legacy:attribute:legacyGroupType_grouperLoader',10096),('d5c17c61ca1f454ea5dd8cf0d914a1a6',1459816163860,1,1459816163873,'7135e07d5e314776b1e17833aee62ea4','If the user is on an IP address on a centrally configured list of addresses','limitIpOnNetworkRealm','etc:attribute:permissionLimits:limitIpOnNetworkRealm','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','ipAddress on network realm','etc:attribute:permissionLimits:ipAddress on network realm',10036),('0ffd3275e8ed4b5294a539897e8031e4',1459816164410,1,1459816164427,'72ed919fa87448f6895ebdcdbc2ba25e','DB name in grouper-loader.properties or default grouper db if blank','attributeLoaderDbName','etc:attribute:attrLoader:attributeLoaderDbName','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderDbName','etc:attribute:attrLoader:attributeLoaderDbName',10043),('fc5de2f0793c48fb8629387d1b83dc7f',1459816163268,1,1459816163287,'730af7d2426945eca3bb0e3015aff089','when the if part is a stem, this is the scope of SUB or ONE','ruleIfStemScope','etc:attribute:rules:ruleIfStemScope','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfStemScope','etc:attribute:rules:ruleIfStemScope',10026),('2cc6ded34620449ebfc62035db08309b',1459816162587,1,1459816162614,'74166e5b8b8b4662afc4497c52faf6bc','subject id to act as, mutually exclusive with identifier','ruleActAsSubjectId','etc:attribute:rules:ruleActAsSubjectId','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleActAsSubjectId','etc:attribute:rules:ruleActAsSubjectId',10011),('960473ac0a764e3db73be6b4a8434b0c',1459816168724,0,1459816168724,'78a353168b3d4cf7bf9d0b299aaf113e',NULL,'legacyAttribute_grouperLoaderPriority','etc:legacy:attribute:legacyAttribute_grouperLoaderPriority','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderPriority','etc:legacy:attribute:legacyAttribute_grouperLoaderPriority',10103),('bd01e198ce9f4a5cb5c50219e7106d60',1459816166801,1,1459816166822,'79d043c3041d4d0db005a220dc5a438d','JEXL expression language fragment that evaluates to the group description, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapGroupDescriptionExpression','etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group description expression','etc:attribute:loaderLdap:Grouper loader LDAP group description expression',10072),('7e814238d3b94d5bb9f173d1a74b4a14',1459816167757,1,1459816167775,'7a9a1f6bccf84dda9159b82838440c01','A list of folder ids and metadata in json format that are the favorites for a user','grouperUserDataFavoriteStems','etc:attribute:userData:grouperUserDataFavoriteStems','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data favorite folders','etc:attribute:userData:Grouper user data favorite folders',10087),('f3a8ad5c473a43628bd988c1cd56e847',1459816163833,1,1459816163849,'7c393699d849478cbb26a265ee746b75','If the user is on an IP address on the following networks','limitIpOnNetworks','etc:attribute:permissionLimits:limitIpOnNetworks','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','ipAddress on networks','etc:attribute:permissionLimits:ipAddress on networks',10035),('5865a9434f884892b851fe4b285c6157',1459816166609,1,1459816166635,'7eb0914e4b5747d3abae2b5ad8edf19b','Attribute names (comma separated) to get LDAP data for expressions in group name, displayExtension, description, optional, for LDAP_GROUP_LIST','grouperLoaderLdapExtraAttributes','etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP extra attributes','etc:attribute:loaderLdap:Grouper loader LDAP extra attributes',10068),('f3e8aedc2caf466eb1a9c0ccb5be5ee6',1459816166440,1,1459816166477,'805535775c484f7fbedfaa6ec1837ee7','This should be a sql like string (e.g. school:orgs:%org%_systemOfRecord), and the loader should be able to query group names to see which names are managed by this loader job.  So if a group falls off the loader resultset (or is moved), this will help the loader remove the members from this group.  Note, if the group is used anywhere as a member or composite member, it wont be removed.  All include/exclude/requireGroups will be removed.  Though the two groups, include and exclude, will not be removed if they have members.  There is a grouper-loader.properties setting to remove loader groups if empty and not used: #if using a sql table, and specifying the name like string, then shoudl the group (in addition to memberships)# be removed if not used anywhere else?loader.sqlTable.likeString.removeGroupIfNotUsed = true','grouperLoaderLdapGroupsLike','etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP groups like','etc:attribute:loaderLdap:Grouper loader LDAP groups like',10065),('a9ce735961814d169110b4d97cbdf113',1459816166704,1,1459816166722,'8088e8e830e24be2beded12f94412c79','JEXL expression language fragment that evaluates to the group name (relative in the stem as the group which has the loader definition), optional, for LDAP_GROUP_LIST, or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapGroupNameExpression','etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group name expression','etc:attribute:loaderLdap:Grouper loader LDAP group name expression',10070),('b95da9343fb2492ebaa7fb1d3a7c32ca',1459816162051,1,1459816162083,'855fd99c277c4e069e0ffa2b052d89d3','member id who invited this user','externalSubjectInviteMemberId','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteMemberId','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId',10006),('cd4905a68628431e9c59eaee354a6cf4',1459816165109,1,1459816165365,'8e84b513b4e948b99127d0fa84a53e78','SQL query with at least the following columns: if_has_action_name, then_has_action_name','attributeLoaderActionSetQuery','etc:attribute:attrLoader:attributeLoaderActionSetQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderActionSetQuery','etc:attribute:attrLoader:attributeLoaderActionSetQuery',10052),('2096c96bf5e14bbba9debadd18df822e',1459816162155,1,1459816162183,'93bac907e57542689a532f2ae14f9cab','email addresses to notify when the user registers','externalSubjectInviteEmailWhenRegistered','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteEmailWhenRegistered','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered',10008),('c42bfd30649c46cbacc3d770596da778',1459816164049,1,1459816164059,'9738db9ed5c645f4a395c0ce24dba834','Make sure the amount is less or equal to the configured value','limitAmountLessThanOrEqual','etc:attribute:permissionLimits:limitAmountLessThanOrEqual','b6bc2fcd772146ee970347e496538926','2a9bd9fd21e34e56aca2c3f93bb68928','amount less than or equal to','etc:attribute:permissionLimits:amount less than or equal to',10039),('e632b008151641b38395597648dff2af',1459816162766,1,1459816162794,'a26523b21e2f4e12bc93828349147061','when the check should be to see if rule should fire, this is owner of type, mutually exclusive with name','ruleCheckOwnerId','etc:attribute:rules:ruleCheckOwnerId','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleCheckOwnerId','etc:attribute:rules:ruleCheckOwnerId',10015),('3e63894cf9fb4395ba9160b5e820aea8',1459816162824,1,1459816162869,'a2d29ed3ef434d4aaf2d865a1179159f','when the check should be to see if rule should fire, this is owner of type, mutually exclusice with id','ruleCheckOwnerName','etc:attribute:rules:ruleCheckOwnerName','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleCheckOwnerName','etc:attribute:rules:ruleCheckOwnerName',10016),('7c7d8dbf4f8345da8ac3a657ff3d83be',1459816166980,1,1459816166998,'a45ebbb8c7d54fce9701361f8184197f','Comma separated subjectIds or subjectIdentifiers who will be allowed to VIEW the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapViewers','etc:attribute:loaderLdap:grouperLoaderLdapViewers','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group viewers','etc:attribute:loaderLdap:Grouper loader LDAP group viewers',10076),('73bd88d6231d4b5095c2ea5391619e3a',1459816168662,0,1459816168662,'a4cacb8e06cc4ad7bafc48491a68da70',NULL,'legacyAttribute_grouperLoaderScheduleType','etc:legacy:attribute:legacyAttribute_grouperLoaderScheduleType','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderScheduleType','etc:legacy:attribute:legacyAttribute_grouperLoaderScheduleType',10099),('8bb0132d8ae74ea8b6b83cb2402e59d6',1459816167099,1,1459816167125,'a58dc65ff39649cfaf72aa3389e1e9e8','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT IN to the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapOptins','etc:attribute:loaderLdap:grouperLoaderLdapOptins','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group optins','etc:attribute:loaderLdap:Grouper loader LDAP group optins',10079),('7af691a1d7cb4ee29a2edf3fdfad9c9e',1459816167829,1,1459816167855,'b09cc09971d1458bb336aad641fdf526','A list of attribute definition ids and metadata in json format that are the recently used attribute definitions for a user','grouperUserDataRecentAttributeDefs','etc:attribute:userData:grouperUserDataRecentAttributeDefs','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data recent attribute definitions','etc:attribute:userData:Grouper user data recent attribute definitions',10089),('7314336d7419484cbebeb9e7695edead',1459816164293,1,1459816164306,'b1d07c0142ad43a7aa3d6a1a6e8fd0b4','is a loader based attribute def, the loader attributes will be available to be assigned','attributeLoader','etc:attribute:attrLoader:attributeLoader','6cd4d8196fe24d21acd51cdf8fcdb3cc','240c728c9e2c42ccb4bd63fae71d8b28','attributeLoader','etc:attribute:attrLoader:attributeLoader',10041),('a8a25cebf2064504b5ad098c41fe1501',1459816163883,1,1459816163894,'b5a9690f188547de9a59a995da25ddad','Configure a set of comma separated labels.  The env variable \'labels\' should be passed with comma separated labels.  If one is there, its ok, if not, then disallowed','limitLabelsContain','etc:attribute:permissionLimits:limitLabelsContain','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','labels contains','etc:attribute:permissionLimits:labels contains',10037),('6aaa31d5d19e434b90a39cbe959899a1',1459816164028,1,1459816164038,'bfdb438d9f03469fa76b4eab9d099384','Make sure the amount is less than the configured value','limitAmountLessThan','etc:attribute:permissionLimits:limitAmountLessThan','b6bc2fcd772146ee970347e496538926','2a9bd9fd21e34e56aca2c3f93bb68928','amount less than','etc:attribute:permissionLimits:amount less than',10038),('8e2f93f08eb049c5ba29684848c83e2b',1459816167993,1,1459816168019,'c3119a12e06041959f4c69b4078dc8f9','A list of attribute definition name ids and metadata in json format that are the favorites for a user','grouperUserDataFavoriteAttributeDefNames','etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data favorite attribute definition names','etc:attribute:userData:Grouper user data favorite attribute definition names',10093),('aed2bf6b78934ee9847a0b2b9e31d0d9',1459816166002,1,1459816166017,'c3d2e8d1b61b481a92b96a5c564e6d29','This holds the type of job from the GrouperLoaderType enum, currently the only valid values are LDAP_SIMPLE, LDAP_GROUP_LIST, LDAP_GROUPS_FROM_ATTRIBUTES. Simple is a group loaded from LDAP filter which returns subject ids or identifiers.  Group list is an LDAP filter which returns group objects, and the group objects have a list of subjects.  Groups from attributes is an LDAP filter that returns subjects which have a multi-valued attribute e.g. affiliations where groups will be created based on subject who have each attribute value  ','grouperLoaderLdapType','etc:attribute:loaderLdap:grouperLoaderLdapType','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP type','etc:attribute:loaderLdap:Grouper loader LDAP type',10054),('4cb3515cfc654061a5acb2a8a3610996',1459816164715,1,1459816164740,'c3d5cb11a5f446858470d00d7434020a','SQL query with at least some of the following columns: attr_name, attr_display_name, attr_description','attributeLoaderAttrQuery','etc:attribute:attrLoader:attributeLoaderAttrQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderAttrQuery','etc:attribute:attrLoader:attributeLoaderAttrQuery',10049),('6b7820c784f6420c9b089b2463a5fa77',1459816166658,1,1459816166678,'cc4950adff3147fd8b36fbe2fc1c2e12','Value could be true or false (default to true).  If true, then there will be an error if there are unresolvable subjects in the results.  If you know there are subjects in LDAP which are not resolvable by Grouper, set to false, they will be ignored','grouperLoaderLdapErrorUnresolvable','etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP error unresolvable','etc:attribute:loaderLdap:Grouper loader LDAP error unresolvable',10069),('f96e8621b55040e7a2b3ab894c54fcaf',1459816167019,1,1459816167042,'cd9d28020e3a447787049e087358a60b','Comma separated subjectIds or subjectIdentifiers who will be allowed to ADMIN the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapAdmins','etc:attribute:loaderLdap:grouperLoaderLdapAdmins','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group admins','etc:attribute:loaderLdap:Grouper loader LDAP group admins',10077),('e7c9b6bfc7cc48fd9e4411aa19379e17',1459816167063,1,1459816167079,'d0147000b33c4cfcaa524e135adb4f43','Comma separated subjectIds or subjectIdentifiers who will be allowed to UPDATE the group memberships.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapUpdaters','etc:attribute:loaderLdap:grouperLoaderLdapUpdaters','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group updaters','etc:attribute:loaderLdap:Grouper loader LDAP group updaters',10078),('64dfea509fd34cbc967b486f27f8be19',1459816167958,1,1459816167977,'d049ee88c5dd43b49ec896c7b4c804e3','A list of attribute definition ids and metadata in json format that are the favorites for a user','grouperUserDataFavoriteAttributeDefs','etc:attribute:userData:grouperUserDataFavoriteAttributeDefs','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data favorite attribute definitions','etc:attribute:userData:Grouper user data favorite attribute definitions',10092),('52bcf03aebcb4dfd9239d48df40cca2e',1459816166893,1,1459816166912,'d936518e709549ea942d07d26ecf45b9','Comma separated GroupTypes which will be applied to the loaded groups.  The reason this enhancement exists is so we can do a group list filter and attach addIncludeExclude to the groups.  Note, if you do this (or use some requireGroups), the group name in the loader query should end in the system of record suffix, which by default is _systemOfRecord. optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','grouperLoaderLdapGroupTypes','etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP group types','etc:attribute:loaderLdap:Grouper loader LDAP group types',10074),('df392c58418743d999e73103e5f90047',1459816166318,1,1459816166340,'db40a48a4ac943ac925a393858337d38','If you want to restrict membership in the dynamic group based on other group(s), put the list of group names here comma-separated.  The require groups means if you put a group names in there (e.g. school:community:employee) then it will \'and\' that group with the member list from the loader.  So only members of the group from the loader query who are also employees will be in the resulting group','grouperLoaderLdapAndGroups','etc:attribute:loaderLdap:grouperLoaderLdapAndGroups','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP require in groups','etc:attribute:loaderLdap:Grouper loader LDAP require in groups',10062),('8a2ebb9e8ecb43fa8c615bbc4046749a',1459816167905,1,1459816167939,'de2074da9cd64e9393d7638e135ce76c','A list of attribute member ids and metadata in json format that are the recently used subjects for a user','grouperUserDataRecentSubjects','etc:attribute:userData:grouperUserDataRecentSubjects','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data recent subjects','etc:attribute:userData:Grouper user data recent subjects',10091),('11af3ec686424b9cb0254bf82f62c5b2',1459816167796,1,1459816167815,'e0a40c9bef224ff3959d909777063368','A list of folder ids and metadata in json format that are the recently used folders for a user','grouperUserDataRecentStems','etc:attribute:userData:grouperUserDataRecentStems','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data recent folders','etc:attribute:userData:Grouper user data recent folders',10088),('550a2e3b9e1c477e9e2a360954940852',1459816168633,0,1459816168633,'e4f3627722644627a5a53e5afac59a27',NULL,'legacyAttribute_grouperLoaderType','etc:legacy:attribute:legacyAttribute_grouperLoaderType','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderType','etc:legacy:attribute:legacyAttribute_grouperLoaderType',10097),('325986d7900545049b13a0b966d3a24d',1459816161826,1,1459816161868,'e6638b1ff38c41b2a4a66d7de21295bc','number of millis since 1970 when this invite expires','externalSubjectInviteExpireDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteExpireDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate',10002),('4f4b9e2f768848f18b536c37418d3b1f',1459816164159,1,1459816164176,'edf4fcdbbff1447e8951e6e07a38c6e3','Make sure the check for the permission happens between 9am to 5pm on Monday through Friday','limitWeekday9to5','etc:attribute:permissionLimits:limitWeekday9to5','b6bc2fcd772146ee970347e496538926','c4777fa00d2e4f7aabc2184cf6023770','Weekday 9 to 5','etc:attribute:permissionLimits:Weekday 9 to 5',10040),('d7b19d36fcb74644b68ea985a3490a8b',1459816163190,1,1459816163212,'f0dd0e291abc44e792b1cf49af78d2c7','RuleIfConditionEnumArg0 if the if condition takes an argument, this is the first one','ruleIfConditionEnumArg0','etc:attribute:rules:ruleIfConditionEnumArg0','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfConditionEnumArg0','etc:attribute:rules:ruleIfConditionEnumArg0',10024),('4deddd2e1bbe4cc49ff7a7741f1682b7',1459816168034,1,1459816168055,'f3a4ba3f2ef441ec8834425942161c77','Preferences and metadata in json format for a user','grouperUserDataPreferences','etc:attribute:userData:grouperUserDataPreferences','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','Grouper user data preferences','etc:attribute:userData:Grouper user data preferences',10094),('82582d20b4c64d8fa72df227ead44184',1459816168738,0,1459816168738,'f3edb985d6e2480da4ad894eda3b620b',NULL,'legacyAttribute_grouperLoaderAndGroups','etc:legacy:attribute:legacyAttribute_grouperLoaderAndGroups','36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','legacyAttribute_grouperLoaderAndGroups','etc:legacy:attribute:legacyAttribute_grouperLoaderAndGroups',10104),('7cf35e369f80471ea98ae9de9cf27639',1459816163024,1,1459816163038,'f44cbb78b4594e0aa9ebb1d66bb1618a','when the if part has an arg, this is owner of if, mutually exclusive with name','ruleIfOwnerId','etc:attribute:rules:ruleIfOwnerId','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfOwnerId','etc:attribute:rules:ruleIfOwnerId',10020),('a2c9cd9112ab481897e3c2ba6b533215',1459816162007,1,1459816162029,'f5aac6d1a9f94ee3870a7b3b56ab9ade','comma separated group ids to assign this user to','externalSubjectInviteGroupUuids','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','externalSubjectInviteGroupUuids','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids',10005),('44b4aeb178064ef997c86953a8092c52',1459816162975,1,1459816163010,'f5bb3d26042d4494b2a4826a03a8b0a1','when the check needs an arg, this is the arg1','ruleCheckArg1','etc:attribute:rules:ruleCheckArg1','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleCheckArg1','etc:attribute:rules:ruleCheckArg1',10019),('2e0e8922e59f44ef87caab10780b7d60',1459816166263,1,1459816166281,'f867d93ca881408cb2191562a5b8cf36','Source ID from the sources.xml that narrows the search for subjects.  This is optional though makes the loader job more efficient','grouperLoaderLdapSourceId','etc:attribute:loaderLdap:grouperLoaderLdapSourceId','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','Grouper loader LDAP source ID','etc:attribute:loaderLdap:Grouper loader LDAP source ID',10060),('797aa8a62bd3486a88ad5dbb5afea214',1459816163404,1,1459816163433,'fa18c25e248e4ca0978c21ea2d6a17ef','RuleThenEnum argument 1 to run when the rule fires (enum might need args)','ruleThenEnumArg1','etc:attribute:rules:ruleThenEnumArg1','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleThenEnumArg1','etc:attribute:rules:ruleThenEnumArg1',10030),('90cac98d130b4553bfbb186f57b650e7',1459816163148,1,1459816163164,'fd1617992c834f03827ff8b836c38c8d','RuleIfConditionEnum that sees if rule should fire, or exclude if should run always','ruleIfConditionEnum','etc:attribute:rules:ruleIfConditionEnum','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','ruleIfConditionEnum','etc:attribute:rules:ruleIfConditionEnum',10023),('12c1032aef424fc79e6ba5b108343efa',1459816164546,1,1459816164580,'fed11b1fd8d342ff8ddb84cee7d94b1d','If a START_TO_START_INTERVAL schedule type, this is the number of seconds between runs','attributeLoaderIntervalSeconds','etc:attribute:attrLoader:attributeLoaderIntervalSeconds','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','attributeLoaderIntervalSeconds','etc:attribute:attrLoader:attributeLoaderIntervalSeconds',10046);
/*!40000 ALTER TABLE `grouper_attribute_def_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_attribute_def_name_set`
--

DROP TABLE IF EXISTS `grouper_attribute_def_name_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attribute_def_name_set` (
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `depth` bigint(20) NOT NULL,
  `if_has_attribute_def_name_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_attribute_def_name_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_attr_def_name_set_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attr_def_name_set_unq_idx` (`parent_attr_def_name_set_id`,`if_has_attribute_def_name_id`,`then_has_attribute_def_name_id`),
  KEY `attr_def_name_set_ifhas_idx` (`if_has_attribute_def_name_id`),
  KEY `attr_def_name_set_then_idx` (`then_has_attribute_def_name_id`),
  CONSTRAINT `fk_attr_def_name_if` FOREIGN KEY (`if_has_attribute_def_name_id`) REFERENCES `grouper_attribute_def_name` (`id`),
  CONSTRAINT `fk_attr_def_name_set_parent` FOREIGN KEY (`parent_attr_def_name_set_id`) REFERENCES `grouper_attribute_def_name_set` (`id`),
  CONSTRAINT `fk_attr_def_name_then` FOREIGN KEY (`then_has_attribute_def_name_id`) REFERENCES `grouper_attribute_def_name` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attribute_def_name_set`
--

LOCK TABLES `grouper_attribute_def_name_set` WRITE;
/*!40000 ALTER TABLE `grouper_attribute_def_name_set` DISABLE KEYS */;
INSERT INTO `grouper_attribute_def_name_set` VALUES (NULL,1459816164683,0,'01ad9bca975f48299cc9f1a1b5b11258',1459816164683,0,'60961ff002334628a502d78685638144','60961ff002334628a502d78685638144','01ad9bca975f48299cc9f1a1b5b11258','self'),(NULL,1459816162220,0,'02fc4078df3a489780b3e8c9a9c2c86b',1459816162220,0,'216aa4131e1e4233bdb1170ea3e2959a','216aa4131e1e4233bdb1170ea3e2959a','02fc4078df3a489780b3e8c9a9c2c86b','self'),(NULL,1459816161615,0,'038e8d3efb10424088a24ff03b8deada',1459816161615,0,'56f40c1d055147e78669a1be50159c53','56f40c1d055147e78669a1be50159c53','038e8d3efb10424088a24ff03b8deada','self'),(NULL,1459816162648,0,'050cacfbb8e345a5a052a12c864f4747',1459816162648,0,'5cbfd85dfd054f3bb9ef6fab9d7db699','5cbfd85dfd054f3bb9ef6fab9d7db699','050cacfbb8e345a5a052a12c864f4747','self'),(NULL,1459816168768,0,'0576b30833b14e1aa92215ab9c39a51d',1459816168768,0,'4bcf2e18aa6a4dfe9f75743111a1ae59','4bcf2e18aa6a4dfe9f75743111a1ae59','0576b30833b14e1aa92215ab9c39a51d','self'),(NULL,1459816163275,0,'0792a179c1034c15922fd72e2e364d1a',1459816163275,0,'730af7d2426945eca3bb0e3015aff089','730af7d2426945eca3bb0e3015aff089','0792a179c1034c15922fd72e2e364d1a','self'),(NULL,1459816168047,0,'0fdc3e441be743b8aaa720fcc0e15418',1459816168047,0,'f3a4ba3f2ef441ec8834425942161c77','f3a4ba3f2ef441ec8834425942161c77','0fdc3e441be743b8aaa720fcc0e15418','self'),(NULL,1459816162837,0,'12e9314ce94742e48359859ee176add2',1459816162837,0,'a2d29ed3ef434d4aaf2d865a1179159f','a2d29ed3ef434d4aaf2d865a1179159f','12e9314ce94742e48359859ee176add2','self'),(NULL,1459816168695,0,'15fea32d0ba5470286c42b1354684b6e',1459816168695,0,'2834e8c199de44eda7c2f74c83c895d2','2834e8c199de44eda7c2f74c83c895d2','15fea32d0ba5470286c42b1354684b6e','self'),(NULL,1459816162990,0,'18927b34acc649928d01021752bed65d',1459816162990,0,'f5bb3d26042d4494b2a4826a03a8b0a1','f5bb3d26042d4494b2a4826a03a8b0a1','18927b34acc649928d01021752bed65d','self'),(NULL,1459816168655,0,'190ca8317f2445eeb23c7ac475637206',1459816168655,0,'2a6d00b79fe24950a14169967d9ae050','2a6d00b79fe24950a14169967d9ae050','190ca8317f2445eeb23c7ac475637206','self'),(NULL,1459816162404,0,'1c9d3791c420488ba2fa967fb9f8729f',1459816162404,0,'529d4487e5ed4a27b594fcdfb79bc439','529d4487e5ed4a27b594fcdfb79bc439','1c9d3791c420488ba2fa967fb9f8729f','self'),(NULL,1459816163538,0,'1cc98c8fcfdf4778ad1423c89e40b346',1459816163538,0,'0f9eb01722f5496d9aae62e828406837','0f9eb01722f5496d9aae62e828406837','1cc98c8fcfdf4778ad1423c89e40b346','self'),(NULL,1459816166405,0,'1d375ac2e73c4dd1b65ec693b482d69e',1459816166405,0,'07ab972cc5c0444d805e096596685432','07ab972cc5c0444d805e096596685432','1d375ac2e73c4dd1b65ec693b482d69e','self'),(NULL,1459816164620,0,'1dfd98e0490d441085898f489083995c',1459816164620,0,'1c1293934a904003a4adcfdcafe4fd88','1c1293934a904003a4adcfdcafe4fd88','1dfd98e0490d441085898f489083995c','self'),(NULL,1459816167446,0,'1f48bb5a25f349ee9a62d20eb507a2fe',1459816167446,0,'14088a5dcafc4c22870e9cb6f65f3998','14088a5dcafc4c22870e9cb6f65f3998','1f48bb5a25f349ee9a62d20eb507a2fe','self'),(NULL,1459816162733,0,'20453a3445c3476285315b6604b796d2',1459816162733,0,'28a96a63bd374b03b076ce1615d6e954','28a96a63bd374b03b076ce1615d6e954','20453a3445c3476285315b6604b796d2','self'),(NULL,1459816166322,0,'2059a81aa6b04367818a453053aae77c',1459816166322,0,'db40a48a4ac943ac925a393858337d38','db40a48a4ac943ac925a393858337d38','2059a81aa6b04367818a453053aae77c','self'),(NULL,1459816164170,0,'24cb012e64ef4997ad6fd0345351781a',1459816164170,0,'edf4fcdbbff1447e8951e6e07a38c6e3','edf4fcdbbff1447e8951e6e07a38c6e3','24cb012e64ef4997ad6fd0345351781a','self'),(NULL,1459816165903,0,'24f3de7826694f86a645e73305555c88',1459816165903,0,'3d4e0066247c4a8d806fd0465fa19264','3d4e0066247c4a8d806fd0465fa19264','24f3de7826694f86a645e73305555c88','self'),(NULL,1459816166295,0,'25f29c45a20740519056c1dffa6c5373',1459816166295,0,'6a4bdf524d1242aabb6a2765da61655e','6a4bdf524d1242aabb6a2765da61655e','25f29c45a20740519056c1dffa6c5373','self'),(NULL,1459816164782,0,'269259823d3640a3bd6e31b34445b89b',1459816164782,0,'3bce1c3e4f76410c95ffa832ca202cbc','3bce1c3e4f76410c95ffa832ca202cbc','269259823d3640a3bd6e31b34445b89b','self'),(NULL,1459816167807,0,'2c798238446a4acca0bda187ee59aada',1459816167807,0,'e0a40c9bef224ff3959d909777063368','e0a40c9bef224ff3959d909777063368','2c798238446a4acca0bda187ee59aada','self'),(NULL,1459816168742,0,'305620dcad7248509b5d146f2038f78d',1459816168742,0,'f3edb985d6e2480da4ad894eda3b620b','f3edb985d6e2480da4ad894eda3b620b','305620dcad7248509b5d146f2038f78d','self'),(NULL,1459816164442,0,'30a9e769eb154a928e30e888413899ca',1459816164442,0,'1e858851f5a04d5d957d4ca242c3a520','1e858851f5a04d5d957d4ca242c3a520','30a9e769eb154a928e30e888413899ca','self'),(NULL,1459816166216,0,'32db5e71990044b7828367a79433a5bc',1459816166216,0,'32b726ca079d423cbb80130baee2e731','32b726ca079d423cbb80130baee2e731','32db5e71990044b7828367a79433a5bc','self'),(NULL,1459816167644,0,'3dc9864ba0184fe4bc2434dacd230531',1459816167644,0,'199926a8d27b4b079b07b5be2b1c6b8a','199926a8d27b4b079b07b5be2b1c6b8a','3dc9864ba0184fe4bc2434dacd230531','self'),(NULL,1459816168799,0,'405cfde80ce74919b398677283dca4b5',1459816168799,0,'5e1c7a2dd9624015ad99837e5da79163','5e1c7a2dd9624015ad99837e5da79163','405cfde80ce74919b398677283dca4b5','self'),(NULL,1459816168200,0,'449f6cf23f884d908c6ec3b3533760c7',1459816168200,0,'0e8f891baffa4efb8c503f893937ed72','0e8f891baffa4efb8c503f893937ed72','449f6cf23f884d908c6ec3b3533760c7','self'),(NULL,1459816166709,0,'4537ef8db140452b932051dde421ff20',1459816166709,0,'8088e8e830e24be2beded12f94412c79','8088e8e830e24be2beded12f94412c79','4537ef8db140452b932051dde421ff20','self'),(NULL,1459816166270,0,'46a4bcec29e843f4a9a7ca2b44e26e29',1459816166270,0,'f867d93ca881408cb2191562a5b8cf36','f867d93ca881408cb2191562a5b8cf36','46a4bcec29e843f4a9a7ca2b44e26e29','self'),(NULL,1459816166170,0,'474e86aa058a49a69a6d458502c45e3d',1459816166170,0,'3abd9f032c2c42318cd5e5e014c27a69','3abd9f032c2c42318cd5e5e014c27a69','474e86aa058a49a69a6d458502c45e3d','self'),(NULL,1459816166765,0,'475df68f6c3e419ca82188fd9bf3a1e0',1459816166765,0,'39cfeba33b784b2da20a99fb80f674d7','39cfeba33b784b2da20a99fb80f674d7','475df68f6c3e419ca82188fd9bf3a1e0','self'),(NULL,1459816165196,0,'486165c3b35b4759a17720dcc7ce74f2',1459816165196,0,'8e84b513b4e948b99127d0fa84a53e78','8e84b513b4e948b99127d0fa84a53e78','486165c3b35b4759a17720dcc7ce74f2','self'),(NULL,1459816162906,0,'4a99682a5f02494f9524de5aa090ca56',1459816162906,0,'08468c13269a4236921d4b33d272bffb','08468c13269a4236921d4b33d272bffb','4a99682a5f02494f9524de5aa090ca56','self'),(NULL,1459816167879,0,'4e05eea651e548129a1d342f95c81499',1459816167879,0,'4477e4a117514f2e900f7aff92c808ab','4477e4a117514f2e900f7aff92c808ab','4e05eea651e548129a1d342f95c81499','self'),(NULL,1459816161846,0,'4ed7db3a60a54e04afb1d6727fc60729',1459816161846,0,'e6638b1ff38c41b2a4a66d7de21295bc','e6638b1ff38c41b2a4a66d7de21295bc','4ed7db3a60a54e04afb1d6727fc60729','self'),(NULL,1459816168679,0,'4fa30d526d30419da22f18c0eb3cd455',1459816168679,0,'5cebc34e1bdc49e1a3c616ec88c7ff7a','5cebc34e1bdc49e1a3c616ec88c7ff7a','4fa30d526d30419da22f18c0eb3cd455','self'),(NULL,1459816164835,0,'514249443fdb478bb86cae4fc53647a0',1459816164835,0,'34f83b00843e4d8a914d6c32aa82510a','34f83b00843e4d8a914d6c32aa82510a','514249443fdb478bb86cae4fc53647a0','self'),(NULL,1459816167919,0,'514ea4ea128d4583ab18d1db88937757',1459816167919,0,'de2074da9cd64e9393d7638e135ce76c','de2074da9cd64e9393d7638e135ce76c','514ea4ea128d4583ab18d1db88937757','self'),(NULL,1459816166447,0,'528512692b394dd590342bce3389b960',1459816166447,0,'805535775c484f7fbedfaa6ec1837ee7','805535775c484f7fbedfaa6ec1837ee7','528512692b394dd590342bce3389b960','self'),(NULL,1459816163349,0,'52c4782b8fc946c7999cf534ada8b6d9',1459816163349,0,'12dbd6f81fbc403e857ea8171ec087ee','12dbd6f81fbc403e857ea8171ec087ee','52c4782b8fc946c7999cf534ada8b6d9','self'),(NULL,1459816166991,0,'565ecc23bd7449b0ba5e486dc8aba2d0',1459816166991,0,'a45ebbb8c7d54fce9701361f8184197f','a45ebbb8c7d54fce9701361f8184197f','565ecc23bd7449b0ba5e486dc8aba2d0','self'),(NULL,1459816167965,0,'59ba6c0a704d46e0b823165cebb966de',1459816167965,0,'d049ee88c5dd43b49ec896c7b4c804e3','d049ee88c5dd43b49ec896c7b4c804e3','59ba6c0a704d46e0b823165cebb966de','self'),(NULL,1459816163863,0,'59fcb5f8d10f444aa9a087144148d648',1459816163863,0,'7135e07d5e314776b1e17833aee62ea4','7135e07d5e314776b1e17833aee62ea4','59fcb5f8d10f444aa9a087144148d648','self'),(NULL,1459816162013,0,'5a0c81ec42cf420d8978c15d5fefbdc2',1459816162013,0,'f5aac6d1a9f94ee3870a7b3b56ab9ade','f5aac6d1a9f94ee3870a7b3b56ab9ade','5a0c81ec42cf420d8978c15d5fefbdc2','self'),(NULL,1459816167725,0,'5b24b379cac34078908139f9c85d0ee6',1459816167725,0,'276e5329b7a44fe396a3de5a951596ea','276e5329b7a44fe396a3de5a951596ea','5b24b379cac34078908139f9c85d0ee6','self'),(NULL,1459816166616,0,'5be496319df240ce8274a70f388877be',1459816166616,0,'7eb0914e4b5747d3abae2b5ad8edf19b','7eb0914e4b5747d3abae2b5ad8edf19b','5be496319df240ce8274a70f388877be','self'),(NULL,1459816161946,0,'5d42d8090fa94effbf9c75aadec1b410',1459816161946,0,'1e49b63b42bf443c93cd5119e5bc745a','1e49b63b42bf443c93cd5119e5bc745a','5d42d8090fa94effbf9c75aadec1b410','self'),(NULL,1459816163199,0,'62400899d90c442f9ab67e75508a836b',1459816163199,0,'f0dd0e291abc44e792b1cf49af78d2c7','f0dd0e291abc44e792b1cf49af78d2c7','62400899d90c442f9ab67e75508a836b','self'),(NULL,1459816164416,0,'67d025522fd14acb84a09a010eb85a1a',1459816164416,0,'72ed919fa87448f6895ebdcdbc2ba25e','72ed919fa87448f6895ebdcdbc2ba25e','67d025522fd14acb84a09a010eb85a1a','self'),(NULL,1459816166520,0,'6ba4a194287445ecbffe2f3c5d61488d',1459816166520,0,'644299b01bb54802ae883050a29f0a80','644299b01bb54802ae883050a29f0a80','6ba4a194287445ecbffe2f3c5d61488d','self'),(NULL,1459816168520,0,'6f42a11d83cd4f3198841a64862b6acd',1459816168520,0,'704fbc4dc6da4a52afa502200ffd05ff','704fbc4dc6da4a52afa502200ffd05ff','6f42a11d83cd4f3198841a64862b6acd','self'),(NULL,1459816163888,0,'6f4fd81fae83461c8810a211755bb73b',1459816163888,0,'b5a9690f188547de9a59a995da25ddad','b5a9690f188547de9a59a995da25ddad','6f4fd81fae83461c8810a211755bb73b','self'),(NULL,1459816166902,0,'6f5e417bcf8c485a8cde0a87d4160370',1459816166902,0,'d936518e709549ea942d07d26ecf45b9','d936518e709549ea942d07d26ecf45b9','6f5e417bcf8c485a8cde0a87d4160370','self'),(NULL,1459816166241,0,'736797f4b3784088af7ea66367a15549',1459816166241,0,'44116f0e5923417fb0b3b660db88604b','44116f0e5923417fb0b3b660db88604b','736797f4b3784088af7ea66367a15549','self'),(NULL,1459816167030,0,'7c5b4a93f49c4c419efc3cd36591a866',1459816167030,0,'cd9d28020e3a447787049e087358a60b','cd9d28020e3a447787049e087358a60b','7c5b4a93f49c4c419efc3cd36591a866','self'),(NULL,1459816167190,0,'800720c4339d4c50918731606c30e014',1459816167190,0,'2fa06802299b49d4b186fa96c52a077e','2fa06802299b49d4b186fa96c52a077e','800720c4339d4c50918731606c30e014','self'),(NULL,1459816164569,0,'8179202ea7f042079a7dfe8147754c80',1459816164569,0,'fed11b1fd8d342ff8ddb84cee7d94b1d','fed11b1fd8d342ff8ddb84cee7d94b1d','8179202ea7f042079a7dfe8147754c80','self'),(NULL,1459816167071,0,'85002815c2b04d0fbd2265cb05bcf363',1459816167071,0,'d0147000b33c4cfcaa524e135adb4f43','d0147000b33c4cfcaa524e135adb4f43','85002815c2b04d0fbd2265cb05bcf363','self'),(NULL,1459816167842,0,'8b6055ea200244fab9f4e95221cb319a',1459816167842,0,'b09cc09971d1458bb336aad641fdf526','b09cc09971d1458bb336aad641fdf526','8b6055ea200244fab9f4e95221cb319a','self'),(NULL,1459816168779,0,'8e3616370a094408b8c860eb06fecdfd',1459816168779,0,'6ef48c395597459d9810bf0aac859903','6ef48c395597459d9810bf0aac859903','8e3616370a094408b8c860eb06fecdfd','self'),(NULL,1459816163811,0,'8f97ad1ce6514b71b02d3eb5b6e58894',1459816163811,0,'2bb97b35188345d69f54e9bbf2008553','2bb97b35188345d69f54e9bbf2008553','8f97ad1ce6514b71b02d3eb5b6e58894','self'),(NULL,1459816162066,0,'9161c6a7b9204fcc98b451de4a723901',1459816162066,0,'855fd99c277c4e069e0ffa2b052d89d3','855fd99c277c4e069e0ffa2b052d89d3','9161c6a7b9204fcc98b451de4a723901','self'),(NULL,1459816162690,0,'94bd377ee1de434ea2d2ad0d6e1fd867',1459816162690,0,'012b580866d74696a897403090f19239','012b580866d74696a897403090f19239','94bd377ee1de434ea2d2ad0d6e1fd867','self'),(NULL,1459816167768,0,'951f75ed6d2741a08b3036edb9e897a7',1459816167768,0,'7a9a1f6bccf84dda9159b82838440c01','7a9a1f6bccf84dda9159b82838440c01','951f75ed6d2741a08b3036edb9e897a7','self'),(NULL,1459816162957,0,'978859dbb7fc4284b6af5c6ca791fb47',1459816162957,0,'4120ee09ca1d457b81744f71c1a0640a','4120ee09ca1d457b81744f71c1a0640a','978859dbb7fc4284b6af5c6ca791fb47','self'),(NULL,1459816166135,0,'9da6c79a3bef42bcb0c595418b71246e',1459816166135,0,'0c5ed4a5aa354da6a527f811cd77f455','0c5ed4a5aa354da6a527f811cd77f455','9da6c79a3bef42bcb0c595418b71246e','self'),(NULL,1459816166670,0,'9db107a113f64e258efa34f3ac4a1119',1459816166670,0,'cc4950adff3147fd8b36fbe2fc1c2e12','cc4950adff3147fd8b36fbe2fc1c2e12','9db107a113f64e258efa34f3ac4a1119','self'),(NULL,1459816164053,0,'9efc878f8a7b4624b2069bc4fd3b837b',1459816164053,0,'9738db9ed5c645f4a395c0ce24dba834','9738db9ed5c645f4a395c0ce24dba834','9efc878f8a7b4624b2069bc4fd3b837b','self'),(NULL,1459816166947,0,'9f26749ca3184812b58abaa043e377c7',1459816166947,0,'45dd837ceb804d058a8701b473d00060','45dd837ceb804d058a8701b473d00060','9f26749ca3184812b58abaa043e377c7','self'),(NULL,1459816167159,0,'a0baab27acb54fa5945079df179ab40f',1459816167159,0,'50c66205af3e4df1ae709ffcb9d33670','50c66205af3e4df1ae709ffcb9d33670','a0baab27acb54fa5945079df179ab40f','self'),(NULL,1459816168004,0,'a3ec132fcb5c4e9e894f5c2f9d4c6cc7',1459816168004,0,'c3119a12e06041959f4c69b4078dc8f9','c3119a12e06041959f4c69b4078dc8f9','a3ec132fcb5c4e9e894f5c2f9d4c6cc7','self'),(NULL,1459816163118,0,'a52d83f184fc48e79feef25932975bd8',1459816163118,0,'2ce2cdca4b0040768a64021a88e8793c','2ce2cdca4b0040768a64021a88e8793c','a52d83f184fc48e79feef25932975bd8','self'),(NULL,1459816164032,0,'a65740dd259f4fd697b5f220e6e9d94e',1459816164032,0,'bfdb438d9f03469fa76b4eab9d099384','bfdb438d9f03469fa76b4eab9d099384','a65740dd259f4fd697b5f220e6e9d94e','self'),(NULL,1459816168640,0,'a6ee5e04d52243afaaea589cc86df58d',1459816168640,0,'e4f3627722644627a5a53e5afac59a27','e4f3627722644627a5a53e5afac59a27','a6ee5e04d52243afaaea589cc86df58d','self'),(NULL,1459816167685,0,'a74bdecacc424a27985f741f720efc86',1459816167685,0,'2ecf3496f4524f52b0001c4556b9ff80','2ecf3496f4524f52b0001c4556b9ff80','a74bdecacc424a27985f741f720efc86','self'),(NULL,1459816163485,0,'a7b256eee90e4be6a81a95a2d6d41e9e',1459816163485,0,'1a1c5f5bf5064e5fbfc30d723a93ac35','1a1c5f5bf5064e5fbfc30d723a93ac35','a7b256eee90e4be6a81a95a2d6d41e9e','self'),(NULL,1459816163841,0,'a9b5173cea3644cfaf7e7bcc3858f0f7',1459816163841,0,'7c393699d849478cbb26a265ee746b75','7c393699d849478cbb26a265ee746b75','a9b5173cea3644cfaf7e7bcc3858f0f7','self'),(NULL,1459816166360,0,'acdd9f719dc54825879936b1dfe1dabf',1459816166360,0,'2699a3d8d58644c395293106c83b0695','2699a3d8d58644c395293106c83b0695','acdd9f719dc54825879936b1dfe1dabf','self'),(NULL,1459816168732,0,'ae31e4c05c9749349609d78cbbf2fe55',1459816168732,0,'78a353168b3d4cf7bf9d0b299aaf113e','78a353168b3d4cf7bf9d0b299aaf113e','ae31e4c05c9749349609d78cbbf2fe55','self'),(NULL,1459816163057,0,'af6e7f78ba6441d5959e33112b39a958',1459816163057,0,'59a31621ed494f5e95710f2e44d45fdd','59a31621ed494f5e95710f2e44d45fdd','af6e7f78ba6441d5959e33112b39a958','self'),(NULL,1459816164487,0,'b2f9f065e075495d972e109fce3b72e4',1459816164487,0,'48190ef247ff41129988f08177726deb','48190ef247ff41129988f08177726deb','b2f9f065e075495d972e109fce3b72e4','self'),(NULL,1459816166082,0,'bb8c6fd7bfd845838b04e9cc1f315f12',1459816166082,0,'2b3af83bf1fe4868a942eb5c4b118685','2b3af83bf1fe4868a942eb5c4b118685','bb8c6fd7bfd845838b04e9cc1f315f12','self'),(NULL,1459816162776,0,'bd8e1c8751844114a04f8bfc7ce88a7e',1459816162776,0,'a26523b21e2f4e12bc93828349147061','a26523b21e2f4e12bc93828349147061','bd8e1c8751844114a04f8bfc7ce88a7e','self'),(NULL,1459816168709,0,'c17013ee5ac54caca858ac108f24ae89',1459816168709,0,'31c7b8e6fc2048e884bd3facdc94e6de','31c7b8e6fc2048e884bd3facdc94e6de','c17013ee5ac54caca858ac108f24ae89','self'),(NULL,1459816163371,0,'cacab489d1ea44e990117304ce29ae98',1459816163371,0,'053cf760d670452caa0f5c5f588639a1','053cf760d670452caa0f5c5f588639a1','cacab489d1ea44e990117304ce29ae98','self'),(NULL,1459816163244,0,'cc6b33b70d794a9a986977b290cbb0a2',1459816163244,0,'5a2f5f08fbae41ff962d5142296866db','5a2f5f08fbae41ff962d5142296866db','cc6b33b70d794a9a986977b290cbb0a2','self'),(NULL,1459816166815,0,'ce35ee13ca504963b62fb13445457a65',1459816166815,0,'79d043c3041d4d0db005a220dc5a438d','79d043c3041d4d0db005a220dc5a438d','ce35ee13ca504963b62fb13445457a65','self'),(NULL,1459816162597,0,'cfb3162ec5a749cbbb5762609bef8c23',1459816162597,0,'74166e5b8b8b4662afc4497c52faf6bc','74166e5b8b8b4662afc4497c52faf6bc','cfb3162ec5a749cbbb5762609bef8c23','self'),(NULL,1459816163418,0,'d23c148d2e6846658ce0c58a12cc1093',1459816163418,0,'fa18c25e248e4ca0978c21ea2d6a17ef','fa18c25e248e4ca0978c21ea2d6a17ef','d23c148d2e6846658ce0c58a12cc1093','self'),(NULL,1459816163588,0,'d2cd15b3892a4571ba1726047f4d613a',1459816163588,0,'596537a994fe4969afb8b5b96f95a58e','596537a994fe4969afb8b5b96f95a58e','d2cd15b3892a4571ba1726047f4d613a','self'),(NULL,1459816164725,0,'d9d524e5eb72479fb37dd004bd9d00fd',1459816164725,0,'c3d5cb11a5f446858470d00d7434020a','c3d5cb11a5f446858470d00d7434020a','d9d524e5eb72479fb37dd004bd9d00fd','self'),(NULL,1459816166572,0,'df9386c88b974b84ac736d0a745c16ce',1459816166572,0,'20fc61b7fc8e4e889d1ce95b4d899cd1','20fc61b7fc8e4e889d1ce95b4d899cd1','df9386c88b974b84ac736d0a745c16ce','self'),(NULL,1459816167228,0,'dfade17a3ead464a94b7769af273e733',1459816167228,0,'5618f29e9f694d8da566f2ddaec01283','5618f29e9f694d8da566f2ddaec01283','dfade17a3ead464a94b7769af273e733','self'),(NULL,1459816167116,0,'e1b877e2f4224ef3933b00a8528422bc',1459816167116,0,'a58dc65ff39649cfaf72aa3389e1e9e8','a58dc65ff39649cfaf72aa3389e1e9e8','e1b877e2f4224ef3933b00a8528422bc','self'),(NULL,1459816163308,0,'e2debb87d4b845b1991754afce213e5d',1459816163308,0,'4d09c98da01e4d5389b4cee05c54fc19','4d09c98da01e4d5389b4cee05c54fc19','e2debb87d4b845b1991754afce213e5d','self'),(NULL,1459816168667,0,'e35eb47c56104131bb18a28ec5bdf575',1459816168667,0,'a4cacb8e06cc4ad7bafc48491a68da70','a4cacb8e06cc4ad7bafc48491a68da70','e35eb47c56104131bb18a28ec5bdf575','self'),(NULL,1459816162169,0,'e585f8a3bd0d486fa502a230a764e213',1459816162169,0,'93bac907e57542689a532f2ae14f9cab','93bac907e57542689a532f2ae14f9cab','e585f8a3bd0d486fa502a230a764e213','self'),(NULL,1459816166859,0,'e7dbedc1cece4e989eeaa380453befd8',1459816166859,0,'1781bc622c7249029c32125733195f5e','1781bc622c7249029c32125733195f5e','e7dbedc1cece4e989eeaa380453befd8','self'),(NULL,1459816164388,0,'ec7ac74c56a74f939632efc821dccaab',1459816164388,0,'582bfa600ca340aebed67753e38a430d','582bfa600ca340aebed67753e38a430d','ec7ac74c56a74f939632efc821dccaab','self'),(NULL,1459816162119,0,'f1c80d405e0e48439eec3ec421a41a5c',1459816162119,0,'35113e2566d843338966edd60c435059','35113e2566d843338966edd60c435059','f1c80d405e0e48439eec3ec421a41a5c','self'),(NULL,1459816161899,0,'f1d4e96cb3f84b15967f9836ffd58f53',1459816161899,0,'6b906f0d952b4c12a57c4b71d2e81001','6b906f0d952b4c12a57c4b71d2e81001','f1d4e96cb3f84b15967f9836ffd58f53','self'),(NULL,1459816163030,0,'f3b3d138eb264ddf9f37506ed8b6ad3b',1459816163030,0,'f44cbb78b4594e0aa9ebb1d66bb1618a','f44cbb78b4594e0aa9ebb1d66bb1618a','f3b3d138eb264ddf9f37506ed8b6ad3b','self'),(NULL,1459816164300,0,'f8acb32afaed4f76a815b771cc404d3c',1459816164300,0,'b1d07c0142ad43a7aa3d6a1a6e8fd0b4','b1d07c0142ad43a7aa3d6a1a6e8fd0b4','f8acb32afaed4f76a815b771cc404d3c','self'),(NULL,1459816166006,0,'fd43fc66000e45338a31940e79491d44',1459816166006,0,'c3d2e8d1b61b481a92b96a5c564e6d29','c3d2e8d1b61b481a92b96a5c564e6d29','fd43fc66000e45338a31940e79491d44','self'),(NULL,1459816163158,0,'fde4d8bbbba84e2891b4c309968785ce',1459816163158,0,'fd1617992c834f03827ff8b836c38c8d','fd1617992c834f03827ff8b836c38c8d','fde4d8bbbba84e2891b4c309968785ce','self');
/*!40000 ALTER TABLE `grouper_attribute_def_name_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_attribute_def_scope`
--

DROP TABLE IF EXISTS `grouper_attribute_def_scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_attribute_def_scope` (
  `attribute_def_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `attribute_def_scope_type` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `scope_string` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `scope_string2` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_def_scope_atdef_idx` (`attribute_def_id`),
  CONSTRAINT `fk_attr_def_scope_def_id` FOREIGN KEY (`attribute_def_id`) REFERENCES `grouper_attribute_def` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_attribute_def_scope`
--

LOCK TABLES `grouper_attribute_def_scope` WRITE;
/*!40000 ALTER TABLE `grouper_attribute_def_scope` DISABLE KEYS */;
INSERT INTO `grouper_attribute_def_scope` VALUES ('b92c64af9edd4b7493d8c4b2a936cbd8',NULL,1459816162568,0,'4ee92c1613d8485dacc95e83f399f302',1459816162568,'nameEquals','etc:attribute:rules:rule',NULL),('05ed0d9e4c5e4024a75c08aa08717579',NULL,1459816164378,0,'5f68131085b9422380873396d77d20f6',1459816164378,'attributeDefNameIdAssigned','b1d07c0142ad43a7aa3d6a1a6e8fd0b4',NULL),('35ee03902f9049fea8520a4c47e57b54',NULL,1459816168630,0,'cefa77ea5e1047b89b7cf4aa746529dd',1459816168630,'idEquals','704fbc4dc6da4a52afa502200ffd05ff',NULL),('c3540f2df6964cb9bbc9b974cf445d84',NULL,1459816161811,0,'f1bed3084d834a69aac8e56adc02821a',1459816161811,'nameEquals','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite',NULL);
/*!40000 ALTER TABLE `grouper_attribute_def_scope` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_audit_entry`
--

DROP TABLE IF EXISTS `grouper_audit_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_audit_entry` (
  `act_as_member_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `audit_type_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `description` text COLLATE utf8_bin,
  `env_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `grouper_engine` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `grouper_version` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `int01` bigint(20) DEFAULT NULL,
  `int02` bigint(20) DEFAULT NULL,
  `int03` bigint(20) DEFAULT NULL,
  `int04` bigint(20) DEFAULT NULL,
  `int05` bigint(20) DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `logged_in_member_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `server_host` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `string01` text COLLATE utf8_bin,
  `string02` text COLLATE utf8_bin,
  `string03` text COLLATE utf8_bin,
  `string04` text COLLATE utf8_bin,
  `string05` text COLLATE utf8_bin,
  `string06` text COLLATE utf8_bin,
  `string07` text COLLATE utf8_bin,
  `string08` text COLLATE utf8_bin,
  `user_ip_address` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `duration_microseconds` bigint(20) DEFAULT NULL,
  `query_count` int(11) DEFAULT NULL,
  `server_user_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_entry_act_as_idx` (`act_as_member_id`),
  KEY `audit_entry_act_as_created_idx` (`act_as_member_id`,`created_on`),
  KEY `audit_entry_type_idx` (`audit_type_id`),
  KEY `audit_entry_context_idx` (`context_id`),
  KEY `audit_entry_logged_in_idx` (`logged_in_member_id`),
  KEY `audit_entry_string01_idx` (`string01`(255)),
  KEY `audit_entry_string02_idx` (`string02`(255)),
  KEY `audit_entry_string03_idx` (`string03`(255)),
  KEY `audit_entry_string04_idx` (`string04`(255)),
  KEY `audit_entry_string05_idx` (`string05`(255)),
  KEY `audit_entry_string06_idx` (`string06`(255)),
  KEY `audit_entry_string07_idx` (`string07`(255)),
  KEY `audit_entry_string08_idx` (`string08`(255)),
  CONSTRAINT `fk_audit_entry_type_id` FOREIGN KEY (`audit_type_id`) REFERENCES `grouper_audit_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_audit_entry`
--

LOCK TABLES `grouper_audit_entry` WRITE;
/*!40000 ALTER TABLE `grouper_audit_entry` DISABLE KEYS */;
INSERT INTO `grouper_audit_entry` VALUES ('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','23fa33b4278c4d72b1e6023b98668a3d',1459816158156,'Added group field: attrReaders, id: 4e9bb975b2cf43e79651b1e519070b2c, type: attributeDef',NULL,'grouperShell','2.2.2',0,'01372b5200c44ae4a281981ea143243f',NULL,NULL,NULL,NULL,NULL,1459816158156,NULL,'grouper','4e9bb975b2cf43e79651b1e519070b2c','attrReaders',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',18719,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','3c3a95bbffcd4e52b160f3c3c830e01d',1459816163889,'Added attributeDefName: etc:attribute:permissionLimits:limitLabelsContain',NULL,'grouperShell','2.2.2',0,'019690e1344b48658a9b422630c97dfd',NULL,NULL,NULL,NULL,NULL,1459816163890,NULL,'grouper','b5a9690f188547de9a59a995da25ddad','etc:attribute:permissionLimits:limitLabelsContain','etc:attribute:permissionLimits:labels contains',NULL,'b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',7693,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','243a0354c7b14540b6024a5d0405c21a',1459816158306,'Added group field: stemmers, id: 984bf86f08fc4d7f9b045f1b74f6f0cf, type: naming',NULL,'grouperShell','2.2.2',0,'027bc9303e214d29bddbd331ad833407',NULL,NULL,NULL,NULL,NULL,1459816158306,NULL,'grouper','984bf86f08fc4d7f9b045f1b74f6f0cf','stemmers',NULL,NULL,'naming',NULL,NULL,NULL,'172.18.0.3',15431,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','c00b64b63223480c8d991379caad5657',1459816166190,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Quartz cron config string, e.g. every day at 8am is: 0 0 8 * * ?\'',NULL,'grouperShell','2.2.2',0,'03b89cdf67ee4c5ab110a2aca7f85338',NULL,NULL,NULL,NULL,NULL,1459816166191,NULL,'grouper','3abd9f032c2c42318cd5e5e014c27a69','etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron','etc:attribute:loaderLdap:Grouper loader LDAP quartz cron','Quartz cron config string, e.g. every day at 8am is: 0 0 8 * * ?','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',12770,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','f3e8aedc2caf466eb1a9c0ccb5be5ee6',1459816166485,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike, Fields changed: description.\ndescription: FROM: \'null\', TO: \'This should be a sql like string (e.g. school:orgs:%org%_systemOfRecord), and the loader should be able to query group names to see which names are managed by this loader job.  So if a group falls ...\'',NULL,'grouperShell','2.2.2',0,'0448f3fd23f54775b3d90b7a65161745',NULL,NULL,NULL,NULL,NULL,1459816166488,NULL,'grouper','805535775c484f7fbedfaa6ec1837ee7','etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike','etc:attribute:loaderLdap:Grouper loader LDAP groups like','This should be a sql like string (e.g. school:orgs:%org%_systemOfRecord), and the loader should be able to query group names to see which names are managed by this loader job.  So if a group falls off the loader resultset (or is moved), this will help the loader remove the members from this group.  Note, if the group is used anywhere as a member or composite member, it wont be removed.  All include/exclude/requireGroups will be removed.  Though the two groups, include and exclude, will not be removed if they have members.  There is a grouper-loader.properties setting to remove loader groups if empty and not used: #if using a sql table, and specifying the name like string, then shoudl the group (in addition to memberships)# be removed if not used anywhere else?loader.sqlTable.likeString.removeGroupIfNotUsed = true','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',31578,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','34736b3306354c188a18c460071de42e',1459816166626,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes',NULL,'grouperShell','2.2.2',0,'04d2b92f593a48b19614708351d55156',NULL,NULL,NULL,NULL,NULL,1459816166627,NULL,'grouper','7eb0914e4b5747d3abae2b5ad8edf19b','etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes','etc:attribute:loaderLdap:Grouper loader LDAP extra attributes',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',22927,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','b65007571ab141728238f43d591e633f',1459816164301,'Added attributeDefName: etc:attribute:attrLoader:attributeLoader',NULL,'grouperShell','2.2.2',0,'04e1983e07434de3a4e531403ffeaf30',NULL,NULL,NULL,NULL,NULL,1459816164302,NULL,'grouper','b1d07c0142ad43a7aa3d6a1a6e8fd0b4','etc:attribute:attrLoader:attributeLoader','etc:attribute:attrLoader:attributeLoader',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeDefLoaderTypeDef',NULL,'172.18.0.3',9403,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','f8b45e1449bb4724ba6587b77b839dbd',1459816168800,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderGroupQuery',NULL,'grouperShell','2.2.2',0,'0503506db25b4cab93d3e4e0bd885ea7',NULL,NULL,NULL,NULL,NULL,1459816168800,NULL,'grouper','5e1c7a2dd9624015ad99837e5da79163','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupQuery','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupQuery',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',9049,7,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','e7d2e5bb9a214c98afe09f3e43fdc45e',1459816167351,'Updated stem: etc:attribute:userData, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in Grouper user data attributes\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816167348\'',NULL,'grouperShell','2.2.2',0,'0538526b6f1a4c898b2877cc9ac9d9e3',NULL,NULL,NULL,NULL,NULL,1459816167352,NULL,'grouper','cb1bfad6c8ed424d902b65d9ec275df0','etc:attribute:userData','1730a44d087442cc96c2d8d63b655716','etc:attribute:userData','folder for built in Grouper user data attributes',NULL,NULL,NULL,'172.18.0.3',3950,4,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','789e4fc65110427582f443bccc7ed464',1459816162391,'Updated attributeDef: etc:attribute:rules:rulesTypeDef, Fields changed: assignToAttributeDef, assignToGroup, assignToStem, multiAssignable.\nassignToAttributeDef: FROM: \'false\', TO: \'true\'\nassignToGroup: FROM: \'false\', TO: \'true\'\nassignToStem: FROM: \'false\', TO: \'true\'\nmultiAssignable: FROM: \'false\', TO: \'true\'',NULL,'grouperShell','2.2.2',0,'058df230012c43ec8679a64b3bdc3b1f',NULL,NULL,NULL,NULL,NULL,1459816162393,NULL,'grouper','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rulesTypeDef',NULL,'fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,NULL,NULL,'172.18.0.3',6841,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','184c4a9524a54f918209456394540023',1459816162650,'Added attributeDefName: etc:attribute:rules:ruleActAsSubjectIdentifier',NULL,'grouperShell','2.2.2',0,'05b862f068be4b919171f61256c9f4fd',NULL,NULL,NULL,NULL,NULL,1459816162653,NULL,'grouper','5cbfd85dfd054f3bb9ef6fab9d7db699','etc:attribute:rules:ruleActAsSubjectIdentifier','etc:attribute:rules:ruleActAsSubjectIdentifier',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',16120,9,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','1a1948141e0143c1a7a92641d494fe97',1459816163693,'Updated stem: etc:attribute:permissionLimits, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in Grouper permission limits\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816163689\'',NULL,'grouperShell','2.2.2',0,'069eab6ea107446faf6566c7feed9373',NULL,NULL,NULL,NULL,NULL,1459816163700,NULL,'grouper','b6bc2fcd772146ee970347e496538926','etc:attribute:permissionLimits','1730a44d087442cc96c2d8d63b655716','etc:attribute:permissionLimits','folder for built in Grouper permission limits',NULL,NULL,NULL,'172.18.0.3',9574,4,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','2d05ad7ebd794bb79815228acd5fed54',1459816164281,'Added attributeDef: etc:attribute:attrLoader:attributeDefLoaderTypeDef',NULL,'grouperShell','2.2.2',0,'06eef68097d547a3b1a7e68ffa03051b',NULL,NULL,NULL,NULL,NULL,1459816164282,NULL,'grouper','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeDefLoaderTypeDef',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,NULL,NULL,'172.18.0.3',39942,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','189f028eb1c6410eaa9305f20ab29064',1459816168656,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderDbName',NULL,'grouperShell','2.2.2',0,'07cdc2c6b54c4481b47f96da5ca7d6c2',NULL,NULL,NULL,NULL,NULL,1459816168656,NULL,'grouper','2a6d00b79fe24950a14169967d9ae050','etc:legacy:attribute:legacyAttribute_grouperLoaderDbName','etc:legacy:attribute:legacyAttribute_grouperLoaderDbName',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',8739,7,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a089b5773113477798959c7c989c1670',1459816163084,'Updated attributeDefName: etc:attribute:rules:ruleIfOwnerName, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the if part has an arg, this is owner of if, mutually exclusive with id\'',NULL,'grouperShell','2.2.2',0,'08cbf4369d854a968f2a47d1de2a6f73',NULL,NULL,NULL,NULL,NULL,1459816163087,NULL,'grouper','59a31621ed494f5e95710f2e44d45fdd','etc:attribute:rules:ruleIfOwnerName','etc:attribute:rules:ruleIfOwnerName','when the if part has an arg, this is owner of if, mutually exclusive with id','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',8647,5,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','916b5eab7ecb4ee6a74c707c50586a5c',1459816162313,'Updated stem: etc:attribute:rules, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in Grouper rules attributes\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816162311\'',NULL,'grouperShell','2.2.2',0,'0af293f297ff43a58346093994774375',NULL,NULL,NULL,NULL,NULL,1459816162314,NULL,'grouper','fc88a71ee4574ae7b0a550d72b5172d9','etc:attribute:rules','1730a44d087442cc96c2d8d63b655716','etc:attribute:rules','folder for built in Grouper rules attributes',NULL,NULL,NULL,'172.18.0.3',3053,4,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','cd4905a68628431e9c59eaee354a6cf4',1459816165367,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderActionSetQuery, Fields changed: description.\ndescription: FROM: \'null\', TO: \'SQL query with at least the following columns: if_has_action_name, then_has_action_name\'',NULL,'grouperShell','2.2.2',0,'0b3f5db5fc364d21880c967681bcac91',NULL,NULL,NULL,NULL,NULL,1459816165368,NULL,'grouper','8e84b513b4e948b99127d0fa84a53e78','etc:attribute:attrLoader:attributeLoaderActionSetQuery','etc:attribute:attrLoader:attributeLoaderActionSetQuery','SQL query with at least the following columns: if_has_action_name, then_has_action_name','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',4598,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','74dcdb6213624e328a6ab5d36797c611',1459816163843,'Added attributeDefName: etc:attribute:permissionLimits:limitIpOnNetworks',NULL,'grouperShell','2.2.2',0,'0be713d58d5443b396132e9fe4907392',NULL,NULL,NULL,NULL,NULL,1459816163845,NULL,'grouper','7c393699d849478cbb26a265ee746b75','etc:attribute:permissionLimits:limitIpOnNetworks','etc:attribute:permissionLimits:ipAddress on networks',NULL,'b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',12366,9,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','0865979fcb75478ea9394435359e8b9a',1459816164125,'Added attributeDef: etc:attribute:permissionLimits:limitsDefMarker',NULL,'grouperShell','2.2.2',0,'0dcc80cd33c84e34ac84cbbce7e1aac1',NULL,NULL,NULL,NULL,NULL,1459816164126,NULL,'grouper','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,NULL,NULL,'172.18.0.3',53556,39,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','79c891d54c214f9292c72ad42a500a21',1459816163988,'Updated attributeDef: etc:attribute:permissionLimits:limitsDefInt, Fields changed: assignToAttributeDef, assignToEffMembership, assignToEffMembershipAssn, assignToGroup, assignToGroupAssn, multiAssignable, valueType.\nassignToAttributeDef: FROM: \'false\', TO: \'true\'\nassignToEffMembership: FROM: \'false\', TO: \'true\'\nassignToEffMembershipAssn: FROM: \'false\', TO: \'true\'\nassignToGroup: FROM: \'false\', TO: \'true\'\nassignToGroupAssn: FROM: \'false\', TO: \'true\'\nmultiAssignable: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'integer\'',NULL,'grouperShell','2.2.2',0,'0e5314d53ba349c79abb73ab5410092e',NULL,NULL,NULL,NULL,NULL,1459816163989,NULL,'grouper','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,NULL,NULL,'172.18.0.3',2439,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','e122a3becbfc47319f96990431825ec1',1459816167892,'Updated attributeDefName: etc:attribute:userData:grouperUserDataRecentAttributeDefNames, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of attribute definition name ids and metadata in json format that are the recently used attribute definition names for a user\'',NULL,'grouperShell','2.2.2',0,'0fe49b5582e14435ab8cd8fdf0acebf1',NULL,NULL,NULL,NULL,NULL,1459816167898,NULL,'grouper','4477e4a117514f2e900f7aff92c808ab','etc:attribute:userData:grouperUserDataRecentAttributeDefNames','etc:attribute:userData:Grouper user data recent attribute definition names','A list of attribute definition name ids and metadata in json format that are the recently used attribute definition names for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',9943,5,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','35b82a4a0f7146248919176310137474',1459816164352,'Added attributeDef: etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'grouperShell','2.2.2',0,'0ffff3440aea451bb26e1419c18e21c7',NULL,NULL,NULL,NULL,NULL,1459816164359,NULL,'grouper','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,NULL,NULL,'172.18.0.3',45740,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','da2e08cc8ac44881af984bd40fd0462e',1459816166084,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapServerId',NULL,'grouperShell','2.2.2',0,'10a55cdba0ba4da8849c3d20547cbc11',NULL,NULL,NULL,NULL,NULL,1459816166093,NULL,'grouper','2b3af83bf1fe4868a942eb5c4b118685','etc:attribute:loaderLdap:grouperLoaderLdapServerId','etc:attribute:loaderLdap:Grouper loader LDAP server ID',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',64383,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','53dc69bab5794483b31635a3fc9b7c90',1459816167160,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapOptouts',NULL,'grouperShell','2.2.2',0,'115dc67dd358454cb793f40fbebff3bd',NULL,NULL,NULL,NULL,NULL,1459816167162,NULL,'grouper','50c66205af3e4df1ae709ffcb9d33670','etc:attribute:loaderLdap:grouperLoaderLdapOptouts','etc:attribute:loaderLdap:Grouper loader LDAP group optouts',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',20075,9,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','0564466782fa4b5fbe17c5861dbd2f23',1459816161090,'Added stem: etc:legacy:attribute',NULL,'grouperShell','2.2.2',0,'1485d14ca8af4f78b31205c0534c7083',NULL,NULL,NULL,NULL,NULL,1459816161094,NULL,'grouper','36792aa7956240feb1bb6025c56ff2f3','etc:legacy:attribute','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy:attribute','',NULL,NULL,NULL,'172.18.0.3',66875,30,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','8cb63a2bb2e44db2a79e928ce5ea7d3b',1459816166874,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression, Fields changed: description.\ndescription: FROM: \'null\', TO: \'JEXL expression language fragment that processes the subject string before passing it to the subject API (optional)\'',NULL,'grouperShell','2.2.2',0,'15a1b2375c294f819cbe629c56e84e48',NULL,NULL,NULL,NULL,NULL,1459816166876,NULL,'grouper','1781bc622c7249029c32125733195f5e','etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression','etc:attribute:loaderLdap:Grouper loader LDAP subject expression','JEXL expression language fragment that processes the subject string before passing it to the subject API (optional)','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',8602,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e42cd0b07fde446da3c91bebf0d7ef51',1459816162992,'Added attributeDefName: etc:attribute:rules:ruleCheckArg1',NULL,'grouperShell','2.2.2',0,'183bc8da81884d2e834e0edf49fdf618',NULL,NULL,NULL,NULL,NULL,1459816163005,NULL,'grouper','f5bb3d26042d4494b2a4826a03a8b0a1','etc:attribute:rules:ruleCheckArg1','etc:attribute:rules:ruleCheckArg1',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',30849,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','e7bcecb6566f419f9f687a57bfb1cdf1',1459816157834,'Added group field: members, id: 2637cba4ab98462581efd051349db069, type: list',NULL,'grouperShell','2.2.2',0,'18f105eef63e4f66aaeba2911f694a95',NULL,NULL,NULL,NULL,NULL,1459816157849,NULL,'grouper','2637cba4ab98462581efd051349db069','members',NULL,NULL,'list',NULL,NULL,NULL,'172.18.0.3',421203,87,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','0b48a27979d24cd892df9e63c7f1a418',1459816161778,'Updated attributeDef: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef, Fields changed: assignToStemAssn, valueType.\nassignToStemAssn: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'191cf5dc739a484a9551ce3ee51be88f',NULL,NULL,NULL,NULL,NULL,1459816161787,NULL,'grouper','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,NULL,NULL,'172.18.0.3',11601,3,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','ea8757bd8a5e4fcb8d05e62bd36a6da4',1459816160856,'Added stem: etc',NULL,'grouperShell','2.2.2',0,'19327e0cf6a64df9ad41180c64367073',NULL,NULL,NULL,NULL,NULL,1459816160884,NULL,'grouper','47bf48f95b9a4c67855b091e3d1003de','etc','d83a1feb851d4ede95786362de79547d','etc','',NULL,NULL,NULL,'172.18.0.3',1264196,34,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','960473ac0a764e3db73be6b4a8434b0c',1459816168733,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderPriority',NULL,'grouperShell','2.2.2',0,'19cc3c93155742ad9ab1bee8c99c1200',NULL,NULL,NULL,NULL,NULL,1459816168733,NULL,'grouper','78a353168b3d4cf7bf9d0b299aaf113e','etc:legacy:attribute:legacyAttribute_grouperLoaderPriority','etc:legacy:attribute:legacyAttribute_grouperLoaderPriority',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',9326,7,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','129701637b9d4e1f9b0222cd9069d8d3',1459816168101,'Added stem: etc:attribute:entities',NULL,'grouperShell','2.2.2',0,'1a7b70dba3444dfe96b7dd6a63615b47',NULL,NULL,NULL,NULL,NULL,1459816168102,NULL,'grouper','2eee186e51494f0a874fe61ff24b7192','etc:attribute:entities','1730a44d087442cc96c2d8d63b655716','etc:attribute:entities','',NULL,NULL,NULL,'172.18.0.3',22359,30,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','e7c9b6bfc7cc48fd9e4411aa19379e17',1459816167087,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapUpdaters, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to UPDATE the group memberships.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'1b08850c230d43b5a14a2fe539cd0e09',NULL,NULL,NULL,NULL,NULL,1459816167089,NULL,'grouper','d0147000b33c4cfcaa524e135adb4f43','etc:attribute:loaderLdap:grouperLoaderLdapUpdaters','etc:attribute:loaderLdap:Grouper loader LDAP group updaters','Comma separated subjectIds or subjectIdentifiers who will be allowed to UPDATE the group memberships.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',10478,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','df392c58418743d999e73103e5f90047',1459816166342,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapAndGroups, Fields changed: description.\ndescription: FROM: \'null\', TO: \'If you want to restrict membership in the dynamic group based on other group(s), put the list of group names here comma-separated.  The require groups means if you put a group names in there (e.g. ...\'',NULL,'grouperShell','2.2.2',0,'1c2b01072c574ceb8a3f6fbab25138f5',NULL,NULL,NULL,NULL,NULL,1459816166349,NULL,'grouper','db40a48a4ac943ac925a393858337d38','etc:attribute:loaderLdap:grouperLoaderLdapAndGroups','etc:attribute:loaderLdap:Grouper loader LDAP require in groups','If you want to restrict membership in the dynamic group based on other group(s), put the list of group names here comma-separated.  The require groups means if you put a group names in there (e.g. school:community:employee) then it will \'and\' that group with the member list from the loader.  So only members of the group from the loader query who are also employees will be in the resulting group','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',11411,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','3b04114215324e6289c1c9be422e7e6c',1459816166312,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType, Fields changed: description.\ndescription: FROM: \'null\', TO: \'The type of subject ID.  This can be either: subjectId (most efficient), subjectIdentifier (2nd most efficient), or subjectIdOrIdentifier\'',NULL,'grouperShell','2.2.2',0,'1cc764b19a6c496eb35007398afb24a1',NULL,NULL,NULL,NULL,NULL,1459816166313,NULL,'grouper','6a4bdf524d1242aabb6a2765da61655e','etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType','etc:attribute:loaderLdap:Grouper loader LDAP subject ID type','The type of subject ID.  This can be either: subjectId (most efficient), subjectIdentifier (2nd most efficient), or subjectIdOrIdentifier','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',13561,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','80a32ac9b4374b90acaecbe3d1ca5d17',1459816158082,'Added group field: attrAdmins, id: cd1c789d1a2e480384662de8de917ed1, type: attributeDef',NULL,'grouperShell','2.2.2',0,'1ce7da8536774afd986b5417ce465bbf',NULL,NULL,NULL,NULL,NULL,1459816158082,NULL,'grouper','cd1c789d1a2e480384662de8de917ed1','attrAdmins',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',9539,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','6930ebdfd50a443593fd420d34f9fc74',1459816168696,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderQuartzCron',NULL,'grouperShell','2.2.2',0,'21596d3a08494794993c21fa4cf1e003',NULL,NULL,NULL,NULL,NULL,1459816168696,NULL,'grouper','2834e8c199de44eda7c2f74c83c895d2','etc:legacy:attribute:legacyAttribute_grouperLoaderQuartzCron','etc:legacy:attribute:legacyAttribute_grouperLoaderQuartzCron',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',5636,7,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','4690457bb691470b874a0e3caf443122',1459816165905,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdap',NULL,'grouperShell','2.2.2',0,'228f206e853a415ca86515f9fa9eac5d',NULL,NULL,NULL,NULL,NULL,1459816165906,NULL,'grouper','3d4e0066247c4a8d806fd0465fa19264','etc:attribute:loaderLdap:grouperLoaderLdap','etc:attribute:loaderLdap:Grouper loader LDAP',NULL,'094308af1376466687416c49f1f6495f','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdapDef',NULL,'172.18.0.3',11845,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','4e42f1e5a42f4b5b80f5604af7bf7022',1459816161562,'Updated attributeDef: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef, Fields changed: assignToStem, multiAssignable.\nassignToStem: FROM: \'false\', TO: \'true\'\nmultiAssignable: FROM: \'false\', TO: \'true\'',NULL,'grouperShell','2.2.2',0,'22fe2959a26b4128a6a0a822bc54210e',NULL,NULL,NULL,NULL,NULL,1459816161570,NULL,'grouper','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef',NULL,'d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,NULL,NULL,'172.18.0.3',20198,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','612df8545c8049d1afcd03b252e61953',1459816163816,'Added attributeDefName: etc:attribute:permissionLimits:limitExpression',NULL,'grouperShell','2.2.2',0,'2375520fb6c14641a4a315886d19f422',NULL,NULL,NULL,NULL,NULL,1459816163818,NULL,'grouper','2bb97b35188345d69f54e9bbf2008553','etc:attribute:permissionLimits:limitExpression','etc:attribute:permissionLimits:Expression',NULL,'b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',11786,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','8a2ebb9e8ecb43fa8c615bbc4046749a',1459816167944,'Updated attributeDefName: etc:attribute:userData:grouperUserDataRecentSubjects, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of attribute member ids and metadata in json format that are the recently used subjects for a user\'',NULL,'grouperShell','2.2.2',0,'23bab62218274bb5bfc6938801af80c7',NULL,NULL,NULL,NULL,NULL,1459816167947,NULL,'grouper','de2074da9cd64e9393d7638e135ce76c','etc:attribute:userData:grouperUserDataRecentSubjects','etc:attribute:userData:Grouper user data recent subjects','A list of attribute member ids and metadata in json format that are the recently used subjects for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',10591,5,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','94adf590110246f88e79f8d5edc90f92',1459816162549,'Updated attributeDef: etc:attribute:rules:rulesAttrDef, Fields changed: assignToAttributeDefAssn, assignToGroupAssn, assignToStemAssn, valueType.\nassignToAttributeDefAssn: FROM: \'false\', TO: \'true\'\nassignToGroupAssn: FROM: \'false\', TO: \'true\'\nassignToStemAssn: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'23f553997ccb47b59f0cd6794e7aca53',NULL,NULL,NULL,NULL,NULL,1459816162553,NULL,'grouper','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,NULL,NULL,'172.18.0.3',5469,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','2cc6ded34620449ebfc62035db08309b',1459816162619,'Updated attributeDefName: etc:attribute:rules:ruleActAsSubjectId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'subject id to act as, mutually exclusive with identifier\'',NULL,'grouperShell','2.2.2',0,'2468882422ba477585ea8de1269d69c6',NULL,NULL,NULL,NULL,NULL,1459816162628,NULL,'grouper','74166e5b8b8b4662afc4497c52faf6bc','etc:attribute:rules:ruleActAsSubjectId','etc:attribute:rules:ruleActAsSubjectId','subject id to act as, mutually exclusive with identifier','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',14706,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a8a25cebf2064504b5ad098c41fe1501',1459816163897,'Updated attributeDefName: etc:attribute:permissionLimits:limitLabelsContain, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Configure a set of comma separated labels.  The env variable \'labels\' should be passed with comma separated labels.  If one is there, its ok, if not, then disallowed\'',NULL,'grouperShell','2.2.2',0,'24858c10ba5c4b32b12768d7f6a64955',NULL,NULL,NULL,NULL,NULL,1459816163900,NULL,'grouper','b5a9690f188547de9a59a995da25ddad','etc:attribute:permissionLimits:limitLabelsContain','etc:attribute:permissionLimits:labels contains','Configure a set of comma separated labels.  The env variable \'labels\' should be passed with comma separated labels.  If one is there, its ok, if not, then disallowed','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',7035,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','4476edf35ff543c1abdac2c03d68e986',1459816158228,'Added group field: attrDefAttrReaders, id: c4305e9f9a134e1998cf093f568003ed, type: attributeDef',NULL,'grouperShell','2.2.2',0,'26c4c8d48a6d4491b537c6a08c6f0830',NULL,NULL,NULL,NULL,NULL,1459816158228,NULL,'grouper','c4305e9f9a134e1998cf093f568003ed','attrDefAttrReaders',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',21478,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','23d7f62a00994d34ac976d2902e40d8c',1459816167726,'Added attributeDefName: etc:attribute:userData:grouperUserDataRecentGroups',NULL,'grouperShell','2.2.2',0,'28020183277e40309f567429e7a0d5a4',NULL,NULL,NULL,NULL,NULL,1459816167732,NULL,'grouper','276e5329b7a44fe396a3de5a951596ea','etc:attribute:userData:grouperUserDataRecentGroups','etc:attribute:userData:Grouper user data recent groups',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',18439,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','791d5b11d1b947d1b7fbe63c8f7b60a0',1459816162666,'Updated attributeDefName: etc:attribute:rules:ruleActAsSubjectIdentifier, Fields changed: description.\ndescription: FROM: \'null\', TO: \'subject identifier to act as, mutually exclusive with id\'',NULL,'grouperShell','2.2.2',0,'2999de6eff4346d3b3c12283bfa9af08',NULL,NULL,NULL,NULL,NULL,1459816162668,NULL,'grouper','5cbfd85dfd054f3bb9ef6fab9d7db699','etc:attribute:rules:ruleActAsSubjectIdentifier','etc:attribute:rules:ruleActAsSubjectIdentifier','subject identifier to act as, mutually exclusive with id','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',11890,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','ae8a9d7bf747464fa3357aeb3eeff58a',1459816164570,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderIntervalSeconds',NULL,'grouperShell','2.2.2',0,'2a15e18acc8a421bafd4c2e9ed07bf6f',NULL,NULL,NULL,NULL,NULL,1459816164572,NULL,'grouper','fed11b1fd8d342ff8ddb84cee7d94b1d','etc:attribute:attrLoader:attributeLoaderIntervalSeconds','etc:attribute:attrLoader:attributeLoaderIntervalSeconds',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',28567,9,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','a194a2a1e2ad45e7b81b45c4f987e830',1459816167411,'Added attributeDef: etc:attribute:userData:grouperUserDataDef',NULL,'grouperShell','2.2.2',0,'2a2a483b96a84ede89472070f95c31cf',NULL,NULL,NULL,NULL,NULL,1459816167412,NULL,'grouper','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserDataDef',NULL,'cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,NULL,NULL,'172.18.0.3',54834,39,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','6017ad626c1145609452065385b405d6',1459816167745,'Updated attributeDefName: etc:attribute:userData:grouperUserDataRecentGroups, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of group ids and metadata in json format that are the recently used groups for a user\'',NULL,'grouperShell','2.2.2',0,'2cff2bd714f94ff9aecc0c2f9fc5a7e8',NULL,NULL,NULL,NULL,NULL,1459816167747,NULL,'grouper','276e5329b7a44fe396a3de5a951596ea','etc:attribute:userData:grouperUserDataRecentGroups','etc:attribute:userData:Grouper user data recent groups','A list of group ids and metadata in json format that are the recently used groups for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',10644,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','225f02a0ebe148948eac60792e71d014',1459816158026,'Added group field: viewers, id: abbe645d24154daebb09dcf8c5940de1, type: access',NULL,'grouperShell','2.2.2',0,'2d7a43a6825d4d38b8bb37dd8a5990bc',NULL,NULL,NULL,NULL,NULL,1459816158026,NULL,'grouper','abbe645d24154daebb09dcf8c5940de1','viewers',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',13175,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a02fbcaf641146609d471715e06b953a',1459816164403,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderType, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Type of loader, e.g. ATTR_SQL_SIMPLE\'',NULL,'grouperShell','2.2.2',0,'2e9b924cc7214a879a06ac77f484a80c',NULL,NULL,NULL,NULL,NULL,1459816164404,NULL,'grouper','582bfa600ca340aebed67753e38a430d','etc:attribute:attrLoader:attributeLoaderType','etc:attribute:attrLoader:attributeLoaderType','Type of loader, e.g. ATTR_SQL_SIMPLE','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',8527,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','43f0e2a5babd431b87a45a1d43d99909',1459816168201,'Added attributeDefName: etc:attribute:entities:entitySubjectIdentifier',NULL,'grouperShell','2.2.2',0,'2f1bf93a32044e5b9acd5cb2aa0597a8',NULL,NULL,NULL,NULL,NULL,1459816168202,NULL,'grouper','0e8f891baffa4efb8c503f893937ed72','etc:attribute:entities:entitySubjectIdentifier','etc:attribute:entities:entitySubjectIdentifier',NULL,'2eee186e51494f0a874fe61ff24b7192','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef',NULL,'172.18.0.3',6746,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','1bba4c47a615420fad39fb10d2af701a',1459816166779,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression, Fields changed: description.\ndescription: FROM: \'null\', TO: \'JEXL expression language fragment that evaluates to the group display name, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'2f3307a5df6c47d181d829939052cda7',NULL,NULL,NULL,NULL,NULL,1459816166783,NULL,'grouper','39cfeba33b784b2da20a99fb80f674d7','etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression','etc:attribute:loaderLdap:Grouper loader LDAP group display name expression','JEXL expression language fragment that evaluates to the group display name, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',10489,5,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','247582158264478682b29d418654f9bb',1459816168106,'Updated stem: etc:attribute:entities, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in Grouper entities attributes\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816168103\'',NULL,'grouperShell','2.2.2',0,'2fd47b5608994736b478c0bc06330e67',NULL,NULL,NULL,NULL,NULL,1459816168108,NULL,'grouper','2eee186e51494f0a874fe61ff24b7192','etc:attribute:entities','1730a44d087442cc96c2d8d63b655716','etc:attribute:entities','folder for built in Grouper entities attributes',NULL,NULL,NULL,'172.18.0.3',4976,4,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','27d0e06cfba140b1a03fd7c903517b2b',1459816167447,'Added attributeDefName: etc:attribute:userData:grouperUserData',NULL,'grouperShell','2.2.2',0,'3102476033ed4779bd8284f25d3a4a3e',NULL,NULL,NULL,NULL,NULL,1459816167449,NULL,'grouper','14088a5dcafc4c22870e9cb6f65f3998','etc:attribute:userData:grouperUserData','etc:attribute:userData:Grouper user data',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserDataDef',NULL,'172.18.0.3',12639,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','b869aa8f5bcb49d9b3991d8916683875',1459816158039,'Added group field: groupAttrReaders, id: fc3d2f92c17b4510a9864f89fd1f04c4, type: access',NULL,'grouperShell','2.2.2',0,'324409da3efa40f89221daddafc5505d',NULL,NULL,NULL,NULL,NULL,1459816158039,NULL,'grouper','fc3d2f92c17b4510a9864f89fd1f04c4','groupAttrReaders',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',9271,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','7cf35e369f80471ea98ae9de9cf27639',1459816163039,'Updated attributeDefName: etc:attribute:rules:ruleIfOwnerId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the if part has an arg, this is owner of if, mutually exclusive with name\'',NULL,'grouperShell','2.2.2',0,'32954646decf470ebb463a2134e1684b',NULL,NULL,NULL,NULL,NULL,1459816163040,NULL,'grouper','f44cbb78b4594e0aa9ebb1d66bb1618a','etc:attribute:rules:ruleIfOwnerId','etc:attribute:rules:ruleIfOwnerId','when the if part has an arg, this is owner of if, mutually exclusive with name','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',2888,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e5f02fa8f28546d1bdc87516d763bd45',1459816164684,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderAttrsLike',NULL,'grouperShell','2.2.2',0,'32ffdc8864484450a36f80e51cd450aa',NULL,NULL,NULL,NULL,NULL,1459816164690,NULL,'grouper','60961ff002334628a502d78685638144','etc:attribute:attrLoader:attributeLoaderAttrsLike','etc:attribute:attrLoader:attributeLoaderAttrsLike',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',22620,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','8e2f93f08eb049c5ba29684848c83e2b',1459816168021,'Updated attributeDefName: etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of attribute definition name ids and metadata in json format that are the favorites for a user\'',NULL,'grouperShell','2.2.2',0,'34bdc4cfe12449ee88987e46acdb7805',NULL,NULL,NULL,NULL,NULL,1459816168029,NULL,'grouper','c3119a12e06041959f4c69b4078dc8f9','etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames','etc:attribute:userData:Grouper user data favorite attribute definition names','A list of attribute definition name ids and metadata in json format that are the favorites for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',10530,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a4179ff316784682889dcbbeb5a19457',1459816164696,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderAttrsLike, Fields changed: description.\ndescription: FROM: \'null\', TO: \'If empty, then orphans will be left alone (for attributeDefName and attributeDefNameSets).  If %, then all orphans deleted.  If a SQL like string, then only ones in that like string not in loader w...\'',NULL,'grouperShell','2.2.2',0,'369b087fff96455ea537107000ffe5d7',NULL,NULL,NULL,NULL,NULL,1459816164702,NULL,'grouper','60961ff002334628a502d78685638144','etc:attribute:attrLoader:attributeLoaderAttrsLike','etc:attribute:attrLoader:attributeLoaderAttrsLike','If empty, then orphans will be left alone (for attributeDefName and attributeDefNameSets).  If %, then all orphans deleted.  If a SQL like string, then only ones in that like string not in loader will be deleted','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',9021,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','a87d5bef3f8b45a08c8c1853907a5f95',1459816168718,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderIntervalSeconds',NULL,'grouperShell','2.2.2',0,'37cf377b8770401da8d5fe8f0d58d555',NULL,NULL,NULL,NULL,NULL,1459816168718,NULL,'grouper','31c7b8e6fc2048e884bd3facdc94e6de','etc:legacy:attribute:legacyAttribute_grouperLoaderIntervalSeconds','etc:legacy:attribute:legacyAttribute_grouperLoaderIntervalSeconds',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',16601,7,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','4f40302308c74a47b2b09ce18b51b5b5',1459816167117,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapOptins',NULL,'grouperShell','2.2.2',0,'38009bb980234bf1807382e533c789ea',NULL,NULL,NULL,NULL,NULL,1459816167118,NULL,'grouper','a58dc65ff39649cfaf72aa3389e1e9e8','etc:attribute:loaderLdap:grouperLoaderLdapOptins','etc:attribute:loaderLdap:Grouper loader LDAP group optins',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',20176,9,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','d606df9bf9e346ff98ce07d7005f0135',1459816165667,'Updated stem: etc:attribute:loaderLdap, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in Grouper loader ldap attributes\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816165659\'',NULL,'grouperShell','2.2.2',0,'3858d34670b84a719c47bce8977e52a2',NULL,NULL,NULL,NULL,NULL,1459816165668,NULL,'grouper','094308af1376466687416c49f1f6495f','etc:attribute:loaderLdap','1730a44d087442cc96c2d8d63b655716','etc:attribute:loaderLdap','folder for built in Grouper loader ldap attributes',NULL,NULL,NULL,'172.18.0.3',8565,4,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','5e1715a2250d4fdc8196bfadcd04ef69',1459816164420,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderDbName',NULL,'grouperShell','2.2.2',0,'39852fc5dfd3403194353b171de8c983',NULL,NULL,NULL,NULL,NULL,1459816164422,NULL,'grouper','72ed919fa87448f6895ebdcdbc2ba25e','etc:attribute:attrLoader:attributeLoaderDbName','etc:attribute:attrLoader:attributeLoaderDbName',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',12874,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','0468297809164a0dba777a0bd51761a4',1459816168769,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderGroupTypes',NULL,'grouperShell','2.2.2',0,'39a63bdb6b644eb59907d562daf239f2',NULL,NULL,NULL,NULL,NULL,1459816168769,NULL,'grouper','4bcf2e18aa6a4dfe9f75743111a1ae59','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupTypes','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupTypes',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',10791,7,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','ff5c7720e0ae4e6c87e47618cacba8df',1459816163135,'Updated attributeDefName: etc:attribute:rules:ruleIfConditionEl, Fields changed: description.\ndescription: FROM: \'null\', TO: \'expression language to run to see if the rule should run, or blank if should run always\'',NULL,'grouperShell','2.2.2',0,'3a4c927f9a84491799dab232fd5b1666',NULL,NULL,NULL,NULL,NULL,1459816163140,NULL,'grouper','2ce2cdca4b0040768a64021a88e8793c','etc:attribute:rules:ruleIfConditionEl','etc:attribute:rules:ruleIfConditionEl','expression language to run to see if the rule should run, or blank if should run always','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',7539,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','c959de66b56b498fa5c42beaca665cac',1459816163372,'Added attributeDefName: etc:attribute:rules:ruleThenEnumArg0',NULL,'grouperShell','2.2.2',0,'3ae86685dffa43cf910487dec07491e6',NULL,NULL,NULL,NULL,NULL,1459816163377,NULL,'grouper','053cf760d670452caa0f5c5f588639a1','etc:attribute:rules:ruleThenEnumArg0','etc:attribute:rules:ruleThenEnumArg0',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',11939,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','a42b6da94ac1421e87853397a83123a4',1459816166297,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType',NULL,'grouperShell','2.2.2',0,'3b11492d9b7643adac1e149b2663c8cf',NULL,NULL,NULL,NULL,NULL,1459816166298,NULL,'grouper','6a4bdf524d1242aabb6a2765da61655e','etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType','etc:attribute:loaderLdap:Grouper loader LDAP subject ID type',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',7387,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','b94b0ff3f39140068fe1a54f64413594',1459816166377,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSearchScope, Fields changed: description.\ndescription: FROM: \'null\', TO: \'How the deep in the subtree the search will take place.  Can be OBJECT_SCOPE, ONELEVEL_SCOPE, or SUBTREE_SCOPE (default)\'',NULL,'grouperShell','2.2.2',0,'3bd4941bc82d43198ac12e00e3f79ea7',NULL,NULL,NULL,NULL,NULL,1459816166381,NULL,'grouper','2699a3d8d58644c395293106c83b0695','etc:attribute:loaderLdap:grouperLoaderLdapSearchScope','etc:attribute:loaderLdap:Grouper loader LDAP search scope','How the deep in the subtree the search will take place.  Can be OBJECT_SCOPE, ONELEVEL_SCOPE, or SUBTREE_SCOPE (default)','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',8264,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','7af691a1d7cb4ee29a2edf3fdfad9c9e',1459816167858,'Updated attributeDefName: etc:attribute:userData:grouperUserDataRecentAttributeDefs, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of attribute definition ids and metadata in json format that are the recently used attribute definitions for a user\'',NULL,'grouperShell','2.2.2',0,'3cea4b2b57434b9ea967a0dec1786e60',NULL,NULL,NULL,NULL,NULL,1459816167860,NULL,'grouper','b09cc09971d1458bb336aad641fdf526','etc:attribute:userData:grouperUserDataRecentAttributeDefs','etc:attribute:userData:Grouper user data recent attribute definitions','A list of attribute definition ids and metadata in json format that are the recently used attribute definitions for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',10013,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','f96e8621b55040e7a2b3ab894c54fcaf',1459816167048,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapAdmins, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to ADMIN the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'3fea7db4ffe647099fa2eee1374c5a8f',NULL,NULL,NULL,NULL,NULL,1459816167051,NULL,'grouper','cd9d28020e3a447787049e087358a60b','etc:attribute:loaderLdap:grouperLoaderLdapAdmins','etc:attribute:loaderLdap:Grouper loader LDAP group admins','Comma separated subjectIds or subjectIdentifiers who will be allowed to ADMIN the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',10588,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','b9c217c7ab9246bc8ec1118d8d860376',1459816167689,'Added attributeDefName: etc:attribute:userData:grouperUserDataFavoriteSubjects',NULL,'grouperShell','2.2.2',0,'40eec854f0014b84bf616eb44e2cd1a6',NULL,NULL,NULL,NULL,NULL,1459816167690,NULL,'grouper','2ecf3496f4524f52b0001c4556b9ff80','etc:attribute:userData:grouperUserDataFavoriteSubjects','etc:attribute:userData:Grouper user data favorite subjects',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',15606,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','f9e41cffc7f5490eb7caf1f756aa7fbe',1459816166861,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression',NULL,'grouperShell','2.2.2',0,'41e06dbaf5a84ffc8d360fc01fe521c1',NULL,NULL,NULL,NULL,NULL,1459816166862,NULL,'grouper','1781bc622c7249029c32125733195f5e','etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression','etc:attribute:loaderLdap:Grouper loader LDAP subject expression',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',15323,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','3e63894cf9fb4395ba9160b5e820aea8',1459816162876,'Updated attributeDefName: etc:attribute:rules:ruleCheckOwnerName, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the check should be to see if rule should fire, this is owner of type, mutually exclusice with id\'',NULL,'grouperShell','2.2.2',0,'42089b891a704174a2f6b7e59051dfbb',NULL,NULL,NULL,NULL,NULL,1459816162882,NULL,'grouper','a2d29ed3ef434d4aaf2d865a1179159f','etc:attribute:rules:ruleCheckOwnerName','etc:attribute:rules:ruleCheckOwnerName','when the check should be to see if rule should fire, this is owner of type, mutually exclusice with id','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',14019,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','60e1e6d55f3d4a9f85f17b789e64ed61',1459816163257,'Updated attributeDefName: etc:attribute:rules:ruleIfConditionEnumArg1, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleIfConditionEnumArg1 if the if condition takes an argument, this is the second param\'',NULL,'grouperShell','2.2.2',0,'436505eeecf94661b23f586aa095af64',NULL,NULL,NULL,NULL,NULL,1459816163258,NULL,'grouper','5a2f5f08fbae41ff962d5142296866db','etc:attribute:rules:ruleIfConditionEnumArg1','etc:attribute:rules:ruleIfConditionEnumArg1','RuleIfConditionEnumArg1 if the if condition takes an argument, this is the second param','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',3451,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','fc5de2f0793c48fb8629387d1b83dc7f',1459816163290,'Updated attributeDefName: etc:attribute:rules:ruleIfStemScope, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the if part is a stem, this is the scope of SUB or ONE\'',NULL,'grouperShell','2.2.2',0,'45421fa738f44198aaa6aaffadde2e70',NULL,NULL,NULL,NULL,NULL,1459816163291,NULL,'grouper','730af7d2426945eca3bb0e3015aff089','etc:attribute:rules:ruleIfStemScope','etc:attribute:rules:ruleIfStemScope','when the if part is a stem, this is the scope of SUB or ONE','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',5809,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','029893a4cadc4eb78bf80e21516ace97',1459816163511,'Updated attributeDefName: etc:attribute:rules:ruleThenEnumArg2, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleThenEnum argument 2 to run when the rule fires (enum might need args)\'',NULL,'grouperShell','2.2.2',0,'457d5cee3e0446088eb2b7c453df7eff',NULL,NULL,NULL,NULL,NULL,1459816163516,NULL,'grouper','1a1c5f5bf5064e5fbfc30d723a93ac35','etc:attribute:rules:ruleThenEnumArg2','etc:attribute:rules:ruleThenEnumArg2','RuleThenEnum argument 2 to run when the rule fires (enum might need args)','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',11851,5,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','4f6e7d1adb7648b1a98d6a407eafb323',1459816161005,'Added stem: etc:legacy',NULL,'grouperShell','2.2.2',0,'469b7f7ec7e3445c8d18b35fc64d294a',NULL,NULL,NULL,NULL,NULL,1459816161007,NULL,'grouper','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy','47bf48f95b9a4c67855b091e3d1003de','etc:legacy','',NULL,NULL,NULL,'172.18.0.3',85863,29,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','5a35b80f8c9840ef992ef276e4666310',1459816164490,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderQuartzCron',NULL,'grouperShell','2.2.2',0,'4a840f043f66470fa23a6c7ba94f406e',NULL,NULL,NULL,NULL,NULL,1459816164511,NULL,'grouper','48190ef247ff41129988f08177726deb','etc:attribute:attrLoader:attributeLoaderQuartzCron','etc:attribute:attrLoader:attributeLoaderQuartzCron',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',42112,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','2204b4ae6558485088f69a193cc00db9',1459816161852,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate',NULL,'grouperShell','2.2.2',0,'4ad2f194b2f548c5b62fa0cef0adc01f',NULL,NULL,NULL,NULL,NULL,1459816161858,NULL,'grouper','e6638b1ff38c41b2a4a66d7de21295bc','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',36124,11,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','a4e080be1317422a9da9b129d8765a60',1459816163159,'Added attributeDefName: etc:attribute:rules:ruleIfConditionEnum',NULL,'grouperShell','2.2.2',0,'4c9e9c11a003418198bdb8a2290667a9',NULL,NULL,NULL,NULL,NULL,1459816163160,NULL,'grouper','fd1617992c834f03827ff8b836c38c8d','etc:attribute:rules:ruleIfConditionEnum','etc:attribute:rules:ruleIfConditionEnum',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',15534,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','9fee9ef7604646729ba78c1038edf99b',1459816166326,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapAndGroups',NULL,'grouperShell','2.2.2',0,'4e4c5038e9b648b4b657d84b830e1328',NULL,NULL,NULL,NULL,NULL,1459816166334,NULL,'grouper','db40a48a4ac943ac925a393858337d38','etc:attribute:loaderLdap:grouperLoaderLdapAndGroups','etc:attribute:loaderLdap:Grouper loader LDAP require in groups',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',15915,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','7314336d7419484cbebeb9e7695edead',1459816164307,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoader, Fields changed: description.\ndescription: FROM: \'null\', TO: \'is a loader based attribute def, the loader attributes will be available to be assigned\'',NULL,'grouperShell','2.2.2',0,'5022e02e4c3c4a5796c997c4b5a8d78a',NULL,NULL,NULL,NULL,NULL,1459816164308,NULL,'grouper','b1d07c0142ad43a7aa3d6a1a6e8fd0b4','etc:attribute:attrLoader:attributeLoader','etc:attribute:attrLoader:attributeLoader','is a loader based attribute def, the loader attributes will be available to be assigned','6cd4d8196fe24d21acd51cdf8fcdb3cc','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeDefLoaderTypeDef',NULL,'172.18.0.3',2927,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','71be3c3a1ed7438fa03a9f603684b57d',1459816167172,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapOptouts, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT OUT of the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'51ce7a9cd20a41299d5f9164c9233ce5',NULL,NULL,NULL,NULL,NULL,1459816167173,NULL,'grouper','50c66205af3e4df1ae709ffcb9d33670','etc:attribute:loaderLdap:grouperLoaderLdapOptouts','etc:attribute:loaderLdap:Grouper loader LDAP group optouts','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT OUT of the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',3851,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','44b4aeb178064ef997c86953a8092c52',1459816163011,'Updated attributeDefName: etc:attribute:rules:ruleCheckArg1, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the check needs an arg, this is the arg1\'',NULL,'grouperShell','2.2.2',0,'527b9af4600d453db2726ed8f1c267ed',NULL,NULL,NULL,NULL,NULL,1459816163015,NULL,'grouper','f5bb3d26042d4494b2a4826a03a8b0a1','etc:attribute:rules:ruleCheckArg1','etc:attribute:rules:ruleCheckArg1','when the check needs an arg, this is the arg1','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',6275,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','904c09b6b5794498bda9fd1c64cd2198',1459816162231,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail, Fields changed: description.\ndescription: FROM: \'null\', TO: \'email sent to user as invite\'',NULL,'grouperShell','2.2.2',0,'52a2cb670b3f4baab3adf2ca806fd8c8',NULL,NULL,NULL,NULL,NULL,1459816162234,NULL,'grouper','216aa4131e1e4233bdb1170ea3e2959a','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail','email sent to user as invite','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',9514,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','892af3b469b04b82901bfbd3834c5854',1459816167967,'Added attributeDefName: etc:attribute:userData:grouperUserDataFavoriteAttributeDefs',NULL,'grouperShell','2.2.2',0,'54b385d481024f05960a2e6dd1535201',NULL,NULL,NULL,NULL,NULL,1459816167968,NULL,'grouper','d049ee88c5dd43b49ec896c7b4c804e3','etc:attribute:userData:grouperUserDataFavoriteAttributeDefs','etc:attribute:userData:Grouper user data favorite attribute definitions',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',11061,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','ab69e171a3f94d74a462971922597b26',1459816167246,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_UPDATE on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'55109899d58f4e26aa5838a2621351f7',NULL,NULL,NULL,NULL,NULL,1459816167247,NULL,'grouper','5618f29e9f694d8da566f2ddaec01283','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters','etc:attribute:loaderLdap:Grouper loader LDAP group attribute updaters','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_UPDATE on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',4114,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','7332f754e23b47a1a8125d7082d2ff33',1459816163595,'Added attributeDefName: etc:attribute:rules:ruleRunDaemon',NULL,'grouperShell','2.2.2',0,'584669793e474cc58f50c9e8c19fe35d',NULL,NULL,NULL,NULL,NULL,1459816163598,NULL,'grouper','596537a994fe4969afb8b5b96f95a58e','etc:attribute:rules:ruleRunDaemon','etc:attribute:rules:ruleRunDaemon',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',25641,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','9b30d4ba08074e2191ff8bd06c074157',1459816166426,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapPriority, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if n...\'',NULL,'grouperShell','2.2.2',0,'5885c73bd1be447c802b0217782f64bf',NULL,NULL,NULL,NULL,NULL,1459816166429,NULL,'grouper','07ab972cc5c0444d805e096596685432','etc:attribute:loaderLdap:grouperLoaderLdapPriority','etc:attribute:loaderLdap:Grouper loader LDAP scheduling priority','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',10498,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','13f0586b4471492284b8272b4853df04',1459816163032,'Added attributeDefName: etc:attribute:rules:ruleIfOwnerId',NULL,'grouperShell','2.2.2',0,'5998ad556ca24121a71ad7266020980e',NULL,NULL,NULL,NULL,NULL,1459816163033,NULL,'grouper','f44cbb78b4594e0aa9ebb1d66bb1618a','etc:attribute:rules:ruleIfOwnerId','etc:attribute:rules:ruleIfOwnerId',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',9774,9,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','7b21a0f6bac34729967562807de21d63',1459816163685,'Added stem: etc:attribute:permissionLimits',NULL,'grouperShell','2.2.2',0,'599de562811d4bfb8f57af91ebb9126a',NULL,NULL,NULL,NULL,NULL,1459816163687,NULL,'grouper','b6bc2fcd772146ee970347e496538926','etc:attribute:permissionLimits','1730a44d087442cc96c2d8d63b655716','etc:attribute:permissionLimits','',NULL,NULL,NULL,'172.18.0.3',37155,30,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','8bb0132d8ae74ea8b6b83cb2402e59d6',1459816167128,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapOptins, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT IN to the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'5a690b65ca124fcb9cb13d9219e5aa34',NULL,NULL,NULL,NULL,NULL,1459816167134,NULL,'grouper','a58dc65ff39649cfaf72aa3389e1e9e8','etc:attribute:loaderLdap:grouperLoaderLdapOptins','etc:attribute:loaderLdap:Grouper loader LDAP group optins','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT IN to the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',10980,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','0ae63d112bdd42918f051d25548340d0',1459816158283,'Added group field: creators, id: a0f3df3f3afe4e28914131d26c413757, type: naming',NULL,'grouperShell','2.2.2',0,'5b1b4753f27941cb97fca033787703e8',NULL,NULL,NULL,NULL,NULL,1459816158283,NULL,'grouper','a0f3df3f3afe4e28914131d26c413757','creators',NULL,NULL,'naming',NULL,NULL,NULL,'172.18.0.3',11683,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','db2b08933797498289a1b2d786f33da3',1459816162958,'Added attributeDefName: etc:attribute:rules:ruleCheckArg0',NULL,'grouperShell','2.2.2',0,'5bdfb3e5b16a4920abf115ef9b06ada0',NULL,NULL,NULL,NULL,NULL,1459816162964,NULL,'grouper','4120ee09ca1d457b81744f71c1a0640a','etc:attribute:rules:ruleCheckArg0','etc:attribute:rules:ruleCheckArg0',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',15947,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','12c1032aef424fc79e6ba5b108343efa',1459816164586,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderIntervalSeconds, Fields changed: description.\ndescription: FROM: \'null\', TO: \'If a START_TO_START_INTERVAL schedule type, this is the number of seconds between runs\'',NULL,'grouperShell','2.2.2',0,'5c35156914254054b1e6dd426eaa546c',NULL,NULL,NULL,NULL,NULL,1459816164596,NULL,'grouper','fed11b1fd8d342ff8ddb84cee7d94b1d','etc:attribute:attrLoader:attributeLoaderIntervalSeconds','etc:attribute:attrLoader:attributeLoaderIntervalSeconds','If a START_TO_START_INTERVAL schedule type, this is the number of seconds between runs','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',19116,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','8f6c1d0d28ee4fe59643f1fc0efd1228',1459816163248,'Added attributeDefName: etc:attribute:rules:ruleIfConditionEnumArg1',NULL,'grouperShell','2.2.2',0,'5d3429991126405692c0958588a4a7aa',NULL,NULL,NULL,NULL,NULL,1459816163250,NULL,'grouper','5a2f5f08fbae41ff962d5142296866db','etc:attribute:rules:ruleIfConditionEnumArg1','etc:attribute:rules:ruleIfConditionEnumArg1',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',21666,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','3f3829c0d8714599853ad296e6a30af9',1459816162699,'Added attributeDefName: etc:attribute:rules:ruleActAsSubjectSourceId',NULL,'grouperShell','2.2.2',0,'5d4f7163174e473a9f60c989da9cef59',NULL,NULL,NULL,NULL,NULL,1459816162701,NULL,'grouper','012b580866d74696a897403090f19239','etc:attribute:rules:ruleActAsSubjectSourceId','etc:attribute:rules:ruleActAsSubjectSourceId',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',20441,9,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','9484aa1ec9af4b48b7e2db04840dd01e',1459816167331,'Added stem: etc:attribute:userData',NULL,'grouperShell','2.2.2',0,'5e02a2c8db06483a87c4c6d858080189',NULL,NULL,NULL,NULL,NULL,1459816167336,NULL,'grouper','cb1bfad6c8ed424d902b65d9ec275df0','etc:attribute:userData','1730a44d087442cc96c2d8d63b655716','etc:attribute:userData','',NULL,NULL,NULL,'172.18.0.3',66367,30,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','3740610bf1a74673bec8d40e5466184c',1459816164455,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderScheduleType, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Type of schedule.  Defaults to CRON if a cron schedule is entered, or START_TO_START_INTERVAL if an interval is entered\'',NULL,'grouperShell','2.2.2',0,'5e4577990ba34e0aacd074c27373c9f3',NULL,NULL,NULL,NULL,NULL,1459816164461,NULL,'grouper','1e858851f5a04d5d957d4ca242c3a520','etc:attribute:attrLoader:attributeLoaderScheduleType','etc:attribute:attrLoader:attributeLoaderScheduleType','Type of schedule.  Defaults to CRON if a cron schedule is entered, or START_TO_START_INTERVAL if an interval is entered','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',9705,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','c05f75a9c85b4fc5b59f1e54bfbd7e60',1459816166766,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression',NULL,'grouperShell','2.2.2',0,'62b8414f057d4a93b4a2514b8413b915',NULL,NULL,NULL,NULL,NULL,1459816166768,NULL,'grouper','39cfeba33b784b2da20a99fb80f674d7','etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression','etc:attribute:loaderLdap:Grouper loader LDAP group display name expression',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',22359,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','5557c2f4bcc34e2e8cd60c0204052972',1459816166529,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute',NULL,'grouperShell','2.2.2',0,'632d9701903044759aae6d80bb796cda',NULL,NULL,NULL,NULL,NULL,1459816166536,NULL,'grouper','644299b01bb54802ae883050a29f0a80','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute','etc:attribute:loaderLdap:Grouper loader LDAP group attribute name',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',35982,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','384e7f3803dd4e88a3d979c0dbb3f97d',1459816168211,'Updated attributeDefName: etc:attribute:entities:entitySubjectIdentifier, Fields changed: description.\ndescription: FROM: \'null\', TO: \'This overrides the subjectId of the entity\'',NULL,'grouperShell','2.2.2',0,'647a31390690409aaeaf860c43df9c80',NULL,NULL,NULL,NULL,NULL,1459816168212,NULL,'grouper','0e8f891baffa4efb8c503f893937ed72','etc:attribute:entities:entitySubjectIdentifier','etc:attribute:entities:entitySubjectIdentifier','This overrides the subjectId of the entity','2eee186e51494f0a874fe61ff24b7192','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef',NULL,'172.18.0.3',8077,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e22af44ed0bf4d11994899e5cfbb0779',1459816164033,'Added attributeDefName: etc:attribute:permissionLimits:limitAmountLessThan',NULL,'grouperShell','2.2.2',0,'65079f941ea1455f9c2e40726ef49a09',NULL,NULL,NULL,NULL,NULL,1459816164034,NULL,'grouper','bfdb438d9f03469fa76b4eab9d099384','etc:attribute:permissionLimits:limitAmountLessThan','etc:attribute:permissionLimits:amount less than',NULL,'b6bc2fcd772146ee970347e496538926','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt',NULL,'172.18.0.3',6066,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','6b7820c784f6420c9b089b2463a5fa77',1459816166685,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Value could be true or false (default to true).  If true, then there will be an error if there are unresolvable subjects in the results.  If you know there are subjects in LDAP which are not resolv...\'',NULL,'grouperShell','2.2.2',0,'65742a5f9888417389cb6b603f18b2d9',NULL,NULL,NULL,NULL,NULL,1459816166687,NULL,'grouper','cc4950adff3147fd8b36fbe2fc1c2e12','etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable','etc:attribute:loaderLdap:Grouper loader LDAP error unresolvable','Value could be true or false (default to true).  If true, then there will be an error if there are unresolvable subjects in the results.  If you know there are subjects in LDAP which are not resolvable by Grouper, set to false, they will be ignored','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',9716,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','fc0fb6d81b5647198e48d10e179402d0',1459816164650,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderPriority, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if n...\'',NULL,'grouperShell','2.2.2',0,'66850a0ab2294b46bf91facb88f5a0ee',NULL,NULL,NULL,NULL,NULL,1459816164658,NULL,'grouper','1c1293934a904003a4adcfdcafe4fd88','etc:attribute:attrLoader:attributeLoaderPriority','etc:attribute:attrLoader:attributeLoaderPriority','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',25722,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','b0e911e0c82d4fbbabe41c84e9a15759',1459816167769,'Added attributeDefName: etc:attribute:userData:grouperUserDataFavoriteStems',NULL,'grouperShell','2.2.2',0,'68a6ebe08b7344f5a6b9ac36964cf1b5',NULL,NULL,NULL,NULL,NULL,1459816167771,NULL,'grouper','7a9a1f6bccf84dda9159b82838440c01','etc:attribute:userData:grouperUserDataFavoriteStems','etc:attribute:userData:Grouper user data favorite folders',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',14547,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','b842c344e0b14fa58eedeb86267fb509',1459816162857,'Added attributeDefName: etc:attribute:rules:ruleCheckOwnerName',NULL,'grouperShell','2.2.2',0,'6941635742354077a8997eac650375bc',NULL,NULL,NULL,NULL,NULL,1459816162864,NULL,'grouper','a2d29ed3ef434d4aaf2d865a1179159f','etc:attribute:rules:ruleCheckOwnerName','etc:attribute:rules:ruleCheckOwnerName',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',39993,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','f2cf26e0ad9f45b18680e8f76bf966c4',1459816158129,'Added group field: attrOptins, id: 3d4dfe7f92184f03801ba09f35992de3, type: attributeDef',NULL,'grouperShell','2.2.2',0,'6aa91065dde0422c8bcbab33610e2304',NULL,NULL,NULL,NULL,NULL,1459816158129,NULL,'grouper','3d4dfe7f92184f03801ba09f35992de3','attrOptins',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',10544,3,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','73c6f0ccacd04367ba9444f6f4f41037',1459816158264,'Added group field: attrDefAttrUpdaters, id: 30d6952ca2314c5c8297c5560f24940f, type: attributeDef',NULL,'grouperShell','2.2.2',0,'6b3cec921b994a2da1bec13bd81c1224',NULL,NULL,NULL,NULL,NULL,1459816158264,NULL,'grouper','30d6952ca2314c5c8297c5560f24940f','attrDefAttrUpdaters',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',21193,3,'root'),('65947ffd4e364921a42c465d94a78c09','b2dea3614191424cbc4314bec387706b','99ec6323827447ebb566a0adbdada197',1459816168525,'Added group type: etc:legacy:attribute:legacyGroupType_grouperLoader',NULL,'grouperShell','2.2.2',0,'6b94fa995d294415b728be9f773d4551',NULL,NULL,NULL,NULL,NULL,1459816168525,NULL,'grouper','704fbc4dc6da4a52afa502200ffd05ff','etc:legacy:attribute:legacyGroupType_grouperLoader',NULL,NULL,NULL,NULL,NULL,NULL,'172.18.0.3',142836,39,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','7e814238d3b94d5bb9f173d1a74b4a14',1459816167778,'Updated attributeDefName: etc:attribute:userData:grouperUserDataFavoriteStems, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of folder ids and metadata in json format that are the favorites for a user\'',NULL,'grouperShell','2.2.2',0,'6c12bed929d941cb98397dfc6d8151b2',NULL,NULL,NULL,NULL,NULL,1459816167785,NULL,'grouper','7a9a1f6bccf84dda9159b82838440c01','etc:attribute:userData:grouperUserDataFavoriteStems','etc:attribute:userData:Grouper user data favorite folders','A list of folder ids and metadata in json format that are the favorites for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',11150,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','97145747376d46c0b93b8b0c0813b3ab',1459816167807,'Added attributeDefName: etc:attribute:userData:grouperUserDataRecentStems',NULL,'grouperShell','2.2.2',0,'6c68d753531441febfa73d03f4b144ae',NULL,NULL,NULL,NULL,NULL,1459816167808,NULL,'grouper','e0a40c9bef224ff3959d909777063368','etc:attribute:userData:grouperUserDataRecentStems','etc:attribute:userData:Grouper user data recent folders',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',18320,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','58e4bd301a9c4bbc856cf119801fa4ec',1459816166960,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapReaders, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to READ the group membership.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'6d6bbf63c860414a8bef4b5d2c8255a1',NULL,NULL,NULL,NULL,NULL,1459816166966,NULL,'grouper','45dd837ceb804d058a8701b473d00060','etc:attribute:loaderLdap:grouperLoaderLdapReaders','etc:attribute:loaderLdap:Grouper loader LDAP group readers','Comma separated subjectIds or subjectIdentifiers who will be allowed to READ the group membership.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',8319,5,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','00618952cb8b4705b94cd916a6713a4e',1459816165885,'Added attributeDef: etc:attribute:loaderLdap:grouperLoaderLdapDef',NULL,'grouperShell','2.2.2',0,'6ef823a313334ce3a2312481c1b167bb',NULL,NULL,NULL,NULL,NULL,1459816165886,NULL,'grouper','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdapDef',NULL,'094308af1376466687416c49f1f6495f',NULL,NULL,NULL,NULL,'172.18.0.3',52198,39,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','9020c22117504dceb753bc010b2d0088',1459816167621,'Added attributeDef: etc:attribute:userData:grouperUserDataValueDef',NULL,'grouperShell','2.2.2',0,'6f8d8e91c77843468914112b36525758',NULL,NULL,NULL,NULL,NULL,1459816167623,NULL,'grouper','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,NULL,NULL,'172.18.0.3',118580,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e1fb3f895a0e4e0d87235bbcfe4591de',1459816163119,'Added attributeDefName: etc:attribute:rules:ruleIfConditionEl',NULL,'grouperShell','2.2.2',0,'707c7339e83d4a5c8dcd62477a2832da',NULL,NULL,NULL,NULL,NULL,1459816163123,NULL,'grouper','2ce2cdca4b0040768a64021a88e8793c','etc:attribute:rules:ruleIfConditionEl','etc:attribute:rules:ruleIfConditionEl',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',17215,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','ed4069452f4f4f69b289e012ee25ee42',1459816167843,'Added attributeDefName: etc:attribute:userData:grouperUserDataRecentAttributeDefs',NULL,'grouperShell','2.2.2',0,'7099d006685e4d0ab27622bc016fc3e9',NULL,NULL,NULL,NULL,NULL,1459816167845,NULL,'grouper','b09cc09971d1458bb336aad641fdf526','etc:attribute:userData:grouperUserDataRecentAttributeDefs','etc:attribute:userData:Grouper user data recent attribute definitions',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',16201,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','d8dc9ab517a54835a37ec7035aeb189c',1459816166273,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSourceId',NULL,'grouperShell','2.2.2',0,'70eece8e6c0c4001b5aff4519ae8d8fd',NULL,NULL,NULL,NULL,NULL,1459816166274,NULL,'grouper','f867d93ca881408cb2191562a5b8cf36','etc:attribute:loaderLdap:grouperLoaderLdapSourceId','etc:attribute:loaderLdap:Grouper loader LDAP source ID',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',15467,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','74973c00475442e7a7eb279b0d0b2795',1459816163823,'Updated attributeDefName: etc:attribute:permissionLimits:limitExpression, Fields changed: description.\ndescription: FROM: \'null\', TO: \'An expression language limit has a value of an EL which evaluates to true or false\'',NULL,'grouperShell','2.2.2',0,'729253c6cbc248d89ceee78c52060c0a',NULL,NULL,NULL,NULL,NULL,1459816163824,NULL,'grouper','2bb97b35188345d69f54e9bbf2008553','etc:attribute:permissionLimits:limitExpression','etc:attribute:permissionLimits:Expression','An expression language limit has a value of an EL which evaluates to true or false','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',3633,5,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','e4639a3fb91d43a49bf595de9c390d53',1459816161236,'Added stem: etc:attribute',NULL,'grouperShell','2.2.2',0,'73551c616b0648f190c47ed485252041',NULL,NULL,NULL,NULL,NULL,1459816161242,NULL,'grouper','1730a44d087442cc96c2d8d63b655716','etc:attribute','47bf48f95b9a4c67855b091e3d1003de','etc:attribute','',NULL,NULL,NULL,'172.18.0.3',94327,29,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','cc4092f92f8648ad88febca2803b5852',1459816165915,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdap, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Marks a group to be processed by the Grouper loader as an LDAP synced job\'',NULL,'grouperShell','2.2.2',0,'740258017be14e078b96b73f57a9e2f5',NULL,NULL,NULL,NULL,NULL,1459816165918,NULL,'grouper','3d4e0066247c4a8d806fd0465fa19264','etc:attribute:loaderLdap:grouperLoaderLdap','etc:attribute:loaderLdap:Grouper loader LDAP','Marks a group to be processed by the Grouper loader as an LDAP synced job','094308af1376466687416c49f1f6495f','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdapDef',NULL,'172.18.0.3',7231,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','29a5f43e03ac4d4a8040e5f44289a96c',1459816162220,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail',NULL,'grouperShell','2.2.2',0,'740eb8be11f44619b388f48d9bc2ff73',NULL,NULL,NULL,NULL,NULL,1459816162222,NULL,'grouper','216aa4131e1e4233bdb1170ea3e2959a','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',7519,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','c42bfd30649c46cbacc3d770596da778',1459816164065,'Updated attributeDefName: etc:attribute:permissionLimits:limitAmountLessThanOrEqual, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Make sure the amount is less or equal to the configured value\'',NULL,'grouperShell','2.2.2',0,'7507cbca480c4a9f9db9dca0e736ca4f',NULL,NULL,NULL,NULL,NULL,1459816164066,NULL,'grouper','9738db9ed5c645f4a395c0ce24dba834','etc:attribute:permissionLimits:limitAmountLessThanOrEqual','etc:attribute:permissionLimits:amount less than or equal to','Make sure the amount is less or equal to the configured value','b6bc2fcd772146ee970347e496538926','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt',NULL,'172.18.0.3',8577,5,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','4804a077ec2c43899a5d981c4d45375f',1459816163982,'Added attributeDef: etc:attribute:permissionLimits:limitsDefInt',NULL,'grouperShell','2.2.2',0,'7612026e30324510833c1729f9bba3ed',NULL,NULL,NULL,NULL,NULL,1459816163983,NULL,'grouper','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,NULL,NULL,'172.18.0.3',63219,39,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','fe42467861024f97be880cd17c509fb1',1459816163395,'Updated attributeDefName: etc:attribute:rules:ruleThenEnumArg0, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleThenEnum argument 0 to run when the rule fires (enum might need args)\'',NULL,'grouperShell','2.2.2',0,'761f437c21174f7883967102103a8082',NULL,NULL,NULL,NULL,NULL,1459816163398,NULL,'grouper','053cf760d670452caa0f5c5f588639a1','etc:attribute:rules:ruleThenEnumArg0','etc:attribute:rules:ruleThenEnumArg0','RuleThenEnum argument 0 to run when the rule fires (enum might need args)','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',13460,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','71ee64b594a141f2b395ca39f83c7adf',1459816157888,'Added group field: admins, id: 2b05b3abce1e4d589fc89512f7d610d9, type: access',NULL,'grouperShell','2.2.2',0,'7684154b24194a94810719f006f62c44',NULL,NULL,NULL,NULL,NULL,1459816157888,NULL,'grouper','2b05b3abce1e4d589fc89512f7d610d9','admins',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',23932,3,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','440b456172304e84a5d01c0fada7d5b1',1459816157981,'Added group field: readers, id: 6ef6c29e94044581bdef90d074a04d45, type: access',NULL,'grouperShell','2.2.2',0,'770a239c62e0447aae9b61526a52a177',NULL,NULL,NULL,NULL,NULL,1459816157981,NULL,'grouper','6ef6c29e94044581bdef90d074a04d45','readers',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',19203,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','d7b19d36fcb74644b68ea985a3490a8b',1459816163215,'Updated attributeDefName: etc:attribute:rules:ruleIfConditionEnumArg0, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleIfConditionEnumArg0 if the if condition takes an argument, this is the first one\'',NULL,'grouperShell','2.2.2',0,'7894764848164abf948ed0881b06b37b',NULL,NULL,NULL,NULL,NULL,1459816163221,NULL,'grouper','f0dd0e291abc44e792b1cf49af78d2c7','etc:attribute:rules:ruleIfConditionEnumArg0','etc:attribute:rules:ruleIfConditionEnumArg0','RuleIfConditionEnumArg0 if the if condition takes an argument, this is the first one','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',10381,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','08c3a4d2942c48c58edbb640c96986af',1459816168048,'Added attributeDefName: etc:attribute:userData:grouperUserDataPreferences',NULL,'grouperShell','2.2.2',0,'789b732a6c4a4d34b9581171b8e051ed',NULL,NULL,NULL,NULL,NULL,1459816168049,NULL,'grouper','f3a4ba3f2ef441ec8834425942161c77','etc:attribute:userData:grouperUserDataPreferences','etc:attribute:userData:Grouper user data preferences',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',15941,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','94b0999935d344ec8a669da43b8a7174',1459816162406,'Added attributeDefName: etc:attribute:rules:rule',NULL,'grouperShell','2.2.2',0,'79497fd600fe42d3b3a8a62e6ff59a18',NULL,NULL,NULL,NULL,NULL,1459816162408,NULL,'grouper','529d4487e5ed4a27b594fcdfb79bc439','etc:attribute:rules:rule','etc:attribute:rules:rule',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rulesTypeDef',NULL,'172.18.0.3',9231,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','49a8efea093546c0b3894c0cd66e4ccb',1459816162908,'Added attributeDefName: etc:attribute:rules:ruleCheckStemScope',NULL,'grouperShell','2.2.2',0,'7b027f0d48bf425ba32c2912098b31c5',NULL,NULL,NULL,NULL,NULL,1459816162912,NULL,'grouper','08468c13269a4236921d4b33d272bffb','etc:attribute:rules:ruleCheckStemScope','etc:attribute:rules:ruleCheckStemScope',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',24631,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','550a2e3b9e1c477e9e2a360954940852',1459816168641,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderType',NULL,'grouperShell','2.2.2',0,'7b90b2292d324ef2b4184f66eb2506ce',NULL,NULL,NULL,NULL,NULL,1459816168641,NULL,'grouper','e4f3627722644627a5a53e5afac59a27','etc:legacy:attribute:legacyAttribute_grouperLoaderType','etc:legacy:attribute:legacyAttribute_grouperLoaderType',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',8652,7,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','274e27eda91a48b6addc6aa49fe50a8a',1459816157955,'Added group field: optins, id: 5cc53183805a46ee8b4d6795bf9548b6, type: access',NULL,'grouperShell','2.2.2',0,'7efb79adb8a9491095403b24a8fa5edf',NULL,NULL,NULL,NULL,NULL,1459816157956,NULL,'grouper','5cc53183805a46ee8b4d6795bf9548b6','optins',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',32707,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','48e769e82bde478f8d05f01b2614bedd',1459816163058,'Added attributeDefName: etc:attribute:rules:ruleIfOwnerName',NULL,'grouperShell','2.2.2',0,'82963d159eed4ff088a533e780e96055',NULL,NULL,NULL,NULL,NULL,1459816163074,NULL,'grouper','59a31621ed494f5e95710f2e44d45fdd','etc:attribute:rules:ruleIfOwnerName','etc:attribute:rules:ruleIfOwnerName',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',28805,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','6aaa31d5d19e434b90a39cbe959899a1',1459816164044,'Updated attributeDefName: etc:attribute:permissionLimits:limitAmountLessThan, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Make sure the amount is less than the configured value\'',NULL,'grouperShell','2.2.2',0,'8391e4e63f604da0b1bdf0e6a4f9d5de',NULL,NULL,NULL,NULL,NULL,1459816164045,NULL,'grouper','bfdb438d9f03469fa76b4eab9d099384','etc:attribute:permissionLimits:limitAmountLessThan','etc:attribute:permissionLimits:amount less than','Make sure the amount is less than the configured value','b6bc2fcd772146ee970347e496538926','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt',NULL,'172.18.0.3',8481,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e59ce96f5e484f12931f41af636c17e7',1459816162120,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid',NULL,'grouperShell','2.2.2',0,'840c68dfd82445abaa7cafc9ea129ea1',NULL,NULL,NULL,NULL,NULL,1459816162125,NULL,'grouper','35113e2566d843338966edd60c435059','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',18229,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','d3d7268b43794299808770f320638d6f',1459816166250,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Attribute name of the filter object result that holds the subject id.  Note, if you use \'dn\', and dn is not an attribute of the object, then the fully qualified object name will be used\'',NULL,'grouperShell','2.2.2',0,'84ac133bcccd4646897df287288dd993',NULL,NULL,NULL,NULL,NULL,1459816166252,NULL,'grouper','44116f0e5923417fb0b3b660db88604b','etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute','etc:attribute:loaderLdap:Grouper loader LDAP subject attribute name','Attribute name of the filter object result that holds the subject id.  Note, if you use \'dn\', and dn is not an attribute of the object, then the fully qualified object name will be used','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',5504,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','42fe5930327e41b3a115ce9012e5c2f9',1459816163328,'Updated attributeDefName: etc:attribute:rules:ruleThenEl, Fields changed: description.\ndescription: FROM: \'null\', TO: \'expression language to run when the rule fires\'',NULL,'grouperShell','2.2.2',0,'853dafa1123144c9aa4be7560989cc76',NULL,NULL,NULL,NULL,NULL,1459816163333,NULL,'grouper','4d09c98da01e4d5389b4cee05c54fc19','etc:attribute:rules:ruleThenEl','etc:attribute:rules:ruleThenEl','expression language to run when the rule fires','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',12467,5,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','8159789da0a14cafbd09145afa025cd8',1459816161769,'Added attributeDef: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'grouperShell','2.2.2',0,'8639454d41974fb48c72d0df59e95511',NULL,NULL,NULL,NULL,NULL,1459816161771,NULL,'grouper','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,NULL,NULL,'172.18.0.3',117476,41,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','797aa8a62bd3486a88ad5dbb5afea214',1459816163439,'Updated attributeDefName: etc:attribute:rules:ruleThenEnumArg1, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleThenEnum argument 1 to run when the rule fires (enum might need args)\'',NULL,'grouperShell','2.2.2',0,'8662c5636eab4c2d991b4e61329d75b9',NULL,NULL,NULL,NULL,NULL,1459816163446,NULL,'grouper','fa18c25e248e4ca0978c21ea2d6a17ef','etc:attribute:rules:ruleThenEnumArg1','etc:attribute:rules:ruleThenEnumArg1','RuleThenEnum argument 1 to run when the rule fires (enum might need args)','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',14058,5,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','2addfdcfc0b843ab9bf3fa03fe141cc7',1459816165989,'Added attributeDef: etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'grouperShell','2.2.2',0,'869ddba532bd434dae5da8e946f98bcf',NULL,NULL,NULL,NULL,NULL,1459816165992,NULL,'grouper','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'094308af1376466687416c49f1f6495f',NULL,NULL,NULL,NULL,'172.18.0.3',67286,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','dcdb24fd00514dd7a38a9ca1f53f4879',1459816164787,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderAttrSetQuery',NULL,'grouperShell','2.2.2',0,'87854024c36840a7ae5179c659b5ab7f',NULL,NULL,NULL,NULL,NULL,1459816164798,NULL,'grouper','3bce1c3e4f76410c95ffa832ca202cbc','etc:attribute:attrLoader:attributeLoaderAttrSetQuery','etc:attribute:attrLoader:attributeLoaderAttrSetQuery',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',34382,9,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','d8211cfa1a6b4abf99f5fab807eae57e',1459816161113,'Updated stem: etc:legacy:attribute, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'Folder for legacy attributes.  Do not delete.\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816161100\'',NULL,'grouperShell','2.2.2',0,'8a09427a861f488895f5c49bbe449359',NULL,NULL,NULL,NULL,NULL,1459816161114,NULL,'grouper','36792aa7956240feb1bb6025c56ff2f3','etc:legacy:attribute','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy:attribute','Folder for legacy attributes.  Do not delete.',NULL,NULL,NULL,'172.18.0.3',12386,4,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','73bd88d6231d4b5095c2ea5391619e3a',1459816168668,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderScheduleType',NULL,'grouperShell','2.2.2',0,'8a7b76d103aa48a2ab3c4a82aeb866b4',NULL,NULL,NULL,NULL,NULL,1459816168668,NULL,'grouper','a4cacb8e06cc4ad7bafc48491a68da70','etc:legacy:attribute:legacyAttribute_grouperLoaderScheduleType','etc:legacy:attribute:legacyAttribute_grouperLoaderScheduleType',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',6417,7,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','53353083cd3e4d82a586202045271442',1459816163356,'Updated attributeDefName: etc:attribute:rules:ruleThenEnum, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleThenEnum to run when the rule fires\'',NULL,'grouperShell','2.2.2',0,'8b681da4952f41f7a6107efac6401b62',NULL,NULL,NULL,NULL,NULL,1459816163360,NULL,'grouper','12dbd6f81fbc403e857ea8171ec087ee','etc:attribute:rules:ruleThenEnum','etc:attribute:rules:ruleThenEnum','RuleThenEnum to run when the rule fires','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',6483,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','52bcf03aebcb4dfd9239d48df40cca2e',1459816166920,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated GroupTypes which will be applied to the loaded groups.  The reason this enhancement exists is so we can do a group list filter and attach addIncludeExclude to the groups.  Note, if ...\'',NULL,'grouperShell','2.2.2',0,'8ce41a0b947f496a8a57145bbd1d0ee0',NULL,NULL,NULL,NULL,NULL,1459816166922,NULL,'grouper','d936518e709549ea942d07d26ecf45b9','etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes','etc:attribute:loaderLdap:Grouper loader LDAP group types','Comma separated GroupTypes which will be applied to the loaded groups.  The reason this enhancement exists is so we can do a group list filter and attach addIncludeExclude to the groups.  Note, if you do this (or use some requireGroups), the group name in the loader query should end in the system of record suffix, which by default is _systemOfRecord. optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',11268,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','0b7c9f116c6e460ea09a2fa20c0aebe6',1459816164524,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderQuartzCron, Fields changed: description.\ndescription: FROM: \'null\', TO: \'If a CRON schedule type, this is the cron setting string from the quartz product to run a job daily, hourly, weekly, etc.  e.g. daily at 7am: 0 0 7 * * ?\'',NULL,'grouperShell','2.2.2',0,'8d3a57de34364c33991262b5e1b7f22e',NULL,NULL,NULL,NULL,NULL,1459816164538,NULL,'grouper','48190ef247ff41129988f08177726deb','etc:attribute:attrLoader:attributeLoaderQuartzCron','etc:attribute:attrLoader:attributeLoaderQuartzCron','If a CRON schedule type, this is the cron setting string from the quartz product to run a job daily, hourly, weekly, etc.  e.g. daily at 7am: 0 0 7 * * ?','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',17010,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','ec4c66e9bdfe4206a088599b05bd9f08',1459816165020,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderActionQuery, Fields changed: description.\ndescription: FROM: \'null\', TO: \'SQL query with at least the following column: action_name\'',NULL,'grouperShell','2.2.2',0,'8edda8f84aee421385bff6d17b10ca23',NULL,NULL,NULL,NULL,NULL,1459816165021,NULL,'grouper','34f83b00843e4d8a914d6c32aa82510a','etc:attribute:attrLoader:attributeLoaderActionQuery','etc:attribute:attrLoader:attributeLoaderActionQuery','SQL query with at least the following column: action_name','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',3212,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','2a53e910238943af90f4e47bd422bd72',1459816164726,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderAttrQuery',NULL,'grouperShell','2.2.2',0,'90d34a4d12b64e4a9a9ee89f1eda3ff1',NULL,NULL,NULL,NULL,NULL,1459816164732,NULL,'grouper','c3d5cb11a5f446858470d00d7434020a','etc:attribute:attrLoader:attributeLoaderAttrQuery','etc:attribute:attrLoader:attributeLoaderAttrQuery',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',18314,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','9d772a6399824b78a976fc55e413f791',1459816168156,'Updated attributeDef: etc:attribute:entities:entitySubjectIdentifierDef, Fields changed: assignToGroup, attributeDefPublic, valueType.\nassignToGroup: FROM: \'false\', TO: \'true\'\nattributeDefPublic: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'914a3970d375411489993b35af16c17a',NULL,NULL,NULL,NULL,NULL,1459816168158,NULL,'grouper','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef',NULL,'2eee186e51494f0a874fe61ff24b7192',NULL,NULL,NULL,NULL,'172.18.0.3',7001,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','6c394b97dd7d4bb19f67fab033a9f2b6',1459816163621,'Updated attributeDefName: etc:attribute:rules:ruleRunDaemon, Fields changed: description.\ndescription: FROM: \'null\', TO: \'T|F for if this rule daemon should run.  Default to true if blank and check and if are enums, false if not\'',NULL,'grouperShell','2.2.2',0,'91b694815dba4445b053e73434a8e05c',NULL,NULL,NULL,NULL,NULL,1459816163625,NULL,'grouper','596537a994fe4969afb8b5b96f95a58e','etc:attribute:rules:ruleRunDaemon','etc:attribute:rules:ruleRunDaemon','T|F for if this rule daemon should run.  Default to true if blank and check and if are enums, false if not','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',15808,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','0bee8b8ab52546cc82faf4efb8ca212a',1459816166817,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression',NULL,'grouperShell','2.2.2',0,'923489fc8103481cb8ea7c3edc8c486d',NULL,NULL,NULL,NULL,NULL,1459816166818,NULL,'grouper','79d043c3041d4d0db005a220dc5a438d','etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression','etc:attribute:loaderLdap:Grouper loader LDAP group description expression',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',17334,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','038ff051b78649d7b942f1b7742ffa6b',1459816168626,'Updated attributeDef: etc:legacy:attribute:legacyAttributeDef_grouperLoader, Fields changed: assignToGroupAssn, valueType.\nassignToGroupAssn: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'938d8d561ef14420b73856e94cb9b4cc',NULL,NULL,NULL,NULL,NULL,1459816168626,NULL,'grouper','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,NULL,NULL,'172.18.0.3',3260,1,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','c66f39bfe9ca40278b54b0cac21c8159',1459816161924,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate, Fields changed: description.\ndescription: FROM: \'null\', TO: \'number of millis since 1970 that this invite was issued\'',NULL,'grouperShell','2.2.2',0,'93ddd7ccd59b4465988aee470ca61f17',NULL,NULL,NULL,NULL,NULL,1459816161927,NULL,'grouper','6b906f0d952b4c12a57c4b71d2e81001','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate','number of millis since 1970 that this invite was issued','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',13141,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','89e8281fe5ae408e8bd1730acae593bc',1459816158346,'Added group field: stemAttrUpdaters, id: 11552e71132c4bd8a199d9d7418cbc97, type: naming',NULL,'grouperShell','2.2.2',0,'93ff1f1ba54a4d5ea5d19c0a5e69aad9',NULL,NULL,NULL,NULL,NULL,1459816158346,NULL,'grouper','11552e71132c4bd8a199d9d7418cbc97','stemAttrUpdaters',NULL,NULL,'naming',NULL,NULL,NULL,'172.18.0.3',14184,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','a06f30635fb74eff9d01463b895bcb1f',1459816167652,'Added attributeDefName: etc:attribute:userData:grouperUserDataFavoriteGroups',NULL,'grouperShell','2.2.2',0,'95609433508840108933bc6907766d09',NULL,NULL,NULL,NULL,NULL,1459816167654,NULL,'grouper','199926a8d27b4b079b07b5be2b1c6b8a','etc:attribute:userData:grouperUserDataFavoriteGroups','etc:attribute:userData:Grouper user data favorite groups',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',15342,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','cff229a117bb426d94c1f4783b055920',1459816166112,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapServerId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Server ID that is configured in the grouper-loader.properties that identifies the connection information to the LDAP server\'',NULL,'grouperShell','2.2.2',0,'9689318ff1f645629bf35af82376f2de',NULL,NULL,NULL,NULL,NULL,1459816166116,NULL,'grouper','2b3af83bf1fe4868a942eb5c4b118685','etc:attribute:loaderLdap:grouperLoaderLdapServerId','etc:attribute:loaderLdap:Grouper loader LDAP server ID','Server ID that is configured in the grouper-loader.properties that identifies the connection information to the LDAP server','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',19257,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','bd01e198ce9f4a5cb5c50219e7106d60',1459816166832,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression, Fields changed: description.\ndescription: FROM: \'null\', TO: \'JEXL expression language fragment that evaluates to the group description, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'997d297e5a3d4351911c625ff1b88e88',NULL,NULL,NULL,NULL,NULL,1459816166837,NULL,'grouper','79d043c3041d4d0db005a220dc5a438d','etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression','etc:attribute:loaderLdap:Grouper loader LDAP group description expression','JEXL expression language fragment that evaluates to the group description, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',15172,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','1b329515ee054ec783c15e0070025c83',1459816157995,'Added group field: updaters, id: 0ad6ce292c314b10aa59cef878ab9a17, type: access',NULL,'grouperShell','2.2.2',0,'9b2177dc4d0b4439a490a1165bbd0760',NULL,NULL,NULL,NULL,NULL,1459816157996,NULL,'grouper','0ad6ce292c314b10aa59cef878ab9a17','updaters',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',6395,3,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','7bbeeff369ab4699bcbaf02e3beb0cd6',1459816163755,'Added attributeDef: etc:attribute:permissionLimits:limitsDef',NULL,'grouperShell','2.2.2',0,'9c49c2e478c646c5abfa37dc51121f85',NULL,NULL,NULL,NULL,NULL,1459816163756,NULL,'grouper','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,NULL,NULL,'172.18.0.3',52114,39,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','b5c5bac0e4644e918c0f400274a9c7c3',1459816166151,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapFilter, Fields changed: description.\ndescription: FROM: \'null\', TO: \'LDAP filter returns objects that have subjectIds or subjectIdentifiers and group name (if LDAP_GROUP_LIST)\'',NULL,'grouperShell','2.2.2',0,'9c623e295dbc4a59bcf7a9232c1693de',NULL,NULL,NULL,NULL,NULL,1459816166155,NULL,'grouper','0c5ed4a5aa354da6a527f811cd77f455','etc:attribute:loaderLdap:grouperLoaderLdapFilter','etc:attribute:loaderLdap:Grouper loader LDAP filter','LDAP filter returns objects that have subjectIds or subjectIdentifiers and group name (if LDAP_GROUP_LIST)','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',9258,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','618cb40edc454387a6a6ac165ef656fe',1459816164054,'Added attributeDefName: etc:attribute:permissionLimits:limitAmountLessThanOrEqual',NULL,'grouperShell','2.2.2',0,'9ca87b73a00141a69be3d6ac9b67eadf',NULL,NULL,NULL,NULL,NULL,1459816164056,NULL,'grouper','9738db9ed5c645f4a395c0ce24dba834','etc:attribute:permissionLimits:limitAmountLessThanOrEqual','etc:attribute:permissionLimits:amount less than or equal to',NULL,'b6bc2fcd772146ee970347e496538926','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt',NULL,'172.18.0.3',7184,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','674c7aedfd90423f873527799b6786b3',1459816158183,'Added group field: attrUpdaters, id: 6f085ccfe46845c4b98d83edc6e7da49, type: attributeDef',NULL,'grouperShell','2.2.2',0,'9ca99e4b443e42e282950e46103df65b',NULL,NULL,NULL,NULL,NULL,1459816158184,NULL,'grouper','6f085ccfe46845c4b98d83edc6e7da49','attrUpdaters',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',19101,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','ff95230673be4a338c69c7e423774475',1459816162789,'Added attributeDefName: etc:attribute:rules:ruleCheckOwnerId',NULL,'grouperShell','2.2.2',0,'9d0eabc86fb942f4894229bb0eb82083',NULL,NULL,NULL,NULL,NULL,1459816162790,NULL,'grouper','a26523b21e2f4e12bc93828349147061','etc:attribute:rules:ruleCheckOwnerId','etc:attribute:rules:ruleCheckOwnerId',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',25118,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','fe34fa3bb2d845b087281d5d90bf8368',1459816166587,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression, Fields changed: description.\ndescription: FROM: \'null\', TO: \'JEXL expression that returns true or false to signify if an attribute (in GROUPS_FROM_ATTRIBUTES) is ok to use for a group.  attributeValue is the variable that is the value of the attribute.\'',NULL,'grouperShell','2.2.2',0,'9da189234c284c98b26c8d692030477e',NULL,NULL,NULL,NULL,NULL,1459816166592,NULL,'grouper','20fc61b7fc8e4e889d1ce95b4d899cd1','etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression','etc:attribute:loaderLdap:Grouper loader LDAP attribute filter expression','JEXL expression that returns true or false to signify if an attribute (in GROUPS_FROM_ATTRIBUTES) is ok to use for a group.  attributeValue is the variable that is the value of the attribute.','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',9486,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','0d1219aff2494a05b4b4b43458acb079',1459816166407,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapPriority',NULL,'grouperShell','2.2.2',0,'9da34bbcb80d408d85cb5d0c67e03291',NULL,NULL,NULL,NULL,NULL,1459816166409,NULL,'grouper','07ab972cc5c0444d805e096596685432','etc:attribute:loaderLdap:grouperLoaderLdapPriority','etc:attribute:loaderLdap:Grouper loader LDAP scheduling priority',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',21675,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','c8be0a6effe04fda88c68a57e7f8bbbf',1459816167235,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters',NULL,'grouperShell','2.2.2',0,'9dabdb58d23748d8b8a5b9c0d5523b95',NULL,NULL,NULL,NULL,NULL,1459816167237,NULL,'grouper','5618f29e9f694d8da566f2ddaec01283','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters','etc:attribute:loaderLdap:Grouper loader LDAP group attribute updaters',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',21475,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','d5c17c61ca1f454ea5dd8cf0d914a1a6',1459816163874,'Updated attributeDefName: etc:attribute:permissionLimits:limitIpOnNetworkRealm, Fields changed: description.\ndescription: FROM: \'null\', TO: \'If the user is on an IP address on a centrally configured list of addresses\'',NULL,'grouperShell','2.2.2',0,'9faa179b6aec4d15a6d666f17dbfd812',NULL,NULL,NULL,NULL,NULL,1459816163876,NULL,'grouper','7135e07d5e314776b1e17833aee62ea4','etc:attribute:permissionLimits:limitIpOnNetworkRealm','etc:attribute:permissionLimits:ipAddress on network realm','If the user is on an IP address on a centrally configured list of addresses','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',3725,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','11af3ec686424b9cb0254bf82f62c5b2',1459816167821,'Updated attributeDefName: etc:attribute:userData:grouperUserDataRecentStems, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of folder ids and metadata in json format that are the recently used folders for a user\'',NULL,'grouperShell','2.2.2',0,'a0da8f14c4144d5eb8e4778fad3a8f72',NULL,NULL,NULL,NULL,NULL,1459816167823,NULL,'grouper','e0a40c9bef224ff3959d909777063368','etc:attribute:userData:grouperUserDataRecentStems','etc:attribute:userData:Grouper user data recent folders','A list of folder ids and metadata in json format that are the recently used folders for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',10093,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','94b790939f37416c9d2b6e9cdc6fd923',1459816158111,'Added group field: attrOptouts, id: 99d5358f26f74749904171eb52d12e5f, type: attributeDef',NULL,'grouperShell','2.2.2',0,'a38411f463f64b7fbfdcdc9709ee8ad6',NULL,NULL,NULL,NULL,NULL,1459816158111,NULL,'grouper','99d5358f26f74749904171eb52d12e5f','attrOptouts',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',20514,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','2e956bc7455b4499850e55c68090b3b8',1459816163275,'Added attributeDefName: etc:attribute:rules:ruleIfStemScope',NULL,'grouperShell','2.2.2',0,'a3e1ae801521416c94a1fabb2eefbaf5',NULL,NULL,NULL,NULL,NULL,1459816163282,NULL,'grouper','730af7d2426945eca3bb0e3015aff089','etc:attribute:rules:ruleIfStemScope','etc:attribute:rules:ruleIfStemScope',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',14936,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e866d25952e34dc9bd6ed26afb277c6e',1459816167072,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapUpdaters',NULL,'grouperShell','2.2.2',0,'a47d176db16e40a58309fb16acacf642',NULL,NULL,NULL,NULL,NULL,1459816167074,NULL,'grouper','d0147000b33c4cfcaa524e135adb4f43','etc:attribute:loaderLdap:grouperLoaderLdapUpdaters','etc:attribute:loaderLdap:Grouper loader LDAP group updaters',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',11224,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','431e2c4c3afa4fdebb2bcf81fbaff710',1459816161640,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInvite, Fields changed: description.\ndescription: FROM: \'null\', TO: \'is an invite\'',NULL,'grouperShell','2.2.2',0,'a4daa607ed694e6a83032a2e56aa31e8',NULL,NULL,NULL,NULL,NULL,1459816161647,NULL,'grouper','56f40c1d055147e78669a1be50159c53','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite','is an invite','d5248b39d72f4fdcb730d1be03de4fbc','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef',NULL,'172.18.0.3',18897,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','d0696d9069fe48f4ae34b29dc8d3cc25',1459816166365,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSearchScope',NULL,'grouperShell','2.2.2',0,'a6b91c4eecd641d9810304dac8b892b5',NULL,NULL,NULL,NULL,NULL,1459816166367,NULL,'grouper','2699a3d8d58644c395293106c83b0695','etc:attribute:loaderLdap:grouperLoaderLdapSearchScope','etc:attribute:loaderLdap:Grouper loader LDAP search scope',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',12751,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','74495ea72b434fbfbcf62c5a7a7ce3f9',1459816164836,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderActionQuery',NULL,'grouperShell','2.2.2',0,'a6c74a5bc2c444238996b71ba818c7e8',NULL,NULL,NULL,NULL,NULL,1459816164838,NULL,'grouper','34f83b00843e4d8a914d6c32aa82510a','etc:attribute:attrLoader:attributeLoaderActionQuery','etc:attribute:attrLoader:attributeLoaderActionQuery',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',16692,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','3e0ac8cccbd44997a161c1a89e7f29f8',1459816164390,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderType',NULL,'grouperShell','2.2.2',0,'a6d9de169a4e4b08b2b0f66c7667bf47',NULL,NULL,NULL,NULL,NULL,1459816164391,NULL,'grouper','582bfa600ca340aebed67753e38a430d','etc:attribute:attrLoader:attributeLoaderType','etc:attribute:attrLoader:attributeLoaderType',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',8944,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','07aaefb56552435db6413591c2a0186e',1459816162749,'Updated attributeDefName: etc:attribute:rules:ruleCheckType, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the check should be to see if rule should fire, enum: RuleCheckType\'',NULL,'grouperShell','2.2.2',0,'a74cc72547ee4005b5eb9c29e934c0d0',NULL,NULL,NULL,NULL,NULL,1459816162751,NULL,'grouper','28a96a63bd374b03b076ce1615d6e954','etc:attribute:rules:ruleCheckType','etc:attribute:rules:ruleCheckType','when the check should be to see if rule should fire, enum: RuleCheckType','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',4589,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','cca82fcdc1ae40048daeec7daeab4093',1459816163543,'Added attributeDefName: etc:attribute:rules:ruleValid',NULL,'grouperShell','2.2.2',0,'a8884b2a5fb64372a6353efeced0f6fc',NULL,NULL,NULL,NULL,NULL,1459816163547,NULL,'grouper','0f9eb01722f5496d9aae62e828406837','etc:attribute:rules:ruleValid','etc:attribute:rules:ruleValid',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',23262,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','7c7d8dbf4f8345da8ac3a657ff3d83be',1459816167004,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapViewers, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to VIEW the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'a88981fc611b4de291936332348a99ea',NULL,NULL,NULL,NULL,NULL,1459816167006,NULL,'grouper','a45ebbb8c7d54fce9701361f8184197f','etc:attribute:loaderLdap:grouperLoaderLdapViewers','etc:attribute:loaderLdap:Grouper loader LDAP group viewers','Comma separated subjectIds or subjectIdentifiers who will be allowed to VIEW the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',9390,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','d5831502745842dcaa6f4a3b8fc95138',1459816162015,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids',NULL,'grouperShell','2.2.2',0,'a911a65f6f404936a7deec9de8b77cf1',NULL,NULL,NULL,NULL,NULL,1459816162023,NULL,'grouper','f5aac6d1a9f94ee3870a7b3b56ab9ade','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',17411,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','4346c85c13cf4e96b2446942240d1a3e',1459816162172,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered',NULL,'grouperShell','2.2.2',0,'aa0a1834d7974f4bacb40bff29e6008d',NULL,NULL,NULL,NULL,NULL,1459816162173,NULL,'grouper','93bac907e57542689a532f2ae14f9cab','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',20052,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','0ffd3275e8ed4b5294a539897e8031e4',1459816164429,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderDbName, Fields changed: description.\ndescription: FROM: \'null\', TO: \'DB name in grouper-loader.properties or default grouper db if blank\'',NULL,'grouperShell','2.2.2',0,'ab45ca19800741c998b75314bf80f44e',NULL,NULL,NULL,NULL,NULL,1459816164431,NULL,'grouper','72ed919fa87448f6895ebdcdbc2ba25e','etc:attribute:attrLoader:attributeLoaderDbName','etc:attribute:attrLoader:attributeLoaderDbName','DB name in grouper-loader.properties or default grouper db if blank','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',5492,5,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','10df232bdb154681a373bf730966154f',1459816161310,'Updated stem: etc:attribute:attrExternalSubjectInvite, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in external subject invite attributes, and holds the data via attributes for invites.  Dont delete this folder\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816161308\'',NULL,'grouperShell','2.2.2',0,'ab7742b021e8494888b7b4f89f3cc4bc',NULL,NULL,NULL,NULL,NULL,1459816161312,NULL,'grouper','d5248b39d72f4fdcb730d1be03de4fbc','etc:attribute:attrExternalSubjectInvite','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrExternalSubjectInvite','folder for built in external subject invite attributes, and holds the data via attributes for invites.  Dont delete this folder',NULL,NULL,NULL,'172.18.0.3',3488,4,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','5f96fd1b64f646d2bb7bfb654e351e22',1459816166992,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapViewers',NULL,'grouperShell','2.2.2',0,'acdfa22a36d54292909c6521e0667d72',NULL,NULL,NULL,NULL,NULL,1459816166993,NULL,'grouper','a45ebbb8c7d54fce9701361f8184197f','etc:attribute:loaderLdap:grouperLoaderLdapViewers','etc:attribute:loaderLdap:Grouper loader LDAP group viewers',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',16857,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','f0642610737149abbf4f6883be48764f',1459816166216,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSearchDn',NULL,'grouperShell','2.2.2',0,'ad6c5b8cda464015b69dec2b47aa644e',NULL,NULL,NULL,NULL,NULL,1459816166219,NULL,'grouper','32b726ca079d423cbb80130baee2e731','etc:attribute:loaderLdap:grouperLoaderLdapSearchDn','etc:attribute:loaderLdap:Grouper loader LDAP search base DN',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',21045,9,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','2768fb08bd7c4eff90209d082ab4ff73',1459816164228,'Added stem: etc:attribute:attrLoader',NULL,'grouperShell','2.2.2',0,'add958e892c2414ab52f6d24b75f229c',NULL,NULL,NULL,NULL,NULL,1459816164229,NULL,'grouper','6cd4d8196fe24d21acd51cdf8fcdb3cc','etc:attribute:attrLoader','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrLoader','',NULL,NULL,NULL,'172.18.0.3',37794,30,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','73cbab28d09f47459ae272f0fc2a3479',1459816161529,'Added attributeDef: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef',NULL,'grouperShell','2.2.2',0,'af9f10e8562346b8904d8b8f3c5f7044',NULL,NULL,NULL,NULL,NULL,1459816161541,NULL,'grouper','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef',NULL,'d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,NULL,NULL,'172.18.0.3',196681,40,'root'),('65947ffd4e364921a42c465d94a78c09','11eac76db424484c86e10a8f817a78c3','253f8398dd0643ba99472aad14409f41',1459816164234,'Updated stem: etc:attribute:attrLoader, Fields changed: description, modifierUUID, modifyTime.\ndescription: FROM: \'null\', TO: \'folder for built in Grouper loader attributes\'\nmodifierUUID: FROM: \'null\', TO: \'65947ffd4e364921a42c465d94a78c09\'\nmodifyTime: FROM: \'0\', TO: \'1459816164231\'',NULL,'grouperShell','2.2.2',0,'b0e84f46bdb7432e8eeab75942414938',NULL,NULL,NULL,NULL,NULL,1459816164236,NULL,'grouper','6cd4d8196fe24d21acd51cdf8fcdb3cc','etc:attribute:attrLoader','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrLoader','folder for built in Grouper loader attributes',NULL,NULL,NULL,'172.18.0.3',4852,4,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','98ba1ea840d5404299ad811e5e2f1da2',1459816162382,'Added attributeDef: etc:attribute:rules:rulesTypeDef',NULL,'grouperShell','2.2.2',0,'b12d87d2ac9e4f3b938ced6c402ba037',NULL,NULL,NULL,NULL,NULL,1459816162384,NULL,'grouper','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rulesTypeDef',NULL,'fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,NULL,NULL,'172.18.0.3',64308,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','40561649fbce4373a84ed95089064d20',1459816166140,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapFilter',NULL,'grouperShell','2.2.2',0,'b241fe89893449ebba5c7c7daedfb9c9',NULL,NULL,NULL,NULL,NULL,1459816166142,NULL,'grouper','0c5ed4a5aa354da6a527f811cd77f455','etc:attribute:loaderLdap:grouperLoaderLdapFilter','etc:attribute:loaderLdap:Grouper loader LDAP filter',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',13388,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','578582bcb2f34cb8b89a44888a2d430c',1459816165890,'Updated attributeDef: etc:attribute:loaderLdap:grouperLoaderLdapDef, Fields changed: assignToGroup.\nassignToGroup: FROM: \'false\', TO: \'true\'',NULL,'grouperShell','2.2.2',0,'b34eada0b7884017b5fe95846976cd91',NULL,NULL,NULL,NULL,NULL,1459816165891,NULL,'grouper','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdapDef',NULL,'094308af1376466687416c49f1f6495f',NULL,NULL,NULL,NULL,'172.18.0.3',2009,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','f2eb81248e904048ad68ed7aafdcbacb',1459816163200,'Added attributeDefName: etc:attribute:rules:ruleIfConditionEnumArg0',NULL,'grouperShell','2.2.2',0,'b3d8335016f14443b951618f80507415',NULL,NULL,NULL,NULL,NULL,1459816163207,NULL,'grouper','f0dd0e291abc44e792b1cf49af78d2c7','etc:attribute:rules:ruleIfConditionEnumArg0','etc:attribute:rules:ruleIfConditionEnumArg0',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',19635,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','d1f8d61e04f14a0a89dcaef2e5ae9e4f',1459816167628,'Updated attributeDef: etc:attribute:userData:grouperUserDataValueDef, Fields changed: assignToImmMembershipAssn, valueType.\nassignToImmMembershipAssn: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'b4e4b6a53e624485a0c7f8bd89d0b607',NULL,NULL,NULL,NULL,NULL,1459816167631,NULL,'grouper','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,NULL,NULL,'172.18.0.3',4531,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','d992665496bd470f9d047184e8caf337',1459816162137,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid, Fields changed: description.\ndescription: FROM: \'null\', TO: \'unique id in the email sent to the user\'',NULL,'grouperShell','2.2.2',0,'b6b91d40bf0f48e9a4076952df1d9fc1',NULL,NULL,NULL,NULL,NULL,1459816162147,NULL,'grouper','35113e2566d843338966edd60c435059','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid','unique id in the email sent to the user','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',16899,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','2df9149731144275bdf6d6c73a46545a',1459816167036,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapAdmins',NULL,'grouperShell','2.2.2',0,'b6d3a22c0eae4aa485fc5d638576e608',NULL,NULL,NULL,NULL,NULL,1459816167037,NULL,'grouper','cd9d28020e3a447787049e087358a60b','etc:attribute:loaderLdap:grouperLoaderLdapAdmins','etc:attribute:loaderLdap:Grouper loader LDAP group admins',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',22106,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','cc27d3ecc6814ca89654ceee86cdd07e',1459816166672,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable',NULL,'grouperShell','2.2.2',0,'b7335a146117433da7a3ac592f5ef681',NULL,NULL,NULL,NULL,NULL,1459816166673,NULL,'grouper','cc4950adff3147fd8b36fbe2fc1c2e12','etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable','etc:attribute:loaderLdap:Grouper loader LDAP error unresolvable',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',14743,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','4a97bd0cc2b4401b97dda3d406b22cd4',1459816164132,'Updated attributeDef: etc:attribute:permissionLimits:limitsDefMarker, Fields changed: assignToAttributeDef, assignToEffMembership, assignToEffMembershipAssn, assignToGroup, assignToGroupAssn, multiAssignable.\nassignToAttributeDef: FROM: \'false\', TO: \'true\'\nassignToEffMembership: FROM: \'false\', TO: \'true\'\nassignToEffMembershipAssn: FROM: \'false\', TO: \'true\'\nassignToGroup: FROM: \'false\', TO: \'true\'\nassignToGroupAssn: FROM: \'false\', TO: \'true\'\nmultiAssignable: FROM: \'false\', TO: \'true\'',NULL,'grouperShell','2.2.2',0,'b88e0778d99045e3bf720f26fa4fa1e1',NULL,NULL,NULL,NULL,NULL,1459816164133,NULL,'grouper','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,NULL,NULL,'172.18.0.3',4613,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','b95da9343fb2492ebaa7fb1d3a7c32ca',1459816162088,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'member id who invited this user\'',NULL,'grouperShell','2.2.2',0,'b88f5f60bd3b4928ad3ec8098354c3a1',NULL,NULL,NULL,NULL,NULL,1459816162093,NULL,'grouper','855fd99c277c4e069e0ffa2b052d89d3','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId','member id who invited this user','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',10749,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','b5986f512dd54d30bb7bc42410b77220',1459816167200,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders',NULL,'grouperShell','2.2.2',0,'b8b413e54f5e4458950f1ff6fa2bf375',NULL,NULL,NULL,NULL,NULL,1459816167201,NULL,'grouper','2fa06802299b49d4b186fa96c52a077e','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders','etc:attribute:loaderLdap:Grouper loader LDAP group attribute readers',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',19807,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','7dfd6f20794b4a5a8fdd969a44ed54f8',1459816162969,'Updated attributeDefName: etc:attribute:rules:ruleCheckArg0, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the check needs an arg, this is the arg0\'',NULL,'grouperShell','2.2.2',0,'b9ccfd7cdb794c079dbbcb36bd7a2159',NULL,NULL,NULL,NULL,NULL,1459816162970,NULL,'grouper','4120ee09ca1d457b81744f71c1a0640a','etc:attribute:rules:ruleCheckArg0','etc:attribute:rules:ruleCheckArg0','when the check needs an arg, this is the arg0','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',3253,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','12333b5e3a464b899fa58c020f81e411',1459816162599,'Added attributeDefName: etc:attribute:rules:ruleActAsSubjectId',NULL,'grouperShell','2.2.2',0,'ba4a9f0b14a04e6c8afee685d60af921',NULL,NULL,NULL,NULL,NULL,1459816162608,NULL,'grouper','74166e5b8b8b4662afc4497c52faf6bc','etc:attribute:rules:ruleActAsSubjectId','etc:attribute:rules:ruleActAsSubjectId',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',22269,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','50f7eb6957804887bb1d70ad5359ce86',1459816168680,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderQuery',NULL,'grouperShell','2.2.2',0,'ba58a0a234444fa8af919797d43071b1',NULL,NULL,NULL,NULL,NULL,1459816168680,NULL,'grouper','5cebc34e1bdc49e1a3c616ec88c7ff7a','etc:legacy:attribute:legacyAttribute_grouperLoaderQuery','etc:legacy:attribute:legacyAttribute_grouperLoaderQuery',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',8605,7,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','36522194fa7049c4944f1023c14e20e0',1459816165996,'Updated attributeDef: etc:attribute:loaderLdap:grouperLoaderLdapValueDef, Fields changed: assignToGroupAssn, valueType.\nassignToGroupAssn: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'bc6674621dd94d9ca4b2b3dbbd819a19',NULL,NULL,NULL,NULL,NULL,1459816165998,NULL,'grouper','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'094308af1376466687416c49f1f6495f',NULL,NULL,NULL,NULL,'172.18.0.3',2872,3,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','b9307b3c26ab440d91b270b950336d12',1459816162536,'Added attributeDef: etc:attribute:rules:rulesAttrDef',NULL,'grouperShell','2.2.2',0,'bd3332b24a6f4ed8adc9392d5c21be76',NULL,NULL,NULL,NULL,NULL,1459816162543,NULL,'grouper','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,NULL,NULL,'172.18.0.3',121379,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','9b0d0d75e1824ae0a5f3e1bfcb9c8d6f',1459816164443,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderScheduleType',NULL,'grouperShell','2.2.2',0,'bf5618a3c3a14240aa92ccaf691d0663',NULL,NULL,NULL,NULL,NULL,1459816164447,NULL,'grouper','1e858851f5a04d5d957d4ca242c3a520','etc:attribute:attrLoader:attributeLoaderScheduleType','etc:attribute:attrLoader:attributeLoaderScheduleType',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',11213,9,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','fc2f092a364b44df9ad23b591e48c385',1459816164288,'Updated attributeDef: etc:attribute:attrLoader:attributeDefLoaderTypeDef, Fields changed: assignToAttributeDef.\nassignToAttributeDef: FROM: \'false\', TO: \'true\'',NULL,'grouperShell','2.2.2',0,'bf7fc5f1ffb047dd9972f0275b05c4ec',NULL,NULL,NULL,NULL,NULL,1459816164290,NULL,'grouper','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeDefLoaderTypeDef',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,NULL,NULL,'172.18.0.3',3708,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','bc0cd5e3ce104a13af5eba779f78ab77',1459816164171,'Added attributeDefName: etc:attribute:permissionLimits:limitWeekday9to5',NULL,'grouperShell','2.2.2',0,'bf8c33b3a2ea488cbd82d73ce5616f32',NULL,NULL,NULL,NULL,NULL,1459816164172,NULL,'grouper','edf4fcdbbff1447e8951e6e07a38c6e3','etc:attribute:permissionLimits:limitWeekday9to5','etc:attribute:permissionLimits:Weekday 9 to 5',NULL,'b6bc2fcd772146ee970347e496538926','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker',NULL,'172.18.0.3',14266,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','1d659db0efdb4062a2192fefbe41f70b',1459816161976,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress, Fields changed: description.\ndescription: FROM: \'null\', TO: \'email address this invite was sent to\'',NULL,'grouperShell','2.2.2',0,'bff52274749a428997aad63d8799e446',NULL,NULL,NULL,NULL,NULL,1459816161981,NULL,'grouper','1e49b63b42bf443c93cd5119e5bc745a','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress','email address this invite was sent to','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',8916,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','e72f8e885d3b4c0799b5394134dced69',1459816163562,'Updated attributeDefName: etc:attribute:rules:ruleValid, Fields changed: description.\ndescription: FROM: \'null\', TO: \'T|F for if this rule is valid, or the reason, managed by hook automatically\'',NULL,'grouperShell','2.2.2',0,'c028f4f0a7de4677ae4e6e520a850ecc',NULL,NULL,NULL,NULL,NULL,1459816163566,NULL,'grouper','0f9eb01722f5496d9aae62e828406837','etc:attribute:rules:ruleValid','etc:attribute:rules:ruleValid','T|F for if this rule is valid, or the reason, managed by hook automatically','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',11748,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','32bdd3c749074e56bc0f86b21c558255',1459816166450,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike',NULL,'grouperShell','2.2.2',0,'c032612d7b5042c6a3e9cb95066cd579',NULL,NULL,NULL,NULL,NULL,1459816166452,NULL,'grouper','805535775c484f7fbedfaa6ec1837ee7','etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike','etc:attribute:loaderLdap:Grouper loader LDAP groups like',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',12554,9,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','b62e1c7566d14267a62216d2aed227b6',1459816165657,'Added stem: etc:attribute:loaderLdap',NULL,'grouperShell','2.2.2',0,'c071008f6e8f46b6a6cf3bdce2a05442',NULL,NULL,NULL,NULL,NULL,1459816165658,NULL,'grouper','094308af1376466687416c49f1f6495f','etc:attribute:loaderLdap','1730a44d087442cc96c2d8d63b655716','etc:attribute:loaderLdap','',NULL,NULL,NULL,'172.18.0.3',178311,30,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','74964979480f45a99af1f992e540767e',1459816158326,'Added group field: stemAttrReaders, id: a9f4b02397d24462a45d981ade0c339e, type: naming',NULL,'grouperShell','2.2.2',0,'c1bbfc957b8d4594a98545dcc218a005',NULL,NULL,NULL,NULL,NULL,1459816158326,NULL,'grouper','a9f4b02397d24462a45d981ade0c339e','stemAttrReaders',NULL,NULL,'naming',NULL,NULL,NULL,'172.18.0.3',16054,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','4cb3515cfc654061a5acb2a8a3610996',1459816164744,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderAttrQuery, Fields changed: description.\ndescription: FROM: \'null\', TO: \'SQL query with at least some of the following columns: attr_name, attr_display_name, attr_description\'',NULL,'grouperShell','2.2.2',0,'c205bcea888e43a69671f6732475ad62',NULL,NULL,NULL,NULL,NULL,1459816164757,NULL,'grouper','c3d5cb11a5f446858470d00d7434020a','etc:attribute:attrLoader:attributeLoaderAttrQuery','etc:attribute:attrLoader:attributeLoaderAttrQuery','SQL query with at least some of the following columns: attr_name, attr_display_name, attr_description','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',18873,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','213c93d5247d4cac82b6525659623b61',1459816166009,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapType',NULL,'grouperShell','2.2.2',0,'c6e45f608836459ca4bb0a1ba7b9b00a',NULL,NULL,NULL,NULL,NULL,1459816166010,NULL,'grouper','c3d2e8d1b61b481a92b96a5c564e6d29','etc:attribute:loaderLdap:grouperLoaderLdapType','etc:attribute:loaderLdap:Grouper loader LDAP type',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',8283,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','fc8c02098db44dd4a84b96e6bd7fdfd7',1459816164622,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderPriority',NULL,'grouperShell','2.2.2',0,'c779a7bb362f4c9e8b1284df692fa88e',NULL,NULL,NULL,NULL,NULL,1459816164624,NULL,'grouper','1c1293934a904003a4adcfdcafe4fd88','etc:attribute:attrLoader:attributeLoaderPriority','etc:attribute:attrLoader:attributeLoaderPriority',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',19688,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','6deb2d2beb9a477cb797e24e171a4afd',1459816157912,'Added group field: optouts, id: 5ea33c8d1890401cad243bb7b765d76b, type: access',NULL,'grouperShell','2.2.2',0,'c79db9dceea448ca8253d95e4d7ca6be',NULL,NULL,NULL,NULL,NULL,1459816157912,NULL,'grouper','5ea33c8d1890401cad243bb7b765d76b','optouts',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',18940,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','eeca4330ac3a49759b7d116f1848a898',1459816168009,'Added attributeDefName: etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames',NULL,'grouperShell','2.2.2',0,'c969fcc47a3441b1bc95f5ebfd40358e',NULL,NULL,NULL,NULL,NULL,1459816168010,NULL,'grouper','c3119a12e06041959f4c69b4078dc8f9','etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames','etc:attribute:userData:Grouper user data favorite attribute definition names',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',17437,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','a264a6db242a4c09b29fa40022439623',1459816161619,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInvite',NULL,'grouperShell','2.2.2',0,'ca928ec6ce754d2facfb357676481b73',NULL,NULL,NULL,NULL,NULL,1459816161620,NULL,'grouper','56f40c1d055147e78669a1be50159c53','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef',NULL,'172.18.0.3',21000,10,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','cc9ba9ab69e64d0c9c9ba96f0f506ce4',1459816168620,'Added attributeDef: etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'grouperShell','2.2.2',0,'cacf7275bd3e4b72945303b93445b350',NULL,NULL,NULL,NULL,NULL,1459816168620,NULL,'grouper','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,NULL,NULL,'172.18.0.3',64762,24,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','157e1da236944b37997285a6ce4d64f5',1459816163311,'Added attributeDefName: etc:attribute:rules:ruleThenEl',NULL,'grouperShell','2.2.2',0,'cb101506c57e4226baa0b807201463e7',NULL,NULL,NULL,NULL,NULL,1459816163313,NULL,'grouper','4d09c98da01e4d5389b4cee05c54fc19','etc:attribute:rules:ruleThenEl','etc:attribute:rules:ruleThenEl',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',16296,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','2013dba4ecb940b8bb5845e351ed4779',1459816167209,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_READ on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'cd1307cb6d0c4b94aa446cce33c6f382',NULL,NULL,NULL,NULL,NULL,1459816167211,NULL,'grouper','2fa06802299b49d4b186fa96c52a077e','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders','etc:attribute:loaderLdap:Grouper loader LDAP group attribute readers','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_READ on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',6476,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','4f4b9e2f768848f18b536c37418d3b1f',1459816164178,'Updated attributeDefName: etc:attribute:permissionLimits:limitWeekday9to5, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Make sure the check for the permission happens between 9am to 5pm on Monday through Friday\'',NULL,'grouperShell','2.2.2',0,'cd859836258a42baad1e3658feac4a70',NULL,NULL,NULL,NULL,NULL,1459816164179,NULL,'grouper','edf4fcdbbff1447e8951e6e07a38c6e3','etc:attribute:permissionLimits:limitWeekday9to5','etc:attribute:permissionLimits:Weekday 9 to 5','Make sure the check for the permission happens between 9am to 5pm on Monday through Friday','b6bc2fcd772146ee970347e496538926','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker',NULL,'172.18.0.3',3670,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','f04b3e10d0534430bf551971a4c6642b',1459816165203,'Added attributeDefName: etc:attribute:attrLoader:attributeLoaderActionSetQuery',NULL,'grouperShell','2.2.2',0,'ce599395d5da48ec91046888e27f8cc7',NULL,NULL,NULL,NULL,NULL,1459816165204,NULL,'grouper','8e84b513b4e948b99127d0fa84a53e78','etc:attribute:attrLoader:attributeLoaderActionSetQuery','etc:attribute:attrLoader:attributeLoaderActionSetQuery',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',96519,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','77176320181c4d7b91ea95a91d490c63',1459816168786,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderGroupsLike',NULL,'grouperShell','2.2.2',0,'ce81bed41d224ab99820292f129b740d',NULL,NULL,NULL,NULL,NULL,1459816168786,NULL,'grouper','6ef48c395597459d9810bf0aac859903','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupsLike','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupsLike',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',12499,7,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','d1fd6f37aecd49a39a5d13179058a5b3',1459816167880,'Added attributeDefName: etc:attribute:userData:grouperUserDataRecentAttributeDefNames',NULL,'grouperShell','2.2.2',0,'d119c785789242c39ce23a497ec9fe4e',NULL,NULL,NULL,NULL,NULL,1459816167886,NULL,'grouper','4477e4a117514f2e900f7aff92c808ab','etc:attribute:userData:grouperUserDataRecentAttributeDefNames','etc:attribute:userData:Grouper user data recent attribute definition names',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',16884,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','90e91ff27cd24a0db42d833427a7352c',1459816163418,'Added attributeDefName: etc:attribute:rules:ruleThenEnumArg1',NULL,'grouperShell','2.2.2',0,'d11cb9639d94428987459be490955692',NULL,NULL,NULL,NULL,NULL,1459816163420,NULL,'grouper','fa18c25e248e4ca0978c21ea2d6a17ef','etc:attribute:rules:ruleThenEnumArg1','etc:attribute:rules:ruleThenEnumArg1',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',16714,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','e0e22b1ca4be420582969eb2ee1e232b',1459816162736,'Added attributeDefName: etc:attribute:rules:ruleCheckType',NULL,'grouperShell','2.2.2',0,'d2340a8f31034a798e8c15acad802ec5',NULL,NULL,NULL,NULL,NULL,1459816162739,NULL,'grouper','28a96a63bd374b03b076ce1615d6e954','etc:attribute:rules:ruleCheckType','etc:attribute:rules:ruleCheckType',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',16184,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','c6b3165c47de4bf89bacbb42df35e220',1459816166712,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression',NULL,'grouperShell','2.2.2',0,'d257519ef42a45639da0aab81e42b742',NULL,NULL,NULL,NULL,NULL,1459816166713,NULL,'grouper','8088e8e830e24be2beded12f94412c79','etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression','etc:attribute:loaderLdap:Grouper loader LDAP group name expression',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',9440,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','aed2bf6b78934ee9847a0b2b9e31d0d9',1459816166020,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapType, Fields changed: description.\ndescription: FROM: \'null\', TO: \'This holds the type of job from the GrouperLoaderType enum, currently the only valid values are LDAP_SIMPLE, LDAP_GROUP_LIST, LDAP_GROUPS_FROM_ATTRIBUTES. Simple is a group loaded from LDAP filter ...\'',NULL,'grouperShell','2.2.2',0,'d3eeb5f5bcbe422f8b6c6c73097bd5b3',NULL,NULL,NULL,NULL,NULL,1459816166022,NULL,'grouper','c3d2e8d1b61b481a92b96a5c564e6d29','etc:attribute:loaderLdap:grouperLoaderLdapType','etc:attribute:loaderLdap:Grouper loader LDAP type','This holds the type of job from the GrouperLoaderType enum, currently the only valid values are LDAP_SIMPLE, LDAP_GROUP_LIST, LDAP_GROUPS_FROM_ATTRIBUTES. Simple is a group loaded from LDAP filter which returns subject ids or identifiers.  Group list is an LDAP filter which returns group objects, and the group objects have a list of subjects.  Groups from attributes is an LDAP filter that returns subjects which have a multi-valued attribute e.g. affiliations where groups will be created based on subject who have each attribute value  ','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',8244,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','2096c96bf5e14bbba9debadd18df822e',1459816162201,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered, Fields changed: description.\ndescription: FROM: \'null\', TO: \'email addresses to notify when the user registers\'',NULL,'grouperShell','2.2.2',0,'d6183870036946b1a949c231f3db6dd6',NULL,NULL,NULL,NULL,NULL,1459816162205,NULL,'grouper','93bac907e57542689a532f2ae14f9cab','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered','email addresses to notify when the user registers','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',23233,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','04e9d97ec9c646d785911c32a84a6586',1459816163350,'Added attributeDefName: etc:attribute:rules:ruleThenEnum',NULL,'grouperShell','2.2.2',0,'d7208793909e493582f9bfe25b1e1fa6',NULL,NULL,NULL,NULL,NULL,1459816163351,NULL,'grouper','12dbd6f81fbc403e857ea8171ec087ee','etc:attribute:rules:ruleThenEnum','etc:attribute:rules:ruleThenEnum',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',11921,9,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','4b0ae9a3ce024543b16d07c907e0ac50',1459816158067,'Added group field: groupAttrUpdaters, id: 76ae221cea544a4f807ac377e2effa8f, type: access',NULL,'grouperShell','2.2.2',0,'d82c45ff505045c79422c4204a239cf5',NULL,NULL,NULL,NULL,NULL,1459816158067,NULL,'grouper','76ae221cea544a4f807ac377e2effa8f','groupAttrUpdaters',NULL,NULL,'access',NULL,NULL,NULL,'172.18.0.3',23221,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','948da685462a4f3ab6fcc6398b18f7b7',1459816166573,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression',NULL,'grouperShell','2.2.2',0,'d8391659e112412b925cfe712117b266',NULL,NULL,NULL,NULL,NULL,1459816166575,NULL,'grouper','20fc61b7fc8e4e889d1ce95b4d899cd1','etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression','etc:attribute:loaderLdap:Grouper loader LDAP attribute filter expression',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',7857,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','299caa66b75e45b78c785c7b648c8191',1459816167923,'Added attributeDefName: etc:attribute:userData:grouperUserDataRecentSubjects',NULL,'grouperShell','2.2.2',0,'da4a09746458440495ca3f59f61b6f9c',NULL,NULL,NULL,NULL,NULL,1459816167929,NULL,'grouper','de2074da9cd64e9393d7638e135ce76c','etc:attribute:userData:grouperUserDataRecentSubjects','etc:attribute:userData:Grouper user data recent subjects',NULL,'cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',24487,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','c659c4ad06254a69ad2cb49f19fc4478',1459816166227,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSearchDn, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Location that constrains the subtree where the filter is applicable\'',NULL,'grouperShell','2.2.2',0,'db13fc0cdee749dbacffd1ed2f1f59e9',NULL,NULL,NULL,NULL,NULL,1459816166229,NULL,'grouper','32b726ca079d423cbb80130baee2e731','etc:attribute:loaderLdap:grouperLoaderLdapSearchDn','etc:attribute:loaderLdap:Grouper loader LDAP search base DN','Location that constrains the subtree where the filter is applicable','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',5112,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','82582d20b4c64d8fa72df227ead44184',1459816168752,'Added attributeDefName: etc:legacy:attribute:legacyAttribute_grouperLoaderAndGroups',NULL,'grouperShell','2.2.2',0,'de0379e5081a4689aa25e1c80a95b2a1',NULL,NULL,NULL,NULL,NULL,1459816168752,NULL,'grouper','f3edb985d6e2480da4ad894eda3b620b','etc:legacy:attribute:legacyAttribute_grouperLoaderAndGroups','etc:legacy:attribute:legacyAttribute_grouperLoaderAndGroups',NULL,'36792aa7956240feb1bb6025c56ff2f3','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader',NULL,'172.18.0.3',14359,7,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','f4e8d347885d469aa092de93a557a2e2',1459816167696,'Updated attributeDefName: etc:attribute:userData:grouperUserDataFavoriteSubjects, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of member ids and metadata in json format that are the favorites for a user\'',NULL,'grouperShell','2.2.2',0,'df036d5462344dd9962c418625726a2b',NULL,NULL,NULL,NULL,NULL,1459816167699,NULL,'grouper','2ecf3496f4524f52b0001c4556b9ff80','etc:attribute:userData:grouperUserDataFavoriteSubjects','etc:attribute:userData:Grouper user data favorite subjects','A list of member ids and metadata in json format that are the favorites for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',5740,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','9c558ffbdb2a46c28c6e72094400e8ad',1459816161902,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate',NULL,'grouperShell','2.2.2',0,'df248d6a335043c5bde2c34b526c7769',NULL,NULL,NULL,NULL,NULL,1459816161907,NULL,'grouper','6b906f0d952b4c12a57c4b71d2e81001','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',22919,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a9ce735961814d169110b4d97cbdf113',1459816166728,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression, Fields changed: description.\ndescription: FROM: \'null\', TO: \'JEXL expression language fragment that evaluates to the group name (relative in the stem as the group which has the loader definition), optional, for LDAP_GROUP_LIST, or LDAP_GROUPS_FROM_ATTRIBUTES\'',NULL,'grouperShell','2.2.2',0,'e05db42bccc8494c9d77ec7a40cb34d7',NULL,NULL,NULL,NULL,NULL,1459816166730,NULL,'grouper','8088e8e830e24be2beded12f94412c79','etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression','etc:attribute:loaderLdap:Grouper loader LDAP group name expression','JEXL expression language fragment that evaluates to the group name (relative in the stem as the group which has the loader definition), optional, for LDAP_GROUP_LIST, or LDAP_GROUPS_FROM_ATTRIBUTES','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',9124,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','23e831bdeb7e411bbd2b4313ec2813d2',1459816167667,'Updated attributeDefName: etc:attribute:userData:grouperUserDataFavoriteGroups, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of group ids and metadata in json format that are the favorites for a user\'',NULL,'grouperShell','2.2.2',0,'e14f7e13d38b4ecda3704a4f4d1a9354',NULL,NULL,NULL,NULL,NULL,1459816167669,NULL,'grouper','199926a8d27b4b079b07b5be2b1c6b8a','etc:attribute:userData:grouperUserDataFavoriteGroups','etc:attribute:userData:Grouper user data favorite groups','A list of group ids and metadata in json format that are the favorites for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',10522,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','7be126e0a319460c8f17d5cf2e42c3ce',1459816161954,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress',NULL,'grouperShell','2.2.2',0,'e27f3520196a4c95a36c67bd68dd919e',NULL,NULL,NULL,NULL,NULL,1459816161961,NULL,'grouper','1e49b63b42bf443c93cd5119e5bc745a','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',21204,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','94d12e4826a44bb99a5060ddf560e544',1459816162414,'Updated attributeDefName: etc:attribute:rules:rule, Fields changed: description.\ndescription: FROM: \'null\', TO: \'is a rule\'',NULL,'grouperShell','2.2.2',0,'e3a71cbbe62a4521b5b6e2cfe285b292',NULL,NULL,NULL,NULL,NULL,1459816162415,NULL,'grouper','529d4487e5ed4a27b594fcdfb79bc439','etc:attribute:rules:rule','etc:attribute:rules:rule','is a rule','fc88a71ee4574ae7b0a550d72b5172d9','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rulesTypeDef',NULL,'172.18.0.3',4144,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','ef9019dfd0ab460dbf99255d2eb91f78',1459816162709,'Updated attributeDefName: etc:attribute:rules:ruleActAsSubjectSourceId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'subject source id to act as\'',NULL,'grouperShell','2.2.2',0,'e3ebb0a14d6548979446c563f415f243',NULL,NULL,NULL,NULL,NULL,1459816162716,NULL,'grouper','012b580866d74696a897403090f19239','etc:attribute:rules:ruleActAsSubjectSourceId','etc:attribute:rules:ruleActAsSubjectSourceId','subject source id to act as','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',13044,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','5865a9434f884892b851fe4b285c6157',1459816166643,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Attribute names (comma separated) to get LDAP data for expressions in group name, displayExtension, description, optional, for LDAP_GROUP_LIST\'',NULL,'grouperShell','2.2.2',0,'e4463f2ebf3a448db958eb9ca7228bdd',NULL,NULL,NULL,NULL,NULL,1459816166651,NULL,'grouper','7eb0914e4b5747d3abae2b5ad8edf19b','etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes','etc:attribute:loaderLdap:Grouper loader LDAP extra attributes','Attribute names (comma separated) to get LDAP data for expressions in group name, displayExtension, description, optional, for LDAP_GROUP_LIST','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',19034,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','325986d7900545049b13a0b966d3a24d',1459816161871,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate, Fields changed: description.\ndescription: FROM: \'null\', TO: \'number of millis since 1970 when this invite expires\'',NULL,'grouperShell','2.2.2',0,'e52e92e53d144856b20e0ade5365239c',NULL,NULL,NULL,NULL,NULL,1459816161874,NULL,'grouper','e6638b1ff38c41b2a4a66d7de21295bc','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate','number of millis since 1970 when this invite expires','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',7088,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','bcd25f6eb3f7404ba27b4ff14803fb33',1459816163864,'Added attributeDefName: etc:attribute:permissionLimits:limitIpOnNetworkRealm',NULL,'grouperShell','2.2.2',0,'e5e9215a0df24722855cf5662d2bcc8a',NULL,NULL,NULL,NULL,NULL,1459816163865,NULL,'grouper','7135e07d5e314776b1e17833aee62ea4','etc:attribute:permissionLimits:limitIpOnNetworkRealm','etc:attribute:permissionLimits:ipAddress on network realm',NULL,'b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',5730,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','64dfea509fd34cbc967b486f27f8be19',1459816167980,'Updated attributeDefName: etc:attribute:userData:grouperUserDataFavoriteAttributeDefs, Fields changed: description.\ndescription: FROM: \'null\', TO: \'A list of attribute definition ids and metadata in json format that are the favorites for a user\'',NULL,'grouperShell','2.2.2',0,'e7ba696fadda4530b07b25d276d816e9',NULL,NULL,NULL,NULL,NULL,1459816167986,NULL,'grouper','d049ee88c5dd43b49ec896c7b4c804e3','etc:attribute:userData:grouperUserDataFavoriteAttributeDefs','etc:attribute:userData:Grouper user data favorite attribute definitions','A list of attribute definition ids and metadata in json format that are the favorites for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',9387,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','9d90748df5764171beb921e16a331ebb',1459816166549,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Attribute name of the filter object result that holds the group name (required for loader ldap type: LDAP_GROUPS_FROM_ATTRIBUTE)\'',NULL,'grouperShell','2.2.2',0,'e8aff0911af04664b61dbebad3f82e98',NULL,NULL,NULL,NULL,NULL,1459816166556,NULL,'grouper','644299b01bb54802ae883050a29f0a80','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute','etc:attribute:loaderLdap:Grouper loader LDAP group attribute name','Attribute name of the filter object result that holds the group name (required for loader ldap type: LDAP_GROUPS_FROM_ATTRIBUTE)','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',10958,5,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','d6b66eb39f3645a3a2703500fecb4a59',1459816161299,'Added stem: etc:attribute:attrExternalSubjectInvite',NULL,'grouperShell','2.2.2',0,'ea72923c3be847e4b8a5a3c21a944ce7',NULL,NULL,NULL,NULL,NULL,1459816161306,NULL,'grouper','d5248b39d72f4fdcb730d1be03de4fbc','etc:attribute:attrExternalSubjectInvite','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrExternalSubjectInvite','',NULL,NULL,NULL,'172.18.0.3',57357,30,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','f3a8ad5c473a43628bd988c1cd56e847',1459816163851,'Updated attributeDefName: etc:attribute:permissionLimits:limitIpOnNetworks, Fields changed: description.\ndescription: FROM: \'null\', TO: \'If the user is on an IP address on the following networks\'',NULL,'grouperShell','2.2.2',0,'eaee786133f6473e91c0d1ac586a6761',NULL,NULL,NULL,NULL,NULL,1459816163851,NULL,'grouper','7c393699d849478cbb26a265ee746b75','etc:attribute:permissionLimits:limitIpOnNetworks','etc:attribute:permissionLimits:ipAddress on networks','If the user is on an IP address on the following networks','b6bc2fcd772146ee970347e496538926','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'172.18.0.3',3882,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','323915da7e4745938a43442acdd43afa',1459816164806,'Updated attributeDefName: etc:attribute:attrLoader:attributeLoaderAttrSetQuery, Fields changed: description.\ndescription: FROM: \'null\', TO: \'SQL query with at least the following columns: if_has_attr_name, then_has_attr_name\'',NULL,'grouperShell','2.2.2',0,'eaf413e6c252445fb28e31952f9835f1',NULL,NULL,NULL,NULL,NULL,1459816164816,NULL,'grouper','3bce1c3e4f76410c95ffa832ca202cbc','etc:attribute:attrLoader:attributeLoaderAttrSetQuery','etc:attribute:attrLoader:attributeLoaderAttrSetQuery','SQL query with at least the following columns: if_has_attr_name, then_has_attr_name','6cd4d8196fe24d21acd51cdf8fcdb3cc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'172.18.0.3',13607,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','4deddd2e1bbe4cc49ff7a7741f1682b7',1459816168057,'Updated attributeDefName: etc:attribute:userData:grouperUserDataPreferences, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Preferences and metadata in json format for a user\'',NULL,'grouperShell','2.2.2',0,'ec0e9a2eec864561ac57f691e51e839c',NULL,NULL,NULL,NULL,NULL,1459816168065,NULL,'grouper','f3a4ba3f2ef441ec8834425942161c77','etc:attribute:userData:grouperUserDataPreferences','etc:attribute:userData:Grouper user data preferences','Preferences and metadata in json format for a user','cb1bfad6c8ed424d902b65d9ec275df0','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef',NULL,'172.18.0.3',12964,5,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','e632b008151641b38395597648dff2af',1459816162807,'Updated attributeDefName: etc:attribute:rules:ruleCheckOwnerId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the check should be to see if rule should fire, this is owner of type, mutually exclusive with name\'',NULL,'grouperShell','2.2.2',0,'ed53222e814c45a294460bcafede822f',NULL,NULL,NULL,NULL,NULL,1459816162816,NULL,'grouper','a26523b21e2f4e12bc93828349147061','etc:attribute:rules:ruleCheckOwnerId','etc:attribute:rules:ruleCheckOwnerId','when the check should be to see if rule should fire, this is owner of type, mutually exclusive with name','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',22966,5,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','8009ec8d23dd4c5c83dd10e0d77ee848',1459816166904,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes',NULL,'grouperShell','2.2.2',0,'f00836b60033429aacca3cce18b63936',NULL,NULL,NULL,NULL,NULL,1459816166907,NULL,'grouper','d936518e709549ea942d07d26ecf45b9','etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes','etc:attribute:loaderLdap:Grouper loader LDAP group types',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',14623,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','90cac98d130b4553bfbb186f57b650e7',1459816163172,'Updated attributeDefName: etc:attribute:rules:ruleIfConditionEnum, Fields changed: description.\ndescription: FROM: \'null\', TO: \'RuleIfConditionEnum that sees if rule should fire, or exclude if should run always\'',NULL,'grouperShell','2.2.2',0,'f0da034219c445509a81af6d175d964a',NULL,NULL,NULL,NULL,NULL,1459816163176,NULL,'grouper','fd1617992c834f03827ff8b836c38c8d','etc:attribute:rules:ruleIfConditionEnum','etc:attribute:rules:ruleIfConditionEnum','RuleIfConditionEnum that sees if rule should fire, or exclude if should run always','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',12388,5,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','b772e0a603f34d7e8aa592f9fcaefd2f',1459816163764,'Updated attributeDef: etc:attribute:permissionLimits:limitsDef, Fields changed: assignToAttributeDef, assignToEffMembership, assignToEffMembershipAssn, assignToGroup, assignToGroupAssn, multiAssignable, valueType.\nassignToAttributeDef: FROM: \'false\', TO: \'true\'\nassignToEffMembership: FROM: \'false\', TO: \'true\'\nassignToEffMembershipAssn: FROM: \'false\', TO: \'true\'\nassignToGroup: FROM: \'false\', TO: \'true\'\nassignToGroupAssn: FROM: \'false\', TO: \'true\'\nmultiAssignable: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'f1d71f8c62b6426694ca1cc40b79a611',NULL,NULL,NULL,NULL,NULL,1459816163765,NULL,'grouper','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,NULL,NULL,'172.18.0.3',2420,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','3660dbcf1bf54570a27f8749eef1268d',1459816167457,'Updated attributeDefName: etc:attribute:userData:grouperUserData, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Marks a group that has memberships which have attributes for user data\'',NULL,'grouperShell','2.2.2',0,'f22ba64baeb448cf8e1c91708f60f84d',NULL,NULL,NULL,NULL,NULL,1459816167486,NULL,'grouper','14088a5dcafc4c22870e9cb6f65f3998','etc:attribute:userData:grouperUserData','etc:attribute:userData:Grouper user data','Marks a group that has memberships which have attributes for user data','cb1bfad6c8ed424d902b65d9ec275df0','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserDataDef',NULL,'172.18.0.3',32422,5,'root'),('65947ffd4e364921a42c465d94a78c09','aac167507e284ceabc91c72d0552a690','10e41282ff0b4434b2111890260d81e6',1459816162307,'Added stem: etc:attribute:rules',NULL,'grouperShell','2.2.2',0,'f5559e8e93ba485b9cd0a76ec0d82b61',NULL,NULL,NULL,NULL,NULL,1459816162309,NULL,'grouper','fc88a71ee4574ae7b0a550d72b5172d9','etc:attribute:rules','1730a44d087442cc96c2d8d63b655716','etc:attribute:rules','',NULL,NULL,NULL,'172.18.0.3',57800,30,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','2e0e8922e59f44ef87caab10780b7d60',1459816166284,'Updated attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSourceId, Fields changed: description.\ndescription: FROM: \'null\', TO: \'Source ID from the sources.xml that narrows the search for subjects.  This is optional though makes the loader job more efficient\'',NULL,'grouperShell','2.2.2',0,'f868e95dd2024c7fbb0d0b62e6d0cf0b',NULL,NULL,NULL,NULL,NULL,1459816166285,NULL,'grouper','f867d93ca881408cb2191562a5b8cf36','etc:attribute:loaderLdap:grouperLoaderLdapSourceId','etc:attribute:loaderLdap:Grouper loader LDAP source ID','Source ID from the sources.xml that narrows the search for subjects.  This is optional though makes the loader job more efficient','094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',7209,5,'root'),('65947ffd4e364921a42c465d94a78c09','d9e42bfec6284e5dbde42a51fa8ac82e','d5263d78c23b4eedbd036a2149205086',1459816158198,'Added group field: attrViewers, id: 7bda5202f90744f7b121c9eb0240e576, type: attributeDef',NULL,'grouperShell','2.2.2',0,'f8ba94d296f14dcb8bb1c7cd670d65a1',NULL,NULL,NULL,NULL,NULL,1459816158198,NULL,'grouper','7bda5202f90744f7b121c9eb0240e576','attrViewers',NULL,NULL,'attributeDef',NULL,NULL,NULL,'172.18.0.3',11891,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','8540b51e8e2145ebb15cc495ecd61022',1459816166949,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapReaders',NULL,'grouperShell','2.2.2',0,'f9149619ca5f4ee6a8d3627e26016aeb',NULL,NULL,NULL,NULL,NULL,1459816166955,NULL,'grouper','45dd837ceb804d058a8701b473d00060','etc:attribute:loaderLdap:grouperLoaderLdapReaders','etc:attribute:loaderLdap:Grouper loader LDAP group readers',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',18052,9,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a2c9cd9112ab481897e3c2ba6b533215',1459816162041,'Updated attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids, Fields changed: description.\ndescription: FROM: \'null\', TO: \'comma separated group ids to assign this user to\'',NULL,'grouperShell','2.2.2',0,'f951c8dfe92b41a5bb82942f2b8b62fd',NULL,NULL,NULL,NULL,NULL,1459816162044,NULL,'grouper','f5aac6d1a9f94ee3870a7b3b56ab9ade','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids','comma separated group ids to assign this user to','d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',16523,5,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','c8f2a547c8004d08aa1fa00df9d7a4d8',1459816164365,'Updated attributeDef: etc:attribute:attrLoader:attributeDefLoaderDef, Fields changed: assignToAttributeDef, valueType.\nassignToAttributeDef: FROM: \'false\', TO: \'true\'\nvalueType: FROM: \'marker\', TO: \'string\'',NULL,'grouperShell','2.2.2',0,'fa612637638a4016b4db871e56422de9',NULL,NULL,NULL,NULL,NULL,1459816164367,NULL,'grouper','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,NULL,NULL,'172.18.0.3',4186,3,'root'),('65947ffd4e364921a42c465d94a78c09','f959f8babe3d467d9c775e6074dfb86d','a1c53a00cab74c4b99c889a175269101',1459816162928,'Updated attributeDefName: etc:attribute:rules:ruleCheckStemScope, Fields changed: description.\ndescription: FROM: \'null\', TO: \'when the check is a stem type, this is Stem.Scope ALL or SUB\'',NULL,'grouperShell','2.2.2',0,'fac3d83b19c440559a07ca0c688304af',NULL,NULL,NULL,NULL,NULL,1459816162933,NULL,'grouper','08468c13269a4236921d4b33d272bffb','etc:attribute:rules:ruleCheckStemScope','etc:attribute:rules:ruleCheckStemScope','when the check is a stem type, this is Stem.Scope ALL or SUB','fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',16728,5,'root'),('65947ffd4e364921a42c465d94a78c09','13253110654d44079dac42accd4c93ce','5c3bb10ded72439ea55f8add3380b0e0',1459816167427,'Updated attributeDef: etc:attribute:userData:grouperUserDataDef, Fields changed: assignToImmMembership.\nassignToImmMembership: FROM: \'false\', TO: \'true\'',NULL,'grouperShell','2.2.2',0,'fcac9d36e2c94461af339808f3542b22',NULL,NULL,NULL,NULL,NULL,1459816167428,NULL,'grouper','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserDataDef',NULL,'cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,NULL,NULL,'172.18.0.3',7888,3,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','728f74ab9e7d4ec9ac46a7c45ed5b8f5',1459816166242,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute',NULL,'grouperShell','2.2.2',0,'fd5bf5a8a7764e7e9c74d073b77d8ffd',NULL,NULL,NULL,NULL,NULL,1459816166243,NULL,'grouper','44116f0e5923417fb0b3b660db88604b','etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute','etc:attribute:loaderLdap:Grouper loader LDAP subject attribute name',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',7267,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','531dc15e5d794a89b9750e666b2f12ec',1459816163488,'Added attributeDefName: etc:attribute:rules:ruleThenEnumArg2',NULL,'grouperShell','2.2.2',0,'fe7c85c21c404066bc797ba3c9bb49bb',NULL,NULL,NULL,NULL,NULL,1459816163498,NULL,'grouper','1a1c5f5bf5064e5fbfc30d723a93ac35','etc:attribute:rules:ruleThenEnumArg2','etc:attribute:rules:ruleThenEnumArg2',NULL,'fc88a71ee4574ae7b0a550d72b5172d9','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef',NULL,'172.18.0.3',43814,9,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','ea0b11775d354ec0902c36f4a8737f5a',1459816166172,'Added attributeDefName: etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron',NULL,'grouperShell','2.2.2',0,'ffdcfae1c98e422ebd92243f9700cc6f',NULL,NULL,NULL,NULL,NULL,1459816166174,NULL,'grouper','3abd9f032c2c42318cd5e5e014c27a69','etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron','etc:attribute:loaderLdap:Grouper loader LDAP quartz cron',NULL,'094308af1376466687416c49f1f6495f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef',NULL,'172.18.0.3',13868,9,'root'),('65947ffd4e364921a42c465d94a78c09','7bae5e789a2e490f9333ef3bd747abeb','d3070a409e5149a0b7bfeb8222f313ab',1459816168146,'Added attributeDef: etc:attribute:entities:entitySubjectIdentifierDef',NULL,'grouperShell','2.2.2',0,'fff63c4df8484609aae9f8d518ca25c0',NULL,NULL,NULL,NULL,NULL,1459816168148,NULL,'grouper','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef',NULL,'2eee186e51494f0a874fe61ff24b7192',NULL,NULL,NULL,NULL,'172.18.0.3',35259,39,'root'),('65947ffd4e364921a42c465d94a78c09','683df7b646084ff2b19cc75a6cf389c0','7fbe1e513dc84bd19a243955ec148c84',1459816162071,'Added attributeDefName: etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId',NULL,'grouperShell','2.2.2',0,'fffa7a4e1b024248aa03b53fcd59a46e',NULL,NULL,NULL,NULL,NULL,1459816162076,NULL,'grouper','855fd99c277c4e069e0ffa2b052d89d3','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId',NULL,'d5248b39d72f4fdcb730d1be03de4fbc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef',NULL,'172.18.0.3',26001,9,'root');
/*!40000 ALTER TABLE `grouper_audit_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_audit_entry_v`
--

DROP TABLE IF EXISTS `grouper_audit_entry_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_audit_entry_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_audit_entry_v` (
  `created_on` tinyint NOT NULL,
  `audit_category` tinyint NOT NULL,
  `action_name` tinyint NOT NULL,
  `logged_in_subject_id` tinyint NOT NULL,
  `act_as_subject_id` tinyint NOT NULL,
  `label_string01` tinyint NOT NULL,
  `string01` tinyint NOT NULL,
  `label_string02` tinyint NOT NULL,
  `string02` tinyint NOT NULL,
  `label_string03` tinyint NOT NULL,
  `string03` tinyint NOT NULL,
  `label_string04` tinyint NOT NULL,
  `string04` tinyint NOT NULL,
  `label_string05` tinyint NOT NULL,
  `string05` tinyint NOT NULL,
  `label_string06` tinyint NOT NULL,
  `string06` tinyint NOT NULL,
  `label_string07` tinyint NOT NULL,
  `string07` tinyint NOT NULL,
  `label_string08` tinyint NOT NULL,
  `string08` tinyint NOT NULL,
  `label_int01` tinyint NOT NULL,
  `int01` tinyint NOT NULL,
  `label_int02` tinyint NOT NULL,
  `int02` tinyint NOT NULL,
  `label_int03` tinyint NOT NULL,
  `int03` tinyint NOT NULL,
  `label_int04` tinyint NOT NULL,
  `int04` tinyint NOT NULL,
  `label_int05` tinyint NOT NULL,
  `int05` tinyint NOT NULL,
  `context_id` tinyint NOT NULL,
  `grouper_engine` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `logged_in_source_id` tinyint NOT NULL,
  `act_as_source_id` tinyint NOT NULL,
  `logged_in_member_id` tinyint NOT NULL,
  `act_as_member_id` tinyint NOT NULL,
  `audit_type_id` tinyint NOT NULL,
  `user_ip_address` tinyint NOT NULL,
  `server_host` tinyint NOT NULL,
  `audit_entry_last_updated` tinyint NOT NULL,
  `audit_entry_id` tinyint NOT NULL,
  `grouper_version` tinyint NOT NULL,
  `env_name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_audit_type`
--

DROP TABLE IF EXISTS `grouper_audit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_audit_type` (
  `action_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `audit_category` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `label_int01` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_int02` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_int03` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_int04` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_int05` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string01` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string02` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string03` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string04` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string05` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string06` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string07` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string08` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `audit_type_category_type_idx` (`audit_category`,`action_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_audit_type`
--

LOCK TABLES `grouper_audit_type` WRITE;
/*!40000 ALTER TABLE `grouper_audit_type` DISABLE KEYS */;
INSERT INTO `grouper_audit_type` VALUES ('assignGroupType','groupTypeAssignment','03a0508d76a940ba8534f67048a0fd5d',1459816157561,0,'03a0508d76a940ba8534f67048a0fd5d',NULL,NULL,NULL,NULL,NULL,'id','groupId','groupName','typeId','typeName',NULL,NULL,NULL,1459816157561),('copy','group','0551e80cc88842efad09023fc77e2efb',1459816157784,0,'0551e80cc88842efad09023fc77e2efb','attributes',NULL,NULL,NULL,NULL,'oldGroupId','oldGroupName','newGroupId','newGroupName','privilegesOfGroup','groupAsPrivilege','listMembersOfGroup','listGroupAsMember',1459816157784),('updateAttributeAssignStem','attributeAssignStem','0a0e7fb294344cf1a9ba14f3caf34703',1459816157656,0,'0a0e7fb294344cf1a9ba14f3caf34703',NULL,NULL,NULL,NULL,NULL,'id','ownerStemName','ownerStemId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157656),('deleteAttributeAssignAttrDef','attributeAssignAttrDef','0a43da8ce9754da8873249f7d36cccad',1459816157703,0,'0a43da8ce9754da8873249f7d36cccad',NULL,NULL,NULL,NULL,NULL,'id','ownerAttributeDefId','ownerAttributeDefName','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157703),('updateExternalSubjAttr','externalSubjectAttribute','0aa49b3aff4e46c883fbfd01f588d0a0',1459816157733,0,'0aa49b3aff4e46c883fbfd01f588d0a0',NULL,NULL,NULL,NULL,NULL,'id','identifier','name','value',NULL,NULL,NULL,NULL,1459816157733),('unassignGroupType','groupTypeAssignment','0ed8367a1a064ca18118206e55563558',1459816157567,0,'0ed8367a1a064ca18118206e55563558',NULL,NULL,NULL,NULL,NULL,'id','groupId','groupName','typeId','typeName',NULL,NULL,NULL,1459816157567),('updateGroup','group','11bb5bb4a4544d5e9841c37c279cde15',1459816157747,0,'11bb5bb4a4544d5e9841c37c279cde15',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157747),('updateStem','stem','11eac76db424484c86e10a8f817a78c3',1459816157770,0,'11eac76db424484c86e10a8f817a78c3',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157770),('createInviteByIdentifier','externalSubjectInvite','11ff76235be14647b9b66dbb6f31e353',1459816157831,0,'11ff76235be14647b9b66dbb6f31e353',NULL,NULL,NULL,NULL,NULL,'identifiers','inviterMemberId','groupIdsAssigned','groupNamesAssigned',NULL,NULL,NULL,NULL,1459816157831),('updateAttributeDef','attributeDef','13253110654d44079dac42accd4c93ce',1459816157608,0,'13253110654d44079dac42accd4c93ce',NULL,NULL,NULL,NULL,NULL,'id','name','description','parentStemId',NULL,NULL,NULL,NULL,1459816157608),('addAttributeAssignGroup','attributeAssignGroup','13b443610e784effa7c6ec6c77c74216',1459816157642,0,'13b443610e784effa7c6ec6c77c74216',NULL,NULL,NULL,NULL,NULL,'id','ownerGroupName','ownerGroupId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157642),('addAttributeAssignImmMship','attributeAssignImmMship','1402f2f771e4486398e3dadced2d7e64',1459816157674,0,'1402f2f771e4486398e3dadced2d7e64',NULL,NULL,NULL,NULL,NULL,'id','ownerMembershipId','ownerOwnerId','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157674),('addGroupPrivilege','privilege','190570c28cb74ee49626928702bb2616',1459816157590,0,'190570c28cb74ee49626928702bb2616',NULL,NULL,NULL,NULL,NULL,'privilegeName','memberId','privilegeType','groupId','groupName',NULL,NULL,NULL,1459816157590),('deleteGroup','group','1a276f2aaa72432b9cc1743d72a46309',1459816157751,0,'1a276f2aaa72432b9cc1743d72a46309',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157751),('addExternalSubject','externalSubjectRegister','1afe7763b2cc46e0852e7398f827af84',1459816157798,0,'1afe7763b2cc46e0852e7398f827af84','numberOfInvites',NULL,NULL,NULL,NULL,'identifier','sourceId','subjectId','inviteEmailSentTo','groupIdsAssigned','groupNamesAssigned',NULL,NULL,1459816157798),('deleteAttributeAssignAssign','attributeAssignAssign','1e64603e3998411187e3b2b70dbefabd',1459816157712,0,'1e64603e3998411187e3b2b70dbefabd',NULL,NULL,NULL,NULL,NULL,'id','ownerAttributeAssignId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,NULL,1459816157712),('deleteAttributeAssignMember','attributeAssignMember','1ea9e369a47f46ba8bcb7e80854da2bf',1459816157672,0,'1ea9e369a47f46ba8bcb7e80854da2bf',NULL,NULL,NULL,NULL,NULL,'id','ownerSourceId','ownerSubjectId','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157672),('addStemPrivilege','privilege','1f92330363314b8798b5f8223d2351dc',1459816157597,0,'1f92330363314b8798b5f8223d2351dc',NULL,NULL,NULL,NULL,NULL,'privilegeName','memberId','privilegeType','stemId','stemName',NULL,NULL,NULL,1459816157597),('deleteGroupField','groupField','216e0d9006f4443aa392009c32aab96f',1459816157510,0,'216e0d9006f4443aa392009c32aab96f',NULL,NULL,NULL,NULL,NULL,'id','name','groupTypeId','groupTypeName','type',NULL,NULL,NULL,1459816157510),('updateGroupType','groupType','258bc16e240045a3a422343c37173b0e',1459816157480,0,'258bc16e240045a3a422343c37173b0e',NULL,NULL,NULL,NULL,NULL,'id','name',NULL,NULL,NULL,NULL,NULL,NULL,1459816157480),('deleteStem','stem','26f2e7a059f84122a090d6b17ad118a2',1459816157771,0,'26f2e7a059f84122a090d6b17ad118a2',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157771),('updateGroupField','groupField','2c4a42d00ed34ab6ae6fe2325dbb1db9',1459816157500,0,'2c4a42d00ed34ab6ae6fe2325dbb1db9',NULL,NULL,NULL,NULL,NULL,'id','name','groupTypeId','groupTypeName','type',NULL,NULL,NULL,1459816157500),('move','group','2f8819de995f49f28b79737e6cbb1a6a',1459816157789,0,'2f8819de995f49f28b79737e6cbb1a6a',NULL,NULL,NULL,NULL,NULL,'groupId','oldGroupName','newGroupName','newStemId','assignAlternateName',NULL,NULL,NULL,1459816157789),('deleteStemPrivilege','privilege','32bbd0c44a5543fbb57c6b9739294a1a',1459816157600,0,'32bbd0c44a5543fbb57c6b9739294a1a',NULL,NULL,NULL,NULL,NULL,'privilegeName','memberId','privilegeType','stemId','stemName',NULL,NULL,NULL,1459816157600),('changeSubject','member','3421d45668d84889b464eba680a571a4',1459816157774,0,'3421d45668d84889b464eba680a571a4',NULL,NULL,NULL,NULL,NULL,'oldMemberId','oldSubjectId','oldSourceId','newMemberId','newSubjectId','newSourceId','deleteOldMember','memberIdChanged',1459816157774),('updateAttributeAssignImmMship','attributeAssignImmMship','388b6de984d4418e9962ea4b6fd91d5f',1459816157675,0,'388b6de984d4418e9962ea4b6fd91d5f',NULL,NULL,NULL,NULL,NULL,'id','ownerMembershipId','ownerOwnerId','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157675),('addAttributeAssignValue','attributeAssignValue','3ac3682977af4d0e999c1cdcd0189e30',1459816157635,0,'3ac3682977af4d0e999c1cdcd0189e30',NULL,NULL,NULL,NULL,NULL,'id','attributeAssignId','attributeDefNameId','value','attributeDefNameName',NULL,NULL,NULL,1459816157635),('updateAttributeAssignAttrDef','attributeAssignAttrDef','443b58bc5e3541588689340ccf8343d8',1459816157696,0,'443b58bc5e3541588689340ccf8343d8',NULL,NULL,NULL,NULL,NULL,'id','ownerAttributeDefId','ownerAttributeDefName','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157696),('addAttributeAssignStem','attributeAssignStem','49c8c4e52e2345e09f250b4832b771e8',1459816157653,0,'49c8c4e52e2345e09f250b4832b771e8',NULL,NULL,NULL,NULL,NULL,'id','ownerStemName','ownerStemId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157653),('deleteGroupType','groupType','570de1ee65fb4de8905120950c63caba',1459816157489,0,'570de1ee65fb4de8905120950c63caba',NULL,NULL,NULL,NULL,NULL,'id','name',NULL,NULL,NULL,NULL,NULL,NULL,1459816157489),('addEntity','entity','57d207f95f3b4f06a06a006af8db72f0',1459816157753,0,'57d207f95f3b4f06a06a006af8db72f0',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157753),('updateGroupAttribute','groupAttribute','5e57eaa796f54dcc87feceb7fef8e667',1459816157534,0,'5e57eaa796f54dcc87feceb7fef8e667',NULL,NULL,NULL,NULL,NULL,'id','groupId','groupName','fieldId','fieldName','value','oldValue',NULL,1459816157534),('addAttributeAssignMember','attributeAssignMember','60c7edeb342941d3abc6cf4230215747',1459816157660,0,'60c7edeb342941d3abc6cf4230215747',NULL,NULL,NULL,NULL,NULL,'id','ownerSourceId','ownerSubjectId','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157660),('updateAttributeAssignGroup','attributeAssignGroup','6123eb82090a46af84ce83ac8dacae55',1459816157646,0,'6123eb82090a46af84ce83ac8dacae55',NULL,NULL,NULL,NULL,NULL,'id','ownerGroupName','ownerGroupId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157646),('addAttributeDefName','attributeDefName','683df7b646084ff2b19cc75a6cf389c0',1459816157620,0,'683df7b646084ff2b19cc75a6cf389c0',NULL,NULL,NULL,NULL,NULL,'id','name','displayName','description','parentStemId','parentAttributeDefId','parentAttributeDefName',NULL,1459816157620),('deleteExternalSubject','externalSubjectRegister','6fda7ceed2ab455e819ba9f6d46048be',1459816157803,0,'6fda7ceed2ab455e819ba9f6d46048be',NULL,NULL,NULL,NULL,NULL,'identifier','subjectId',NULL,NULL,NULL,NULL,NULL,NULL,1459816157803),('deleteGroupComposite','groupComposite','79d351190e134f2cacf0d0b8fb9c7b60',1459816157559,0,'79d351190e134f2cacf0d0b8fb9c7b60',NULL,NULL,NULL,NULL,NULL,'id','ownerId','ownerName','leftFactorId','leftFactorName','rightFactorId','rightFactorName','type',1459816157559),('addAttributeDef','attributeDef','7bae5e789a2e490f9333ef3bd747abeb',1459816157606,0,'7bae5e789a2e490f9333ef3bd747abeb',NULL,NULL,NULL,NULL,NULL,'id','name','description','parentStemId',NULL,NULL,NULL,NULL,1459816157606),('exportMembership','membership','808ecf680a93402ca0e0c6fe0e00e7bb',1459816157589,0,'808ecf680a93402ca0e0c6fe0e00e7bb',NULL,NULL,NULL,NULL,NULL,'groupId','groupName','exportSize','file',NULL,NULL,NULL,NULL,1459816157589),('addAttributeAssignAnyMship','attributeAssignAnyMship','841aa7a8d48f4f44ab5ba0e4058df02c',1459816157683,0,'841aa7a8d48f4f44ab5ba0e4058df02c',NULL,NULL,NULL,NULL,NULL,'id','ownerGroupId','ownerGroupName','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157683),('updateExternalSubject','externalSubject','882addd996944534acfd5f7470dac12c',1459816157721,0,'882addd996944534acfd5f7470dac12c',NULL,NULL,NULL,NULL,NULL,'id','name','identifier',NULL,NULL,NULL,NULL,NULL,1459816157721),('updateGroupComposite','groupComposite','8d82032144c446daabcbd84cd06713dd',1459816157550,0,'8d82032144c446daabcbd84cd06713dd',NULL,NULL,NULL,NULL,NULL,'id','ownerId','ownerName','leftFactorId','leftFactorName','rightFactorId','rightFactorName','type',1459816157550),('deleteGroupPrivilege','privilege','8ddf3135c9da4804971a79242578b2f7',1459816157596,0,'8ddf3135c9da4804971a79242578b2f7',NULL,NULL,NULL,NULL,NULL,'privilegeName','memberId','privilegeType','groupId','groupName',NULL,NULL,NULL,1459816157596),('updateEntity','entity','9928eae60a634fc2bf570c76924237d9',1459816157758,0,'9928eae60a634fc2bf570c76924237d9',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157758),('deleteExternalSubject','externalSubject','9a0ef07e2fdc4e2ca86e14268ba3be63',1459816157725,0,'9a0ef07e2fdc4e2ca86e14268ba3be63',NULL,NULL,NULL,NULL,NULL,'id','name','identifier',NULL,NULL,NULL,NULL,NULL,1459816157725),('deleteAttributeAssignImmMship','attributeAssignImmMship','9dcb70c6319f44cb85d59b250bccf361',1459816157678,0,'9dcb70c6319f44cb85d59b250bccf361',NULL,NULL,NULL,NULL,NULL,'id','ownerMembershipId','ownerOwnerId','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157678),('deleteGroupMembership','membership','9f98486f4e3a4e9c8a024dd417d60045',1459816157587,0,'9f98486f4e3a4e9c8a024dd417d60045',NULL,NULL,NULL,NULL,NULL,'id','fieldId','fieldName','memberId','membershipType','groupId','groupName',NULL,1459816157587),('deleteAttributeDef','attributeDef','a109a3217d83411e854539825e7aae16',1459816157611,0,'a109a3217d83411e854539825e7aae16',NULL,NULL,NULL,NULL,NULL,'id','name','description','parentStemId',NULL,NULL,NULL,NULL,1459816157611),('updateGroupMembership','membership','a1411818c537414b8259b0ba3583c115',1459816157577,0,'a1411818c537414b8259b0ba3583c115',NULL,NULL,NULL,NULL,NULL,'id','fieldId','fieldName','memberId','membershipType','groupId','groupName',NULL,1459816157577),('addStem','stem','aac167507e284ceabc91c72d0552a690',1459816157766,0,'aac167507e284ceabc91c72d0552a690',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157766),('addGroup','group','adb8e0fb527041139ebf6b9443259d11',1459816157743,0,'adb8e0fb527041139ebf6b9443259d11',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157743),('addGroupType','groupType','b2dea3614191424cbc4314bec387706b',1459816157475,0,'b2dea3614191424cbc4314bec387706b',NULL,NULL,NULL,NULL,NULL,'id','name',NULL,NULL,NULL,NULL,NULL,NULL,1459816157475),('updateGroupPrivilege','privilege','b5d9bc7869a149fdb7ac04bebf171cc6',1459816157591,0,'b5d9bc7869a149fdb7ac04bebf171cc6',NULL,NULL,NULL,NULL,NULL,'privilegeName','memberId','privilegeType','groupId','groupName',NULL,NULL,NULL,1459816157591),('addAttributeAssignAttrDef','attributeAssignAttrDef','b61d95f16be2403495f95853c3746162',1459816157690,0,'b61d95f16be2403495f95853c3746162',NULL,NULL,NULL,NULL,NULL,'id','ownerAttributeDefId','ownerAttributeDefName','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157690),('createInviteByEmail','externalSubjectInvite','bab3b0df3117411b966183da2d14d470',1459816157830,0,'bab3b0df3117411b966183da2d14d470',NULL,NULL,NULL,NULL,NULL,'emailsSentTo','inviterMemberId','groupIdsAssigned','groupNamesAssigned',NULL,NULL,NULL,NULL,1459816157830),('deleteAttributeDefName','attributeDefName','bcd23d3201c045d4a4f2c5c35ee1508b',1459816157625,0,'bcd23d3201c045d4a4f2c5c35ee1508b',NULL,NULL,NULL,NULL,NULL,'id','name','displayName','description','parentStemId','parentAttributeDefId','parentAttributeDefName',NULL,1459816157625),('addGroupMembership','membership','c1d24423cccb413b90ccd806e5b4c9f4',1459816157571,0,'c1d24423cccb413b90ccd806e5b4c9f4',NULL,NULL,NULL,NULL,NULL,'id','fieldId','fieldName','memberId','membershipType','groupId','groupName',NULL,1459816157571),('move','stem','c4eba83c498a40e5ac2e2f5e08a4066d',1459816157795,0,'c4eba83c498a40e5ac2e2f5e08a4066d',NULL,NULL,NULL,NULL,NULL,'stemId','oldStemName','newStemName','newParentStemId','assignAlternateName',NULL,NULL,NULL,1459816157795),('import','importExport','c5d25211291f4c2097f8bbe918969185',1459816157781,0,'c5d25211291f4c2097f8bbe918969185',NULL,NULL,NULL,NULL,NULL,'fileName','subjectId',NULL,NULL,NULL,NULL,NULL,NULL,1459816157781),('deleteAttributeAssignGroup','attributeAssignGroup','c6945c0371f6442ab849480e69324145',1459816157647,0,'c6945c0371f6442ab849480e69324145',NULL,NULL,NULL,NULL,NULL,'id','ownerGroupName','ownerGroupId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157647),('deleteEntity','entity','c6f7b43e98654aabacd966df38a2f627',1459816157760,0,'c6f7b43e98654aabacd966df38a2f627',NULL,NULL,NULL,NULL,NULL,'id','name','parentStemId','displayName','description',NULL,NULL,NULL,1459816157760),('deleteAttributeAssignAnyMship','attributeAssignAnyMship','cba38e4b5469402589ec02e14e6f2277',1459816157689,0,'cba38e4b5469402589ec02e14e6f2277',NULL,NULL,NULL,NULL,NULL,'id','ownerGroupId','ownerGroupName','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157689),('updateAttributeAssignAnyMship','attributeAssignAnyMship','d18706c573c84f74916ef8058f816ce0',1459816157688,0,'d18706c573c84f74916ef8058f816ce0',NULL,NULL,NULL,NULL,NULL,'id','ownerGroupId','ownerGroupName','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157688),('addAttributeAssignAssign','attributeAssignAssign','d373caec88bd42f491c857c8f7e75f1e',1459816157704,0,'d373caec88bd42f491c857c8f7e75f1e',NULL,NULL,NULL,NULL,NULL,'id','ownerAttributeAssignId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,NULL,1459816157704),('updateAttributeAssignAssign','attributeAssignAssign','d65004f9bd704427a6ff517cd8d4ddc8',1459816157710,0,'d65004f9bd704427a6ff517cd8d4ddc8',NULL,NULL,NULL,NULL,NULL,'id','ownerAttributeAssignId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,NULL,1459816157710),('updateAttributeAssignValue','attributeAssignValue','d669ebc6f74346f4b48a51e7f467ee2b',1459816157639,0,'d669ebc6f74346f4b48a51e7f467ee2b',NULL,NULL,NULL,NULL,NULL,'id','attributeAssignId','attributeDefNameId','value','attributeDefNameName',NULL,NULL,NULL,1459816157639),('addGroupField','groupField','d9e42bfec6284e5dbde42a51fa8ac82e',1459816157496,0,'d9e42bfec6284e5dbde42a51fa8ac82e',NULL,NULL,NULL,NULL,NULL,'id','name','groupTypeId','groupTypeName','type',NULL,NULL,NULL,1459816157496),('importMembership','membership','de1ec386e7ba4b87b24b652887f93b94',1459816157590,0,'de1ec386e7ba4b87b24b652887f93b94',NULL,NULL,NULL,NULL,NULL,'groupId','groupName','file','totalAdded','totalDeleted',NULL,NULL,NULL,1459816157590),('deleteExternalSubjAttr','externalSubjectAttribute','e0014d23ba8b4994b1da6ed881375df6',1459816157738,0,'e0014d23ba8b4994b1da6ed881375df6',NULL,NULL,NULL,NULL,NULL,'id','identifier','name','value',NULL,NULL,NULL,NULL,1459816157738),('deleteAttributeAssignStem','attributeAssignStem','e3ffa3e65d2441bfa43fa31efd44ffdd',1459816157658,0,'e3ffa3e65d2441bfa43fa31efd44ffdd',NULL,NULL,NULL,NULL,NULL,'id','ownerStemName','ownerStemId','attributeDefNameName','attributeDefNameId','action','attributeDefId',NULL,1459816157658),('updateStemPrivilege','privilege','eb1348d44a684e86bfe3d443565995ff',1459816157598,0,'eb1348d44a684e86bfe3d443565995ff',NULL,NULL,NULL,NULL,NULL,'privilegeName','memberId','privilegeType','stemId','stemName',NULL,NULL,NULL,1459816157598),('copy','stem','eb699fcfc563408e8454be756f4b0adc',1459816157790,0,'eb699fcfc563408e8454be756f4b0adc','attributes',NULL,NULL,NULL,NULL,'oldStemId','oldStemName','newStemName','newStemId','privilegesOfStem','privilegesOfGroup','listMembersOfGroup','listGroupAsMember',1459816157790),('updateExternalSubject','externalSubjectRegister','ebdc3f8113cd46588ca426b037db028f',1459816157828,0,'ebdc3f8113cd46588ca426b037db028f','numberOfInvites',NULL,NULL,NULL,NULL,'identifier','sourceId','subjectId','inviteEmailSentTo','groupIdsAssigned','groupNamesAssigned',NULL,NULL,1459816157828),('addExternalSubjAttr','externalSubjectAttribute','ed18251c3e064bce8ea899b2949896e9',1459816157726,0,'ed18251c3e064bce8ea899b2949896e9',NULL,NULL,NULL,NULL,NULL,'id','identifier','name','value',NULL,NULL,NULL,NULL,1459816157726),('deleteGroupAttribute','groupAttribute','f03bbe7481c7405295f4a1a8121f55ee',1459816157543,0,'f03bbe7481c7405295f4a1a8121f55ee',NULL,NULL,NULL,NULL,NULL,'id','groupId','groupName','fieldId','fieldName','value',NULL,NULL,1459816157543),('addGroupComposite','groupComposite','f484a558eb8d4824afc370ac1ea4e854',1459816157546,0,'f484a558eb8d4824afc370ac1ea4e854',NULL,NULL,NULL,NULL,NULL,'id','ownerId','ownerName','leftFactorId','leftFactorName','rightFactorId','rightFactorName','type',1459816157546),('deleteAttributeAssignValue','attributeAssignValue','f52942afa566471485043947d822b0e1',1459816157641,0,'f52942afa566471485043947d822b0e1',NULL,NULL,NULL,NULL,NULL,'id','attributeAssignId','attributeDefNameId','value','attributeDefNameName',NULL,NULL,NULL,1459816157641),('addGroupAttribute','groupAttribute','f5e8c90fe77742a98751b93f6ff904b5',1459816157525,0,'f5e8c90fe77742a98751b93f6ff904b5',NULL,NULL,NULL,NULL,NULL,'id','groupId','groupName','fieldId','fieldName','value',NULL,NULL,1459816157525),('addExternalSubject','externalSubject','f74fa3d35ac04d01bbb372afc7c4abde',1459816157715,0,'f74fa3d35ac04d01bbb372afc7c4abde',NULL,NULL,NULL,NULL,NULL,'id','name','identifier',NULL,NULL,NULL,NULL,NULL,1459816157715),('updateAttributeDefName','attributeDefName','f959f8babe3d467d9c775e6074dfb86d',1459816157624,0,'f959f8babe3d467d9c775e6074dfb86d',NULL,NULL,NULL,NULL,NULL,'id','name','displayName','description','parentStemId','parentAttributeDefId','parentAttributeDefName',NULL,1459816157624),('updateAttributeAssignMember','attributeAssignMember','fd7c200f691e4da182b5ed07fbfb30d6',1459816157665,0,'fd7c200f691e4da182b5ed07fbfb30d6',NULL,NULL,NULL,NULL,NULL,'id','ownerSourceId','ownerSubjectId','ownerMemberId','attributeDefNameName','attributeDefNameId','action','attributeDefId',1459816157665);
/*!40000 ALTER TABLE `grouper_audit_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_aval_asn_asn_attrdef_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_asn_attrdef_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_attrdef_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_asn_attrdef_v` (
  `name_of_attr_def_assigned_to` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `id_of_attr_def_assigned_to` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_asn_efmship_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_asn_efmship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_efmship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_asn_efmship_v` (
  `group_name` tinyint NOT NULL,
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_asn_group_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_asn_group_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_group_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_asn_group_v` (
  `group_name` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_asn_member_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_asn_member_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_member_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_asn_member_v` (
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_asn_mship_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_asn_mship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_mship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_asn_mship_v` (
  `group_name` tinyint NOT NULL,
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_asn_stem_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_asn_stem_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_stem_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_asn_stem_v` (
  `stem_name` tinyint NOT NULL,
  `action1` tinyint NOT NULL,
  `action2` tinyint NOT NULL,
  `attribute_def_name_name1` tinyint NOT NULL,
  `attribute_def_name_name2` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `stem_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name1` tinyint NOT NULL,
  `attribute_def_name_disp_name2` tinyint NOT NULL,
  `name_of_attribute_def1` tinyint NOT NULL,
  `name_of_attribute_def2` tinyint NOT NULL,
  `attribute_assign_notes1` tinyint NOT NULL,
  `attribute_assign_notes2` tinyint NOT NULL,
  `enabled2` tinyint NOT NULL,
  `enabled_time2` tinyint NOT NULL,
  `disabled_time2` tinyint NOT NULL,
  `stem_id` tinyint NOT NULL,
  `attribute_assign_id1` tinyint NOT NULL,
  `attribute_assign_id2` tinyint NOT NULL,
  `attribute_def_name_id1` tinyint NOT NULL,
  `attribute_def_name_id2` tinyint NOT NULL,
  `attribute_def_id1` tinyint NOT NULL,
  `attribute_def_id2` tinyint NOT NULL,
  `action_id1` tinyint NOT NULL,
  `action_id2` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_attrdef_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_attrdef_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_attrdef_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_attrdef_v` (
  `name_of_attr_def_assigned_to` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def_assigned` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `id_of_attr_def_assigned_to` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_efmship_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_efmship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_efmship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_efmship_v` (
  `group_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_group_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_group_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_group_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_group_v` (
  `group_name` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_member_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_member_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_member_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_member_v` (
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_mship_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_mship_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_mship_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_mship_v` (
  `group_name` tinyint NOT NULL,
  `source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `list_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_aval_asn_stem_v`
--

DROP TABLE IF EXISTS `grouper_aval_asn_stem_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_stem_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_aval_asn_stem_v` (
  `stem_name` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `stem_display_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `name_of_attribute_def` tinyint NOT NULL,
  `attribute_assign_notes` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `stem_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `attribute_assign_value_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_change_log_consumer`
--

DROP TABLE IF EXISTS `grouper_change_log_consumer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_change_log_consumer` (
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `last_sequence_processed` bigint(20) DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `change_log_consumer_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_change_log_consumer`
--

LOCK TABLES `grouper_change_log_consumer` WRITE;
/*!40000 ALTER TABLE `grouper_change_log_consumer` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_change_log_consumer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_change_log_entry`
--

DROP TABLE IF EXISTS `grouper_change_log_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_change_log_entry` (
  `change_log_type_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `sequence_number` bigint(20) NOT NULL,
  `string01` text COLLATE utf8_bin,
  `string02` text COLLATE utf8_bin,
  `string03` text COLLATE utf8_bin,
  `string04` text COLLATE utf8_bin,
  `string05` text COLLATE utf8_bin,
  `string06` text COLLATE utf8_bin,
  `string07` text COLLATE utf8_bin,
  `string08` text COLLATE utf8_bin,
  `string09` text COLLATE utf8_bin,
  `string10` text COLLATE utf8_bin,
  `string11` text COLLATE utf8_bin,
  `string12` text COLLATE utf8_bin,
  PRIMARY KEY (`sequence_number`),
  KEY `change_log_sequence_number_idx` (`sequence_number`,`created_on`),
  KEY `change_log_context_id_idx` (`context_id`),
  KEY `change_log_created_on_idx` (`created_on`),
  KEY `change_log_entry_string01_idx` (`string01`(255)),
  KEY `change_log_entry_string02_idx` (`string02`(255)),
  KEY `change_log_entry_string03_idx` (`string03`(255)),
  KEY `change_log_entry_string04_idx` (`string04`(255)),
  KEY `change_log_entry_string05_idx` (`string05`(255)),
  KEY `change_log_entry_string06_idx` (`string06`(255)),
  KEY `change_log_entry_string07_idx` (`string07`(255)),
  KEY `change_log_entry_string08_idx` (`string08`(255)),
  KEY `change_log_entry_string09_idx` (`string09`(255)),
  KEY `change_log_entry_string10_idx` (`string10`(255)),
  KEY `change_log_entry_string11_idx` (`string11`(255)),
  KEY `change_log_entry_string12_idx` (`string12`(255)),
  KEY `fk_change_log_entry_type_id` (`change_log_type_id`),
  CONSTRAINT `fk_change_log_entry_type_id` FOREIGN KEY (`change_log_type_id`) REFERENCES `grouper_change_log_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_change_log_entry`
--

LOCK TABLES `grouper_change_log_entry` WRITE;
/*!40000 ALTER TABLE `grouper_change_log_entry` DISABLE KEYS */;
INSERT INTO `grouper_change_log_entry` VALUES ('f59f00f913e04fc2866da743463c9d9f',NULL,1459816157352000,1,'65947ffd4e364921a42c465d94a78c09','GrouperSystem','g:isa','application',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f59f00f913e04fc2866da743463c9d9f',NULL,1459816157393000,2,'dd763c74578f453caaac27517173178f','GrouperAll','g:isa','application',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','e7bcecb6566f419f9f687a57bfb1cdf1',1459816157432000,3,'2637cba4ab98462581efd051349db069','members',NULL,NULL,'list',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','71ee64b594a141f2b395ca39f83c7adf',1459816157865000,4,'2b05b3abce1e4d589fc89512f7d610d9','admins',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','6deb2d2beb9a477cb797e24e171a4afd',1459816157893000,5,'5ea33c8d1890401cad243bb7b765d76b','optouts',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','274e27eda91a48b6addc6aa49fe50a8a',1459816157923000,6,'5cc53183805a46ee8b4d6795bf9548b6','optins',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','440b456172304e84a5d01c0fada7d5b1',1459816157962000,7,'6ef6c29e94044581bdef90d074a04d45','readers',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','1b329515ee054ec783c15e0070025c83',1459816157989000,8,'0ad6ce292c314b10aa59cef878ab9a17','updaters',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','225f02a0ebe148948eac60792e71d014',1459816158015000,9,'abbe645d24154daebb09dcf8c5940de1','viewers',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','b869aa8f5bcb49d9b3991d8916683875',1459816158030000,10,'fc3d2f92c17b4510a9864f89fd1f04c4','groupAttrReaders',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','4b0ae9a3ce024543b16d07c907e0ac50',1459816158044000,11,'76ae221cea544a4f807ac377e2effa8f','groupAttrUpdaters',NULL,NULL,'access',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','80a32ac9b4374b90acaecbe3d1ca5d17',1459816158074000,12,'cd1c789d1a2e480384662de8de917ed1','attrAdmins',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','94b790939f37416c9d2b6e9cdc6fd923',1459816158091000,13,'99d5358f26f74749904171eb52d12e5f','attrOptouts',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','f2cf26e0ad9f45b18680e8f76bf966c4',1459816158118000,14,'3d4dfe7f92184f03801ba09f35992de3','attrOptins',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','23fa33b4278c4d72b1e6023b98668a3d',1459816158138000,15,'4e9bb975b2cf43e79651b1e519070b2c','attrReaders',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','674c7aedfd90423f873527799b6786b3',1459816158165000,16,'6f085ccfe46845c4b98d83edc6e7da49','attrUpdaters',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','d5263d78c23b4eedbd036a2149205086',1459816158186000,17,'7bda5202f90744f7b121c9eb0240e576','attrViewers',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','4476edf35ff543c1abdac2c03d68e986',1459816158207000,18,'c4305e9f9a134e1998cf093f568003ed','attrDefAttrReaders',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','73c6f0ccacd04367ba9444f6f4f41037',1459816158243000,19,'30d6952ca2314c5c8297c5560f24940f','attrDefAttrUpdaters',NULL,NULL,'attributeDef',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','0ae63d112bdd42918f051d25548340d0',1459816158272000,20,'a0f3df3f3afe4e28914131d26c413757','creators',NULL,NULL,'naming',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','243a0354c7b14540b6024a5d0405c21a',1459816158290000,21,'984bf86f08fc4d7f9b045f1b74f6f0cf','stemmers',NULL,NULL,'naming',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','74964979480f45a99af1f992e540767e',1459816158310000,22,'a9f4b02397d24462a45d981ade0c339e','stemAttrReaders',NULL,NULL,'naming',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d779ee27ec264344a6c2ed9baaa8e2d5','89e8281fe5ae408e8bd1730acae593bc',1459816158332000,23,'11552e71132c4bd8a199d9d7418cbc97','stemAttrUpdaters',NULL,NULL,'naming',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7069503770c84a6b83c6d2bf47891b25',NULL,1459816158425000,24,'d83a1feb851d4ede95786362de79547d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `grouper_change_log_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_change_log_entry_temp`
--

DROP TABLE IF EXISTS `grouper_change_log_entry_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_change_log_entry_temp` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `change_log_type_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) NOT NULL,
  `string01` text COLLATE utf8_bin,
  `string02` text COLLATE utf8_bin,
  `string03` text COLLATE utf8_bin,
  `string04` text COLLATE utf8_bin,
  `string05` text COLLATE utf8_bin,
  `string06` text COLLATE utf8_bin,
  `string07` text COLLATE utf8_bin,
  `string08` text COLLATE utf8_bin,
  `string09` text COLLATE utf8_bin,
  `string10` text COLLATE utf8_bin,
  `string11` text COLLATE utf8_bin,
  `string12` text COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `change_log_temp_string01_idx` (`string01`(255)),
  KEY `change_log_temp_string02_idx` (`string02`(255)),
  KEY `change_log_temp_string03_idx` (`string03`(255)),
  KEY `change_log_temp_string04_idx` (`string04`(255)),
  KEY `change_log_temp_string05_idx` (`string05`(255)),
  KEY `change_log_temp_string06_idx` (`string06`(255)),
  KEY `change_log_temp_string07_idx` (`string07`(255)),
  KEY `change_log_temp_string08_idx` (`string08`(255)),
  KEY `change_log_temp_string09_idx` (`string09`(255)),
  KEY `change_log_temp_string10_idx` (`string10`(255)),
  KEY `change_log_temp_string11_idx` (`string11`(255)),
  KEY `change_log_temp_string12_idx` (`string12`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_change_log_entry_temp`
--

LOCK TABLES `grouper_change_log_entry_temp` WRITE;
/*!40000 ALTER TABLE `grouper_change_log_entry_temp` DISABLE KEYS */;
INSERT INTO `grouper_change_log_entry_temp` VALUES ('0039b56292ef42febc5df581674d4717','780d4bda84dd4f8897b670da7038c945','7b21a0f6bac34729967562807de21d63',1459816163679000,'8682332826634b61a40a70e810eed95e','stem','GrouperSystem','g:isa','naming','stem','b6bc2fcd772146ee970347e496538926','etc:attribute:permissionLimits','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('006ab22109d946ed83276e27f819f142','fdab0b9a610e44af96429a2864b1a62a','0468297809164a0dba777a0bd51761a4',1459816168768000,'0576b30833b14e1aa92215ab9c39a51d','self','4bcf2e18aa6a4dfe9f75743111a1ae59','4bcf2e18aa6a4dfe9f75743111a1ae59','0576b30833b14e1aa92215ab9c39a51d','0','','','','','',''),('01b8bbf6d2034ddfb3ea95ae3326acf6','520088bd71644ff58922b1f98b718099','ae8a9d7bf747464fa3357aeb3eeff58a',1459816164557000,'fed11b1fd8d342ff8ddb84cee7d94b1d','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderIntervalSeconds','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('037f6077fffb4adf99e367923660f752','fdab0b9a610e44af96429a2864b1a62a','fc8c02098db44dd4a84b96e6bd7fdfd7',1459816164621000,'1dfd98e0490d441085898f489083995c','self','1c1293934a904003a4adcfdcafe4fd88','1c1293934a904003a4adcfdcafe4fd88','1dfd98e0490d441085898f489083995c','0','','','','','',''),('03b76bdbf1a64992a6c907ee31aaabaf','fdab0b9a610e44af96429a2864b1a62a','f8b45e1449bb4724ba6587b77b839dbd',1459816168799000,'405cfde80ce74919b398677283dca4b5','self','5e1c7a2dd9624015ad99837e5da79163','5e1c7a2dd9624015ad99837e5da79163','405cfde80ce74919b398677283dca4b5','0','','','','','',''),('03ca64e1e6e6451dac874c72496401bb','fdab0b9a610e44af96429a2864b1a62a','f04b3e10d0534430bf551971a4c6642b',1459816165196000,'486165c3b35b4759a17720dcc7ce74f2','self','8e84b513b4e948b99127d0fa84a53e78','8e84b513b4e948b99127d0fa84a53e78','486165c3b35b4759a17720dcc7ce74f2','0','','','','','',''),('04f2d02e5d32484b8a2640e655348f72','520088bd71644ff58922b1f98b718099','9b0d0d75e1824ae0a5f3e1bfcb9c8d6f',1459816164440000,'1e858851f5a04d5d957d4ca242c3a520','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderScheduleType','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('056edf1b44a0473d91b2dbddd22dba20','cd505cb7ba9f48dea846010d979f512e','7bbeeff369ab4699bcbaf02e3beb0cd6',1459816163734000,'340993371dc0497f80a6053beb40fe52','assign','dd528f792dd544938a2588848992e909','','','','','','','','',''),('067d178c0fa943dea7ecc9ef0678da66','520088bd71644ff58922b1f98b718099','0d1219aff2494a05b4b4b43458acb079',1459816166404000,'07ab972cc5c0444d805e096596685432','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapPriority','094308af1376466687416c49f1f6495f','','','','','','','',''),('07e1ba81e1a345d5be4aae91707e3eb8','e9a154dfe2d8473090e9956009767985','98ba1ea840d5404299ad811e5e2f1da2',1459816162356000,'ac55308969ef460d9b99fff54766cbbe','self','0484c4c31b4e4469a120821ddddf9ff2','0484c4c31b4e4469a120821ddddf9ff2','ac55308969ef460d9b99fff54766cbbe','0','','','','','',''),('07efcf00a1554b8c85b8532153f809ff','b892749dbf494c4abaecda25bdfa7086','10df232bdb154681a373bf730966154f',1459816161308000,'d5248b39d72f4fdcb730d1be03de4fbc','etc:attribute:attrExternalSubjectInvite','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrExternalSubjectInvite','folder for built in external subject invite attributes, and holds the data via attributes for invites.  Dont delete this folder','description','','folder for built in external subject invite attributes, and holds the data via attributes for invites.  Dont delete this folder','','','',''),('083058e013bc4d3abcaf98578dcf7512','fdab0b9a610e44af96429a2864b1a62a','e42cd0b07fde446da3c91bebf0d7ef51',1459816162990000,'18927b34acc649928d01021752bed65d','self','f5bb3d26042d4494b2a4826a03a8b0a1','f5bb3d26042d4494b2a4826a03a8b0a1','18927b34acc649928d01021752bed65d','0','','','','','',''),('091b0e3e727140ab8d2465ff793ce428','0aee5f4ab0a84991b23f77155da86e77','3b04114215324e6289c1c9be422e7e6c',1459816166309000,'6a4bdf524d1242aabb6a2765da61655e','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType','094308af1376466687416c49f1f6495f','The type of subject ID.  This can be either: subjectId (most efficient), subjectIdentifier (2nd most efficient), or subjectIdOrIdentifier','description','','The type of subject ID.  This can be either: subjectId (most efficient), subjectIdentifier (2nd most efficient), or subjectIdOrIdentifier','','','',''),('0932e3440aec47259682c16e14e29c3c','780d4bda84dd4f8897b670da7038c945','',1459816168185000,'d8809bfac4ba4706849a3d3562d4228c','attrUpdate','GrouperAll','g:isa','attributeDef','attributeDef','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef','dd763c74578f453caaac27517173178f','6f085ccfe46845c4b98d83edc6e7da49','immediate',''),('0afba20972da4ac594f66b2208d0a393','fdab0b9a610e44af96429a2864b1a62a','c6b3165c47de4bf89bacbb42df35e220',1459816166709000,'4537ef8db140452b932051dde421ff20','self','8088e8e830e24be2beded12f94412c79','8088e8e830e24be2beded12f94412c79','4537ef8db140452b932051dde421ff20','0','','','','','',''),('0b794c8f96054f37975dde55c21556e6','9ab325f8c43c48969b81919e0a237678','7bbeeff369ab4699bcbaf02e3beb0cd6',1459816163713000,'dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef','b6bc2fcd772146ee970347e496538926','','limit','','','','','','',''),('0b9649bc7373476db81781a8f99e8437','780d4bda84dd4f8897b670da7038c945','98ba1ea840d5404299ad811e5e2f1da2',1459816162378000,'3b3a36463c06409eb6098006c0846044','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rulesTypeDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('0babeaf1a1ab49dca427f27134e8b02c','fdab0b9a610e44af96429a2864b1a62a','97145747376d46c0b93b8b0c0813b3ab',1459816167807000,'2c798238446a4acca0bda187ee59aada','self','e0a40c9bef224ff3959d909777063368','e0a40c9bef224ff3959d909777063368','2c798238446a4acca0bda187ee59aada','0','','','','','',''),('0d1ba7cff49847b08efbd6496eae3b43','0aee5f4ab0a84991b23f77155da86e77','94d12e4826a44bb99a5060ddf560e544',1459816162413000,'529d4487e5ed4a27b594fcdfb79bc439','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rule','fc88a71ee4574ae7b0a550d72b5172d9','is a rule','description','','is a rule','','','',''),('0d29b9022d1544d38a3f8d4118a3c4d8','0aee5f4ab0a84991b23f77155da86e77','df392c58418743d999e73103e5f90047',1459816166341000,'db40a48a4ac943ac925a393858337d38','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapAndGroups','094308af1376466687416c49f1f6495f','If you want to restrict membership in the dynamic group based on other group(s), put the list of group names here comma-separated.  The require groups means if you put a group names in there (e.g. school:community:employee) then it will \'and\' that group with the member list from the loader.  So only members of the group from the loader query who are also employees will be in the resulting group','description','','If you want to restrict membership in the dynamic group based on other group(s), put the list of group names here comma-separated.  The require groups means if you put a group names in there (e.g. school:community:employee) then it will \'and\' that group with the member list from the loader.  So only members of the group from the loader query who are also employees will be in the resulting group','','','',''),('0f38dca6832a426ba3bfb29139256b53','780d4bda84dd4f8897b670da7038c945','',1459816164024000,'d80f5b2c22e447d3a0c035a391b59aef','attrUpdate','GrouperAll','g:isa','attributeDef','attributeDef','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt','dd763c74578f453caaac27517173178f','6f085ccfe46845c4b98d83edc6e7da49','immediate',''),('0f3ca47c41ca4edaab3f7e8757e4d381','e9a154dfe2d8473090e9956009767985','35b82a4a0f7146248919176310137474',1459816164336000,'844624ab432744928164e9aee56c17bc','self','be6656b9ea314c3786f7024884eb2ab3','be6656b9ea314c3786f7024884eb2ab3','844624ab432744928164e9aee56c17bc','0','','','','','',''),('0fee21739304481ca3856689c9670f4f','fdab0b9a610e44af96429a2864b1a62a','b842c344e0b14fa58eedeb86267fb509',1459816162838000,'12e9314ce94742e48359859ee176add2','self','a2d29ed3ef434d4aaf2d865a1179159f','a2d29ed3ef434d4aaf2d865a1179159f','12e9314ce94742e48359859ee176add2','0','','','','','',''),('1031461b2d9b4e68a62710f5c3f54184','7069503770c84a6b83c6d2bf47891b25','0564466782fa4b5fbe17c5861dbd2f23',1459816161038000,'36792aa7956240feb1bb6025c56ff2f3','etc:legacy:attribute','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy:attribute','','','','','','','',''),('10e31edeb8dc4b8697a2df77fa4b09e2','fdab0b9a610e44af96429a2864b1a62a','32bdd3c749074e56bc0f86b21c558255',1459816166447000,'528512692b394dd590342bce3389b960','self','805535775c484f7fbedfaa6ec1837ee7','805535775c484f7fbedfaa6ec1837ee7','528512692b394dd590342bce3389b960','0','','','','','',''),('1130463310a94fb3b87938683908efeb','520088bd71644ff58922b1f98b718099','4690457bb691470b874a0e3caf443122',1459816165898000,'3d4e0066247c4a8d806fd0465fa19264','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdap','094308af1376466687416c49f1f6495f','','','','','','','',''),('11dd83e481c04c75bec5fccce1a4a26e','520088bd71644ff58922b1f98b718099','a264a6db242a4c09b29fa40022439623',1459816161610000,'56f40c1d055147e78669a1be50159c53','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('1222363aa7fe45ed8981a93fd4c9e0b7','9ab325f8c43c48969b81919e0a237678','2d05ad7ebd794bb79815228acd5fed54',1459816164249000,'240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeDefLoaderTypeDef','6cd4d8196fe24d21acd51cdf8fcdb3cc','','type','','','','','','',''),('12aaf4768d7d4fdc88c13e1a7a21fc14','e9a154dfe2d8473090e9956009767985','7bbeeff369ab4699bcbaf02e3beb0cd6',1459816163742000,'f62d02fa6b334767868f68f27df17526','self','340993371dc0497f80a6053beb40fe52','340993371dc0497f80a6053beb40fe52','f62d02fa6b334767868f68f27df17526','0','','','','','',''),('12f24c1f09414363911a186545486d02','520088bd71644ff58922b1f98b718099','5557c2f4bcc34e2e8cd60c0204052972',1459816166515000,'644299b01bb54802ae883050a29f0a80','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute','094308af1376466687416c49f1f6495f','','','','','','','',''),('130a7991c5954468a9361e288cafdd70','520088bd71644ff58922b1f98b718099','13f0586b4471492284b8272b4853df04',1459816163029000,'f44cbb78b4594e0aa9ebb1d66bb1618a','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfOwnerId','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('15de4d9498754ffda665948cdcf83516','0aee5f4ab0a84991b23f77155da86e77','12c1032aef424fc79e6ba5b108343efa',1459816164580000,'fed11b1fd8d342ff8ddb84cee7d94b1d','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderIntervalSeconds','6cd4d8196fe24d21acd51cdf8fcdb3cc','If a START_TO_START_INTERVAL schedule type, this is the number of seconds between runs','description','','If a START_TO_START_INTERVAL schedule type, this is the number of seconds between runs','','','',''),('15f39e5a1ac240a79ad0de2d77a5a8c6','fdab0b9a610e44af96429a2864b1a62a','ae8a9d7bf747464fa3357aeb3eeff58a',1459816164569000,'8179202ea7f042079a7dfe8147754c80','self','fed11b1fd8d342ff8ddb84cee7d94b1d','fed11b1fd8d342ff8ddb84cee7d94b1d','8179202ea7f042079a7dfe8147754c80','0','','','','','',''),('169ea0a319fe4210821fa5013ba7ffec','0aee5f4ab0a84991b23f77155da86e77','90cac98d130b4553bfbb186f57b650e7',1459816163165000,'fd1617992c834f03827ff8b836c38c8d','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEnum','fc88a71ee4574ae7b0a550d72b5172d9','RuleIfConditionEnum that sees if rule should fire, or exclude if should run always','description','','RuleIfConditionEnum that sees if rule should fire, or exclude if should run always','','','',''),('1acc0329bbab4b4f8ba3eca83e98fb2e','fdab0b9a610e44af96429a2864b1a62a','3c3a95bbffcd4e52b160f3c3c830e01d',1459816163888000,'6f4fd81fae83461c8810a211755bb73b','self','b5a9690f188547de9a59a995da25ddad','b5a9690f188547de9a59a995da25ddad','6f4fd81fae83461c8810a211755bb73b','0','','','','','',''),('1b0f50b9fd404df29d74bd71b095452b','520088bd71644ff58922b1f98b718099','c6b3165c47de4bf89bacbb42df35e220',1459816166708000,'8088e8e830e24be2beded12f94412c79','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression','094308af1376466687416c49f1f6495f','','','','','','','',''),('1c56f6c7f2374d16b0700106bbf90ddf','520088bd71644ff58922b1f98b718099','189f028eb1c6410eaa9305f20ab29064',1459816168654000,'2a6d00b79fe24950a14169967d9ae050','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderDbName','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('1c6b5e450be842718868784ca3122c8e','0aee5f4ab0a84991b23f77155da86e77','6aaa31d5d19e434b90a39cbe959899a1',1459816164038000,'bfdb438d9f03469fa76b4eab9d099384','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitAmountLessThan','b6bc2fcd772146ee970347e496538926','Make sure the amount is less than the configured value','description','','Make sure the amount is less than the configured value','','','',''),('1ccd5f218a30405f9870046839a1aee3','fdab0b9a610e44af96429a2864b1a62a','2204b4ae6558485088f69a193cc00db9',1459816161846000,'4ed7db3a60a54e04afb1d6727fc60729','self','e6638b1ff38c41b2a4a66d7de21295bc','e6638b1ff38c41b2a4a66d7de21295bc','4ed7db3a60a54e04afb1d6727fc60729','0','','','','','',''),('1dbb2eae61cd4555b51a90e60ad7f85b','0aee5f4ab0a84991b23f77155da86e77','ef9019dfd0ab460dbf99255d2eb91f78',1459816162704000,'012b580866d74696a897403090f19239','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleActAsSubjectSourceId','fc88a71ee4574ae7b0a550d72b5172d9','subject source id to act as','description','','subject source id to act as','','','',''),('1e56c484c3f94fafa6dc51b54a32160b','fdab0b9a610e44af96429a2864b1a62a','12333b5e3a464b899fa58c020f81e411',1459816162597000,'cfb3162ec5a749cbbb5762609bef8c23','self','74166e5b8b8b4662afc4497c52faf6bc','74166e5b8b8b4662afc4497c52faf6bc','cfb3162ec5a749cbbb5762609bef8c23','0','','','','','',''),('1e97e69ff7224ffc8302de61f21ef7f6','fdab0b9a610e44af96429a2864b1a62a','a06f30635fb74eff9d01463b895bcb1f',1459816167646000,'3dc9864ba0184fe4bc2434dacd230531','self','199926a8d27b4b079b07b5be2b1c6b8a','199926a8d27b4b079b07b5be2b1c6b8a','3dc9864ba0184fe4bc2434dacd230531','0','','','','','',''),('1ee0e8536a1b40b6aedd0fea8ebddb02','0aee5f4ab0a84991b23f77155da86e77','ff5c7720e0ae4e6c87e47618cacba8df',1459816163133000,'2ce2cdca4b0040768a64021a88e8793c','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEl','fc88a71ee4574ae7b0a550d72b5172d9','expression language to run to see if the rule should run, or blank if should run always','description','','expression language to run to see if the rule should run, or blank if should run always','','','',''),('1f9aeed937624a17a145173f38c030d0','7069503770c84a6b83c6d2bf47891b25','e4639a3fb91d43a49bf595de9c390d53',1459816161162000,'1730a44d087442cc96c2d8d63b655716','etc:attribute','47bf48f95b9a4c67855b091e3d1003de','etc:attribute','','','','','','','',''),('203a37f096794ba0842d2ba9c8c91adf','520088bd71644ff58922b1f98b718099','29a5f43e03ac4d4a8040e5f44289a96c',1459816162218000,'216aa4131e1e4233bdb1170ea3e2959a','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('20798d449f16431fb5eef7571c5eec07','520088bd71644ff58922b1f98b718099','3e0ac8cccbd44997a161c1a89e7f29f8',1459816164386000,'582bfa600ca340aebed67753e38a430d','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderType','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('20c860810a12470692dd1eb0ce71b340','0aee5f4ab0a84991b23f77155da86e77','cd4905a68628431e9c59eaee354a6cf4',1459816165365000,'8e84b513b4e948b99127d0fa84a53e78','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderActionSetQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','SQL query with at least the following columns: if_has_action_name, then_has_action_name','description','','SQL query with at least the following columns: if_has_action_name, then_has_action_name','','','',''),('20e9647a8a704189adf5ab60c979bde3','fdab0b9a610e44af96429a2864b1a62a','ff95230673be4a338c69c7e423774475',1459816162776000,'bd8e1c8751844114a04f8bfc7ce88a7e','self','a26523b21e2f4e12bc93828349147061','a26523b21e2f4e12bc93828349147061','bd8e1c8751844114a04f8bfc7ce88a7e','0','','','','','',''),('216c4d98a6f7494f98c4edf7d14b338e','fdab0b9a610e44af96429a2864b1a62a','892af3b469b04b82901bfbd3834c5854',1459816167965000,'59ba6c0a704d46e0b823165cebb966de','self','d049ee88c5dd43b49ec896c7b4c804e3','d049ee88c5dd43b49ec896c7b4c804e3','59ba6c0a704d46e0b823165cebb966de','0','','','','','',''),('222fc0a9c96d48dba13804b425d87c17','520088bd71644ff58922b1f98b718099','48e769e82bde478f8d05f01b2614bedd',1459816163049000,'59a31621ed494f5e95710f2e44d45fdd','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfOwnerName','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('24ce854f0fda4b7e9f2e1b19a26097bd','b892749dbf494c4abaecda25bdfa7086','d8211cfa1a6b4abf99f5fab807eae57e',1459816161103000,'36792aa7956240feb1bb6025c56ff2f3','etc:legacy:attribute','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy:attribute','Folder for legacy attributes.  Do not delete.','description','','Folder for legacy attributes.  Do not delete.','','','',''),('2554749509f44647a3af0b6c6b1c441f','fdab0b9a610e44af96429a2864b1a62a','f2eb81248e904048ad68ed7aafdcbacb',1459816163199000,'62400899d90c442f9ab67e75508a836b','self','f0dd0e291abc44e792b1cf49af78d2c7','f0dd0e291abc44e792b1cf49af78d2c7','62400899d90c442f9ab67e75508a836b','0','','','','','',''),('2653468116164af09ebdc68b7d751331','0aee5f4ab0a84991b23f77155da86e77','0ffd3275e8ed4b5294a539897e8031e4',1459816164427000,'72ed919fa87448f6895ebdcdbc2ba25e','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderDbName','6cd4d8196fe24d21acd51cdf8fcdb3cc','DB name in grouper-loader.properties or default grouper db if blank','description','','DB name in grouper-loader.properties or default grouper db if blank','','','',''),('2684cd894a3e48738f4a0fb1375a683d','520088bd71644ff58922b1f98b718099','9c558ffbdb2a46c28c6e72094400e8ad',1459816161896000,'6b906f0d952b4c12a57c4b71d2e81001','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('269be017c60f4d5cb0e487d856858c8a','520088bd71644ff58922b1f98b718099','f04b3e10d0534430bf551971a4c6642b',1459816165195000,'8e84b513b4e948b99127d0fa84a53e78','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderActionSetQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('26b67a145b184624b48c299381f1e156','fdab0b9a610e44af96429a2864b1a62a','2e956bc7455b4499850e55c68090b3b8',1459816163275000,'0792a179c1034c15922fd72e2e364d1a','self','730af7d2426945eca3bb0e3015aff089','730af7d2426945eca3bb0e3015aff089','0792a179c1034c15922fd72e2e364d1a','0','','','','','',''),('283b173365464c9080b3feeb4167bbbe','520088bd71644ff58922b1f98b718099','dcdb24fd00514dd7a38a9ca1f53f4879',1459816164781000,'3bce1c3e4f76410c95ffa832ca202cbc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderAttrSetQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('28a8467e6fc84ed388f85919df1ad216','780d4bda84dd4f8897b670da7038c945','73cbab28d09f47459ae272f0fc2a3479',1459816161524000,'f2b8fc4b482f4cfb983fb2e2d693b177','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('2951b8ff60f3424ebf17a86810577628','cd505cb7ba9f48dea846010d979f512e','2d05ad7ebd794bb79815228acd5fed54',1459816164270000,'0f7cd113751f46f6b0f95653dd6f325d','assign','240c728c9e2c42ccb4bd63fae71d8b28','','','','','','','','',''),('299c338021ec45ad9e8d10a5c6b26ff7','520088bd71644ff58922b1f98b718099','a87d5bef3f8b45a08c8c1853907a5f95',1459816168708000,'31c7b8e6fc2048e884bd3facdc94e6de','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderIntervalSeconds','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('2a6b6fa2b8154140bc27da2a73ee2f6f','0aee5f4ab0a84991b23f77155da86e77','60e1e6d55f3d4a9f85f17b789e64ed61',1459816163256000,'5a2f5f08fbae41ff962d5142296866db','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEnumArg1','fc88a71ee4574ae7b0a550d72b5172d9','RuleIfConditionEnumArg1 if the if condition takes an argument, this is the second param','description','','RuleIfConditionEnumArg1 if the if condition takes an argument, this is the second param','','','',''),('2abdbc00607e43ce8ae78d791e3b0897','520088bd71644ff58922b1f98b718099','a06f30635fb74eff9d01463b895bcb1f',1459816167643000,'199926a8d27b4b079b07b5be2b1c6b8a','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteGroups','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('2b36dfdd481b4e9e8f1b97fc81029acd','0aee5f4ab0a84991b23f77155da86e77','0b7c9f116c6e460ea09a2fa20c0aebe6',1459816164522000,'48190ef247ff41129988f08177726deb','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderQuartzCron','6cd4d8196fe24d21acd51cdf8fcdb3cc','If a CRON schedule type, this is the cron setting string from the quartz product to run a job daily, hourly, weekly, etc.  e.g. daily at 7am: 0 0 7 * * ?','description','','If a CRON schedule type, this is the cron setting string from the quartz product to run a job daily, hourly, weekly, etc.  e.g. daily at 7am: 0 0 7 * * ?','','','',''),('2ba64113e32b48409f4da1be9772f8d6','fdab0b9a610e44af96429a2864b1a62a','da2e08cc8ac44881af984bd40fd0462e',1459816166082000,'bb8c6fd7bfd845838b04e9cc1f315f12','self','2b3af83bf1fe4868a942eb5c4b118685','2b3af83bf1fe4868a942eb5c4b118685','bb8c6fd7bfd845838b04e9cc1f315f12','0','','','','','',''),('2c478953a9c6471887c060d4af7a0a3c','fdab0b9a610e44af96429a2864b1a62a','7be126e0a319460c8f17d5cf2e42c3ce',1459816161946000,'5d42d8090fa94effbf9c75aadec1b410','self','1e49b63b42bf443c93cd5119e5bc745a','1e49b63b42bf443c93cd5119e5bc745a','5d42d8090fa94effbf9c75aadec1b410','0','','','','','',''),('2e2ea791e4684a6ebae3eeeb65d4c334','e9a154dfe2d8473090e9956009767985','a194a2a1e2ad45e7b81b45c4f987e830',1459816167396000,'6255905954654702a983ebc686c25ee8','self','d6a8882a75a3485baee64ea5255866cb','d6a8882a75a3485baee64ea5255866cb','6255905954654702a983ebc686c25ee8','0','','','','','',''),('2f3caa0cb459414d9a527ccf251aeddf','fdab0b9a610e44af96429a2864b1a62a','d0696d9069fe48f4ae34b29dc8d3cc25',1459816166360000,'acdd9f719dc54825879936b1dfe1dabf','self','2699a3d8d58644c395293106c83b0695','2699a3d8d58644c395293106c83b0695','acdd9f719dc54825879936b1dfe1dabf','0','','','','','',''),('2f7685f8ed0a45a99212222b6badabb9','520088bd71644ff58922b1f98b718099','e22af44ed0bf4d11994899e5cfbb0779',1459816164031000,'bfdb438d9f03469fa76b4eab9d099384','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitAmountLessThan','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('33756e19b2cf4925baf53b75b1f0b1b0','fdab0b9a610e44af96429a2864b1a62a','49a8efea093546c0b3894c0cd66e4ccb',1459816162906000,'4a99682a5f02494f9524de5aa090ca56','self','08468c13269a4236921d4b33d272bffb','08468c13269a4236921d4b33d272bffb','4a99682a5f02494f9524de5aa090ca56','0','','','','','',''),('3492ba8bb5d845058fc16748a793ea5e','520088bd71644ff58922b1f98b718099','d5831502745842dcaa6f4a3b8fc95138',1459816162011000,'f5aac6d1a9f94ee3870a7b3b56ab9ade','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('351cd361690d4060a6cefe57b1826724','0aee5f4ab0a84991b23f77155da86e77','52bcf03aebcb4dfd9239d48df40cca2e',1459816166912000,'d936518e709549ea942d07d26ecf45b9','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes','094308af1376466687416c49f1f6495f','Comma separated GroupTypes which will be applied to the loaded groups.  The reason this enhancement exists is so we can do a group list filter and attach addIncludeExclude to the groups.  Note, if you do this (or use some requireGroups), the group name in the loader query should end in the system of record suffix, which by default is _systemOfRecord. optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated GroupTypes which will be applied to the loaded groups.  The reason this enhancement exists is so we can do a group list filter and attach addIncludeExclude to the groups.  Note, if you do this (or use some requireGroups), the group name in the loader query should end in the system of record suffix, which by default is _systemOfRecord. optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('358a93ee7ea2478aa105ac9db56c16c6','0aee5f4ab0a84991b23f77155da86e77','4deddd2e1bbe4cc49ff7a7741f1682b7',1459816168055000,'f3a4ba3f2ef441ec8834425942161c77','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataPreferences','cb1bfad6c8ed424d902b65d9ec275df0','Preferences and metadata in json format for a user','description','','Preferences and metadata in json format for a user','','','',''),('359c0e78daef4b82be0b4e68acdff0a6','fdab0b9a610e44af96429a2864b1a62a','50f7eb6957804887bb1d70ad5359ce86',1459816168679000,'4fa30d526d30419da22f18c0eb3cd455','self','5cebc34e1bdc49e1a3c616ec88c7ff7a','5cebc34e1bdc49e1a3c616ec88c7ff7a','4fa30d526d30419da22f18c0eb3cd455','0','','','','','',''),('3612ea5c18a74df7ad5812ea77b3e665','520088bd71644ff58922b1f98b718099','94b0999935d344ec8a669da43b8a7174',1459816162403000,'529d4487e5ed4a27b594fcdfb79bc439','da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rule','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('3628aeb9226d4f2da3baf66ab9174561','780d4bda84dd4f8897b670da7038c945','99ec6323827447ebb566a0adbdada197',1459816168427000,'6d0a0572f1ce4db996e6fea57f2f4f4b','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','3e4973476a6e4351a925503a921ad728','etc:legacy:attribute:legacyGroupTypeDef_grouperLoader','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('36426890ec8a45d29b6a47bfd7cb5c8e','780d4bda84dd4f8897b670da7038c945','0564466782fa4b5fbe17c5861dbd2f23',1459816161083000,'4e8d1000f8a445c4bf1226d0c1f8d46d','stem','GrouperSystem','g:isa','naming','stem','36792aa7956240feb1bb6025c56ff2f3','etc:legacy:attribute','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('37281555ab0a4eb6b2c168fc0777d517','fdab0b9a610e44af96429a2864b1a62a','eeca4330ac3a49759b7d116f1848a898',1459816168004000,'a3ec132fcb5c4e9e894f5c2f9d4c6cc7','self','c3119a12e06041959f4c69b4078dc8f9','c3119a12e06041959f4c69b4078dc8f9','a3ec132fcb5c4e9e894f5c2f9d4c6cc7','0','','','','','',''),('387cf3fa3f31444bbbfb5ef055bf4acf','7069503770c84a6b83c6d2bf47891b25','7b21a0f6bac34729967562807de21d63',1459816163656000,'b6bc2fcd772146ee970347e496538926','etc:attribute:permissionLimits','1730a44d087442cc96c2d8d63b655716','etc:attribute:permissionLimits','','','','','','','',''),('38dee50b169445a195fb9cf0a53c9fa5','520088bd71644ff58922b1f98b718099','f2eb81248e904048ad68ed7aafdcbacb',1459816163194000,'f0dd0e291abc44e792b1cf49af78d2c7','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEnumArg0','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('398b6f731b0f492ea4ac42dfaa6fa239','0aee5f4ab0a84991b23f77155da86e77','b94b0ff3f39140068fe1a54f64413594',1459816166374000,'2699a3d8d58644c395293106c83b0695','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSearchScope','094308af1376466687416c49f1f6495f','How the deep in the subtree the search will take place.  Can be OBJECT_SCOPE, ONELEVEL_SCOPE, or SUBTREE_SCOPE (default)','description','','How the deep in the subtree the search will take place.  Can be OBJECT_SCOPE, ONELEVEL_SCOPE, or SUBTREE_SCOPE (default)','','','',''),('39f8ff2278df4919aea18baa17b3da50','780d4bda84dd4f8897b670da7038c945','8159789da0a14cafbd09145afa025cd8',1459816161764000,'1c187c48c9be45e884be9c19e9a87f29','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('3b71f0822d0c4adb9f353089e21e7cec','780d4bda84dd4f8897b670da7038c945','',1459816164140000,'ed287e4ba015469f8f1a8babc2a896b0','attrRead','GrouperAll','g:isa','attributeDef','attributeDef','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker','dd763c74578f453caaac27517173178f','4e9bb975b2cf43e79651b1e519070b2c','immediate',''),('3c172b5d6d474330a3e6322cdad00ea0','fdab0b9a610e44af96429a2864b1a62a','27d0e06cfba140b1a03fd7c903517b2b',1459816167446000,'1f48bb5a25f349ee9a62d20eb507a2fe','self','14088a5dcafc4c22870e9cb6f65f3998','14088a5dcafc4c22870e9cb6f65f3998','1f48bb5a25f349ee9a62d20eb507a2fe','0','','','','','',''),('3c311e9df9f64061bfbb84479ce27c18','9ab325f8c43c48969b81919e0a237678','98ba1ea840d5404299ad811e5e2f1da2',1459816162329000,'da7ae804604741feb591dd47b6f352be','etc:attribute:rules:rulesTypeDef','fc88a71ee4574ae7b0a550d72b5172d9','','type','','','','','','',''),('3c69d3f5d6544e538118af582e9b2fdd','0aee5f4ab0a84991b23f77155da86e77','a02fbcaf641146609d471715e06b953a',1459816164399000,'582bfa600ca340aebed67753e38a430d','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderType','6cd4d8196fe24d21acd51cdf8fcdb3cc','Type of loader, e.g. ATTR_SQL_SIMPLE','description','','Type of loader, e.g. ATTR_SQL_SIMPLE','','','',''),('3ca03f84fab7465c94048565148c7b30','fdab0b9a610e44af96429a2864b1a62a','73bd88d6231d4b5095c2ea5391619e3a',1459816168667000,'e35eb47c56104131bb18a28ec5bdf575','self','a4cacb8e06cc4ad7bafc48491a68da70','a4cacb8e06cc4ad7bafc48491a68da70','e35eb47c56104131bb18a28ec5bdf575','0','','','','','',''),('3d253a7d28694db79f564a37f778b1c9','0aee5f4ab0a84991b23f77155da86e77','23e831bdeb7e411bbd2b4313ec2813d2',1459816167660000,'199926a8d27b4b079b07b5be2b1c6b8a','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteGroups','cb1bfad6c8ed424d902b65d9ec275df0','A list of group ids and metadata in json format that are the favorites for a user','description','','A list of group ids and metadata in json format that are the favorites for a user','','','',''),('3d2d9d3c1f534019ada2353f9216dfb4','fdab0b9a610e44af96429a2864b1a62a','5a35b80f8c9840ef992ef276e4666310',1459816164487000,'b2f9f065e075495d972e109fce3b72e4','self','48190ef247ff41129988f08177726deb','48190ef247ff41129988f08177726deb','b2f9f065e075495d972e109fce3b72e4','0','','','','','',''),('3d47fb1697014f90988a83d7f20b8ac4','0aee5f4ab0a84991b23f77155da86e77','f3a8ad5c473a43628bd988c1cd56e847',1459816163849000,'7c393699d849478cbb26a265ee746b75','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitIpOnNetworks','b6bc2fcd772146ee970347e496538926','If the user is on an IP address on the following networks','description','','If the user is on an IP address on the following networks','','','',''),('3ff4c7819ecb4d3fa9fa3eddc08ce042','b892749dbf494c4abaecda25bdfa7086','916b5eab7ecb4ee6a74c707c50586a5c',1459816162311000,'fc88a71ee4574ae7b0a550d72b5172d9','etc:attribute:rules','1730a44d087442cc96c2d8d63b655716','etc:attribute:rules','folder for built in Grouper rules attributes','description','','folder for built in Grouper rules attributes','','','',''),('3ff6c033e8be47ef92d8ac573153f34f','fdab0b9a610e44af96429a2864b1a62a','0d1219aff2494a05b4b4b43458acb079',1459816166405000,'1d375ac2e73c4dd1b65ec693b482d69e','self','07ab972cc5c0444d805e096596685432','07ab972cc5c0444d805e096596685432','1d375ac2e73c4dd1b65ec693b482d69e','0','','','','','',''),('40820fe0a2da4650b82ba29828ef7aa4','fdab0b9a610e44af96429a2864b1a62a','b5986f512dd54d30bb7bc42410b77220',1459816167190000,'800720c4339d4c50918731606c30e014','self','2fa06802299b49d4b186fa96c52a077e','2fa06802299b49d4b186fa96c52a077e','800720c4339d4c50918731606c30e014','0','','','','','',''),('437a2a833da744eda33d1289815d4a8f','cd505cb7ba9f48dea846010d979f512e','b9307b3c26ab440d91b270b950336d12',1459816162482000,'449d095dcf4e466d97f89767c5ea21b6','assign','b92c64af9edd4b7493d8c4b2a936cbd8','','','','','','','','',''),('43db7deb451e45deb27c6fb5f1535a7a','520088bd71644ff58922b1f98b718099','e42cd0b07fde446da3c91bebf0d7ef51',1459816162985000,'f5bb3d26042d4494b2a4826a03a8b0a1','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckArg1','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('4402fb0c2f5e41e39b378a8013fc489a','780d4bda84dd4f8897b670da7038c945','2d05ad7ebd794bb79815228acd5fed54',1459816164281000,'b2c3650f51db4669adc839b366a1fe2f','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeDefLoaderTypeDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('441b1e80b30f4683aa855ca694860985','780d4bda84dd4f8897b670da7038c945','00618952cb8b4705b94cd916a6713a4e',1459816165884000,'9577683b84054c3298fc0c1dcbed48fb','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdapDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('4544cd5642a54e39a0983f2469ca5de4','fdab0b9a610e44af96429a2864b1a62a','e1fb3f895a0e4e0d87235bbcfe4591de',1459816163118000,'a52d83f184fc48e79feef25932975bd8','self','2ce2cdca4b0040768a64021a88e8793c','2ce2cdca4b0040768a64021a88e8793c','a52d83f184fc48e79feef25932975bd8','0','','','','','',''),('458860986b544aa6be699948824e1603','520088bd71644ff58922b1f98b718099','612df8545c8049d1afcd03b252e61953',1459816163810000,'2bb97b35188345d69f54e9bbf2008553','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitExpression','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('45a0274d0a2c41a18445bb482fc9ff06','e9a154dfe2d8473090e9956009767985','00618952cb8b4705b94cd916a6713a4e',1459816165872000,'017723bd984b4c879e200314a94e0a09','self','b94d85f218fc429880af53502780c4a3','b94d85f218fc429880af53502780c4a3','017723bd984b4c879e200314a94e0a09','0','','','','','',''),('461a5143afe441048920dd083603e4f0','fdab0b9a610e44af96429a2864b1a62a','bcd25f6eb3f7404ba27b4ff14803fb33',1459816163863844,'59fcb5f8d10f444aa9a087144148d648','self','7135e07d5e314776b1e17833aee62ea4','7135e07d5e314776b1e17833aee62ea4','59fcb5f8d10f444aa9a087144148d648','0','','','','','',''),('465f29b2b2694fc7b49031a4e762c2d5','b892749dbf494c4abaecda25bdfa7086','253f8398dd0643ba99472aad14409f41',1459816164232000,'6cd4d8196fe24d21acd51cdf8fcdb3cc','etc:attribute:attrLoader','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrLoader','folder for built in Grouper loader attributes','description','','folder for built in Grouper loader attributes','','','',''),('4702954495934bd4b695550fa415673a','fdab0b9a610e44af96429a2864b1a62a','bc0cd5e3ce104a13af5eba779f78ab77',1459816164170000,'24cb012e64ef4997ad6fd0345351781a','self','edf4fcdbbff1447e8951e6e07a38c6e3','edf4fcdbbff1447e8951e6e07a38c6e3','24cb012e64ef4997ad6fd0345351781a','0','','','','','',''),('474b864ad61d4bd99cf2e4881ee39969','520088bd71644ff58922b1f98b718099','d8dc9ab517a54835a37ec7035aeb189c',1459816166267000,'f867d93ca881408cb2191562a5b8cf36','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSourceId','094308af1376466687416c49f1f6495f','','','','','','','',''),('48ea43401a164f47aa46021e4c71f195','fdab0b9a610e44af96429a2864b1a62a','e5f02fa8f28546d1bdc87516d763bd45',1459816164683000,'01ad9bca975f48299cc9f1a1b5b11258','self','60961ff002334628a502d78685638144','60961ff002334628a502d78685638144','01ad9bca975f48299cc9f1a1b5b11258','0','','','','','',''),('49844eaaeeaf4ccdafb9439bd3d184c8','7069503770c84a6b83c6d2bf47891b25','4f6e7d1adb7648b1a98d6a407eafb323',1459816160935000,'44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy','47bf48f95b9a4c67855b091e3d1003de','etc:legacy','','','','','','','',''),('49a2fdeb0ffc431488658d5a2e1ef945','cd505cb7ba9f48dea846010d979f512e','4804a077ec2c43899a5d981c4d45375f',1459816163956000,'d02a510effc546e4aafc958453d3080d','assign','2a9bd9fd21e34e56aca2c3f93bb68928','','','','','','','','',''),('4b51051a1f464a5ba931a3cc924b9509','520088bd71644ff58922b1f98b718099','550a2e3b9e1c477e9e2a360954940852',1459816168638000,'e4f3627722644627a5a53e5afac59a27','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderType','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('4bcc359872fd4d8dbe32e3da45828273','520088bd71644ff58922b1f98b718099','7be126e0a319460c8f17d5cf2e42c3ce',1459816161944000,'1e49b63b42bf443c93cd5119e5bc745a','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('4c11d15a105946eb8bce9422f9b10c96','fdab0b9a610e44af96429a2864b1a62a','2df9149731144275bdf6d6c73a46545a',1459816167030000,'7c5b4a93f49c4c419efc3cd36591a866','self','cd9d28020e3a447787049e087358a60b','cd9d28020e3a447787049e087358a60b','7c5b4a93f49c4c419efc3cd36591a866','0','','','','','',''),('4c27f0cd914e48309e3c6c3459e87e5a','0aee5f4ab0a84991b23f77155da86e77','4f4b9e2f768848f18b536c37418d3b1f',1459816164177000,'edf4fcdbbff1447e8951e6e07a38c6e3','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitWeekday9to5','b6bc2fcd772146ee970347e496538926','Make sure the check for the permission happens between 9am to 5pm on Monday through Friday','description','','Make sure the check for the permission happens between 9am to 5pm on Monday through Friday','','','',''),('4cffefb812c44703a8b3d4a1f0fcea04','520088bd71644ff58922b1f98b718099','97145747376d46c0b93b8b0c0813b3ab',1459816167801000,'e0a40c9bef224ff3959d909777063368','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentStems','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('500d0a2ed4ea498e8a7e772e62b76145','9ab325f8c43c48969b81919e0a237678','99ec6323827447ebb566a0adbdada197',1459816168404000,'3e4973476a6e4351a925503a921ad728','etc:legacy:attribute:legacyGroupTypeDef_grouperLoader','36792aa7956240feb1bb6025c56ff2f3','','attr','','','','','','',''),('50a007f04f9049349fb6fa4463532751','780d4bda84dd4f8897b670da7038c945','4804a077ec2c43899a5d981c4d45375f',1459816163981000,'8d3df0547e994247879b71015bd78ca2','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('513bdabca652485ead06bf8cf45a82f5','780d4bda84dd4f8897b670da7038c945','e4639a3fb91d43a49bf595de9c390d53',1459816161224000,'0d63372c449c42259c2e345aa87e8d28','stem','GrouperSystem','g:isa','naming','stem','1730a44d087442cc96c2d8d63b655716','etc:attribute','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('5156859412594fff9ae31ccb01d6725f','520088bd71644ff58922b1f98b718099','23d7f62a00994d34ac976d2902e40d8c',1459816167724000,'276e5329b7a44fe396a3de5a951596ea','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentGroups','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('51a18fa61a264a05bf85dd912c7879ce','520088bd71644ff58922b1f98b718099','53dc69bab5794483b31635a3fc9b7c90',1459816167157000,'50c66205af3e4df1ae709ffcb9d33670','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapOptouts','094308af1376466687416c49f1f6495f','','','','','','','',''),('52110599cc154f0abd96e73f78b63f4c','520088bd71644ff58922b1f98b718099','e0e22b1ca4be420582969eb2ee1e232b',1459816162728000,'28a96a63bd374b03b076ce1615d6e954','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckType','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('52b8260e08b14bae810b5e376f9d63a5','fdab0b9a610e44af96429a2864b1a62a','a42b6da94ac1421e87853397a83123a4',1459816166296000,'25f29c45a20740519056c1dffa6c5373','self','6a4bdf524d1242aabb6a2765da61655e','6a4bdf524d1242aabb6a2765da61655e','25f29c45a20740519056c1dffa6c5373','0','','','','','',''),('52bf5f6115404f35b883bc45f40151d3','780d4bda84dd4f8897b670da7038c945','cc9ba9ab69e64d0c9c9ba96f0f506ce4',1459816168617000,'a017066ca9f34367a059896d7fcc9576','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('541cff2c37a943bda8b557bd5fe4710d','0aee5f4ab0a84991b23f77155da86e77','2e0e8922e59f44ef87caab10780b7d60',1459816166281000,'f867d93ca881408cb2191562a5b8cf36','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSourceId','094308af1376466687416c49f1f6495f','Source ID from the sources.xml that narrows the search for subjects.  This is optional though makes the loader job more efficient','description','','Source ID from the sources.xml that narrows the search for subjects.  This is optional though makes the loader job more efficient','','','',''),('5546d36453bd4609a76d9db5a58c3758','520088bd71644ff58922b1f98b718099','b5986f512dd54d30bb7bc42410b77220',1459816167189000,'2fa06802299b49d4b186fa96c52a077e','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders','094308af1376466687416c49f1f6495f','','','','','','','',''),('55920e3c2f004255b39b7e9e96d9af7d','9ab325f8c43c48969b81919e0a237678','0865979fcb75478ea9394435359e8b9a',1459816164077000,'c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker','b6bc2fcd772146ee970347e496538926','','limit','','','','','','',''),('55a1609b8d7047ba9a7a22d48c0865d1','0aee5f4ab0a84991b23f77155da86e77','cff229a117bb426d94c1f4783b055920',1459816166108000,'2b3af83bf1fe4868a942eb5c4b118685','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapServerId','094308af1376466687416c49f1f6495f','Server ID that is configured in the grouper-loader.properties that identifies the connection information to the LDAP server','description','','Server ID that is configured in the grouper-loader.properties that identifies the connection information to the LDAP server','','','',''),('55e6d083f60048579ffbb73b286aa32c','780d4bda84dd4f8897b670da7038c945','129701637b9d4e1f9b0222cd9069d8d3',1459816168101000,'907dd06185a744da9854e1f17bbf5e46','stem','GrouperSystem','g:isa','naming','stem','2eee186e51494f0a874fe61ff24b7192','etc:attribute:entities','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('565124a21d7542219e51343d4cb84b1d','0aee5f4ab0a84991b23f77155da86e77','029893a4cadc4eb78bf80e21516ace97',1459816163506000,'1a1c5f5bf5064e5fbfc30d723a93ac35','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnumArg2','fc88a71ee4574ae7b0a550d72b5172d9','RuleThenEnum argument 2 to run when the rule fires (enum might need args)','description','','RuleThenEnum argument 2 to run when the rule fires (enum might need args)','','','',''),('5702894b2417442492feb07388093cba','fdab0b9a610e44af96429a2864b1a62a','213c93d5247d4cac82b6525659623b61',1459816166006000,'fd43fc66000e45338a31940e79491d44','self','c3d2e8d1b61b481a92b96a5c564e6d29','c3d2e8d1b61b481a92b96a5c564e6d29','fd43fc66000e45338a31940e79491d44','0','','','','','',''),('570e9e30684a4d369a8382d75a1e29b9','fdab0b9a610e44af96429a2864b1a62a','23d7f62a00994d34ac976d2902e40d8c',1459816167725000,'5b24b379cac34078908139f9c85d0ee6','self','276e5329b7a44fe396a3de5a951596ea','276e5329b7a44fe396a3de5a951596ea','5b24b379cac34078908139f9c85d0ee6','0','','','','','',''),('5773489cd64041ebb2bba10dc9992f21','fdab0b9a610e44af96429a2864b1a62a','4346c85c13cf4e96b2446942240d1a3e',1459816162169000,'e585f8a3bd0d486fa502a230a764e213','self','93bac907e57542689a532f2ae14f9cab','93bac907e57542689a532f2ae14f9cab','e585f8a3bd0d486fa502a230a764e213','0','','','','','',''),('5796c2b57bde4cbb934a282be0d1d027','520088bd71644ff58922b1f98b718099','618cb40edc454387a6a6ac165ef656fe',1459816164052000,'9738db9ed5c645f4a395c0ce24dba834','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitAmountLessThanOrEqual','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('57d02f8be6dc4a78b8739c58279ab638','0aee5f4ab0a84991b23f77155da86e77','384e7f3803dd4e88a3d979c0dbb3f97d',1459816168208000,'0e8f891baffa4efb8c503f893937ed72','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifier','2eee186e51494f0a874fe61ff24b7192','This overrides the subjectId of the entity','description','','This overrides the subjectId of the entity','','','',''),('583a8dc9463d4888adb27d1df05422ec','b892749dbf494c4abaecda25bdfa7086','1a1948141e0143c1a7a92641d494fe97',1459816163691000,'b6bc2fcd772146ee970347e496538926','etc:attribute:permissionLimits','1730a44d087442cc96c2d8d63b655716','etc:attribute:permissionLimits','folder for built in Grouper permission limits','description','','folder for built in Grouper permission limits','','','',''),('5a1ca643b8834678998697aa93c81966','e9a154dfe2d8473090e9956009767985','73cbab28d09f47459ae272f0fc2a3479',1459816161424000,'10a3f634383242db826f8d46b6d71a22','self','4bec2791320a4968b79705397e72ad80','4bec2791320a4968b79705397e72ad80','10a3f634383242db826f8d46b6d71a22','0','','','','','',''),('5a63d9307e344e3284b2eb49ffe3d13a','7069503770c84a6b83c6d2bf47891b25','9484aa1ec9af4b48b7e2db04840dd01e',1459816167273000,'cb1bfad6c8ed424d902b65d9ec275df0','etc:attribute:userData','1730a44d087442cc96c2d8d63b655716','etc:attribute:userData','','','','','','','',''),('5acf83ee604c4936ba1081b5db5ddf42','780d4bda84dd4f8897b670da7038c945','',1459816164007000,'d4103d3531a849eeae7b0d96806246e6','attrRead','GrouperAll','g:isa','attributeDef','attributeDef','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt','dd763c74578f453caaac27517173178f','4e9bb975b2cf43e79651b1e519070b2c','immediate',''),('5b75f78c83b746caa6d2a71cb05686ef','fdab0b9a610e44af96429a2864b1a62a','3e0ac8cccbd44997a161c1a89e7f29f8',1459816164388000,'ec7ac74c56a74f939632efc821dccaab','self','582bfa600ca340aebed67753e38a430d','582bfa600ca340aebed67753e38a430d','ec7ac74c56a74f939632efc821dccaab','0','','','','','',''),('5e4d825852544f6b9aa5ed5a536d7b16','fdab0b9a610e44af96429a2864b1a62a','3f3829c0d8714599853ad296e6a30af9',1459816162690000,'94bd377ee1de434ea2d2ad0d6e1fd867','self','012b580866d74696a897403090f19239','012b580866d74696a897403090f19239','94bd377ee1de434ea2d2ad0d6e1fd867','0','','','','','',''),('5e7104946ff54b8eb765e210663a71a3','fdab0b9a610e44af96429a2864b1a62a','74495ea72b434fbfbcf62c5a7a7ce3f9',1459816164835000,'514249443fdb478bb86cae4fc53647a0','self','34f83b00843e4d8a914d6c32aa82510a','34f83b00843e4d8a914d6c32aa82510a','514249443fdb478bb86cae4fc53647a0','0','','','','','',''),('6099678092324eb48266c1d7af6db2ff','0aee5f4ab0a84991b23f77155da86e77','a089b5773113477798959c7c989c1670',1459816163079000,'59a31621ed494f5e95710f2e44d45fdd','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfOwnerName','fc88a71ee4574ae7b0a550d72b5172d9','when the if part has an arg, this is owner of if, mutually exclusive with id','description','','when the if part has an arg, this is owner of if, mutually exclusive with id','','','',''),('60d01dc83bf245e1972b0981131fc0f1','520088bd71644ff58922b1f98b718099','db2b08933797498289a1b2d786f33da3',1459816162956000,'4120ee09ca1d457b81744f71c1a0640a','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckArg0','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('626a179f53b64b508760d16537ee717f','520088bd71644ff58922b1f98b718099','eeca4330ac3a49759b7d116f1848a898',1459816168001000,'c3119a12e06041959f4c69b4078dc8f9','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('6273cc16d08d4fb2aa640e1b7a9f7d94','520088bd71644ff58922b1f98b718099','f8b45e1449bb4724ba6587b77b839dbd',1459816168794000,'5e1c7a2dd9624015ad99837e5da79163','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupQuery','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('6299f2cd294148e7a8ac7c88cc9105cd','fdab0b9a610e44af96429a2864b1a62a','e22af44ed0bf4d11994899e5cfbb0779',1459816164032000,'a65740dd259f4fd697b5f220e6e9d94e','self','bfdb438d9f03469fa76b4eab9d099384','bfdb438d9f03469fa76b4eab9d099384','a65740dd259f4fd697b5f220e6e9d94e','0','','','','','',''),('62ae3d380c2d48cf887939de5ef0244d','520088bd71644ff58922b1f98b718099','f0642610737149abbf4f6883be48764f',1459816166212000,'32b726ca079d423cbb80130baee2e731','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSearchDn','094308af1376466687416c49f1f6495f','','','','','','','',''),('634bec8cdd284b00af15676f80e17150','7069503770c84a6b83c6d2bf47891b25','d6b66eb39f3645a3a2703500fecb4a59',1459816161260000,'d5248b39d72f4fdcb730d1be03de4fbc','etc:attribute:attrExternalSubjectInvite','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrExternalSubjectInvite','','','','','','','',''),('635a20a606064d8ab16bd2ecb363f35b','0aee5f4ab0a84991b23f77155da86e77','bd01e198ce9f4a5cb5c50219e7106d60',1459816166823000,'79d043c3041d4d0db005a220dc5a438d','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression','094308af1376466687416c49f1f6495f','JEXL expression language fragment that evaluates to the group description, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','JEXL expression language fragment that evaluates to the group description, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('6364a0728b914080a34ada34f88c3a7b','fdab0b9a610e44af96429a2864b1a62a','189f028eb1c6410eaa9305f20ab29064',1459816168655000,'190ca8317f2445eeb23c7ac475637206','self','2a6d00b79fe24950a14169967d9ae050','2a6d00b79fe24950a14169967d9ae050','190ca8317f2445eeb23c7ac475637206','0','','','','','',''),('639293865bd142dcbbfa05389e83be98','fdab0b9a610e44af96429a2864b1a62a','db2b08933797498289a1b2d786f33da3',1459816162957000,'978859dbb7fc4284b6af5c6ca791fb47','self','4120ee09ca1d457b81744f71c1a0640a','4120ee09ca1d457b81744f71c1a0640a','978859dbb7fc4284b6af5c6ca791fb47','0','','','','','',''),('63c7ad965843442dbed6453412361099','780d4bda84dd4f8897b670da7038c945','',1459816168173000,'0ef478543f2a4735bf94ad80cdfa247d','attrRead','GrouperAll','g:isa','attributeDef','attributeDef','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef','dd763c74578f453caaac27517173178f','4e9bb975b2cf43e79651b1e519070b2c','immediate',''),('6498fb99858a4673ac7f924277546573','780d4bda84dd4f8897b670da7038c945','10e41282ff0b4434b2111890260d81e6',1459816162305000,'9de77a6bd3fc4df5af7af8fd8515915b','stem','GrouperSystem','g:isa','naming','stem','fc88a71ee4574ae7b0a550d72b5172d9','etc:attribute:rules','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('659a95849d3b4b0db552610275a04280','520088bd71644ff58922b1f98b718099','da2e08cc8ac44881af984bd40fd0462e',1459816166076000,'2b3af83bf1fe4868a942eb5c4b118685','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapServerId','094308af1376466687416c49f1f6495f','','','','','','','',''),('65d49bf0cebc46778121c94e8b35d5ab','b892749dbf494c4abaecda25bdfa7086','247582158264478682b29d418654f9bb',1459816168104000,'2eee186e51494f0a874fe61ff24b7192','etc:attribute:entities','1730a44d087442cc96c2d8d63b655716','etc:attribute:entities','folder for built in Grouper entities attributes','description','','folder for built in Grouper entities attributes','','','',''),('660498bc4edc466189075200177ff844','0aee5f4ab0a84991b23f77155da86e77','b95da9343fb2492ebaa7fb1d3a7c32ca',1459816162083000,'855fd99c277c4e069e0ffa2b052d89d3','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId','d5248b39d72f4fdcb730d1be03de4fbc','member id who invited this user','description','','member id who invited this user','','','',''),('66d9841d31854a9bbcc60c8d00612c60','0aee5f4ab0a84991b23f77155da86e77','1bba4c47a615420fad39fb10d2af701a',1459816166773000,'39cfeba33b784b2da20a99fb80f674d7','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression','094308af1376466687416c49f1f6495f','JEXL expression language fragment that evaluates to the group display name, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','JEXL expression language fragment that evaluates to the group display name, optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('66df8bff250e43179989e95bec7d7b53','fdab0b9a610e44af96429a2864b1a62a','cca82fcdc1ae40048daeec7daeab4093',1459816163538000,'1cc98c8fcfdf4778ad1423c89e40b346','self','0f9eb01722f5496d9aae62e828406837','0f9eb01722f5496d9aae62e828406837','1cc98c8fcfdf4778ad1423c89e40b346','0','','','','','',''),('6707e2d5b3034cb883e122a09e7b5d6b','cd505cb7ba9f48dea846010d979f512e','00618952cb8b4705b94cd916a6713a4e',1459816165864000,'b94d85f218fc429880af53502780c4a3','assign','19faf0fca06b4aeb8a5cce52382a3f0e','','','','','','','','',''),('679ce45bb0274f52aa8b2c86a3f0a63d','520088bd71644ff58922b1f98b718099','9fee9ef7604646729ba78c1038edf99b',1459816166321000,'db40a48a4ac943ac925a393858337d38','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapAndGroups','094308af1376466687416c49f1f6495f','','','','','','','',''),('6827aae0d7fb45e4baa206c718120300','520088bd71644ff58922b1f98b718099','184c4a9524a54f918209456394540023',1459816162641000,'5cbfd85dfd054f3bb9ef6fab9d7db699','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleActAsSubjectIdentifier','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('68350f4d921a498f8e24f5a3eda202ac','e9a154dfe2d8473090e9956009767985','9020c22117504dceb753bc010b2d0088',1459816167599000,'2dec318c2e7247d39b3aec0ccfcfbe42','self','b796316b96774a288bc842e51f9cca08','b796316b96774a288bc842e51f9cca08','2dec318c2e7247d39b3aec0ccfcfbe42','0','','','','','',''),('68e7496ed6a04ee99db9b0d3426bf693','0aee5f4ab0a84991b23f77155da86e77','791d5b11d1b947d1b7fbe63c8f7b60a0',1459816162664000,'5cbfd85dfd054f3bb9ef6fab9d7db699','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleActAsSubjectIdentifier','fc88a71ee4574ae7b0a550d72b5172d9','subject identifier to act as, mutually exclusive with id','description','','subject identifier to act as, mutually exclusive with id','','','',''),('6925ecdda9ca4a8488757ea2aa054145','520088bd71644ff58922b1f98b718099','99ec6323827447ebb566a0adbdada197',1459816168518000,'704fbc4dc6da4a52afa502200ffd05ff','3e4973476a6e4351a925503a921ad728','etc:legacy:attribute:legacyGroupType_grouperLoader','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('69ae5f67d9c143a3bc2e39e5b6f39d81','0aee5f4ab0a84991b23f77155da86e77','ec4c66e9bdfe4206a088599b05bd9f08',1459816165019000,'34f83b00843e4d8a914d6c32aa82510a','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderActionQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','SQL query with at least the following column: action_name','description','','SQL query with at least the following column: action_name','','','',''),('69c730b2a72348c68abb73ee6868ce79','520088bd71644ff58922b1f98b718099','c959de66b56b498fa5c42beaca665cac',1459816163369000,'053cf760d670452caa0f5c5f588639a1','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnumArg0','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('6a4aa33b87fb4d3fa85231b5835f0d3d','fdab0b9a610e44af96429a2864b1a62a','82582d20b4c64d8fa72df227ead44184',1459816168742000,'305620dcad7248509b5d146f2038f78d','self','f3edb985d6e2480da4ad894eda3b620b','f3edb985d6e2480da4ad894eda3b620b','305620dcad7248509b5d146f2038f78d','0','','','','','',''),('6c3d65cb06194f009863c0acd8d6b41f','fdab0b9a610e44af96429a2864b1a62a','f0642610737149abbf4f6883be48764f',1459816166216000,'32db5e71990044b7828367a79433a5bc','self','32b726ca079d423cbb80130baee2e731','32b726ca079d423cbb80130baee2e731','32db5e71990044b7828367a79433a5bc','0','','','','','',''),('6cb88edb9d854a3fa5306ed9721e3761','780d4bda84dd4f8897b670da7038c945','d6b66eb39f3645a3a2703500fecb4a59',1459816161297000,'1143dd90311d452bb41bd9885f7188c6','stem','GrouperSystem','g:isa','naming','stem','d5248b39d72f4fdcb730d1be03de4fbc','etc:attribute:attrExternalSubjectInvite','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('6d71c96c873d40488447a25a09e8a94d','7069503770c84a6b83c6d2bf47891b25','10e41282ff0b4434b2111890260d81e6',1459816162257000,'fc88a71ee4574ae7b0a550d72b5172d9','etc:attribute:rules','1730a44d087442cc96c2d8d63b655716','etc:attribute:rules','','','','','','','',''),('6da3377f452642a3b67b82024826e97a','520088bd71644ff58922b1f98b718099','892af3b469b04b82901bfbd3834c5854',1459816167962000,'d049ee88c5dd43b49ec896c7b4c804e3','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteAttributeDefs','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('6dc5063019cb4d989d481ec863e337ad','0aee5f4ab0a84991b23f77155da86e77','42fe5930327e41b3a115ce9012e5c2f9',1459816163321000,'4d09c98da01e4d5389b4cee05c54fc19','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEl','fc88a71ee4574ae7b0a550d72b5172d9','expression language to run when the rule fires','description','','expression language to run when the rule fires','','','',''),('6e397973b5624e2db7a4ddaedbac8b3b','520088bd71644ff58922b1f98b718099','8f6c1d0d28ee4fe59643f1fc0efd1228',1459816163237000,'5a2f5f08fbae41ff962d5142296866db','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEnumArg1','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('6e9690ad10ce4e8aaefa63f978838476','520088bd71644ff58922b1f98b718099','34736b3306354c188a18c460071de42e',1459816166613000,'7eb0914e4b5747d3abae2b5ad8edf19b','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes','094308af1376466687416c49f1f6495f','','','','','','','',''),('6ee85bad5fe643d5abf8bd7a6607dfe7','520088bd71644ff58922b1f98b718099','8009ec8d23dd4c5c83dd10e0d77ee848',1459816166897000,'d936518e709549ea942d07d26ecf45b9','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupTypes','094308af1376466687416c49f1f6495f','','','','','','','',''),('6f90b5a52293407886e6d774fa22d870','fdab0b9a610e44af96429a2864b1a62a','e0e22b1ca4be420582969eb2ee1e232b',1459816162733000,'20453a3445c3476285315b6604b796d2','self','28a96a63bd374b03b076ce1615d6e954','28a96a63bd374b03b076ce1615d6e954','20453a3445c3476285315b6604b796d2','0','','','','','',''),('6ffc51ea5c3446d8bb0ec4617abb1930','0aee5f4ab0a84991b23f77155da86e77','7af691a1d7cb4ee29a2edf3fdfad9c9e',1459816167856000,'b09cc09971d1458bb336aad641fdf526','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentAttributeDefs','cb1bfad6c8ed424d902b65d9ec275df0','A list of attribute definition ids and metadata in json format that are the recently used attribute definitions for a user','description','','A list of attribute definition ids and metadata in json format that are the recently used attribute definitions for a user','','','',''),('701bfeeb51ef42e0aa02529a18db1de9','9ab325f8c43c48969b81919e0a237678','4804a077ec2c43899a5d981c4d45375f',1459816163926000,'2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitsDefInt','b6bc2fcd772146ee970347e496538926','','limit','','','','','','',''),('72a5ee2689ab47a0a62cbfa1578c35a2','e9a154dfe2d8473090e9956009767985','d3070a409e5149a0b7bfeb8222f313ab',1459816168137000,'25775809bca445f991d461d3f7536b86','self','9a0966321c5f4109a04f490e0b6236d1','9a0966321c5f4109a04f490e0b6236d1','25775809bca445f991d461d3f7536b86','0','','','','','',''),('74f77b8a22824b3db273a4044ab6b56d','fdab0b9a610e44af96429a2864b1a62a','4690457bb691470b874a0e3caf443122',1459816165903000,'24f3de7826694f86a645e73305555c88','self','3d4e0066247c4a8d806fd0465fa19264','3d4e0066247c4a8d806fd0465fa19264','24f3de7826694f86a645e73305555c88','0','','','','','',''),('74faa26942c84c32b52d24667e7449ba','780d4bda84dd4f8897b670da7038c945','9484aa1ec9af4b48b7e2db04840dd01e',1459816167330000,'70f397c88e7846aa89ee718e7f3568e8','stem','GrouperSystem','g:isa','naming','stem','cb1bfad6c8ed424d902b65d9ec275df0','etc:attribute:userData','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('753570724d4c49b5acc917f618d68fbb','520088bd71644ff58922b1f98b718099','43f0e2a5babd431b87a45a1d43d99909',1459816168199000,'0e8f891baffa4efb8c503f893937ed72','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifier','2eee186e51494f0a874fe61ff24b7192','','','','','','','',''),('75400e6738354878af0fa35e6ce5816a','e9a154dfe2d8473090e9956009767985','99ec6323827447ebb566a0adbdada197',1459816168418000,'a90e7ef39785487b912464b825064023','self','7dd02b274f3c4f3dbe277931a06bc9aa','7dd02b274f3c4f3dbe277931a06bc9aa','a90e7ef39785487b912464b825064023','0','','','','','',''),('75d0b84553724a83b26014158f0a9b6a','0aee5f4ab0a84991b23f77155da86e77','11af3ec686424b9cb0254bf82f62c5b2',1459816167815000,'e0a40c9bef224ff3959d909777063368','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentStems','cb1bfad6c8ed424d902b65d9ec275df0','A list of folder ids and metadata in json format that are the recently used folders for a user','description','','A list of folder ids and metadata in json format that are the recently used folders for a user','','','',''),('76139c99a7f74c758215328c3b3e8fad','cd505cb7ba9f48dea846010d979f512e','0865979fcb75478ea9394435359e8b9a',1459816164111000,'4893e5881f5d49c9917da7615feebf1e','assign','c4777fa00d2e4f7aabc2184cf6023770','','','','','','','','',''),('76626ae1575c452a90276aa91570c7e0','7069503770c84a6b83c6d2bf47891b25','ea8757bd8a5e4fcb8d05e62bd36a6da4',1459816159823000,'47bf48f95b9a4c67855b091e3d1003de','etc','d83a1feb851d4ede95786362de79547d','etc','','','','','','','',''),('76a99f6598814de3bade2eea8d993f5a','0aee5f4ab0a84991b23f77155da86e77','c42bfd30649c46cbacc3d770596da778',1459816164059000,'9738db9ed5c645f4a395c0ce24dba834','2a9bd9fd21e34e56aca2c3f93bb68928','etc:attribute:permissionLimits:limitAmountLessThanOrEqual','b6bc2fcd772146ee970347e496538926','Make sure the amount is less or equal to the configured value','description','','Make sure the amount is less or equal to the configured value','','','',''),('77433ea91a41474caf7e6f9f4728c706','520088bd71644ff58922b1f98b718099','157e1da236944b37997285a6ce4d64f5',1459816163305000,'4d09c98da01e4d5389b4cee05c54fc19','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEl','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('78874522eb1d465bb93c0dff2dbab1ef','0aee5f4ab0a84991b23f77155da86e77','1d659db0efdb4062a2192fefbe41f70b',1459816161973000,'1e49b63b42bf443c93cd5119e5bc745a','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress','d5248b39d72f4fdcb730d1be03de4fbc','email address this invite was sent to','description','','email address this invite was sent to','','','',''),('79030d79caa84dee9c8c820494970732','780d4bda84dd4f8897b670da7038c945','b9307b3c26ab440d91b270b950336d12',1459816162526000,'e78d095e4b4b4643a7bb5fe6bbf89134','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('7a43303f1add432bbe997923b6d972a6','fdab0b9a610e44af96429a2864b1a62a','8009ec8d23dd4c5c83dd10e0d77ee848',1459816166902000,'6f5e417bcf8c485a8cde0a87d4160370','self','d936518e709549ea942d07d26ecf45b9','d936518e709549ea942d07d26ecf45b9','6f5e417bcf8c485a8cde0a87d4160370','0','','','','','',''),('7a6201e6104d49678c757e25b2590296','cd505cb7ba9f48dea846010d979f512e','d3070a409e5149a0b7bfeb8222f313ab',1459816168136000,'9a0966321c5f4109a04f490e0b6236d1','assign','98e846065291427bb67c498d8e70d8ec','','','','','','','','',''),('7d0986b56b7c4187bf350061d4fe0bee','0aee5f4ab0a84991b23f77155da86e77','325986d7900545049b13a0b966d3a24d',1459816161869000,'e6638b1ff38c41b2a4a66d7de21295bc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate','d5248b39d72f4fdcb730d1be03de4fbc','number of millis since 1970 when this invite expires','description','','number of millis since 1970 when this invite expires','','','',''),('7e189d983cfe4338b7d20640420d75df','0aee5f4ab0a84991b23f77155da86e77','a9ce735961814d169110b4d97cbdf113',1459816166722000,'8088e8e830e24be2beded12f94412c79','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupNameExpression','094308af1376466687416c49f1f6495f','JEXL expression language fragment that evaluates to the group name (relative in the stem as the group which has the loader definition), optional, for LDAP_GROUP_LIST, or LDAP_GROUPS_FROM_ATTRIBUTES','description','','JEXL expression language fragment that evaluates to the group name (relative in the stem as the group which has the loader definition), optional, for LDAP_GROUP_LIST, or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('7ee635311566457c90fff90b287f23a4','520088bd71644ff58922b1f98b718099','2e956bc7455b4499850e55c68090b3b8',1459816163272000,'730af7d2426945eca3bb0e3015aff089','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfStemScope','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('801393c6fe084fe4ac2fc4128d3ef1e9','520088bd71644ff58922b1f98b718099','b842c344e0b14fa58eedeb86267fb509',1459816162831000,'a2d29ed3ef434d4aaf2d865a1179159f','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckOwnerName','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('80bc1bfb00164d548114738db3d256df','780d4bda84dd4f8897b670da7038c945','4f6e7d1adb7648b1a98d6a407eafb323',1459816160999000,'a9e3b63922b94cb585c1638755168bbb','stem','GrouperSystem','g:isa','naming','stem','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('811e4ec0190f47ac9aa8f1b48b88a11a','520088bd71644ff58922b1f98b718099','fc8c02098db44dd4a84b96e6bd7fdfd7',1459816164614000,'1c1293934a904003a4adcfdcafe4fd88','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderPriority','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('81ce20a83e2b4c079473e8b5bd9f5d04','0aee5f4ab0a84991b23f77155da86e77','b5c5bac0e4644e918c0f400274a9c7c3',1459816166147000,'0c5ed4a5aa354da6a527f811cd77f455','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapFilter','094308af1376466687416c49f1f6495f','LDAP filter returns objects that have subjectIds or subjectIdentifiers and group name (if LDAP_GROUP_LIST)','description','','LDAP filter returns objects that have subjectIds or subjectIdentifiers and group name (if LDAP_GROUP_LIST)','','','',''),('83d20eeb3fc240d8984f8b3cb6222a67','0aee5f4ab0a84991b23f77155da86e77','3660dbcf1bf54570a27f8749eef1268d',1459816167455000,'14088a5dcafc4c22870e9cb6f65f3998','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserData','cb1bfad6c8ed424d902b65d9ec275df0','Marks a group that has memberships which have attributes for user data','description','','Marks a group that has memberships which have attributes for user data','','','',''),('84136d07b8aa4bcbad9c85d9fe7d29f2','0aee5f4ab0a84991b23f77155da86e77','323915da7e4745938a43442acdd43afa',1459816164804000,'3bce1c3e4f76410c95ffa832ca202cbc','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderAttrSetQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','SQL query with at least the following columns: if_has_attr_name, then_has_attr_name','description','','SQL query with at least the following columns: if_has_attr_name, then_has_attr_name','','','',''),('847201ee3a1343e2bd90f4861ea47a05','780d4bda84dd4f8897b670da7038c945','2768fb08bd7c4eff90209d082ab4ff73',1459816164226000,'8c5ea395c4544f77b2f9e771b36e4f14','stem','GrouperSystem','g:isa','naming','stem','6cd4d8196fe24d21acd51cdf8fcdb3cc','etc:attribute:attrLoader','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('8570b99fe4114dc9ac52881e6810eda5','0aee5f4ab0a84991b23f77155da86e77','44b4aeb178064ef997c86953a8092c52',1459816163010000,'f5bb3d26042d4494b2a4826a03a8b0a1','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckArg1','fc88a71ee4574ae7b0a550d72b5172d9','when the check needs an arg, this is the arg1','description','','when the check needs an arg, this is the arg1','','','',''),('85b1f7af4cb44e598a1ea28b5137dbf9','e9a154dfe2d8473090e9956009767985','2addfdcfc0b843ab9bf3fa03fe141cc7',1459816165971000,'64f282d78bd64a7aa63c565a9e69fd02','self','3da21ec8d898406b9b7e805830782c48','3da21ec8d898406b9b7e805830782c48','64f282d78bd64a7aa63c565a9e69fd02','0','','','','','',''),('86312931ae6640c185b2c945d2334536','0aee5f4ab0a84991b23f77155da86e77','4cb3515cfc654061a5acb2a8a3610996',1459816164740000,'c3d5cb11a5f446858470d00d7434020a','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderAttrQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','SQL query with at least some of the following columns: attr_name, attr_display_name, attr_description','description','','SQL query with at least some of the following columns: attr_name, attr_display_name, attr_description','','','',''),('865ac0215e454a5a94ed5eda92054d0c','0aee5f4ab0a84991b23f77155da86e77','2096c96bf5e14bbba9debadd18df822e',1459816162183000,'93bac907e57542689a532f2ae14f9cab','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered','d5248b39d72f4fdcb730d1be03de4fbc','email addresses to notify when the user registers','description','','email addresses to notify when the user registers','','','',''),('8716d00a791446f69ddfacc31b612e6f','fdab0b9a610e44af96429a2864b1a62a','728f74ab9e7d4ec9ac46a7c45ed5b8f5',1459816166241000,'736797f4b3784088af7ea66367a15549','self','44116f0e5923417fb0b3b660db88604b','44116f0e5923417fb0b3b660db88604b','736797f4b3784088af7ea66367a15549','0','','','','','',''),('872457571aea4b82a75f4ea7d9296486','fdab0b9a610e44af96429a2864b1a62a','8540b51e8e2145ebb15cc495ecd61022',1459816166947000,'9f26749ca3184812b58abaa043e377c7','self','45dd837ceb804d058a8701b473d00060','45dd837ceb804d058a8701b473d00060','9f26749ca3184812b58abaa043e377c7','0','','','','','',''),('87e12dfeb69540e0920174892aafc166','fdab0b9a610e44af96429a2864b1a62a','04e9d97ec9c646d785911c32a84a6586',1459816163349000,'52c4782b8fc946c7999cf534ada8b6d9','self','12dbd6f81fbc403e857ea8171ec087ee','12dbd6f81fbc403e857ea8171ec087ee','52c4782b8fc946c7999cf534ada8b6d9','0','','','','','',''),('87fe2551b3c746b8ad495d844cfa44b9','780d4bda84dd4f8897b670da7038c945','b62e1c7566d14267a62216d2aed227b6',1459816165656000,'adabd5c25ccc45fa8115e808bc44a0ef','stem','GrouperSystem','g:isa','naming','stem','094308af1376466687416c49f1f6495f','etc:attribute:loaderLdap','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('882f41c8d64d47ce88e3248457df2ecb','9ab325f8c43c48969b81919e0a237678','35b82a4a0f7146248919176310137474',1459816164317000,'05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef','6cd4d8196fe24d21acd51cdf8fcdb3cc','','attr','','','','','','',''),('89702d8162824435b739a599ffe1c016','0aee5f4ab0a84991b23f77155da86e77','d7b19d36fcb74644b68ea985a3490a8b',1459816163212000,'f0dd0e291abc44e792b1cf49af78d2c7','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEnumArg0','fc88a71ee4574ae7b0a550d72b5172d9','RuleIfConditionEnumArg0 if the if condition takes an argument, this is the first one','description','','RuleIfConditionEnumArg0 if the if condition takes an argument, this is the first one','','','',''),('898cf7d193ed413b8bd28e961d8b8d58','fdab0b9a610e44af96429a2864b1a62a','0bee8b8ab52546cc82faf4efb8ca212a',1459816166815000,'ce35ee13ca504963b62fb13445457a65','self','79d043c3041d4d0db005a220dc5a438d','79d043c3041d4d0db005a220dc5a438d','ce35ee13ca504963b62fb13445457a65','0','','','','','',''),('89e840ca920648cbae92ddfcb35546f7','520088bd71644ff58922b1f98b718099','3c3a95bbffcd4e52b160f3c3c830e01d',1459816163887000,'b5a9690f188547de9a59a995da25ddad','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitLabelsContain','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('8a3b970b7f354473b4a109385ec08b77','0aee5f4ab0a84991b23f77155da86e77','e72f8e885d3b4c0799b5394134dced69',1459816163559000,'0f9eb01722f5496d9aae62e828406837','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleValid','fc88a71ee4574ae7b0a550d72b5172d9','T|F for if this rule is valid, or the reason, managed by hook automatically','description','','T|F for if this rule is valid, or the reason, managed by hook automatically','','','',''),('8a870bf8c8d1443b87c6866cd4f3d159','780d4bda84dd4f8897b670da7038c945','',1459816164148000,'2f7e066ed0384c18b85bc96acdc3c598','attrUpdate','GrouperAll','g:isa','attributeDef','attributeDef','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker','dd763c74578f453caaac27517173178f','6f085ccfe46845c4b98d83edc6e7da49','immediate',''),('8bcc9b0e417740fdb1d487319f120629','520088bd71644ff58922b1f98b718099','c8be0a6effe04fda88c68a57e7f8bbbf',1459816167226000,'5618f29e9f694d8da566f2ddaec01283','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters','094308af1376466687416c49f1f6495f','','','','','','','',''),('8c95337804764d198336db2b4c5128f8','520088bd71644ff58922b1f98b718099','49a8efea093546c0b3894c0cd66e4ccb',1459816162896000,'08468c13269a4236921d4b33d272bffb','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckStemScope','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('8da9a51e9e374b288ce1a7747bb3d3dd','0aee5f4ab0a84991b23f77155da86e77','a1c53a00cab74c4b99c889a175269101',1459816162917000,'08468c13269a4236921d4b33d272bffb','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckStemScope','fc88a71ee4574ae7b0a550d72b5172d9','when the check is a stem type, this is Stem.Scope ALL or SUB','description','','when the check is a stem type, this is Stem.Scope ALL or SUB','','','',''),('8e04463381a141f3a85e0ee929cf8f99','520088bd71644ff58922b1f98b718099','c05f75a9c85b4fc5b59f1e54bfbd7e60',1459816166758000,'39cfeba33b784b2da20a99fb80f674d7','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupDisplayNameExpression','094308af1376466687416c49f1f6495f','','','','','','','',''),('8e5f52047a544c67a9953fd5462d5530','0aee5f4ab0a84991b23f77155da86e77','8cb63a2bb2e44db2a79e928ce5ea7d3b',1459816166868000,'1781bc622c7249029c32125733195f5e','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression','094308af1376466687416c49f1f6495f','JEXL expression language fragment that processes the subject string before passing it to the subject API (optional)','description','','JEXL expression language fragment that processes the subject string before passing it to the subject API (optional)','','','',''),('8ebd4ed0795040e18759c076795b1cab','520088bd71644ff58922b1f98b718099','e59ce96f5e484f12931f41af636c17e7',1459816162113000,'35113e2566d843338966edd60c435059','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('8f95007b7bd04aac9af18a316cb0e441','520088bd71644ff58922b1f98b718099','f9e41cffc7f5490eb7caf1f756aa7fbe',1459816166857000,'1781bc622c7249029c32125733195f5e','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSubjectExpression','094308af1376466687416c49f1f6495f','','','','','','','',''),('8f99a02ecbb4497aa2cdbbcd65e8926e','520088bd71644ff58922b1f98b718099','0bee8b8ab52546cc82faf4efb8ca212a',1459816166806000,'79d043c3041d4d0db005a220dc5a438d','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupDescriptionExpression','094308af1376466687416c49f1f6495f','','','','','','','',''),('8fcbab3fcfb6440ba6df04c5ebee2c07','780d4bda84dd4f8897b670da7038c945','7bbeeff369ab4699bcbaf02e3beb0cd6',1459816163754000,'a05e9947e20e4f47a35e4a5f49271023','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('90394b4f3cb244f988cbb76277dffbac','0aee5f4ab0a84991b23f77155da86e77','f4e8d347885d469aa092de93a557a2e2',1459816167695000,'2ecf3496f4524f52b0001c4556b9ff80','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteSubjects','cb1bfad6c8ed424d902b65d9ec275df0','A list of member ids and metadata in json format that are the favorites for a user','description','','A list of member ids and metadata in json format that are the favorites for a user','','','',''),('91972995aacb4c7f8a65bddb6a8b21d9','0aee5f4ab0a84991b23f77155da86e77','7cf35e369f80471ea98ae9de9cf27639',1459816163038000,'f44cbb78b4594e0aa9ebb1d66bb1618a','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfOwnerId','fc88a71ee4574ae7b0a550d72b5172d9','when the if part has an arg, this is owner of if, mutually exclusive with name','description','','when the if part has an arg, this is owner of if, mutually exclusive with name','','','',''),('92c4874668014e32bf042e2036762d16','780d4bda84dd4f8897b670da7038c945','2addfdcfc0b843ab9bf3fa03fe141cc7',1459816165988000,'6151aaab62814bfbb8ca9744a95a7428','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('92e82006b41c4cb79b4f08c281b205fb','fdab0b9a610e44af96429a2864b1a62a','c959de66b56b498fa5c42beaca665cac',1459816163371000,'cacab489d1ea44e990117304ce29ae98','self','053cf760d670452caa0f5c5f588639a1','053cf760d670452caa0f5c5f588639a1','cacab489d1ea44e990117304ce29ae98','0','','','','','',''),('93c9bd75b94f485b9f76b59c58fdf2e5','e9a154dfe2d8473090e9956009767985','cc9ba9ab69e64d0c9c9ba96f0f506ce4',1459816168597000,'3c37a5ff12f5415baea521959501a947','self','f2fcf4ee10ba4fe495e2ae04762a4e76','f2fcf4ee10ba4fe495e2ae04762a4e76','3c37a5ff12f5415baea521959501a947','0','','','','','',''),('94247875e6c84ed2a082a8221391e4c3','780d4bda84dd4f8897b670da7038c945','9020c22117504dceb753bc010b2d0088',1459816167615000,'9e1fcd948b554547b466b0e41bacc012','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('94884217a3e949469d7e702ce020105b','e9a154dfe2d8473090e9956009767985','b9307b3c26ab440d91b270b950336d12',1459816162486000,'47e4d6e8577e43ffbc78774d9ed88bf2','self','449d095dcf4e466d97f89767c5ea21b6','449d095dcf4e466d97f89767c5ea21b6','47e4d6e8577e43ffbc78774d9ed88bf2','0','','','','','',''),('953a99cbab75430395d52450fe4b12e9','520088bd71644ff58922b1f98b718099','2204b4ae6558485088f69a193cc00db9',1459816161838000,'e6638b1ff38c41b2a4a66d7de21295bc','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('953af2e9e4d046249056284a208f19f1','520088bd71644ff58922b1f98b718099','e1fb3f895a0e4e0d87235bbcfe4591de',1459816163116000,'2ce2cdca4b0040768a64021a88e8793c','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEl','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('95c111aca05d485483e3f77c3784815b','780d4bda84dd4f8897b670da7038c945','d3070a409e5149a0b7bfeb8222f313ab',1459816168145000,'67cf38884b204905ab933c08c230a1f3','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('95e7d785f5d34b569f9cebb5fb71ce30','fdab0b9a610e44af96429a2864b1a62a','299caa66b75e45b78c785c7b648c8191',1459816167920000,'514ea4ea128d4583ab18d1db88937757','self','de2074da9cd64e9393d7638e135ce76c','de2074da9cd64e9393d7638e135ce76c','514ea4ea128d4583ab18d1db88937757','0','','','','','',''),('9632348bc49a43f3902ca22b042e9a5b','9ab325f8c43c48969b81919e0a237678','2addfdcfc0b843ab9bf3fa03fe141cc7',1459816165936000,'51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapValueDef','094308af1376466687416c49f1f6495f','','attr','','','','','','',''),('96b9ece468ed44a88b1499825bae78a9','fdab0b9a610e44af96429a2864b1a62a','48e769e82bde478f8d05f01b2614bedd',1459816163057000,'af6e7f78ba6441d5959e33112b39a958','self','59a31621ed494f5e95710f2e44d45fdd','59a31621ed494f5e95710f2e44d45fdd','af6e7f78ba6441d5959e33112b39a958','0','','','','','',''),('9a914ea2ad9b4db79408368a98f144d7','0aee5f4ab0a84991b23f77155da86e77','3e63894cf9fb4395ba9160b5e820aea8',1459816162869000,'a2d29ed3ef434d4aaf2d865a1179159f','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckOwnerName','fc88a71ee4574ae7b0a550d72b5172d9','when the check should be to see if rule should fire, this is owner of type, mutually exclusice with id','description','','when the check should be to see if rule should fire, this is owner of type, mutually exclusice with id','','','',''),('9ab432ffd1ab4aa9b032dc621522ba93','9ab325f8c43c48969b81919e0a237678','73cbab28d09f47459ae272f0fc2a3479',1459816161370000,'1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDef','d5248b39d72f4fdcb730d1be03de4fbc','','type','','','','','','',''),('9b2b7adfd8774862af0860a483368117','520088bd71644ff58922b1f98b718099','3f3829c0d8714599853ad296e6a30af9',1459816162689000,'012b580866d74696a897403090f19239','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleActAsSubjectSourceId','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('9b5678881c6d4ceba21af45b72359421','520088bd71644ff58922b1f98b718099','728f74ab9e7d4ec9ac46a7c45ed5b8f5',1459816166240000,'44116f0e5923417fb0b3b660db88604b','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute','094308af1376466687416c49f1f6495f','','','','','','','',''),('9d60a14e405c43c0a87aad5350d53c7c','fdab0b9a610e44af96429a2864b1a62a','9c558ffbdb2a46c28c6e72094400e8ad',1459816161899000,'f1d4e96cb3f84b15967f9836ffd58f53','self','6b906f0d952b4c12a57c4b71d2e81001','6b906f0d952b4c12a57c4b71d2e81001','f1d4e96cb3f84b15967f9836ffd58f53','0','','','','','',''),('9dad6263b0c345e08611e08fc5bf852c','520088bd71644ff58922b1f98b718099','5f96fd1b64f646d2bb7bfb654e351e22',1459816166990000,'a45ebbb8c7d54fce9701361f8184197f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapViewers','094308af1376466687416c49f1f6495f','','','','','','','',''),('9ea327a194ea40ddaaa697d95655d063','520088bd71644ff58922b1f98b718099','74495ea72b434fbfbcf62c5a7a7ce3f9',1459816164833000,'34f83b00843e4d8a914d6c32aa82510a','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderActionQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('9fd828137812448c8a1bd782b83e607a','fdab0b9a610e44af96429a2864b1a62a','612df8545c8049d1afcd03b252e61953',1459816163812000,'8f97ad1ce6514b71b02d3eb5b6e58894','self','2bb97b35188345d69f54e9bbf2008553','2bb97b35188345d69f54e9bbf2008553','8f97ad1ce6514b71b02d3eb5b6e58894','0','','','','','',''),('a14effff531645a7bf5ad4d53f0908a6','0aee5f4ab0a84991b23f77155da86e77','6c394b97dd7d4bb19f67fab033a9f2b6',1459816163617000,'596537a994fe4969afb8b5b96f95a58e','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleRunDaemon','fc88a71ee4574ae7b0a550d72b5172d9','T|F for if this rule daemon should run.  Default to true if blank and check and if are enums, false if not','description','','T|F for if this rule daemon should run.  Default to true if blank and check and if are enums, false if not','','','',''),('a184ec8e06624851a157bdade298ba21','0aee5f4ab0a84991b23f77155da86e77','a4179ff316784682889dcbbeb5a19457',1459816164694000,'60961ff002334628a502d78685638144','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderAttrsLike','6cd4d8196fe24d21acd51cdf8fcdb3cc','If empty, then orphans will be left alone (for attributeDefName and attributeDefNameSets).  If %, then all orphans deleted.  If a SQL like string, then only ones in that like string not in loader will be deleted','description','','If empty, then orphans will be left alone (for attributeDefName and attributeDefNameSets).  If %, then all orphans deleted.  If a SQL like string, then only ones in that like string not in loader will be deleted','','','',''),('a19bf4b04c1a4cff97bde079554fc77c','520088bd71644ff58922b1f98b718099','08c3a4d2942c48c58edbb640c96986af',1459816168043000,'f3a4ba3f2ef441ec8834425942161c77','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataPreferences','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('a3d501d644bf4fbaa49278c9b9c7654f','fdab0b9a610e44af96429a2864b1a62a','948da685462a4f3ab6fcc6398b18f7b7',1459816166572000,'df9386c88b974b84ac736d0a745c16ce','self','20fc61b7fc8e4e889d1ce95b4d899cd1','20fc61b7fc8e4e889d1ce95b4d899cd1','df9386c88b974b84ac736d0a745c16ce','0','','','','','',''),('a40923defa2c4472a5f7008e3b78faff','fdab0b9a610e44af96429a2864b1a62a','d5831502745842dcaa6f4a3b8fc95138',1459816162013000,'5a0c81ec42cf420d8978c15d5fefbdc2','self','f5aac6d1a9f94ee3870a7b3b56ab9ade','f5aac6d1a9f94ee3870a7b3b56ab9ade','5a0c81ec42cf420d8978c15d5fefbdc2','0','','','','','',''),('a410724c845e47ddbe7dcfb05e9a6833','0aee5f4ab0a84991b23f77155da86e77','fe42467861024f97be880cd17c509fb1',1459816163389000,'053cf760d670452caa0f5c5f588639a1','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnumArg0','fc88a71ee4574ae7b0a550d72b5172d9','RuleThenEnum argument 0 to run when the rule fires (enum might need args)','description','','RuleThenEnum argument 0 to run when the rule fires (enum might need args)','','','',''),('a46bd83883c34097a742ff4527521459','0aee5f4ab0a84991b23f77155da86e77','d5c17c61ca1f454ea5dd8cf0d914a1a6',1459816163873000,'7135e07d5e314776b1e17833aee62ea4','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitIpOnNetworkRealm','b6bc2fcd772146ee970347e496538926','If the user is on an IP address on a centrally configured list of addresses','description','','If the user is on an IP address on a centrally configured list of addresses','','','',''),('a4acd2a82684479b9dfb60517735eeea','fdab0b9a610e44af96429a2864b1a62a','2a53e910238943af90f4e47bd422bd72',1459816164725000,'d9d524e5eb72479fb37dd004bd9d00fd','self','c3d5cb11a5f446858470d00d7434020a','c3d5cb11a5f446858470d00d7434020a','d9d524e5eb72479fb37dd004bd9d00fd','0','','','','','',''),('a4edba07bcb4443b85e1954c6d7e30a4','7069503770c84a6b83c6d2bf47891b25','2768fb08bd7c4eff90209d082ab4ff73',1459816164197000,'6cd4d8196fe24d21acd51cdf8fcdb3cc','etc:attribute:attrLoader','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrLoader','','','','','','','',''),('a56c5703513c419095c4dcd0db357760','fdab0b9a610e44af96429a2864b1a62a','b0e911e0c82d4fbbabe41c84e9a15759',1459816167768000,'951f75ed6d2741a08b3036edb9e897a7','self','7a9a1f6bccf84dda9159b82838440c01','7a9a1f6bccf84dda9159b82838440c01','951f75ed6d2741a08b3036edb9e897a7','0','','','','','',''),('a766e60373334e3ca0d9c14df817cb3f','fdab0b9a610e44af96429a2864b1a62a','f9e41cffc7f5490eb7caf1f756aa7fbe',1459816166859000,'e7dbedc1cece4e989eeaa380453befd8','self','1781bc622c7249029c32125733195f5e','1781bc622c7249029c32125733195f5e','e7dbedc1cece4e989eeaa380453befd8','0','','','','','',''),('a85c4d1433ea42eca04bdd258e0ce881','fdab0b9a610e44af96429a2864b1a62a','618cb40edc454387a6a6ac165ef656fe',1459816164053000,'9efc878f8a7b4624b2069bc4fd3b837b','self','9738db9ed5c645f4a395c0ce24dba834','9738db9ed5c645f4a395c0ce24dba834','9efc878f8a7b4624b2069bc4fd3b837b','0','','','','','',''),('a919171f4f0244d6b3e6c2ea81c7356b','fdab0b9a610e44af96429a2864b1a62a','184c4a9524a54f918209456394540023',1459816162648000,'050cacfbb8e345a5a052a12c864f4747','self','5cbfd85dfd054f3bb9ef6fab9d7db699','5cbfd85dfd054f3bb9ef6fab9d7db699','050cacfbb8e345a5a052a12c864f4747','0','','','','','',''),('a95ee43c438249a9ab49f3e727cd791d','520088bd71644ff58922b1f98b718099','d1fd6f37aecd49a39a5d13179058a5b3',1459816167878000,'4477e4a117514f2e900f7aff92c808ab','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentAttributeDefNames','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('aa7f72ae871247e399f0728beb1bca9c','fdab0b9a610e44af96429a2864b1a62a','a87d5bef3f8b45a08c8c1853907a5f95',1459816168709000,'c17013ee5ac54caca858ac108f24ae89','self','31c7b8e6fc2048e884bd3facdc94e6de','31c7b8e6fc2048e884bd3facdc94e6de','c17013ee5ac54caca858ac108f24ae89','0','','','','','',''),('aaa4a2be1ba44a8191855fea38a8d8ae','520088bd71644ff58922b1f98b718099','ff95230673be4a338c69c7e423774475',1459816162773000,'a26523b21e2f4e12bc93828349147061','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckOwnerId','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('abca107ab62942c1a6bba70ebb46f171','0aee5f4ab0a84991b23f77155da86e77','e122a3becbfc47319f96990431825ec1',1459816167890000,'4477e4a117514f2e900f7aff92c808ab','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentAttributeDefNames','cb1bfad6c8ed424d902b65d9ec275df0','A list of attribute definition name ids and metadata in json format that are the recently used attribute definition names for a user','description','','A list of attribute definition name ids and metadata in json format that are the recently used attribute definition names for a user','','','',''),('abd36174c49c435684e64e78b0903c15','520088bd71644ff58922b1f98b718099','b65007571ab141728238f43d591e633f',1459816164299000,'b1d07c0142ad43a7aa3d6a1a6e8fd0b4','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeLoader','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('abfd947dda624272bee2682a17b4d010','fdab0b9a610e44af96429a2864b1a62a','a4e080be1317422a9da9b129d8765a60',1459816163158000,'fde4d8bbbba84e2891b4c309968785ce','self','fd1617992c834f03827ff8b836c38c8d','fd1617992c834f03827ff8b836c38c8d','fde4d8bbbba84e2891b4c309968785ce','0','','','','','',''),('ac5279bd68ac49d696801c3a45e435a4','fdab0b9a610e44af96429a2864b1a62a','5e1715a2250d4fdc8196bfadcd04ef69',1459816164416000,'67d025522fd14acb84a09a010eb85a1a','self','72ed919fa87448f6895ebdcdbc2ba25e','72ed919fa87448f6895ebdcdbc2ba25e','67d025522fd14acb84a09a010eb85a1a','0','','','','','',''),('ad062744d4984c5095a4d2b2e7cbed03','fdab0b9a610e44af96429a2864b1a62a','53dc69bab5794483b31635a3fc9b7c90',1459816167159000,'a0baab27acb54fa5945079df179ab40f','self','50c66205af3e4df1ae709ffcb9d33670','50c66205af3e4df1ae709ffcb9d33670','a0baab27acb54fa5945079df179ab40f','0','','','','','',''),('ad22dada6cda4857bc9afcad04286417','520088bd71644ff58922b1f98b718099','5e1715a2250d4fdc8196bfadcd04ef69',1459816164415000,'72ed919fa87448f6895ebdcdbc2ba25e','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderDbName','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('ad98bdf5f9444a229190b8c4b2eb33f9','0aee5f4ab0a84991b23f77155da86e77','7e814238d3b94d5bb9f173d1a74b4a14',1459816167775000,'7a9a1f6bccf84dda9159b82838440c01','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteStems','cb1bfad6c8ed424d902b65d9ec275df0','A list of folder ids and metadata in json format that are the favorites for a user','description','','A list of folder ids and metadata in json format that are the favorites for a user','','','',''),('ae9b415dd0334c0b92b61c2d57b58172','fdab0b9a610e44af96429a2864b1a62a','4f40302308c74a47b2b09ce18b51b5b5',1459816167116000,'e1b877e2f4224ef3933b00a8528422bc','self','a58dc65ff39649cfaf72aa3389e1e9e8','a58dc65ff39649cfaf72aa3389e1e9e8','e1b877e2f4224ef3933b00a8528422bc','0','','','','','',''),('af1ff7095e144a42a54abf173ae6ece0','cd505cb7ba9f48dea846010d979f512e','99ec6323827447ebb566a0adbdada197',1459816168417000,'7dd02b274f3c4f3dbe277931a06bc9aa','assign','3e4973476a6e4351a925503a921ad728','','','','','','','','',''),('afc29a647ea64aa98a15b1f29124f76d','0aee5f4ab0a84991b23f77155da86e77','6017ad626c1145609452065385b405d6',1459816167737000,'276e5329b7a44fe396a3de5a951596ea','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentGroups','cb1bfad6c8ed424d902b65d9ec275df0','A list of group ids and metadata in json format that are the recently used groups for a user','description','','A list of group ids and metadata in json format that are the recently used groups for a user','','','',''),('b0a0a7ab9c214ddcb4f3dae16b4d93af','fdab0b9a610e44af96429a2864b1a62a','7332f754e23b47a1a8125d7082d2ff33',1459816163590000,'d2cd15b3892a4571ba1726047f4d613a','self','596537a994fe4969afb8b5b96f95a58e','596537a994fe4969afb8b5b96f95a58e','d2cd15b3892a4571ba1726047f4d613a','0','','','','','',''),('b0a8270401394b0dbe0e7c3f9924c8ea','520088bd71644ff58922b1f98b718099','d0696d9069fe48f4ae34b29dc8d3cc25',1459816166359000,'2699a3d8d58644c395293106c83b0695','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSearchScope','094308af1376466687416c49f1f6495f','','','','','','','',''),('b1553c33378248adb9cff455f18c8593','520088bd71644ff58922b1f98b718099','50f7eb6957804887bb1d70ad5359ce86',1459816168677000,'5cebc34e1bdc49e1a3c616ec88c7ff7a','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderQuery','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('b15b6b69065445dbbd34a39c5f960459','520088bd71644ff58922b1f98b718099','5a35b80f8c9840ef992ef276e4666310',1459816164476000,'48190ef247ff41129988f08177726deb','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderQuartzCron','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('b2174fea0f4b4275bb9e1f47b43bf45a','fdab0b9a610e44af96429a2864b1a62a','9b0d0d75e1824ae0a5f3e1bfcb9c8d6f',1459816164442000,'30a9e769eb154a928e30e888413899ca','self','1e858851f5a04d5d957d4ca242c3a520','1e858851f5a04d5d957d4ca242c3a520','30a9e769eb154a928e30e888413899ca','0','','','','','',''),('b2e03f2a81e6425eaeedf3e1d854d4e2','520088bd71644ff58922b1f98b718099','7332f754e23b47a1a8125d7082d2ff33',1459816163583000,'596537a994fe4969afb8b5b96f95a58e','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleRunDaemon','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('b2e5bd673f794feca40e816fb3897543','520088bd71644ff58922b1f98b718099','b9c217c7ab9246bc8ec1118d8d860376',1459816167684000,'2ecf3496f4524f52b0001c4556b9ff80','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteSubjects','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('b383a738f61d481dabef9843c32fb759','0aee5f4ab0a84991b23f77155da86e77','a8a25cebf2064504b5ad098c41fe1501',1459816163895000,'b5a9690f188547de9a59a995da25ddad','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitLabelsContain','b6bc2fcd772146ee970347e496538926','Configure a set of comma separated labels.  The env variable \'labels\' should be passed with comma separated labels.  If one is there, its ok, if not, then disallowed','description','','Configure a set of comma separated labels.  The env variable \'labels\' should be passed with comma separated labels.  If one is there, its ok, if not, then disallowed','','','',''),('b3c59e1db5cd46cebbc93273be1bcfad','fdab0b9a610e44af96429a2864b1a62a','08c3a4d2942c48c58edbb640c96986af',1459816168048000,'0fdc3e441be743b8aaa720fcc0e15418','self','f3a4ba3f2ef441ec8834425942161c77','f3a4ba3f2ef441ec8834425942161c77','0fdc3e441be743b8aaa720fcc0e15418','0','','','','','',''),('b468759b7c204c0ead0c1b2ef6adf3e3','520088bd71644ff58922b1f98b718099','0468297809164a0dba777a0bd51761a4',1459816168767000,'4bcf2e18aa6a4dfe9f75743111a1ae59','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupTypes','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('b48d18fa3b694e4ea920bb16f27757e1','520088bd71644ff58922b1f98b718099','cca82fcdc1ae40048daeec7daeab4093',1459816163535000,'0f9eb01722f5496d9aae62e828406837','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleValid','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('b49bd7d54a8f441a8445dcf4a700a6c7','fdab0b9a610e44af96429a2864b1a62a','9fee9ef7604646729ba78c1038edf99b',1459816166322000,'2059a81aa6b04367818a453053aae77c','self','db40a48a4ac943ac925a393858337d38','db40a48a4ac943ac925a393858337d38','2059a81aa6b04367818a453053aae77c','0','','','','','',''),('b4c76b82e9084c019e3934bc7979fec7','0aee5f4ab0a84991b23f77155da86e77','2cc6ded34620449ebfc62035db08309b',1459816162614000,'74166e5b8b8b4662afc4497c52faf6bc','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleActAsSubjectId','fc88a71ee4574ae7b0a550d72b5172d9','subject id to act as, mutually exclusive with identifier','description','','subject id to act as, mutually exclusive with identifier','','','',''),('b4d9cc57373646758250618735d0fe80','fdab0b9a610e44af96429a2864b1a62a','34736b3306354c188a18c460071de42e',1459816166617000,'5be496319df240ce8274a70f388877be','self','7eb0914e4b5747d3abae2b5ad8edf19b','7eb0914e4b5747d3abae2b5ad8edf19b','5be496319df240ce8274a70f388877be','0','','','','','',''),('b5224f4f34304487b144fd390123c9a0','0aee5f4ab0a84991b23f77155da86e77','e7c9b6bfc7cc48fd9e4411aa19379e17',1459816167079000,'d0147000b33c4cfcaa524e135adb4f43','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapUpdaters','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to UPDATE the group memberships.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to UPDATE the group memberships.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('b629b1df8bf04bf196f34af532bae7da','0aee5f4ab0a84991b23f77155da86e77','6b7820c784f6420c9b089b2463a5fa77',1459816166678000,'cc4950adff3147fd8b36fbe2fc1c2e12','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable','094308af1376466687416c49f1f6495f','Value could be true or false (default to true).  If true, then there will be an error if there are unresolvable subjects in the results.  If you know there are subjects in LDAP which are not resolvable by Grouper, set to false, they will be ignored','description','','Value could be true or false (default to true).  If true, then there will be an error if there are unresolvable subjects in the results.  If you know there are subjects in LDAP which are not resolvable by Grouper, set to false, they will be ignored','','','',''),('b6532163b5a7490d97ee1151178d2aa6','fdab0b9a610e44af96429a2864b1a62a','e59ce96f5e484f12931f41af636c17e7',1459816162119000,'f1c80d405e0e48439eec3ec421a41a5c','self','35113e2566d843338966edd60c435059','35113e2566d843338966edd60c435059','f1c80d405e0e48439eec3ec421a41a5c','0','','','','','',''),('b6f0604b331a4657ae70f1a50b08247b','0aee5f4ab0a84991b23f77155da86e77','fe34fa3bb2d845b087281d5d90bf8368',1459816166584000,'20fc61b7fc8e4e889d1ce95b4d899cd1','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression','094308af1376466687416c49f1f6495f','JEXL expression that returns true or false to signify if an attribute (in GROUPS_FROM_ATTRIBUTES) is ok to use for a group.  attributeValue is the variable that is the value of the attribute.','description','','JEXL expression that returns true or false to signify if an attribute (in GROUPS_FROM_ATTRIBUTES) is ok to use for a group.  attributeValue is the variable that is the value of the attribute.','','','',''),('b70fca73ac864342b2ca665e9749a6d6','0aee5f4ab0a84991b23f77155da86e77','74973c00475442e7a7eb279b0d0b2795',1459816163822000,'2bb97b35188345d69f54e9bbf2008553','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitExpression','b6bc2fcd772146ee970347e496538926','An expression language limit has a value of an EL which evaluates to true or false','description','','An expression language limit has a value of an EL which evaluates to true or false','','','',''),('b735eb01a89b40b3bbc2f03d71b2c60a','520088bd71644ff58922b1f98b718099','948da685462a4f3ab6fcc6398b18f7b7',1459816166571000,'20fc61b7fc8e4e889d1ce95b4d899cd1','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapAttributeFilterExpression','094308af1376466687416c49f1f6495f','','','','','','','',''),('b758e3ab1cc2452f9893805712a13aaf','e9a154dfe2d8473090e9956009767985','2d05ad7ebd794bb79815228acd5fed54',1459816164272000,'41c9a815cb1e48f9b47e860ba2c05042','self','0f7cd113751f46f6b0f95653dd6f325d','0f7cd113751f46f6b0f95653dd6f325d','41c9a815cb1e48f9b47e860ba2c05042','0','','','','','',''),('b788c0a90fd34aa88a638df4d82c3055','fdab0b9a610e44af96429a2864b1a62a','c8be0a6effe04fda88c68a57e7f8bbbf',1459816167228000,'dfade17a3ead464a94b7769af273e733','self','5618f29e9f694d8da566f2ddaec01283','5618f29e9f694d8da566f2ddaec01283','dfade17a3ead464a94b7769af273e733','0','','','','','',''),('b92105d3e41847afb75e7ea2ee3533c7','cd505cb7ba9f48dea846010d979f512e','2addfdcfc0b843ab9bf3fa03fe141cc7',1459816165968000,'3da21ec8d898406b9b7e805830782c48','assign','51f5a5e597fc4028824384b06614aba2','','','','','','','','',''),('ba89b5fd50594588a65062f7e15dd0e5','fdab0b9a610e44af96429a2864b1a62a','ed4069452f4f4f69b289e012ee25ee42',1459816167842000,'8b6055ea200244fab9f4e95221cb319a','self','b09cc09971d1458bb336aad641fdf526','b09cc09971d1458bb336aad641fdf526','8b6055ea200244fab9f4e95221cb319a','0','','','','','',''),('baa384d39871437d9bcb1f49b665f476','0aee5f4ab0a84991b23f77155da86e77','f96e8621b55040e7a2b3ab894c54fcaf',1459816167042000,'cd9d28020e3a447787049e087358a60b','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapAdmins','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to ADMIN the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to ADMIN the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('bae4ef0890e4451898be984eff48f3da','fdab0b9a610e44af96429a2864b1a62a','d8dc9ab517a54835a37ec7035aeb189c',1459816166270000,'46a4bcec29e843f4a9a7ca2b44e26e29','self','f867d93ca881408cb2191562a5b8cf36','f867d93ca881408cb2191562a5b8cf36','46a4bcec29e843f4a9a7ca2b44e26e29','0','','','','','',''),('bbfdb941c24845f69d78c5d73f1fc56f','0aee5f4ab0a84991b23f77155da86e77','a2c9cd9112ab481897e3c2ba6b533215',1459816162032000,'f5aac6d1a9f94ee3870a7b3b56ab9ade','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids','d5248b39d72f4fdcb730d1be03de4fbc','comma separated group ids to assign this user to','description','','comma separated group ids to assign this user to','','','',''),('bc148ffa2f054a9292ffd69fc5cea20f','9ab325f8c43c48969b81919e0a237678','9020c22117504dceb753bc010b2d0088',1459816167524000,'af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataValueDef','cb1bfad6c8ed424d902b65d9ec275df0','','attr','','','','','','',''),('bca94ac506f64700b78f1f516836245e','0aee5f4ab0a84991b23f77155da86e77','f3e8aedc2caf466eb1a9c0ccb5be5ee6',1459816166478000,'805535775c484f7fbedfaa6ec1837ee7','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike','094308af1376466687416c49f1f6495f','This should be a sql like string (e.g. school:orgs:%org%_systemOfRecord), and the loader should be able to query group names to see which names are managed by this loader job.  So if a group falls off the loader resultset (or is moved), this will help the loader remove the members from this group.  Note, if the group is used anywhere as a member or composite member, it wont be removed.  All include/exclude/requireGroups will be removed.  Though the two groups, include and exclude, will not be removed if they have members.  There is a grouper-loader.properties setting to remove loader groups if empty and not used: #if using a sql table, and specifying the name like string, then shoudl the group (in addition to memberships)# be removed if not used anywhere else?loader.sqlTable.likeString.removeGroupIfNotUsed = true','description','','This should be a sql like string (e.g. school:orgs:%org%_systemOfRecord), and the loader should be able to query group names to see which names are managed by this loader job.  So if a group falls off the loader resultset (or is moved), this will help the loader remove the members from this group.  Note, if the group is used anywhere as a member or composite member, it wont be removed.  All include/exclude/requireGroups will be removed.  Though the two groups, include and exclude, will not be removed if they have members.  There is a grouper-loader.properties setting to remove loader groups if empty and not used: #if using a sql table, and specifying the name like string, then shoudl the group (in addition to memberships)# be removed if not used anywhere else?loader.sqlTable.likeString.removeGroupIfNotUsed = true','','','',''),('bd4abcc65ae24f60947d87d7fa1f0b4d','780d4bda84dd4f8897b670da7038c945','35b82a4a0f7146248919176310137474',1459816164351000,'a6d997af2ca74e08bbeca5024d632129','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeDefLoaderDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('be7eb23fd2064855a6e8ce1e99935825','520088bd71644ff58922b1f98b718099','4346c85c13cf4e96b2446942240d1a3e',1459816162167000,'93bac907e57542689a532f2ae14f9cab','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('bff15112c58b43fc9eff43a641dc4494','520088bd71644ff58922b1f98b718099','bc0cd5e3ce104a13af5eba779f78ab77',1459816164163000,'edf4fcdbbff1447e8951e6e07a38c6e3','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitWeekday9to5','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('c02e8708f309435687b4eaa2f5c878e1','520088bd71644ff58922b1f98b718099','ed4069452f4f4f69b289e012ee25ee42',1459816167841000,'b09cc09971d1458bb336aad641fdf526','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentAttributeDefs','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('c040d1bdad284f608fcf3730be2c9dca','cd505cb7ba9f48dea846010d979f512e','8159789da0a14cafbd09145afa025cd8',1459816161723000,'9c65cb79f47246f0b16efcbc28fff250','assign','c3540f2df6964cb9bbc9b974cf445d84','','','','','','','','',''),('c084a3da253549889c65cda50996e478','fdab0b9a610e44af96429a2864b1a62a','99ec6323827447ebb566a0adbdada197',1459816168520000,'6f42a11d83cd4f3198841a64862b6acd','self','704fbc4dc6da4a52afa502200ffd05ff','704fbc4dc6da4a52afa502200ffd05ff','6f42a11d83cd4f3198841a64862b6acd','0','','','','','',''),('c0ce0c03bdc24182b8ebe6c26eb2110a','cd505cb7ba9f48dea846010d979f512e','73cbab28d09f47459ae272f0fc2a3479',1459816161421000,'4bec2791320a4968b79705397e72ad80','assign','1f60e0aa563e441e86b646c79c66b6ff','','','','','','','','',''),('c0d2b2e76d2044fd8fd7455695b85451','520088bd71644ff58922b1f98b718099','8540b51e8e2145ebb15cc495ecd61022',1459816166946000,'45dd837ceb804d058a8701b473d00060','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapReaders','094308af1376466687416c49f1f6495f','','','','','','','',''),('c1259f3dc5eb4ac98c28161db4b06f57','0aee5f4ab0a84991b23f77155da86e77','e632b008151641b38395597648dff2af',1459816162794000,'a26523b21e2f4e12bc93828349147061','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckOwnerId','fc88a71ee4574ae7b0a550d72b5172d9','when the check should be to see if rule should fire, this is owner of type, mutually exclusive with name','description','','when the check should be to see if rule should fire, this is owner of type, mutually exclusive with name','','','',''),('c2c9d74fc875441ebe9aaf2c0a226d4e','fdab0b9a610e44af96429a2864b1a62a','157e1da236944b37997285a6ce4d64f5',1459816163308000,'e2debb87d4b845b1991754afce213e5d','self','4d09c98da01e4d5389b4cee05c54fc19','4d09c98da01e4d5389b4cee05c54fc19','e2debb87d4b845b1991754afce213e5d','0','','','','','',''),('c34113c5b00c4515a7b0acb87c6d42eb','520088bd71644ff58922b1f98b718099','77176320181c4d7b91ea95a91d490c63',1459816168778000,'6ef48c395597459d9810bf0aac859903','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderGroupsLike','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('c3bba531ac494d31ab9a3090ec297899','0aee5f4ab0a84991b23f77155da86e77','8bb0132d8ae74ea8b6b83cb2402e59d6',1459816167125000,'a58dc65ff39649cfaf72aa3389e1e9e8','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapOptins','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT IN to the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT IN to the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('c3c8d82e6f4d40eb9bc77fd8fc071157','520088bd71644ff58922b1f98b718099','82582d20b4c64d8fa72df227ead44184',1459816168741000,'f3edb985d6e2480da4ad894eda3b620b','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderAndGroups','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('c41e8f60ee144a9f83ff3715042ee9e4','0aee5f4ab0a84991b23f77155da86e77','9b30d4ba08074e2191ff8bd06c074157',1459816166420000,'07ab972cc5c0444d805e096596685432','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapPriority','094308af1376466687416c49f1f6495f','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','description','','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','','','',''),('c47c6a70d3d348ca908ab69aceb1b3c2','0aee5f4ab0a84991b23f77155da86e77','2013dba4ecb940b8bb5845e351ed4779',1459816167205000,'2fa06802299b49d4b186fa96c52a077e','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrReaders','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_READ on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_READ on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('c4bc028b33834e37baa91a44326c26bc','fdab0b9a610e44af96429a2864b1a62a','b65007571ab141728238f43d591e633f',1459816164300000,'f8acb32afaed4f76a815b771cc404d3c','self','b1d07c0142ad43a7aa3d6a1a6e8fd0b4','b1d07c0142ad43a7aa3d6a1a6e8fd0b4','f8acb32afaed4f76a815b771cc404d3c','0','','','','','',''),('c51a7aa2cd3140668d57359197368cba','fdab0b9a610e44af96429a2864b1a62a','7fbe1e513dc84bd19a243955ec148c84',1459816162066000,'9161c6a7b9204fcc98b451de4a723901','self','855fd99c277c4e069e0ffa2b052d89d3','855fd99c277c4e069e0ffa2b052d89d3','9161c6a7b9204fcc98b451de4a723901','0','','','','','',''),('c5b10608f54b470c981356ebc23b2fc2','0aee5f4ab0a84991b23f77155da86e77','9d90748df5764171beb921e16a331ebb',1459816166547000,'644299b01bb54802ae883050a29f0a80','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttribute','094308af1376466687416c49f1f6495f','Attribute name of the filter object result that holds the group name (required for loader ldap type: LDAP_GROUPS_FROM_ATTRIBUTE)','description','','Attribute name of the filter object result that holds the group name (required for loader ldap type: LDAP_GROUPS_FROM_ATTRIBUTE)','','','',''),('c63651af06694ad8a4f27d9f74722186','fdab0b9a610e44af96429a2864b1a62a','960473ac0a764e3db73be6b4a8434b0c',1459816168732000,'ae31e4c05c9749349609d78cbbf2fe55','self','78a353168b3d4cf7bf9d0b299aaf113e','78a353168b3d4cf7bf9d0b299aaf113e','ae31e4c05c9749349609d78cbbf2fe55','0','','','','','',''),('c63d6d85238c4e16836e8d8847028885','520088bd71644ff58922b1f98b718099','a4e080be1317422a9da9b129d8765a60',1459816163157000,'fd1617992c834f03827ff8b836c38c8d','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfConditionEnum','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('c6d05207551c4e4e94c5325140021d5f','520088bd71644ff58922b1f98b718099','bcd25f6eb3f7404ba27b4ff14803fb33',1459816163863000,'7135e07d5e314776b1e17833aee62ea4','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitIpOnNetworkRealm','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('c6f00bebfb7b4f819252fa27d995ee6e','e9a154dfe2d8473090e9956009767985','4804a077ec2c43899a5d981c4d45375f',1459816163957000,'3f4130e6f63948229f4086e7a144c0a0','self','d02a510effc546e4aafc958453d3080d','d02a510effc546e4aafc958453d3080d','3f4130e6f63948229f4086e7a144c0a0','0','','','','','',''),('c7b1c58da085446ab5aca488c41e9136','0aee5f4ab0a84991b23f77155da86e77','d3d7268b43794299808770f320638d6f',1459816166249000,'44116f0e5923417fb0b3b660db88604b','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSubjectAttribute','094308af1376466687416c49f1f6495f','Attribute name of the filter object result that holds the subject id.  Note, if you use \'dn\', and dn is not an attribute of the object, then the fully qualified object name will be used','description','','Attribute name of the filter object result that holds the subject id.  Note, if you use \'dn\', and dn is not an attribute of the object, then the fully qualified object name will be used','','','',''),('c8ce88edf1604f9ab07734c90864d0b6','520088bd71644ff58922b1f98b718099','e5f02fa8f28546d1bdc87516d763bd45',1459816164680000,'60961ff002334628a502d78685638144','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderAttrsLike','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('c922628fdb2644268df1870dbdc69bf5','520088bd71644ff58922b1f98b718099','27d0e06cfba140b1a03fd7c903517b2b',1459816167440000,'14088a5dcafc4c22870e9cb6f65f3998','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserData','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('ca1aeaad2e2442ed82f33272dc6ea31f','0aee5f4ab0a84991b23f77155da86e77','c66f39bfe9ca40278b54b0cac21c8159',1459816161916000,'6b906f0d952b4c12a57c4b71d2e81001','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate','d5248b39d72f4fdcb730d1be03de4fbc','number of millis since 1970 that this invite was issued','description','','number of millis since 1970 that this invite was issued','','','',''),('cb0dd708845349bb91e0c435a7350076','0aee5f4ab0a84991b23f77155da86e77','c00b64b63223480c8d991379caad5657',1459816166184000,'3abd9f032c2c42318cd5e5e014c27a69','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron','094308af1376466687416c49f1f6495f','Quartz cron config string, e.g. every day at 8am is: 0 0 8 * * ?','description','','Quartz cron config string, e.g. every day at 8am is: 0 0 8 * * ?','','','',''),('cbc0c27f6d804ebd96c654cefe2a80ed','fdab0b9a610e44af96429a2864b1a62a','8f6c1d0d28ee4fe59643f1fc0efd1228',1459816163244000,'cc6b33b70d794a9a986977b290cbb0a2','self','5a2f5f08fbae41ff962d5142296866db','5a2f5f08fbae41ff962d5142296866db','cc6b33b70d794a9a986977b290cbb0a2','0','','','','','',''),('ccaf559e6ffd4c88a3fed91749247f4e','0aee5f4ab0a84991b23f77155da86e77','5865a9434f884892b851fe4b285c6157',1459816166635000,'7eb0914e4b5747d3abae2b5ad8edf19b','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapExtraAttributes','094308af1376466687416c49f1f6495f','Attribute names (comma separated) to get LDAP data for expressions in group name, displayExtension, description, optional, for LDAP_GROUP_LIST','description','','Attribute names (comma separated) to get LDAP data for expressions in group name, displayExtension, description, optional, for LDAP_GROUP_LIST','','','',''),('cd0755ee892d49389562c21d5b52a5a2','0aee5f4ab0a84991b23f77155da86e77','71be3c3a1ed7438fa03a9f603684b57d',1459816167170000,'50c66205af3e4df1ae709ffcb9d33670','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapOptouts','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT OUT of the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to OPT OUT of the group membership list.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('cd4bb1c8237e46d6a20897ff5086e5ac','520088bd71644ff58922b1f98b718099','ea0b11775d354ec0902c36f4a8737f5a',1459816166169000,'3abd9f032c2c42318cd5e5e014c27a69','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapQuartzCron','094308af1376466687416c49f1f6495f','','','','','','','',''),('cd813c642979425faf6c2b84003386b6','9ab325f8c43c48969b81919e0a237678','d3070a409e5149a0b7bfeb8222f313ab',1459816168118000,'98e846065291427bb67c498d8e70d8ec','etc:attribute:entities:entitySubjectIdentifierDef','2eee186e51494f0a874fe61ff24b7192','','attr','','','','','','',''),('cd88a1024f414dc0856844847cbd301f','b892749dbf494c4abaecda25bdfa7086','e7d2e5bb9a214c98afe09f3e43fdc45e',1459816167349000,'cb1bfad6c8ed424d902b65d9ec275df0','etc:attribute:userData','1730a44d087442cc96c2d8d63b655716','etc:attribute:userData','folder for built in Grouper user data attributes','description','','folder for built in Grouper user data attributes','','','',''),('cda9d6cf62e748a191657ec3c085d2de','0aee5f4ab0a84991b23f77155da86e77','7c7d8dbf4f8345da8ac3a657ff3d83be',1459816166998000,'a45ebbb8c7d54fce9701361f8184197f','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapViewers','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to VIEW the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to VIEW the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('ce27298cdf674f0abcd9f22918db78b0','fdab0b9a610e44af96429a2864b1a62a','dcdb24fd00514dd7a38a9ca1f53f4879',1459816164782000,'269259823d3640a3bd6e31b34445b89b','self','3bce1c3e4f76410c95ffa832ca202cbc','3bce1c3e4f76410c95ffa832ca202cbc','269259823d3640a3bd6e31b34445b89b','0','','','','','',''),('cebdc9b69f414ee7a019f4f4e561841c','0aee5f4ab0a84991b23f77155da86e77','8a2ebb9e8ecb43fa8c615bbc4046749a',1459816167939000,'de2074da9cd64e9393d7638e135ce76c','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentSubjects','cb1bfad6c8ed424d902b65d9ec275df0','A list of attribute member ids and metadata in json format that are the recently used subjects for a user','description','','A list of attribute member ids and metadata in json format that are the recently used subjects for a user','','','',''),('cecf1350a7d9416492e3dae9e1b0c9b6','0aee5f4ab0a84991b23f77155da86e77','904c09b6b5794498bda9fd1c64cd2198',1459816162227000,'216aa4131e1e4233bdb1170ea3e2959a','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail','d5248b39d72f4fdcb730d1be03de4fbc','email sent to user as invite','description','','email sent to user as invite','','','',''),('cf7ad8fab99c4b7883d79a84ed7844da','520088bd71644ff58922b1f98b718099','2a53e910238943af90f4e47bd422bd72',1459816164720000,'c3d5cb11a5f446858470d00d7434020a','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderAttrQuery','6cd4d8196fe24d21acd51cdf8fcdb3cc','','','','','','','',''),('cfae707cd19e4a62bc073327f04930d5','fdab0b9a610e44af96429a2864b1a62a','d1fd6f37aecd49a39a5d13179058a5b3',1459816167879000,'4e05eea651e548129a1d342f95c81499','self','4477e4a117514f2e900f7aff92c808ab','4477e4a117514f2e900f7aff92c808ab','4e05eea651e548129a1d342f95c81499','0','','','','','',''),('d018c812e3c94fb2a3626c4be813e17d','fdab0b9a610e44af96429a2864b1a62a','e866d25952e34dc9bd6ed26afb277c6e',1459816167071000,'85002815c2b04d0fbd2265cb05bcf363','self','d0147000b33c4cfcaa524e135adb4f43','d0147000b33c4cfcaa524e135adb4f43','85002815c2b04d0fbd2265cb05bcf363','0','','','','','',''),('d111f17c5a2645169d2461103c586682','9ab325f8c43c48969b81919e0a237678','8159789da0a14cafbd09145afa025cd8',1459816161668000,'c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteAttrDef','d5248b39d72f4fdcb730d1be03de4fbc','','attr','','','','','','',''),('d2286781d3fe475794b0e2ba6bc3e0fc','0aee5f4ab0a84991b23f77155da86e77','58e4bd301a9c4bbc856cf119801fa4ec',1459816166959000,'45dd837ceb804d058a8701b473d00060','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapReaders','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to READ the group membership.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to READ the group membership.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('d25f04847b3440de9c720cdb15e36d33','520088bd71644ff58922b1f98b718099','6930ebdfd50a443593fd420d34f9fc74',1459816168695000,'2834e8c199de44eda7c2f74c83c895d2','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderQuartzCron','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('d398c5c655fd48c7bc973c5e93b7e5e1','520088bd71644ff58922b1f98b718099','7fbe1e513dc84bd19a243955ec148c84',1459816162061000,'855fd99c277c4e069e0ffa2b052d89d3','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId','d5248b39d72f4fdcb730d1be03de4fbc','','','','','','','',''),('d591214b069340ada14f65228929f237','520088bd71644ff58922b1f98b718099','2df9149731144275bdf6d6c73a46545a',1459816167029000,'cd9d28020e3a447787049e087358a60b','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapAdmins','094308af1376466687416c49f1f6495f','','','','','','','',''),('d59db3d7bff44be9a5bcf9c659848694','520088bd71644ff58922b1f98b718099','213c93d5247d4cac82b6525659623b61',1459816166005000,'c3d2e8d1b61b481a92b96a5c564e6d29','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapType','094308af1376466687416c49f1f6495f','','','','','','','',''),('d5a1bcdde314459a9bebc21ffdabacea','0aee5f4ab0a84991b23f77155da86e77','d992665496bd470f9d047184e8caf337',1459816162136000,'35113e2566d843338966edd60c435059','c3540f2df6964cb9bbc9b974cf445d84','etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid','d5248b39d72f4fdcb730d1be03de4fbc','unique id in the email sent to the user','description','','unique id in the email sent to the user','','','',''),('d6ffa7af63fd48709e24d964e0b756b6','0aee5f4ab0a84991b23f77155da86e77','cc4092f92f8648ad88febca2803b5852',1459816165912000,'3d4e0066247c4a8d806fd0465fa19264','19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdap','094308af1376466687416c49f1f6495f','Marks a group to be processed by the Grouper loader as an LDAP synced job','description','','Marks a group to be processed by the Grouper loader as an LDAP synced job','','','',''),('d75f39a36b7746a4b535531066391b6b','fdab0b9a610e44af96429a2864b1a62a','a264a6db242a4c09b29fa40022439623',1459816161615000,'038e8d3efb10424088a24ff03b8deada','self','56f40c1d055147e78669a1be50159c53','56f40c1d055147e78669a1be50159c53','038e8d3efb10424088a24ff03b8deada','0','','','','','',''),('d83c4fcb8cea4f1e8f71d763c4b50f8c','fdab0b9a610e44af96429a2864b1a62a','94b0999935d344ec8a669da43b8a7174',1459816162404000,'1c9d3791c420488ba2fa967fb9f8729f','self','529d4487e5ed4a27b594fcdfb79bc439','529d4487e5ed4a27b594fcdfb79bc439','1c9d3791c420488ba2fa967fb9f8729f','0','','','','','',''),('d880ec1c66db41d3ae0a77ae3b6b9e59','780d4bda84dd4f8897b670da7038c945','',1459816163799000,'109f0358574544ee8f167a6dff1534c8','attrUpdate','GrouperAll','g:isa','attributeDef','attributeDef','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef','dd763c74578f453caaac27517173178f','6f085ccfe46845c4b98d83edc6e7da49','immediate',''),('d8cca3cfaacf422fa9fd3c4ddaf6ab40','b892749dbf494c4abaecda25bdfa7086','d606df9bf9e346ff98ce07d7005f0135',1459816165660000,'094308af1376466687416c49f1f6495f','etc:attribute:loaderLdap','1730a44d087442cc96c2d8d63b655716','etc:attribute:loaderLdap','folder for built in Grouper loader ldap attributes','description','','folder for built in Grouper loader ldap attributes','','','',''),('d90cdddb7cdb407693798d0bf4011955','520088bd71644ff58922b1f98b718099','73bd88d6231d4b5095c2ea5391619e3a',1459816168664000,'a4cacb8e06cc4ad7bafc48491a68da70','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderScheduleType','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('d918b621e97641928fb2cc4828a79aaa','fdab0b9a610e44af96429a2864b1a62a','40561649fbce4373a84ed95089064d20',1459816166135000,'9da6c79a3bef42bcb0c595418b71246e','self','0c5ed4a5aa354da6a527f811cd77f455','0c5ed4a5aa354da6a527f811cd77f455','9da6c79a3bef42bcb0c595418b71246e','0','','','','','',''),('d959af880b764154b11b0819892fe45a','fdab0b9a610e44af96429a2864b1a62a','531dc15e5d794a89b9750e666b2f12ec',1459816163485000,'a7b256eee90e4be6a81a95a2d6d41e9e','self','1a1c5f5bf5064e5fbfc30d723a93ac35','1a1c5f5bf5064e5fbfc30d723a93ac35','a7b256eee90e4be6a81a95a2d6d41e9e','0','','','','','',''),('d9a77e1c81854af9afd0a8fb55d2d709','520088bd71644ff58922b1f98b718099','32bdd3c749074e56bc0f86b21c558255',1459816166446000,'805535775c484f7fbedfaa6ec1837ee7','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupsLike','094308af1376466687416c49f1f6495f','','','','','','','',''),('dbd0d2590ccf498098efd08400407660','fdab0b9a610e44af96429a2864b1a62a','29a5f43e03ac4d4a8040e5f44289a96c',1459816162220000,'02fc4078df3a489780b3e8c9a9c2c86b','self','216aa4131e1e4233bdb1170ea3e2959a','216aa4131e1e4233bdb1170ea3e2959a','02fc4078df3a489780b3e8c9a9c2c86b','0','','','','','',''),('dd0f80dbb0d84a6c9a585a5f41a06116','0aee5f4ab0a84991b23f77155da86e77','431e2c4c3afa4fdebb2bcf81fbaff710',1459816161638000,'56f40c1d055147e78669a1be50159c53','1f60e0aa563e441e86b646c79c66b6ff','etc:attribute:attrExternalSubjectInvite:externalSubjectInvite','d5248b39d72f4fdcb730d1be03de4fbc','is an invite','description','','is an invite','','','',''),('dde358fbc75243f790a9c813f48a70c1','0aee5f4ab0a84991b23f77155da86e77','8e2f93f08eb049c5ba29684848c83e2b',1459816168020000,'c3119a12e06041959f4c69b4078dc8f9','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteAttributeDefNames','cb1bfad6c8ed424d902b65d9ec275df0','A list of attribute definition name ids and metadata in json format that are the favorites for a user','description','','A list of attribute definition name ids and metadata in json format that are the favorites for a user','','','',''),('ddf688304037409da8354c0346f0111c','520088bd71644ff58922b1f98b718099','12333b5e3a464b899fa58c020f81e411',1459816162595000,'74166e5b8b8b4662afc4497c52faf6bc','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleActAsSubjectId','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('df2387719d0d485d8bf6a9115cc404e9','0aee5f4ab0a84991b23f77155da86e77','53353083cd3e4d82a586202045271442',1459816163354000,'12dbd6f81fbc403e857ea8171ec087ee','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnum','fc88a71ee4574ae7b0a550d72b5172d9','RuleThenEnum to run when the rule fires','description','','RuleThenEnum to run when the rule fires','','','',''),('df50619f3eac46b9922ffe0a4a603a61','0aee5f4ab0a84991b23f77155da86e77','c659c4ad06254a69ad2cb49f19fc4478',1459816166225000,'32b726ca079d423cbb80130baee2e731','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSearchDn','094308af1376466687416c49f1f6495f','Location that constrains the subtree where the filter is applicable','description','','Location that constrains the subtree where the filter is applicable','','','',''),('df5baae5f03c4f7aa1f060ec8aa7351c','520088bd71644ff58922b1f98b718099','4f40302308c74a47b2b09ce18b51b5b5',1459816167115000,'a58dc65ff39649cfaf72aa3389e1e9e8','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapOptins','094308af1376466687416c49f1f6495f','','','','','','','',''),('dfc1913c97154fb4907469d85b65e28e','0aee5f4ab0a84991b23f77155da86e77','fc5de2f0793c48fb8629387d1b83dc7f',1459816163289000,'730af7d2426945eca3bb0e3015aff089','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleIfStemScope','fc88a71ee4574ae7b0a550d72b5172d9','when the if part is a stem, this is the scope of SUB or ONE','description','','when the if part is a stem, this is the scope of SUB or ONE','','','',''),('e04622def0a9497fb61216f3f632c98c','0aee5f4ab0a84991b23f77155da86e77','07aaefb56552435db6413591c2a0186e',1459816162748000,'28a96a63bd374b03b076ce1615d6e954','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckType','fc88a71ee4574ae7b0a550d72b5172d9','when the check should be to see if rule should fire, enum: RuleCheckType','description','','when the check should be to see if rule should fire, enum: RuleCheckType','','','',''),('e04634379a4e42d39361a0f8fc89a17f','0aee5f4ab0a84991b23f77155da86e77','7314336d7419484cbebeb9e7695edead',1459816164306000,'b1d07c0142ad43a7aa3d6a1a6e8fd0b4','240c728c9e2c42ccb4bd63fae71d8b28','etc:attribute:attrLoader:attributeLoader','6cd4d8196fe24d21acd51cdf8fcdb3cc','is a loader based attribute def, the loader attributes will be available to be assigned','description','','is a loader based attribute def, the loader attributes will be available to be assigned','','','',''),('e196abf623c54d16a2cfb7a45df0c77e','9ab325f8c43c48969b81919e0a237678','b9307b3c26ab440d91b270b950336d12',1459816162430000,'b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:rulesAttrDef','fc88a71ee4574ae7b0a550d72b5172d9','','attr','','','','','','',''),('e210d9d4164b4756af5e5088b992b439','e9a154dfe2d8473090e9956009767985','0865979fcb75478ea9394435359e8b9a',1459816164112000,'20d9a7b124a24e6f9663b3d41b28c905','self','4893e5881f5d49c9917da7615feebf1e','4893e5881f5d49c9917da7615feebf1e','20d9a7b124a24e6f9663b3d41b28c905','0','','','','','',''),('e2315e5c7bbb490ebeb656ef86cab6a0','780d4bda84dd4f8897b670da7038c945','a194a2a1e2ad45e7b81b45c4f987e830',1459816167409000,'9cf767efae1a40fbb83795fe2fb844e4','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserDataDef','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('e391f4e409124b0bbaebe8e429289d5b','520088bd71644ff58922b1f98b718099','b0e911e0c82d4fbbabe41c84e9a15759',1459816167767000,'7a9a1f6bccf84dda9159b82838440c01','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteStems','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('e3a5bc38e52d4d5585d9bee3a8c67f33','fdab0b9a610e44af96429a2864b1a62a','90e91ff27cd24a0db42d833427a7352c',1459816163418000,'d23c148d2e6846658ce0c58a12cc1093','self','fa18c25e248e4ca0978c21ea2d6a17ef','fa18c25e248e4ca0978c21ea2d6a17ef','d23c148d2e6846658ce0c58a12cc1093','0','','','','','',''),('e3cc847fca3b4185b6cddff8f08b892e','fdab0b9a610e44af96429a2864b1a62a','6930ebdfd50a443593fd420d34f9fc74',1459816168695950,'15fea32d0ba5470286c42b1354684b6e','self','2834e8c199de44eda7c2f74c83c895d2','2834e8c199de44eda7c2f74c83c895d2','15fea32d0ba5470286c42b1354684b6e','0','','','','','',''),('e3f8cbdb08a945ab89e40e6e297d6c61','cd505cb7ba9f48dea846010d979f512e','a194a2a1e2ad45e7b81b45c4f987e830',1459816167389000,'d6a8882a75a3485baee64ea5255866cb','assign','a9cce636abf44507876f639467f74174','','','','','','','','',''),('e5c2f526f8a049df80d19016a4b9cddd','0aee5f4ab0a84991b23f77155da86e77','fc0fb6d81b5647198e48d10e179402d0',1459816164633000,'1c1293934a904003a4adcfdcafe4fd88','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderPriority','6cd4d8196fe24d21acd51cdf8fcdb3cc','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','description','','Quartz has a fixed threadpool (max configured in the grouper-loader.properties), and when the max is reached, then jobs are prioritized by this integer.  The higher the better, and the default if not set is 5.','','','',''),('e6bf13bb82ce4f0d8adeb413c8084dc4','520088bd71644ff58922b1f98b718099','04e9d97ec9c646d785911c32a84a6586',1459816163347000,'12dbd6f81fbc403e857ea8171ec087ee','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnum','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('e759ea7e3d0b4d50ad6d33b01df7d6c9','520088bd71644ff58922b1f98b718099','cc27d3ecc6814ca89654ceee86cdd07e',1459816166662000,'cc4950adff3147fd8b36fbe2fc1c2e12','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapErrorUnresolvable','094308af1376466687416c49f1f6495f','','','','','','','',''),('e7c7b45aae1f4758bc8cef95f7283114','520088bd71644ff58922b1f98b718099','e866d25952e34dc9bd6ed26afb277c6e',1459816167069000,'d0147000b33c4cfcaa524e135adb4f43','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapUpdaters','094308af1376466687416c49f1f6495f','','','','','','','',''),('e85e8f6000654efab203e3f8aa758856','fdab0b9a610e44af96429a2864b1a62a','550a2e3b9e1c477e9e2a360954940852',1459816168640000,'a6ee5e04d52243afaaea589cc86df58d','self','e4f3627722644627a5a53e5afac59a27','e4f3627722644627a5a53e5afac59a27','a6ee5e04d52243afaaea589cc86df58d','0','','','','','',''),('e9b227841a284d319ee09139b3fae90d','9ab325f8c43c48969b81919e0a237678','a194a2a1e2ad45e7b81b45c4f987e830',1459816167362000,'a9cce636abf44507876f639467f74174','etc:attribute:userData:grouperUserDataDef','cb1bfad6c8ed424d902b65d9ec275df0','','attr','','','','','','',''),('ea1ce896b22a44c4ae2ea08c9d725dae','520088bd71644ff58922b1f98b718099','90e91ff27cd24a0db42d833427a7352c',1459816163409000,'fa18c25e248e4ca0978c21ea2d6a17ef','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnumArg1','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('ea7a2a4da7ca4789923ca4e73d99866a','fdab0b9a610e44af96429a2864b1a62a','c05f75a9c85b4fc5b59f1e54bfbd7e60',1459816166765000,'475df68f6c3e419ca82188fd9bf3a1e0','self','39cfeba33b784b2da20a99fb80f674d7','39cfeba33b784b2da20a99fb80f674d7','475df68f6c3e419ca82188fd9bf3a1e0','0','','','','','',''),('eaa64ec8bd824268af2c019e432980a6','cd505cb7ba9f48dea846010d979f512e','98ba1ea840d5404299ad811e5e2f1da2',1459816162355000,'0484c4c31b4e4469a120821ddddf9ff2','assign','da7ae804604741feb591dd47b6f352be','','','','','','','','',''),('eaf2b0dbd6234fa7b6ca26295c81a9fa','780d4bda84dd4f8897b670da7038c945','ea8757bd8a5e4fcb8d05e62bd36a6da4',1459816160723000,'cc2794fc2094406b8ea78833a4daa2b1','stem','GrouperSystem','g:isa','naming','stem','47bf48f95b9a4c67855b091e3d1003de','etc','65947ffd4e364921a42c465d94a78c09','984bf86f08fc4d7f9b045f1b74f6f0cf','immediate',''),('eb02041ed1cf4f208314b44552adf15a','fdab0b9a610e44af96429a2864b1a62a','74dcdb6213624e328a6ab5d36797c611',1459816163841000,'a9b5173cea3644cfaf7e7bcc3858f0f7','self','7c393699d849478cbb26a265ee746b75','7c393699d849478cbb26a265ee746b75','a9b5173cea3644cfaf7e7bcc3858f0f7','0','','','','','',''),('eb4e6d7548bd4b0d8d680dc8ced184b7','520088bd71644ff58922b1f98b718099','299caa66b75e45b78c785c7b648c8191',1459816167916000,'de2074da9cd64e9393d7638e135ce76c','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataRecentSubjects','cb1bfad6c8ed424d902b65d9ec275df0','','','','','','','',''),('eb9eb8032b9745e3bdb8b207bc05ae8f','cd505cb7ba9f48dea846010d979f512e','cc9ba9ab69e64d0c9c9ba96f0f506ce4',1459816168594000,'f2fcf4ee10ba4fe495e2ae04762a4e76','assign','35ee03902f9049fea8520a4c47e57b54','','','','','','','','',''),('ebc27dbb26eb4acb8ec8232ab81afaa3','780d4bda84dd4f8897b670da7038c945','',1459816163786000,'40724d2570b24e22b72383132addeb4a','attrRead','GrouperAll','g:isa','attributeDef','attributeDef','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitsDef','dd763c74578f453caaac27517173178f','4e9bb975b2cf43e79651b1e519070b2c','immediate',''),('ece452b104074b4588c0d82f2cfc9f1d','fdab0b9a610e44af96429a2864b1a62a','43f0e2a5babd431b87a45a1d43d99909',1459816168200000,'449f6cf23f884d908c6ec3b3533760c7','self','0e8f891baffa4efb8c503f893937ed72','0e8f891baffa4efb8c503f893937ed72','449f6cf23f884d908c6ec3b3533760c7','0','','','','','',''),('ed605bf9175c4c7b8ae32acb88e6aa3a','7069503770c84a6b83c6d2bf47891b25','b62e1c7566d14267a62216d2aed227b6',1459816165612000,'094308af1376466687416c49f1f6495f','etc:attribute:loaderLdap','1730a44d087442cc96c2d8d63b655716','etc:attribute:loaderLdap','','','','','','','',''),('eef211cdca0c4593b58f4ccb3e64b9e6','520088bd71644ff58922b1f98b718099','74dcdb6213624e328a6ab5d36797c611',1459816163839000,'7c393699d849478cbb26a265ee746b75','dd528f792dd544938a2588848992e909','etc:attribute:permissionLimits:limitIpOnNetworks','b6bc2fcd772146ee970347e496538926','','','','','','','',''),('ef775306245142d688bb0e9c2ac54efd','0aee5f4ab0a84991b23f77155da86e77','ab69e171a3f94d74a462971922597b26',1459816167244000,'5618f29e9f694d8da566f2ddaec01283','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapGroupAttrUpdaters','094308af1376466687416c49f1f6495f','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_UPDATE on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','description','','Comma separated subjectIds or subjectIdentifiers who will be allowed to GROUP_ATTR_UPDATE on the group.  optional for LDAP_GROUP_LIST or LDAP_GROUPS_FROM_ATTRIBUTES','','','',''),('ef9a7ddb36604b3b90c2fd5db085d18b','9ab325f8c43c48969b81919e0a237678','00618952cb8b4705b94cd916a6713a4e',1459816165843000,'19faf0fca06b4aeb8a5cce52382a3f0e','etc:attribute:loaderLdap:grouperLoaderLdapDef','094308af1376466687416c49f1f6495f','','attr','','','','','','',''),('efae04d1b3b147c3853a0a815742ab4d','e9a154dfe2d8473090e9956009767985','8159789da0a14cafbd09145afa025cd8',1459816161724000,'83560d0a5bbd4e13889a93048dc7d687','self','9c65cb79f47246f0b16efcbc28fff250','9c65cb79f47246f0b16efcbc28fff250','83560d0a5bbd4e13889a93048dc7d687','0','','','','','',''),('f0cd42bffe59465598c0a762807d5a94','fdab0b9a610e44af96429a2864b1a62a','cc27d3ecc6814ca89654ceee86cdd07e',1459816166670000,'9db107a113f64e258efa34f3ac4a1119','self','cc4950adff3147fd8b36fbe2fc1c2e12','cc4950adff3147fd8b36fbe2fc1c2e12','9db107a113f64e258efa34f3ac4a1119','0','','','','','',''),('f1861efa2764499abea9dbba6a245502','0aee5f4ab0a84991b23f77155da86e77','aed2bf6b78934ee9847a0b2b9e31d0d9',1459816166017000,'c3d2e8d1b61b481a92b96a5c564e6d29','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapType','094308af1376466687416c49f1f6495f','This holds the type of job from the GrouperLoaderType enum, currently the only valid values are LDAP_SIMPLE, LDAP_GROUP_LIST, LDAP_GROUPS_FROM_ATTRIBUTES. Simple is a group loaded from LDAP filter which returns subject ids or identifiers.  Group list is an LDAP filter which returns group objects, and the group objects have a list of subjects.  Groups from attributes is an LDAP filter that returns subjects which have a multi-valued attribute e.g. affiliations where groups will be created based on subject who have each attribute value  ','description','','This holds the type of job from the GrouperLoaderType enum, currently the only valid values are LDAP_SIMPLE, LDAP_GROUP_LIST, LDAP_GROUPS_FROM_ATTRIBUTES. Simple is a group loaded from LDAP filter which returns subject ids or identifiers.  Group list is an LDAP filter which returns group objects, and the group objects have a list of subjects.  Groups from attributes is an LDAP filter that returns subjects which have a multi-valued attribute e.g. affiliations where groups will be created based on subject who have each attribute value  ','','','',''),('f3ff58d4dea241b4b9d137ab0ef78f73','fdab0b9a610e44af96429a2864b1a62a','5557c2f4bcc34e2e8cd60c0204052972',1459816166520000,'6ba4a194287445ecbffe2f3c5d61488d','self','644299b01bb54802ae883050a29f0a80','644299b01bb54802ae883050a29f0a80','6ba4a194287445ecbffe2f3c5d61488d','0','','','','','',''),('f408e31c641542668a6fa11513fa36ba','fdab0b9a610e44af96429a2864b1a62a','13f0586b4471492284b8272b4853df04',1459816163030000,'f3b3d138eb264ddf9f37506ed8b6ad3b','self','f44cbb78b4594e0aa9ebb1d66bb1618a','f44cbb78b4594e0aa9ebb1d66bb1618a','f3b3d138eb264ddf9f37506ed8b6ad3b','0','','','','','',''),('f4e00d89ea5e4a5c9ede4431ae975c9a','cd505cb7ba9f48dea846010d979f512e','9020c22117504dceb753bc010b2d0088',1459816167597000,'b796316b96774a288bc842e51f9cca08','assign','af747ed516a548a6b22ca4020b5a67a0','','','','','','','','',''),('f4e1de150aca4e14a6be5eba6272365a','520088bd71644ff58922b1f98b718099','531dc15e5d794a89b9750e666b2f12ec',1459816163470000,'1a1c5f5bf5064e5fbfc30d723a93ac35','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnumArg2','fc88a71ee4574ae7b0a550d72b5172d9','','','','','','','',''),('f65eb0bbf950447687ec9577aeb9ec55','cd505cb7ba9f48dea846010d979f512e','35b82a4a0f7146248919176310137474',1459816164335000,'be6656b9ea314c3786f7024884eb2ab3','assign','05ed0d9e4c5e4024a75c08aa08717579','','','','','','','','',''),('f6debf47fdb64865b532a699fa6e355f','7069503770c84a6b83c6d2bf47891b25','129701637b9d4e1f9b0222cd9069d8d3',1459816168084000,'2eee186e51494f0a874fe61ff24b7192','etc:attribute:entities','1730a44d087442cc96c2d8d63b655716','etc:attribute:entities','','','','','','','',''),('f6f824af0c474ffcb4c2cc5841db9815','0aee5f4ab0a84991b23f77155da86e77','3740610bf1a74673bec8d40e5466184c',1459816164452000,'1e858851f5a04d5d957d4ca242c3a520','05ed0d9e4c5e4024a75c08aa08717579','etc:attribute:attrLoader:attributeLoaderScheduleType','6cd4d8196fe24d21acd51cdf8fcdb3cc','Type of schedule.  Defaults to CRON if a cron schedule is entered, or START_TO_START_INTERVAL if an interval is entered','description','','Type of schedule.  Defaults to CRON if a cron schedule is entered, or START_TO_START_INTERVAL if an interval is entered','','','',''),('f70bd61587dd47bfbd3c1e245395f80f','fdab0b9a610e44af96429a2864b1a62a','5f96fd1b64f646d2bb7bfb654e351e22',1459816166991000,'565ecc23bd7449b0ba5e486dc8aba2d0','self','a45ebbb8c7d54fce9701361f8184197f','a45ebbb8c7d54fce9701361f8184197f','565ecc23bd7449b0ba5e486dc8aba2d0','0','','','','','',''),('f80f02c0fb4848f99585496a6bd69c5b','0aee5f4ab0a84991b23f77155da86e77','64dfea509fd34cbc967b486f27f8be19',1459816167977000,'d049ee88c5dd43b49ec896c7b4c804e3','af747ed516a548a6b22ca4020b5a67a0','etc:attribute:userData:grouperUserDataFavoriteAttributeDefs','cb1bfad6c8ed424d902b65d9ec275df0','A list of attribute definition ids and metadata in json format that are the favorites for a user','description','','A list of attribute definition ids and metadata in json format that are the favorites for a user','','','',''),('f87ac48bf6f44aab9ffa90e94096e91c','0aee5f4ab0a84991b23f77155da86e77','7dfd6f20794b4a5a8fdd969a44ed54f8',1459816162968000,'4120ee09ca1d457b81744f71c1a0640a','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleCheckArg0','fc88a71ee4574ae7b0a550d72b5172d9','when the check needs an arg, this is the arg0','description','','when the check needs an arg, this is the arg0','','','',''),('f8b87ea1109246a99ad197083e18d9f6','9ab325f8c43c48969b81919e0a237678','cc9ba9ab69e64d0c9c9ba96f0f506ce4',1459816168560000,'35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttributeDef_grouperLoader','36792aa7956240feb1bb6025c56ff2f3','','attr','','','','','','',''),('f9d380b0578d42e6a3317e30be0f92e3','fdab0b9a610e44af96429a2864b1a62a','77176320181c4d7b91ea95a91d490c63',1459816168779000,'8e3616370a094408b8c860eb06fecdfd','self','6ef48c395597459d9810bf0aac859903','6ef48c395597459d9810bf0aac859903','8e3616370a094408b8c860eb06fecdfd','0','','','','','',''),('fad42c529a014bd38b3975d38a0faab3','520088bd71644ff58922b1f98b718099','a42b6da94ac1421e87853397a83123a4',1459816166294000,'6a4bdf524d1242aabb6a2765da61655e','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapSubjectIdType','094308af1376466687416c49f1f6495f','','','','','','','',''),('fb804e8cc16b4101b88068cccdd29c27','fdab0b9a610e44af96429a2864b1a62a','b9c217c7ab9246bc8ec1118d8d860376',1459816167685000,'a74bdecacc424a27985f741f720efc86','self','2ecf3496f4524f52b0001c4556b9ff80','2ecf3496f4524f52b0001c4556b9ff80','a74bdecacc424a27985f741f720efc86','0','','','','','',''),('fd60546c90e9457da73b8d2fd4670882','0aee5f4ab0a84991b23f77155da86e77','797aa8a62bd3486a88ad5dbb5afea214',1459816163433000,'fa18c25e248e4ca0978c21ea2d6a17ef','b92c64af9edd4b7493d8c4b2a936cbd8','etc:attribute:rules:ruleThenEnumArg1','fc88a71ee4574ae7b0a550d72b5172d9','RuleThenEnum argument 1 to run when the rule fires (enum might need args)','description','','RuleThenEnum argument 1 to run when the rule fires (enum might need args)','','','',''),('fe1781d0d2ff44e5a02b25672ee1264b','fdab0b9a610e44af96429a2864b1a62a','ea0b11775d354ec0902c36f4a8737f5a',1459816166170000,'474e86aa058a49a69a6d458502c45e3d','self','3abd9f032c2c42318cd5e5e014c27a69','3abd9f032c2c42318cd5e5e014c27a69','474e86aa058a49a69a6d458502c45e3d','0','','','','','',''),('fe606c8fd0bb441eac2aca5b3a7f7c51','780d4bda84dd4f8897b670da7038c945','0865979fcb75478ea9394435359e8b9a',1459816164124000,'0183ae81a9804e2ba7bd269344ceb9eb','attrAdmin','GrouperSystem','g:isa','attributeDef','attributeDef','c4777fa00d2e4f7aabc2184cf6023770','etc:attribute:permissionLimits:limitsDefMarker','65947ffd4e364921a42c465d94a78c09','cd1c789d1a2e480384662de8de917ed1','immediate',''),('fe96229a0a0447c480628b36efbc418f','520088bd71644ff58922b1f98b718099','960473ac0a764e3db73be6b4a8434b0c',1459816168727000,'78a353168b3d4cf7bf9d0b299aaf113e','35ee03902f9049fea8520a4c47e57b54','etc:legacy:attribute:legacyAttribute_grouperLoaderPriority','36792aa7956240feb1bb6025c56ff2f3','','','','','','','',''),('fe9d7dd7618a4f9f901d8f8bd7e265f7','520088bd71644ff58922b1f98b718099','40561649fbce4373a84ed95089064d20',1459816166134000,'0c5ed4a5aa354da6a527f811cd77f455','51f5a5e597fc4028824384b06614aba2','etc:attribute:loaderLdap:grouperLoaderLdapFilter','094308af1376466687416c49f1f6495f','','','','','','','','');
/*!40000 ALTER TABLE `grouper_change_log_entry_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_change_log_entry_v`
--

DROP TABLE IF EXISTS `grouper_change_log_entry_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_change_log_entry_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_change_log_entry_v` (
  `created_on` tinyint NOT NULL,
  `change_log_category` tinyint NOT NULL,
  `action_name` tinyint NOT NULL,
  `sequence_number` tinyint NOT NULL,
  `label_string01` tinyint NOT NULL,
  `string01` tinyint NOT NULL,
  `label_string02` tinyint NOT NULL,
  `string02` tinyint NOT NULL,
  `label_string03` tinyint NOT NULL,
  `string03` tinyint NOT NULL,
  `label_string04` tinyint NOT NULL,
  `string04` tinyint NOT NULL,
  `label_string05` tinyint NOT NULL,
  `string05` tinyint NOT NULL,
  `label_string06` tinyint NOT NULL,
  `string06` tinyint NOT NULL,
  `label_string07` tinyint NOT NULL,
  `string07` tinyint NOT NULL,
  `label_string08` tinyint NOT NULL,
  `string08` tinyint NOT NULL,
  `label_string09` tinyint NOT NULL,
  `string09` tinyint NOT NULL,
  `label_string10` tinyint NOT NULL,
  `string10` tinyint NOT NULL,
  `label_string11` tinyint NOT NULL,
  `string11` tinyint NOT NULL,
  `label_string12` tinyint NOT NULL,
  `string12` tinyint NOT NULL,
  `context_id` tinyint NOT NULL,
  `change_log_type_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_change_log_type`
--

DROP TABLE IF EXISTS `grouper_change_log_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_change_log_type` (
  `action_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `change_log_category` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `label_string01` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string02` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string03` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string04` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string05` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string06` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string07` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string08` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string09` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string10` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string11` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `label_string12` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `change_log_type_cat_type_idx` (`change_log_category`,`action_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_change_log_type`
--

LOCK TABLES `grouper_change_log_type` WRITE;
/*!40000 ALTER TABLE `grouper_change_log_type` DISABLE KEYS */;
INSERT INTO `grouper_change_log_type` VALUES ('updateAttributeDefName','attributeDefName','0aee5f4ab0a84991b23f77155da86e77',1459816157330,0,'0aee5f4ab0a84991b23f77155da86e77','id','attributeDefId','name','stemId','description','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,1459816157330),('updateEntity','entity','1e9c1aaf27664326baf10a27c0ef9b26',1459816157183,0,'1e9c1aaf27664326baf10a27c0ef9b26','id','name','parentStemId','displayName','description','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,1459816157183),('deleteGroup','group','2c3e7f8180734d08bd1336b4511eb078',1459816157179,0,'2c3e7f8180734d08bd1336b4511eb078','id','name','parentStemId','displayName','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157179),('deleteEntity','entity','348ebe6f5c8d4a0b99d86c28f41a138e',1459816157190,0,'348ebe6f5c8d4a0b99d86c28f41a138e','id','name','parentStemId','displayName','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157190),('addGroup','group','35db3dbcc7b84dc79321af7ecb7193b8',1459816157154,0,'35db3dbcc7b84dc79321af7ecb7193b8','id','name','parentStemId','displayName','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157154),('addAttributeAssignValue','attributeAssignValue','38aa1b4462344553ab2843da0e489fac',1459816157345,0,'38aa1b4462344553ab2843da0e489fac','id','attributeAssignId','attributeDefNameId','attributeDefNameName','value','valueType',NULL,NULL,NULL,NULL,NULL,NULL,1459816157345),('deleteAttributeDefName','attributeDefName','47b5647bc6044e6ba80f1175fdd8e6b9',1459816157332,0,'47b5647bc6044e6ba80f1175fdd8e6b9','id','attributeDefId','name','stemId','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157332),('deleteAttributeDef','attributeDef','4cd0f1150c514cdb944476becb5eef17',1459816157212,0,'4cd0f1150c514cdb944476becb5eef17','id','name','stemId','description','attributeDefType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157212),('deleteRoleSet','roleSet','4f2f01c44a4444eea6810400c63cbeba',1459816157325,0,'4f2f01c44a4444eea6810400c63cbeba','id','type','ifHasRoleId','thenHasRoleId','parentRoleSetId','depth',NULL,NULL,NULL,NULL,NULL,NULL,1459816157325),('deleteMembership','membership','50eb3039aac14c1aa10a13499705f2ca',1459816157138,0,'50eb3039aac14c1aa10a13499705f2ca','id','fieldName','subjectId','sourceId','membershipType','groupId','groupName','memberId','fieldId','subjectName',NULL,NULL,1459816157138),('addAttributeDefName','attributeDefName','520088bd71644ff58922b1f98b718099',1459816157325,0,'520088bd71644ff58922b1f98b718099','id','attributeDefId','name','stemId','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157325),('deleteGroupField','groupField','531f812080fc4b6aaa5e38d9d4e241cd',1459816157086,0,'531f812080fc4b6aaa5e38d9d4e241cd','id','name','groupTypeId','groupTypeName','type',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157086),('assignGroupType','groupTypeAssignment','5cec432e473b49549bdb46fe7fd2d02f',1459816157114,0,'5cec432e473b49549bdb46fe7fd2d02f','id','groupId','groupName','typeId','typeName',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157114),('updateAttributeAssignAction','attributeAssignAction','638427f653e541c09f7284d30c8eb0b1',1459816157294,0,'638427f653e541c09f7284d30c8eb0b1','id','name','attributeDefId','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,NULL,NULL,1459816157294),('addEntity','entity','68aa77dfcb3741f1a1e287eb18cc2d38',1459816157181,0,'68aa77dfcb3741f1a1e287eb18cc2d38','id','name','parentStemId','displayName','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157181),('deleteStem','stem','6bddd0b8c37d460b93c5a6e916455818',1459816157236,0,'6bddd0b8c37d460b93c5a6e916455818','id','name','parentStemId','displayName','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157236),('addStem','stem','7069503770c84a6b83c6d2bf47891b25',1459816157234,0,'7069503770c84a6b83c6d2bf47891b25','id','name','parentStemId','displayName','description',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157234),('deleteAttributeAssignAction','attributeAssignAction','70a06c205fc5490cac0823c8165e296e',1459816157301,0,'70a06c205fc5490cac0823c8165e296e','id','name','attributeDefId',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157301),('addAttributeAssign','attributeAssign','745bfc3312644c2c877011dd15c7aca4',1459816157333,0,'745bfc3312644c2c877011dd15c7aca4','id','attributeDefNameId','attributeAssignActionId','assignType','ownerId1','ownerId2','attributeDefNameName','action','disallowed',NULL,NULL,NULL,1459816157333),('deleteAttributeAssignActionSet','attributeAssignActionSet','7461d9fc69a243ccb226ce2f291a5c9c',1459816157320,0,'7461d9fc69a243ccb226ce2f291a5c9c','id','type','ifHasAttrAssnActionId','thenHasAttrAssnActionId','parentAttrAssignActionSetId','depth',NULL,NULL,NULL,NULL,NULL,NULL,1459816157320),('permissionChangeOnRole','permission','7756d15d3f9d41768900050c35a607cd',1459816157349,0,'7756d15d3f9d41768900050c35a607cd','roleId','roleName',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157349),('addPrivilege','privilege','780d4bda84dd4f8897b670da7038c945',1459816157141,0,'780d4bda84dd4f8897b670da7038c945','id','privilegeName','subjectId','sourceId','privilegeType','ownerType','ownerId','ownerName','memberId','fieldId','membershipType',NULL,1459816157141),('updateGroup','group','79c6965ea92a4d36bb90b103b34c5198',1459816157161,0,'79c6965ea92a4d36bb90b103b34c5198','id','name','parentStemId','displayName','description','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,1459816157161),('updateGroupComposite','groupComposite','7e3890a7fe474b5cb1148d737790964c',1459816157095,0,'7e3890a7fe474b5cb1148d737790964c','id','ownerId','ownerName','leftFactorId','leftFactorName','rightFactorId','rightFactorName','type',NULL,NULL,NULL,NULL,1459816157095),('updatePrivilege','privilege','7e4017dcfc29420292ddc97a2f7d950c',1459816157146,0,'7e4017dcfc29420292ddc97a2f7d950c','id','privilegeName','subjectId','sourceId','privilegeType','ownerType','ownerId','ownerName','membershipType',NULL,NULL,NULL,1459816157146),('deleteMember','member','7f521e99280b4a448e08cd8819e307d6',1459816157258,0,'7f521e99280b4a448e08cd8819e307d6','id','subjectId','subjectSourceId','subjectTypeId',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157258),('deleteGroupComposite','groupComposite','97374b19f7514d51bc1bd3f3355881c8',1459816157103,0,'97374b19f7514d51bc1bd3f3355881c8','id','ownerId','ownerName','leftFactorId','leftFactorName','rightFactorId','rightFactorName','type',NULL,NULL,NULL,NULL,1459816157103),('updateMembership','membership','99b195b7879c424db66f273eb5e59e80',1459816157135,0,'99b195b7879c424db66f273eb5e59e80','id','fieldName','subjectId','sourceId','membershipType','groupId','groupName','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,1459816157135),('addAttributeDef','attributeDef','9ab325f8c43c48969b81919e0a237678',1459816157195,0,'9ab325f8c43c48969b81919e0a237678','id','name','stemId','description','attributeDefType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157195),('deleteAttributeAssign','attributeAssign','9e0e644946a64212b56b5758a1bdad06',1459816157344,0,'9e0e644946a64212b56b5758a1bdad06','id','attributeDefNameId','attributeAssignActionId','assignType','ownerId1','ownerId2','attributeDefNameName','action','disallowed',NULL,NULL,NULL,1459816157344),('deleteAttributeAssignValue','attributeAssignValue','a5ac17be6e1f454b90525f40559de39f',1459816157347,0,'a5ac17be6e1f454b90525f40559de39f','id','attributeAssignId','attributeDefNameId','attributeDefNameName','value','valueType',NULL,NULL,NULL,NULL,NULL,NULL,1459816157347),('updateStem','stem','b892749dbf494c4abaecda25bdfa7086',1459816157235,0,'b892749dbf494c4abaecda25bdfa7086','id','name','parentStemId','displayName','description','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,1459816157235),('updateAttributeDef','attributeDef','c41c813e1a904708b8695bbd4ef97e70',1459816157206,0,'c41c813e1a904708b8695bbd4ef97e70','id','name','stemId','description','attributeDefType','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,1459816157206),('addMembership','membership','c4e62671027b4e8abdcb006b088ab3b5',1459816157126,0,'c4e62671027b4e8abdcb006b088ab3b5','id','fieldName','subjectId','sourceId','membershipType','groupId','groupName','memberId','fieldId',NULL,NULL,NULL,1459816157126),('updateMember','member','c774acacbe3b40a688e59e69dd32ce84',1459816157253,0,'c774acacbe3b40a688e59e69dd32ce84','id','subjectId','subjectSourceId','subjectTypeId','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,NULL,1459816157253),('addAttributeAssignAction','attributeAssignAction','cd505cb7ba9f48dea846010d979f512e',1459816157287,0,'cd505cb7ba9f48dea846010d979f512e','id','name','attributeDefId',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157287),('deletePrivilege','privilege','d13157b65b4c40cc967152ef5c7431f6',1459816157151,0,'d13157b65b4c40cc967152ef5c7431f6','id','privilegeName','subjectId','sourceId','privilegeType','ownerType','ownerId','ownerName','memberId','fieldId','membershipType',NULL,1459816157151),('addGroupField','groupField','d779ee27ec264344a6c2ed9baaa8e2d5',1459816157026,0,'d779ee27ec264344a6c2ed9baaa8e2d5','id','name','groupTypeId','groupTypeName','type',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157026),('updateGroupField','groupField','d80f035d580a47fe8403ca996ac76bc6',1459816157083,0,'d80f035d580a47fe8403ca996ac76bc6','id','name','groupTypeId','groupTypeName','type','propertyChanged','propertyOldValue','propertyNewValue',NULL,NULL,NULL,NULL,1459816157083),('changeSubject','member','da027832002c404d9a59d903a74fc0fe',1459816157267,0,'da027832002c404d9a59d903a74fc0fe','oldMemberId','oldSubjectId','oldSourceId','newMemberId','newSubjectId','newSourceId','deleteOldMember','memberIdChanged',NULL,NULL,NULL,NULL,1459816157267),('addAttributeAssignActionSet','attributeAssignActionSet','e9a154dfe2d8473090e9956009767985',1459816157311,0,'e9a154dfe2d8473090e9956009767985','id','type','ifHasAttrAssnActionId','thenHasAttrAssnActionId','parentAttrAssignActionSetId','depth',NULL,NULL,NULL,NULL,NULL,NULL,1459816157311),('deleteAttributeDefNameSet','attributeDefNameSet','eaeb9a3c3c7942daa35824dfa9f1eeba',1459816157323,0,'eaeb9a3c3c7942daa35824dfa9f1eeba','id','type','ifHasAttributeDefNameId','thenHasAttributeDefNameId','parentAttrDefNameSetId','depth',NULL,NULL,NULL,NULL,NULL,NULL,1459816157323),('addGroupComposite','groupComposite','f2a2be5d913146c5ac2dea0070ca6279',1459816157093,0,'f2a2be5d913146c5ac2dea0070ca6279','id','ownerId','ownerName','leftFactorId','leftFactorName','rightFactorId','rightFactorName','type',NULL,NULL,NULL,NULL,1459816157093),('addMember','member','f59f00f913e04fc2866da743463c9d9f',1459816157239,0,'f59f00f913e04fc2866da743463c9d9f','id','subjectId','subjectSourceId','subjectTypeId',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157239),('unassignGroupType','groupTypeAssignment','fa9162bb9e3f4200a90305d2f4aec1b6',1459816157123,0,'fa9162bb9e3f4200a90305d2f4aec1b6','id','groupId','groupName','typeId','typeName',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1459816157123),('addAttributeDefNameSet','attributeDefNameSet','fdab0b9a610e44af96429a2864b1a62a',1459816157321,0,'fdab0b9a610e44af96429a2864b1a62a','id','type','ifHasAttributeDefNameId','thenHasAttributeDefNameId','parentAttrDefNameSetId','depth',NULL,NULL,NULL,NULL,NULL,NULL,1459816157321),('addRoleSet','roleSet','fe2015fb414e4150b61a54b9ce6e9c1e',1459816157324,0,'fe2015fb414e4150b61a54b9ce6e9c1e','id','type','ifHasRoleId','thenHasRoleId','parentRoleSetId','depth',NULL,NULL,NULL,NULL,NULL,NULL,1459816157324);
/*!40000 ALTER TABLE `grouper_change_log_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_composites`
--

DROP TABLE IF EXISTS `grouper_composites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_composites` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner` varchar(40) COLLATE utf8_bin NOT NULL,
  `left_factor` varchar(40) COLLATE utf8_bin NOT NULL,
  `right_factor` varchar(40) COLLATE utf8_bin NOT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `creator_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `composite_composite_idx` (`owner`),
  KEY `composite_createtime_idx` (`create_time`),
  KEY `composite_creator_idx` (`creator_id`),
  KEY `composite_factor_idx` (`left_factor`,`right_factor`),
  KEY `composite_left_factor_idx` (`left_factor`),
  KEY `composite_right_factor_idx` (`right_factor`),
  KEY `composite_context_idx` (`context_id`),
  CONSTRAINT `fk_composites_creator_id` FOREIGN KEY (`creator_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_composites_left_factor` FOREIGN KEY (`left_factor`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_composites_owner` FOREIGN KEY (`owner`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_composites_right_factor` FOREIGN KEY (`right_factor`) REFERENCES `grouper_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_composites`
--

LOCK TABLES `grouper_composites` WRITE;
/*!40000 ALTER TABLE `grouper_composites` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_composites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_composites_v`
--

DROP TABLE IF EXISTS `grouper_composites_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_composites_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_composites_v` (
  `OWNER_GROUP_NAME` tinyint NOT NULL,
  `COMPOSITE_TYPE` tinyint NOT NULL,
  `LEFT_FACTOR_GROUP_NAME` tinyint NOT NULL,
  `RIGHT_FACTOR_GROUP_NAME` tinyint NOT NULL,
  `OWNER_GROUP_DISPLAYNAME` tinyint NOT NULL,
  `LEFT_FACTOR_GROUP_DISPLAYNAME` tinyint NOT NULL,
  `RIGHT_FACTOR_GROUP_DISPLAYNAME` tinyint NOT NULL,
  `owner_group_id` tinyint NOT NULL,
  `LEFT_FACTOR_GROUP_ID` tinyint NOT NULL,
  `RIGHT_FACTOR_GROUP_ID` tinyint NOT NULL,
  `COMPOSITE_ID` tinyint NOT NULL,
  `CREATE_TIME` tinyint NOT NULL,
  `CREATOR_ID` tinyint NOT NULL,
  `HIBERNATE_VERSION_NUMBER` tinyint NOT NULL,
  `CONTEXT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_ddl`
--

DROP TABLE IF EXISTS `grouper_ddl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_ddl` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `object_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `db_version` int(11) DEFAULT NULL,
  `last_updated` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `history` text COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grouper_ddl_object_name_idx` (`object_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_ddl`
--

LOCK TABLES `grouper_ddl` WRITE;
/*!40000 ALTER TABLE `grouper_ddl` DISABLE KEYS */;
INSERT INTO `grouper_ddl` VALUES ('57fe0a2d3a4546499a7e6c39e6322399','Subject',1,'2016/04/05 00:28:58','2016/04/05 00:28:58: upgrade Subject from V0 to V1, '),('a7c7b5d02ba6412ab6ff394d19c98662','Grouper',29,'2016/04/05 00:28:58','2016/04/05 00:28:58: upgrade Grouper from V28 to V29, 2016/04/05 00:28:58: upgrade Grouper from V27 to V28, 2016/04/05 00:28:57: upgrade Grouper from V26 to V27, 2016/04/05 00:28:57: upgrade Grouper from V25 to V26, 2016/04/05 00:28:57: upgrade Grouper from V24 to V25, 2016/04/05 00:28:57: upgrade Grouper from V23 to V24, 2016/04/05 00:28:57: upgrade Grouper from V22 to V23, 2016/04/05 00:28:56: upgrade Grouper from V21 to V22, 2016/04/05 00:28:56: upgrade Grouper from V20 to V21, 2016/04/05 00:28:56: upgrade Grouper from V19 to V20, 2016/04/05 00:28:56: upgrade Grouper from V18 to V19, 2016/04/05 00:28:56: upgrade Grouper from V17 to V18, 2016/04/05 00:28:56: upgrade Grouper from V16 to V17, 2016/04/05 00:28:56: upgrade Grouper from V15 to V16, 2016/04/05 00:28:56: upgrade Grouper from V14 to V15, 2016/04/05 00:28:56: upgrade Grouper from V13 to V14, 2016/04/05 00:28:56: upgrade Grouper from V12 to V13, 2016/04/05 00:28:56: upgrade Grouper from V11 to V12, 2016/04/05 00:28:56: upgrade Grouper from V10 to V11, 2016/04/05 00:28:56: upgrade Grouper from V9 to V10, 2016/04/05 00:28:56: upgrade Grouper from V8 to V9, 2016/04/05 00:28:56: upgrade Grouper from V7 to V8, 2016/04/05 00:28:56: upgrade Grouper from V6 to V7, 2016/04/05 00:28:56: upgrade Grouper from V5 to V6, 2016/04/05 00:28:56: upgrade Grouper from V4 to V5, 2016/04/05 00:28:56: upgrade Grouper from V3 to V4, 2016/04/05 00:28:56: upgrade Grouper from V2 to V3, 2016/04/05 00:28:55: upgrade Grouper from V1 to V2, 2016/04/05 00:28:55: upgrade Grouper from V0 to V1, ');
/*!40000 ALTER TABLE `grouper_ddl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_ext_subj`
--

DROP TABLE IF EXISTS `grouper_ext_subj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_ext_subj` (
  `uuid` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `identifier` varchar(300) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `institution` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `search_string_lower` text COLLATE utf8_bin,
  `create_time` bigint(20) NOT NULL,
  `creator_member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `modify_time` bigint(20) NOT NULL,
  `modifier_member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `enabled` varchar(1) COLLATE utf8_bin NOT NULL,
  `disabled_time` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) NOT NULL,
  `vetted_email_addresses` text COLLATE utf8_bin,
  PRIMARY KEY (`uuid`),
  KEY `grouper_ext_subj_cxt_id_idx` (`context_id`),
  KEY `grouper_ext_subj_idfr_idx` (`identifier`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_ext_subj`
--

LOCK TABLES `grouper_ext_subj` WRITE;
/*!40000 ALTER TABLE `grouper_ext_subj` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_ext_subj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_ext_subj_attr`
--

DROP TABLE IF EXISTS `grouper_ext_subj_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_ext_subj_attr` (
  `uuid` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_system_name` varchar(200) COLLATE utf8_bin NOT NULL,
  `attribute_value` varchar(600) COLLATE utf8_bin DEFAULT NULL,
  `subject_uuid` varchar(40) COLLATE utf8_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `creator_member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `modify_time` bigint(20) NOT NULL,
  `modifier_member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `hibernate_version_number` bigint(20) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `grouper_extsubjattr_subj_idx` (`subject_uuid`,`attribute_system_name`),
  KEY `grouper_extsubjattr_cxtid_idx` (`context_id`),
  KEY `grouper_extsubjattr_value_idx` (`attribute_value`(255)),
  CONSTRAINT `fk_ext_subj_attr_subj_uuid` FOREIGN KEY (`subject_uuid`) REFERENCES `grouper_ext_subj` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_ext_subj_attr`
--

LOCK TABLES `grouper_ext_subj_attr` WRITE;
/*!40000 ALTER TABLE `grouper_ext_subj_attr` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_ext_subj_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_ext_subj_invite_v`
--

DROP TABLE IF EXISTS `grouper_ext_subj_invite_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_ext_subj_invite_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_ext_subj_invite_v` (
  `invite_id` tinyint NOT NULL,
  `invite_member_id` tinyint NOT NULL,
  `invite_date` tinyint NOT NULL,
  `email_address` tinyint NOT NULL,
  `invite_email_when_registered` tinyint NOT NULL,
  `invite_group_uuids` tinyint NOT NULL,
  `invite_expire_date` tinyint NOT NULL,
  `email_body` tinyint NOT NULL,
  `expire_attr_expire_date` tinyint NOT NULL,
  `expire_attr_enabled` tinyint NOT NULL,
  `assignment_expire_date` tinyint NOT NULL,
  `assignment_enabled` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_ext_subj_v`
--

DROP TABLE IF EXISTS `grouper_ext_subj_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_ext_subj_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_ext_subj_v` (
  `uuid` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `identifier` tinyint NOT NULL,
  `description` tinyint NOT NULL,
  `institution` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `search_string_lower` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_fields`
--

DROP TABLE IF EXISTS `grouper_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_fields` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(32) COLLATE utf8_bin NOT NULL,
  `read_privilege` varchar(32) COLLATE utf8_bin NOT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `write_privilege` varchar(32) COLLATE utf8_bin NOT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_and_type` (`name`,`type`),
  KEY `fields_context_idx` (`context_id`),
  KEY `grouper_fields_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_fields`
--

LOCK TABLES `grouper_fields` WRITE;
/*!40000 ALTER TABLE `grouper_fields` DISABLE KEYS */;
INSERT INTO `grouper_fields` VALUES ('0ad6ce292c314b10aa59cef878ab9a17','updaters','admin','access','admin',0,'1b329515ee054ec783c15e0070025c83'),('11552e71132c4bd8a199d9d7418cbc97','stemAttrUpdaters','stem','naming','stem',0,'89e8281fe5ae408e8bd1730acae593bc'),('2637cba4ab98462581efd051349db069','members','read','list','update',0,'e7bcecb6566f419f9f687a57bfb1cdf1'),('2b05b3abce1e4d589fc89512f7d610d9','admins','admin','access','admin',0,'71ee64b594a141f2b395ca39f83c7adf'),('30d6952ca2314c5c8297c5560f24940f','attrDefAttrUpdaters','attrAdmin','attributeDef','attrAdmin',0,'73c6f0ccacd04367ba9444f6f4f41037'),('3d4dfe7f92184f03801ba09f35992de3','attrOptins','attrUpdate','attributeDef','attrUpdate',0,'f2cf26e0ad9f45b18680e8f76bf966c4'),('4e9bb975b2cf43e79651b1e519070b2c','attrReaders','attrAdmin','attributeDef','attrAdmin',0,'23fa33b4278c4d72b1e6023b98668a3d'),('5cc53183805a46ee8b4d6795bf9548b6','optins','update','access','update',0,'274e27eda91a48b6addc6aa49fe50a8a'),('5ea33c8d1890401cad243bb7b765d76b','optouts','update','access','update',0,'6deb2d2beb9a477cb797e24e171a4afd'),('6ef6c29e94044581bdef90d074a04d45','readers','admin','access','admin',0,'440b456172304e84a5d01c0fada7d5b1'),('6f085ccfe46845c4b98d83edc6e7da49','attrUpdaters','attrAdmin','attributeDef','attrAdmin',0,'674c7aedfd90423f873527799b6786b3'),('76ae221cea544a4f807ac377e2effa8f','groupAttrUpdaters','admin','access','admin',0,'4b0ae9a3ce024543b16d07c907e0ac50'),('7bda5202f90744f7b121c9eb0240e576','attrViewers','attrAdmin','attributeDef','attrAdmin',0,'d5263d78c23b4eedbd036a2149205086'),('984bf86f08fc4d7f9b045f1b74f6f0cf','stemmers','stem','naming','stem',0,'243a0354c7b14540b6024a5d0405c21a'),('99d5358f26f74749904171eb52d12e5f','attrOptouts','attrUpdate','attributeDef','attrUpdate',0,'94b790939f37416c9d2b6e9cdc6fd923'),('a0f3df3f3afe4e28914131d26c413757','creators','stem','naming','stem',0,'0ae63d112bdd42918f051d25548340d0'),('a9f4b02397d24462a45d981ade0c339e','stemAttrReaders','stem','naming','stem',0,'74964979480f45a99af1f992e540767e'),('abbe645d24154daebb09dcf8c5940de1','viewers','admin','access','admin',0,'225f02a0ebe148948eac60792e71d014'),('c4305e9f9a134e1998cf093f568003ed','attrDefAttrReaders','attrAdmin','attributeDef','attrAdmin',0,'4476edf35ff543c1abdac2c03d68e986'),('cd1c789d1a2e480384662de8de917ed1','attrAdmins','attrAdmin','attributeDef','attrAdmin',0,'80a32ac9b4374b90acaecbe3d1ca5d17'),('fc3d2f92c17b4510a9864f89fd1f04c4','groupAttrReaders','admin','access','admin',0,'b869aa8f5bcb49d9b3991d8916683875');
/*!40000 ALTER TABLE `grouper_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_group_set`
--

DROP TABLE IF EXISTS `grouper_group_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_group_set` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_attr_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_attr_def_id_null` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '<NULL>',
  `owner_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_group_id_null` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '<NULL>',
  `owner_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_stem_id_null` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '<NULL>',
  `member_attr_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `field_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `member_field_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `mship_type` varchar(16) COLLATE utf8_bin NOT NULL,
  `depth` int(11) NOT NULL,
  `via_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `parent_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `creator_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_set_uniq_idx` (`member_id`,`field_id`,`owner_id`,`parent_id`,`mship_type`),
  KEY `group_set_owner_field_idx` (`owner_id`,`field_id`),
  KEY `group_set_creator_idx` (`creator_id`),
  KEY `group_set_parent_idx` (`parent_id`),
  KEY `group_set_via_group_idx` (`via_group_id`),
  KEY `group_set_context_idx` (`context_id`),
  KEY `group_set_gmember_idx` (`member_group_id`),
  KEY `group_set_smember_idx` (`member_stem_id`),
  KEY `group_set_amember_idx` (`member_attr_def_id`),
  KEY `group_set_gowner_field_idx` (`owner_group_id`,`field_id`),
  KEY `group_set_sowner_field_idx` (`owner_stem_id`,`field_id`),
  KEY `group_set_aowner_field_idx` (`owner_attr_def_id`,`field_id`),
  KEY `group_set_gowner_member_idx` (`owner_group_id`,`member_group_id`,`field_id`,`depth`),
  KEY `group_set_sowner_member_idx` (`owner_stem_id`,`member_stem_id`,`field_id`,`depth`),
  KEY `group_set_aowner_member_idx` (`owner_attr_def_id`,`member_attr_def_id`,`field_id`,`depth`),
  KEY `fk_group_set_field_id` (`field_id`),
  KEY `fk_group_set_member_field_id` (`member_field_id`),
  CONSTRAINT `fk_group_set_creator_id` FOREIGN KEY (`creator_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_group_set_field_id` FOREIGN KEY (`field_id`) REFERENCES `grouper_fields` (`id`),
  CONSTRAINT `fk_group_set_member_field_id` FOREIGN KEY (`member_field_id`) REFERENCES `grouper_fields` (`id`),
  CONSTRAINT `fk_group_set_member_group_id` FOREIGN KEY (`member_group_id`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_group_set_member_stem_id` FOREIGN KEY (`member_stem_id`) REFERENCES `grouper_stems` (`id`),
  CONSTRAINT `fk_group_set_owner_attr_def_id` FOREIGN KEY (`owner_attr_def_id`) REFERENCES `grouper_attribute_def` (`id`),
  CONSTRAINT `fk_group_set_owner_group_id` FOREIGN KEY (`owner_group_id`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_group_set_owner_stem_id` FOREIGN KEY (`owner_stem_id`) REFERENCES `grouper_stems` (`id`),
  CONSTRAINT `fk_group_set_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `grouper_group_set` (`id`),
  CONSTRAINT `fk_group_set_via_group_id` FOREIGN KEY (`via_group_id`) REFERENCES `grouper_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_group_set`
--

LOCK TABLES `grouper_group_set` WRITE;
/*!40000 ALTER TABLE `grouper_group_set` DISABLE KEYS */;
INSERT INTO `grouper_group_set` VALUES ('00335229c8244b5c833ba7d8d44bc296',NULL,'<NULL>',NULL,'<NULL>','1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716',NULL,NULL,'1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','1730a44d087442cc96c2d8d63b655716','immediate',0,NULL,'00335229c8244b5c833ba7d8d44bc296','65947ffd4e364921a42c465d94a78c09',1459816161186,'e4639a3fb91d43a49bf595de9c390d53',0),('028647d27d0a40928aa728026f763819','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'028647d27d0a40928aa728026f763819','65947ffd4e364921a42c465d94a78c09',1459816168575,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('040270ded6ee49fa91cd2b227beeafd1','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'040270ded6ee49fa91cd2b227beeafd1','65947ffd4e364921a42c465d94a78c09',1459816161685,'8159789da0a14cafbd09145afa025cd8',0),('048dee8db8dc4ea78c1d5e29d9a0c26f','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'048dee8db8dc4ea78c1d5e29d9a0c26f','65947ffd4e364921a42c465d94a78c09',1459816164078,'0865979fcb75478ea9394435359e8b9a',0),('04da70d9bb734981a05d610f4b4af92f','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'04da70d9bb734981a05d610f4b4af92f','65947ffd4e364921a42c465d94a78c09',1459816164330,'35b82a4a0f7146248919176310137474',0),('05bb3845fb064b0495e508a18b7be882','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'05bb3845fb064b0495e508a18b7be882','65947ffd4e364921a42c465d94a78c09',1459816162338,'98ba1ea840d5404299ad811e5e2f1da2',0),('062afede3e50410e99e34b0145aae8f8','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'062afede3e50410e99e34b0145aae8f8','65947ffd4e364921a42c465d94a78c09',1459816167571,'9020c22117504dceb753bc010b2d0088',0),('0677d7efec304e769dc8ee2b807af8de',NULL,'<NULL>',NULL,'<NULL>','d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,'d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','d5248b39d72f4fdcb730d1be03de4fbc','immediate',0,NULL,'0677d7efec304e769dc8ee2b807af8de','65947ffd4e364921a42c465d94a78c09',1459816161262,'d6b66eb39f3645a3a2703500fecb4a59',0),('06df51ce350746baa29e10b2e0855f7f','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'06df51ce350746baa29e10b2e0855f7f','65947ffd4e364921a42c465d94a78c09',1459816162347,'98ba1ea840d5404299ad811e5e2f1da2',0),('091fbe65a5c1439a9398e715f18b7904','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','dd528f792dd544938a2588848992e909','immediate',0,NULL,'091fbe65a5c1439a9398e715f18b7904','65947ffd4e364921a42c465d94a78c09',1459816163724,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('0ed50c8ef73549a1be3abff4fc4f899a','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'0ed50c8ef73549a1be3abff4fc4f899a','65947ffd4e364921a42c465d94a78c09',1459816165861,'00618952cb8b4705b94cd916a6713a4e',0),('10a8f9c75e854d2a8ee5743668662648',NULL,'<NULL>',NULL,'<NULL>','47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de',NULL,NULL,'47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','47bf48f95b9a4c67855b091e3d1003de','immediate',0,NULL,'10a8f9c75e854d2a8ee5743668662648','65947ffd4e364921a42c465d94a78c09',1459816160265,'ea8757bd8a5e4fcb8d05e62bd36a6da4',0),('13f8a3f315bc4c6eb3386124c589c4c2','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'13f8a3f315bc4c6eb3386124c589c4c2','65947ffd4e364921a42c465d94a78c09',1459816164259,'2d05ad7ebd794bb79815228acd5fed54',0),('1a220459c4e842608470e144f148a8cb','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'1a220459c4e842608470e144f148a8cb','65947ffd4e364921a42c465d94a78c09',1459816167555,'9020c22117504dceb753bc010b2d0088',0),('1da776751a454e8395ca0903fcce85e7','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'1da776751a454e8395ca0903fcce85e7','65947ffd4e364921a42c465d94a78c09',1459816168406,'99ec6323827447ebb566a0adbdada197',0),('1e16c12099254fb8a326c04114f5f2e2','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'1e16c12099254fb8a326c04114f5f2e2','65947ffd4e364921a42c465d94a78c09',1459816164256,'2d05ad7ebd794bb79815228acd5fed54',0),('1fe5deb98b2a47f683553f2c29a565a7','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'1fe5deb98b2a47f683553f2c29a565a7','65947ffd4e364921a42c465d94a78c09',1459816167566,'9020c22117504dceb753bc010b2d0088',0),('20b723a3f023407ba1b12bd28f0acebc','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','dd528f792dd544938a2588848992e909','immediate',0,NULL,'20b723a3f023407ba1b12bd28f0acebc','65947ffd4e364921a42c465d94a78c09',1459816163731,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('22a5a11f8fcd4ab9899c8027dd59792b','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'22a5a11f8fcd4ab9899c8027dd59792b','65947ffd4e364921a42c465d94a78c09',1459816165860,'00618952cb8b4705b94cd916a6713a4e',0),('23df3ab489e349fc9cd5f23c04b485b5',NULL,'<NULL>',NULL,'<NULL>','36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,'36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','36792aa7956240feb1bb6025c56ff2f3','immediate',0,NULL,'23df3ab489e349fc9cd5f23c04b485b5','65947ffd4e364921a42c465d94a78c09',1459816161051,'0564466782fa4b5fbe17c5861dbd2f23',0),('24513acbb8044962bcb6e9a815a7a041','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'24513acbb8044962bcb6e9a815a7a041','65947ffd4e364921a42c465d94a78c09',1459816164319,'35b82a4a0f7146248919176310137474',0),('267f395ac4f042bba0cbf468609a60e7',NULL,'<NULL>',NULL,'<NULL>','1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716',NULL,NULL,'1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','1730a44d087442cc96c2d8d63b655716','immediate',0,NULL,'267f395ac4f042bba0cbf468609a60e7','65947ffd4e364921a42c465d94a78c09',1459816161173,'e4639a3fb91d43a49bf595de9c390d53',0),('28cbcf4c8d13414ca8b706e6be219c38','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'28cbcf4c8d13414ca8b706e6be219c38','65947ffd4e364921a42c465d94a78c09',1459816165851,'00618952cb8b4705b94cd916a6713a4e',0),('2930ed814ad542baa6d0729ee25d6490','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'2930ed814ad542baa6d0729ee25d6490','65947ffd4e364921a42c465d94a78c09',1459816162345,'98ba1ea840d5404299ad811e5e2f1da2',0),('2ab148731d0246dd86fd706ef86c9bca',NULL,'<NULL>',NULL,'<NULL>','36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,'36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','36792aa7956240feb1bb6025c56ff2f3','immediate',0,NULL,'2ab148731d0246dd86fd706ef86c9bca','65947ffd4e364921a42c465d94a78c09',1459816161052,'0564466782fa4b5fbe17c5861dbd2f23',0),('30ab4725bcf14f5b8a4a1136223d93dc',NULL,'<NULL>',NULL,'<NULL>','d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d',NULL,NULL,'d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','d83a1feb851d4ede95786362de79547d','immediate',0,NULL,'30ab4725bcf14f5b8a4a1136223d93dc','65947ffd4e364921a42c465d94a78c09',1459816158447,NULL,0),('321dfb66a45c4beaa6975eea9ad13710','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'321dfb66a45c4beaa6975eea9ad13710','65947ffd4e364921a42c465d94a78c09',1459816168416,'99ec6323827447ebb566a0adbdada197',0),('3286141fb20c48d89828599fd08385cb',NULL,'<NULL>',NULL,'<NULL>','fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,'fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','fc88a71ee4574ae7b0a550d72b5172d9','immediate',0,NULL,'3286141fb20c48d89828599fd08385cb','65947ffd4e364921a42c465d94a78c09',1459816162266,'10e41282ff0b4434b2111890260d81e6',0),('35657c4d3a414b1b84df288de93e6315','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'35657c4d3a414b1b84df288de93e6315','65947ffd4e364921a42c465d94a78c09',1459816164333,'35b82a4a0f7146248919176310137474',0),('370f1493a83c48b1be850e7e03b34204','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'370f1493a83c48b1be850e7e03b34204','65947ffd4e364921a42c465d94a78c09',1459816162444,'b9307b3c26ab440d91b270b950336d12',0),('3798233a8db24758821303ec86472116','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'3798233a8db24758821303ec86472116','65947ffd4e364921a42c465d94a78c09',1459816164096,'0865979fcb75478ea9394435359e8b9a',0),('38d84f9dccf44bbfbcbcd6ce17eee94a','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'38d84f9dccf44bbfbcbcd6ce17eee94a','65947ffd4e364921a42c465d94a78c09',1459816164103,'0865979fcb75478ea9394435359e8b9a',0),('3915e36df36b4e5ca388c43291001361','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'3915e36df36b4e5ca388c43291001361','65947ffd4e364921a42c465d94a78c09',1459816168131,'d3070a409e5149a0b7bfeb8222f313ab',0),('3b7e9a1ed6af4f74b1eb6dbbd8d7290f','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'3b7e9a1ed6af4f74b1eb6dbbd8d7290f','65947ffd4e364921a42c465d94a78c09',1459816162442,'b9307b3c26ab440d91b270b950336d12',0),('3b9dd54864664e22819f01d1ff15370d','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'3b9dd54864664e22819f01d1ff15370d','65947ffd4e364921a42c465d94a78c09',1459816162454,'b9307b3c26ab440d91b270b950336d12',0),('3d7482a684014ceeb355b1c78c42b19e','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'3d7482a684014ceeb355b1c78c42b19e','65947ffd4e364921a42c465d94a78c09',1459816162452,'b9307b3c26ab440d91b270b950336d12',0),('3e68f5a6286c4f7595dcd9b045530da4','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'3e68f5a6286c4f7595dcd9b045530da4','65947ffd4e364921a42c465d94a78c09',1459816164101,'0865979fcb75478ea9394435359e8b9a',0),('3e8d940ac7bd4d1f9f2ed8ce903a7263','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'3e8d940ac7bd4d1f9f2ed8ce903a7263','65947ffd4e364921a42c465d94a78c09',1459816163943,'4804a077ec2c43899a5d981c4d45375f',0),('3eb9a41c33ba4430a004a92ff1ed1fc2','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'3eb9a41c33ba4430a004a92ff1ed1fc2','65947ffd4e364921a42c465d94a78c09',1459816162352,'98ba1ea840d5404299ad811e5e2f1da2',0),('3eddb7f3c5ce44028720a0081a3a889a','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'3eddb7f3c5ce44028720a0081a3a889a','65947ffd4e364921a42c465d94a78c09',1459816164257,'2d05ad7ebd794bb79815228acd5fed54',0),('406dc5f74ff8494483ca6258312ba495','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'406dc5f74ff8494483ca6258312ba495','65947ffd4e364921a42c465d94a78c09',1459816165963,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('40969dc9a5fc464bbfbe4f0b77aacf7e','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'40969dc9a5fc464bbfbe4f0b77aacf7e','65947ffd4e364921a42c465d94a78c09',1459816168120,'d3070a409e5149a0b7bfeb8222f313ab',0),('40caada41e514805b5026e300596fbdc',NULL,'<NULL>',NULL,'<NULL>','b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926',NULL,NULL,'b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','b6bc2fcd772146ee970347e496538926','immediate',0,NULL,'40caada41e514805b5026e300596fbdc','65947ffd4e364921a42c465d94a78c09',1459816163657,'7b21a0f6bac34729967562807de21d63',0),('40fa3f1221464fa18c28ec93574758ef','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'40fa3f1221464fa18c28ec93574758ef','65947ffd4e364921a42c465d94a78c09',1459816168576,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('4397d7a373474aa495e3c9572ddb59d6','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'4397d7a373474aa495e3c9572ddb59d6','65947ffd4e364921a42c465d94a78c09',1459816168570,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('44c3dce3f0234b88a0d1ac9d11d0d763','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','a9cce636abf44507876f639467f74174','immediate',0,NULL,'44c3dce3f0234b88a0d1ac9d11d0d763','65947ffd4e364921a42c465d94a78c09',1459816167382,'a194a2a1e2ad45e7b81b45c4f987e830',0),('4651f927121245aba24dfc3539e287c1','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'4651f927121245aba24dfc3539e287c1','65947ffd4e364921a42c465d94a78c09',1459816167526,'9020c22117504dceb753bc010b2d0088',0),('48d64e4ac5c9475d8db6921f7c5ada4f','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'48d64e4ac5c9475d8db6921f7c5ada4f','65947ffd4e364921a42c465d94a78c09',1459816162445,'b9307b3c26ab440d91b270b950336d12',0),('493b8cf86c62479b9c13365ed0032be2','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'493b8cf86c62479b9c13365ed0032be2','65947ffd4e364921a42c465d94a78c09',1459816168122,'d3070a409e5149a0b7bfeb8222f313ab',0),('4a6c001ab5b64211965820e7536e7fb8',NULL,'<NULL>',NULL,'<NULL>','2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192',NULL,NULL,'2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','2eee186e51494f0a874fe61ff24b7192','immediate',0,NULL,'4a6c001ab5b64211965820e7536e7fb8','65947ffd4e364921a42c465d94a78c09',1459816168088,'129701637b9d4e1f9b0222cd9069d8d3',0),('4ff31043620d4b2a8ed43f83e96fadda',NULL,'<NULL>',NULL,'<NULL>','fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,'fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','fc88a71ee4574ae7b0a550d72b5172d9','immediate',0,NULL,'4ff31043620d4b2a8ed43f83e96fadda','65947ffd4e364921a42c465d94a78c09',1459816162269,'10e41282ff0b4434b2111890260d81e6',0),('4ff57082a6eb46a0a00c62bcb49c2226','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','a9cce636abf44507876f639467f74174','immediate',0,NULL,'4ff57082a6eb46a0a00c62bcb49c2226','65947ffd4e364921a42c465d94a78c09',1459816167367,'a194a2a1e2ad45e7b81b45c4f987e830',0),('54058d222c184e53b917a40cd2e98ead','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'54058d222c184e53b917a40cd2e98ead','65947ffd4e364921a42c465d94a78c09',1459816161377,'73cbab28d09f47459ae272f0fc2a3479',0),('543af4f6dc8e4459830808207e2ad045','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'543af4f6dc8e4459830808207e2ad045','65947ffd4e364921a42c465d94a78c09',1459816161385,'73cbab28d09f47459ae272f0fc2a3479',0),('54fc6d069871441e85c1dc47d7d40299','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'54fc6d069871441e85c1dc47d7d40299','65947ffd4e364921a42c465d94a78c09',1459816161386,'73cbab28d09f47459ae272f0fc2a3479',0),('55bc82b78db6423cb538c6183166ecc3',NULL,'<NULL>',NULL,'<NULL>','6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','6cd4d8196fe24d21acd51cdf8fcdb3cc','immediate',0,NULL,'55bc82b78db6423cb538c6183166ecc3','65947ffd4e364921a42c465d94a78c09',1459816164212,'2768fb08bd7c4eff90209d082ab4ff73',0),('585d1d42ae2748c481f71cdc0ee6abe3','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'585d1d42ae2748c481f71cdc0ee6abe3','65947ffd4e364921a42c465d94a78c09',1459816163937,'4804a077ec2c43899a5d981c4d45375f',0),('58f373a912e749428e1139731ff51b43','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','a9cce636abf44507876f639467f74174','immediate',0,NULL,'58f373a912e749428e1139731ff51b43','65947ffd4e364921a42c465d94a78c09',1459816167380,'a194a2a1e2ad45e7b81b45c4f987e830',0),('59fcee1e55214d9bb70bfe93e552edf2',NULL,'<NULL>',NULL,'<NULL>','fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,'fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','fc88a71ee4574ae7b0a550d72b5172d9','immediate',0,NULL,'59fcee1e55214d9bb70bfe93e552edf2','65947ffd4e364921a42c465d94a78c09',1459816162264,'10e41282ff0b4434b2111890260d81e6',0),('5b6ccbcc57d24a2c818db73602a68003','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'5b6ccbcc57d24a2c818db73602a68003','65947ffd4e364921a42c465d94a78c09',1459816168587,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('5db63ce196fa4888869ba516de92474b','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','dd528f792dd544938a2588848992e909','immediate',0,NULL,'5db63ce196fa4888869ba516de92474b','65947ffd4e364921a42c465d94a78c09',1459816163719,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('5e0e0b1e564f45968ef29ca216743d2f','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'5e0e0b1e564f45968ef29ca216743d2f','65947ffd4e364921a42c465d94a78c09',1459816167552,'9020c22117504dceb753bc010b2d0088',0),('5fd38838bad643d49ab026f8d153bb36',NULL,'<NULL>',NULL,'<NULL>','b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926',NULL,NULL,'b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','b6bc2fcd772146ee970347e496538926','immediate',0,NULL,'5fd38838bad643d49ab026f8d153bb36','65947ffd4e364921a42c465d94a78c09',1459816163660,'7b21a0f6bac34729967562807de21d63',0),('60642bed830740de955e3708d7f998c9','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'60642bed830740de955e3708d7f998c9','65947ffd4e364921a42c465d94a78c09',1459816162431,'b9307b3c26ab440d91b270b950336d12',0),('62ad1b0549bf46bb85af4ddbd8b0776c',NULL,'<NULL>',NULL,'<NULL>','47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de',NULL,NULL,'47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','47bf48f95b9a4c67855b091e3d1003de','immediate',0,NULL,'62ad1b0549bf46bb85af4ddbd8b0776c','65947ffd4e364921a42c465d94a78c09',1459816160019,'ea8757bd8a5e4fcb8d05e62bd36a6da4',0),('64ae13d3fe704e2a9d7b48c52bbc7c1c','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'64ae13d3fe704e2a9d7b48c52bbc7c1c','65947ffd4e364921a42c465d94a78c09',1459816167568,'9020c22117504dceb753bc010b2d0088',0),('6549e79ab88a42e8855ca7bf2cc6e51b','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'6549e79ab88a42e8855ca7bf2cc6e51b','65947ffd4e364921a42c465d94a78c09',1459816165954,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('6768cb1cadc942cf870d7deec9ff0f12','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','dd528f792dd544938a2588848992e909','immediate',0,NULL,'6768cb1cadc942cf870d7deec9ff0f12','65947ffd4e364921a42c465d94a78c09',1459816163714,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('68a9fe7a7a594440a685563120e7b4fc',NULL,'<NULL>',NULL,'<NULL>','47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de',NULL,NULL,'47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','47bf48f95b9a4c67855b091e3d1003de','immediate',0,NULL,'68a9fe7a7a594440a685563120e7b4fc','65947ffd4e364921a42c465d94a78c09',1459816159837,'ea8757bd8a5e4fcb8d05e62bd36a6da4',0),('68ed3dae5b5c4d8890718585260441d5',NULL,'<NULL>',NULL,'<NULL>','cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,'cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','cb1bfad6c8ed424d902b65d9ec275df0','immediate',0,NULL,'68ed3dae5b5c4d8890718585260441d5','65947ffd4e364921a42c465d94a78c09',1459816167278,'9484aa1ec9af4b48b7e2db04840dd01e',0),('6cb811566a9f41b480f5c14dd23a16c1','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'6cb811566a9f41b480f5c14dd23a16c1','65947ffd4e364921a42c465d94a78c09',1459816164325,'35b82a4a0f7146248919176310137474',0),('6eca5bd39fd4489abfdbecce4048a1d7','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'6eca5bd39fd4489abfdbecce4048a1d7','65947ffd4e364921a42c465d94a78c09',1459816161389,'73cbab28d09f47459ae272f0fc2a3479',0),('71c9837e4bcb40688f25abdd55a8e4ee',NULL,'<NULL>',NULL,'<NULL>','d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,'d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','d5248b39d72f4fdcb730d1be03de4fbc','immediate',0,NULL,'71c9837e4bcb40688f25abdd55a8e4ee','65947ffd4e364921a42c465d94a78c09',1459816161263,'d6b66eb39f3645a3a2703500fecb4a59',0),('745cac1be7c04605899d4a2f6415fea8','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'745cac1be7c04605899d4a2f6415fea8','65947ffd4e364921a42c465d94a78c09',1459816165853,'00618952cb8b4705b94cd916a6713a4e',0),('74dbec332a754b7994f2b29f4b1f2cf6','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'74dbec332a754b7994f2b29f4b1f2cf6','65947ffd4e364921a42c465d94a78c09',1459816164262,'2d05ad7ebd794bb79815228acd5fed54',0),('76f30c3f07f44d5195957308b9ea5cbb','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'76f30c3f07f44d5195957308b9ea5cbb','65947ffd4e364921a42c465d94a78c09',1459816162349,'98ba1ea840d5404299ad811e5e2f1da2',0),('7775d43305a5416082607aa5f2f36269','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'7775d43305a5416082607aa5f2f36269','65947ffd4e364921a42c465d94a78c09',1459816165949,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('77c18218f3134bc29fcd221e7287c77b','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','dd528f792dd544938a2588848992e909','immediate',0,NULL,'77c18218f3134bc29fcd221e7287c77b','65947ffd4e364921a42c465d94a78c09',1459816163720,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('784d60196b2a426b99eb2017b3dabf70',NULL,'<NULL>',NULL,'<NULL>','2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192',NULL,NULL,'2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','2eee186e51494f0a874fe61ff24b7192','immediate',0,NULL,'784d60196b2a426b99eb2017b3dabf70','65947ffd4e364921a42c465d94a78c09',1459816168085,'129701637b9d4e1f9b0222cd9069d8d3',0),('78be03b103684b908ab33b8ad3a29f6a',NULL,'<NULL>',NULL,'<NULL>','6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','6cd4d8196fe24d21acd51cdf8fcdb3cc','immediate',0,NULL,'78be03b103684b908ab33b8ad3a29f6a','65947ffd4e364921a42c465d94a78c09',1459816164198,'2768fb08bd7c4eff90209d082ab4ff73',0),('79b18f33b8d04ca694b34deebeed98c1','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'79b18f33b8d04ca694b34deebeed98c1','65947ffd4e364921a42c465d94a78c09',1459816168407,'99ec6323827447ebb566a0adbdada197',0),('79ee263ed2574e5d9d7cbbce4d7ddaa3','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'79ee263ed2574e5d9d7cbbce4d7ddaa3','65947ffd4e364921a42c465d94a78c09',1459816163939,'4804a077ec2c43899a5d981c4d45375f',0),('7cbbd03e4ddf4345a44790157b5973d1','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'7cbbd03e4ddf4345a44790157b5973d1','65947ffd4e364921a42c465d94a78c09',1459816162450,'b9307b3c26ab440d91b270b950336d12',0),('8038cff0a57f4b95a4d87e52a4718287',NULL,'<NULL>',NULL,'<NULL>','47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de',NULL,NULL,'47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','47bf48f95b9a4c67855b091e3d1003de','immediate',0,NULL,'8038cff0a57f4b95a4d87e52a4718287','65947ffd4e364921a42c465d94a78c09',1459816159833,'ea8757bd8a5e4fcb8d05e62bd36a6da4',0),('80e114e249874a9a966403831071a510','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'80e114e249874a9a966403831071a510','65947ffd4e364921a42c465d94a78c09',1459816167544,'9020c22117504dceb753bc010b2d0088',0),('823470d93c634d56be6bd5a2bea88ae3','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'823470d93c634d56be6bd5a2bea88ae3','65947ffd4e364921a42c465d94a78c09',1459816161717,'8159789da0a14cafbd09145afa025cd8',0),('824171c44432403d9fab369eb64c434d','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'824171c44432403d9fab369eb64c434d','65947ffd4e364921a42c465d94a78c09',1459816165845,'00618952cb8b4705b94cd916a6713a4e',0),('843f32ec291a401bb3bacf2f1bb00696',NULL,'<NULL>',NULL,'<NULL>','094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f',NULL,NULL,'094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','094308af1376466687416c49f1f6495f','immediate',0,NULL,'843f32ec291a401bb3bacf2f1bb00696','65947ffd4e364921a42c465d94a78c09',1459816165622,'b62e1c7566d14267a62216d2aed227b6',0),('85f4827c404f4fafb96c3ce9ecfbbf4c','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'85f4827c404f4fafb96c3ce9ecfbbf4c','65947ffd4e364921a42c465d94a78c09',1459816164255,'2d05ad7ebd794bb79815228acd5fed54',0),('860cb6bb92d0407d9d8cbb8dffe7ea9f',NULL,'<NULL>',NULL,'<NULL>','d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,'d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','d5248b39d72f4fdcb730d1be03de4fbc','immediate',0,NULL,'860cb6bb92d0407d9d8cbb8dffe7ea9f','65947ffd4e364921a42c465d94a78c09',1459816161269,'d6b66eb39f3645a3a2703500fecb4a59',0),('861750b77f2149648b266ca70aa767d6','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'861750b77f2149648b266ca70aa767d6','65947ffd4e364921a42c465d94a78c09',1459816168123,'d3070a409e5149a0b7bfeb8222f313ab',0),('871a472520db4cc8abdebe00345595f9','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'871a472520db4cc8abdebe00345595f9','65947ffd4e364921a42c465d94a78c09',1459816164262,'2d05ad7ebd794bb79815228acd5fed54',0),('885e1b92d77141ad8f489fec753e793b',NULL,'<NULL>',NULL,'<NULL>','36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,'36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','36792aa7956240feb1bb6025c56ff2f3','immediate',0,NULL,'885e1b92d77141ad8f489fec753e793b','65947ffd4e364921a42c465d94a78c09',1459816161047,'0564466782fa4b5fbe17c5861dbd2f23',0),('88dcfdd9276e4d13bef85d78f0d741de','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'88dcfdd9276e4d13bef85d78f0d741de','65947ffd4e364921a42c465d94a78c09',1459816168130,'d3070a409e5149a0b7bfeb8222f313ab',0),('88f7974e919e458999c5a6d6316a743c','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'88f7974e919e458999c5a6d6316a743c','65947ffd4e364921a42c465d94a78c09',1459816165951,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('892e28aff9f24dac936fa31f7f4c4500','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'892e28aff9f24dac936fa31f7f4c4500','65947ffd4e364921a42c465d94a78c09',1459816162341,'98ba1ea840d5404299ad811e5e2f1da2',0),('895552df5cfa4b0c9bbe15455c94ed87',NULL,'<NULL>',NULL,'<NULL>','fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,'fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','fc88a71ee4574ae7b0a550d72b5172d9','immediate',0,NULL,'895552df5cfa4b0c9bbe15455c94ed87','65947ffd4e364921a42c465d94a78c09',1459816162277,'10e41282ff0b4434b2111890260d81e6',0),('89b5513cc9de4903b4b3c62668dd9cc1','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'89b5513cc9de4903b4b3c62668dd9cc1','65947ffd4e364921a42c465d94a78c09',1459816168126,'d3070a409e5149a0b7bfeb8222f313ab',0),('8b5cad3346484275a72e1868cd16249a','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'8b5cad3346484275a72e1868cd16249a','65947ffd4e364921a42c465d94a78c09',1459816168563,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('8ecd49f920c846cb97cc660eb9d1d4c7','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'8ecd49f920c846cb97cc660eb9d1d4c7','65947ffd4e364921a42c465d94a78c09',1459816165944,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('8fc57e6b1cfb463fac2dc7e270580f48',NULL,'<NULL>',NULL,'<NULL>','b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926',NULL,NULL,'b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','b6bc2fcd772146ee970347e496538926','immediate',0,NULL,'8fc57e6b1cfb463fac2dc7e270580f48','65947ffd4e364921a42c465d94a78c09',1459816163662,'7b21a0f6bac34729967562807de21d63',0),('9024025949514a4ab4d8563760f90b83','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'9024025949514a4ab4d8563760f90b83','65947ffd4e364921a42c465d94a78c09',1459816163953,'4804a077ec2c43899a5d981c4d45375f',0),('91d2dc01db114733b6cd41901acb1d67','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'91d2dc01db114733b6cd41901acb1d67','65947ffd4e364921a42c465d94a78c09',1459816164260,'2d05ad7ebd794bb79815228acd5fed54',0),('91d8952fbb594d96b8cfcb63d65a8334','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','a9cce636abf44507876f639467f74174','immediate',0,NULL,'91d8952fbb594d96b8cfcb63d65a8334','65947ffd4e364921a42c465d94a78c09',1459816167376,'a194a2a1e2ad45e7b81b45c4f987e830',0),('9717b5012df14833a9d42d1b24e04a69','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'9717b5012df14833a9d42d1b24e04a69','65947ffd4e364921a42c465d94a78c09',1459816168408,'99ec6323827447ebb566a0adbdada197',0),('97655a92a7ac4c24b49ee842d2c8fb5e',NULL,'<NULL>',NULL,'<NULL>','cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,'cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','cb1bfad6c8ed424d902b65d9ec275df0','immediate',0,NULL,'97655a92a7ac4c24b49ee842d2c8fb5e','65947ffd4e364921a42c465d94a78c09',1459816167280,'9484aa1ec9af4b48b7e2db04840dd01e',0),('98caef470b6c4af4a9b1a3f24498f3df',NULL,'<NULL>',NULL,'<NULL>','2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192',NULL,NULL,'2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','2eee186e51494f0a874fe61ff24b7192','immediate',0,NULL,'98caef470b6c4af4a9b1a3f24498f3df','65947ffd4e364921a42c465d94a78c09',1459816168090,'129701637b9d4e1f9b0222cd9069d8d3',0),('9b138b2276344b6a81918c42898b39dc','240c728c9e2c42ccb4bd63fae71d8b28','240c728c9e2c42ccb4bd63fae71d8b28',NULL,'<NULL>',NULL,'<NULL>','240c728c9e2c42ccb4bd63fae71d8b28',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','240c728c9e2c42ccb4bd63fae71d8b28','immediate',0,NULL,'9b138b2276344b6a81918c42898b39dc','65947ffd4e364921a42c465d94a78c09',1459816164251,'2d05ad7ebd794bb79815228acd5fed54',0),('9cfea339e22e4b09bdfb0e4e0993a6f5','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'9cfea339e22e4b09bdfb0e4e0993a6f5','65947ffd4e364921a42c465d94a78c09',1459816168583,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('9ec124a92db04b2f84129c17fca005d5','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'9ec124a92db04b2f84129c17fca005d5','65947ffd4e364921a42c465d94a78c09',1459816168415,'99ec6323827447ebb566a0adbdada197',0),('a0cebdd2692a4235a012db8b79fd1428','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'a0cebdd2692a4235a012db8b79fd1428','65947ffd4e364921a42c465d94a78c09',1459816165859,'00618952cb8b4705b94cd916a6713a4e',0),('a127a52f681e4a03977f4389cc48898e','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','a9cce636abf44507876f639467f74174','immediate',0,NULL,'a127a52f681e4a03977f4389cc48898e','65947ffd4e364921a42c465d94a78c09',1459816167371,'a194a2a1e2ad45e7b81b45c4f987e830',0),('a2f6bf70986a45f8835aa5bb9c6a2cf6',NULL,'<NULL>',NULL,'<NULL>','094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f',NULL,NULL,'094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','094308af1376466687416c49f1f6495f','immediate',0,NULL,'a2f6bf70986a45f8835aa5bb9c6a2cf6','65947ffd4e364921a42c465d94a78c09',1459816165619,'b62e1c7566d14267a62216d2aed227b6',0),('a318dbcab2d545798fb7952306218a44','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'a318dbcab2d545798fb7952306218a44','65947ffd4e364921a42c465d94a78c09',1459816161397,'73cbab28d09f47459ae272f0fc2a3479',0),('a387b07719da4ca2849d788533bb384e',NULL,'<NULL>',NULL,'<NULL>','b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926',NULL,NULL,'b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','b6bc2fcd772146ee970347e496538926','immediate',0,NULL,'a387b07719da4ca2849d788533bb384e','65947ffd4e364921a42c465d94a78c09',1459816163663,'7b21a0f6bac34729967562807de21d63',0),('a514cd1788e74b9ca6e9123447d1544d','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'a514cd1788e74b9ca6e9123447d1544d','65947ffd4e364921a42c465d94a78c09',1459816164332,'35b82a4a0f7146248919176310137474',0),('a78ca7ea5e04417e9ed1915b92371491','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'a78ca7ea5e04417e9ed1915b92371491','65947ffd4e364921a42c465d94a78c09',1459816165956,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('a7ca331b887547ad82144e9df23f647e','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'a7ca331b887547ad82144e9df23f647e','65947ffd4e364921a42c465d94a78c09',1459816168581,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('a8a4a5e628b24678bff2e7875ae30488','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'a8a4a5e628b24678bff2e7875ae30488','65947ffd4e364921a42c465d94a78c09',1459816165850,'00618952cb8b4705b94cd916a6713a4e',0),('a9b8a8d3e813453eb330894e72b0f88b','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'a9b8a8d3e813453eb330894e72b0f88b','65947ffd4e364921a42c465d94a78c09',1459816161704,'8159789da0a14cafbd09145afa025cd8',0),('a9bab1f97d574500a0b16ed0e4cf4031','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'a9bab1f97d574500a0b16ed0e4cf4031','65947ffd4e364921a42c465d94a78c09',1459816168407,'99ec6323827447ebb566a0adbdada197',0),('a9ecd23a3c994f8d87e65d1a4fa917c2','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','dd528f792dd544938a2588848992e909','immediate',0,NULL,'a9ecd23a3c994f8d87e65d1a4fa917c2','65947ffd4e364921a42c465d94a78c09',1459816163732,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('aa81ea1448ef424eb85364aa32f9af45','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'aa81ea1448ef424eb85364aa32f9af45','65947ffd4e364921a42c465d94a78c09',1459816162344,'98ba1ea840d5404299ad811e5e2f1da2',0),('acd29f52664a45368164a2c2630518a6',NULL,'<NULL>',NULL,'<NULL>','1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716',NULL,NULL,'1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','1730a44d087442cc96c2d8d63b655716','immediate',0,NULL,'acd29f52664a45368164a2c2630518a6','65947ffd4e364921a42c465d94a78c09',1459816161181,'e4639a3fb91d43a49bf595de9c390d53',0),('ad4ead319ead4b169bc3c5e65edadef8','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'ad4ead319ead4b169bc3c5e65edadef8','65947ffd4e364921a42c465d94a78c09',1459816163927,'4804a077ec2c43899a5d981c4d45375f',0),('ad9c00b3a53946e289496c035693780f',NULL,'<NULL>',NULL,'<NULL>','cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,'cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','cb1bfad6c8ed424d902b65d9ec275df0','immediate',0,NULL,'ad9c00b3a53946e289496c035693780f','65947ffd4e364921a42c465d94a78c09',1459816167282,'9484aa1ec9af4b48b7e2db04840dd01e',0),('af0c506b20804bdda7e503f329d5095a','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'af0c506b20804bdda7e503f329d5095a','65947ffd4e364921a42c465d94a78c09',1459816164091,'0865979fcb75478ea9394435359e8b9a',0),('af3101b2c92c44d58fa6bc53ad931918','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','a9cce636abf44507876f639467f74174','immediate',0,NULL,'af3101b2c92c44d58fa6bc53ad931918','65947ffd4e364921a42c465d94a78c09',1459816167364,'a194a2a1e2ad45e7b81b45c4f987e830',0),('b0da91608fce43fdb93688089ef19afc',NULL,'<NULL>',NULL,'<NULL>','6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','6cd4d8196fe24d21acd51cdf8fcdb3cc','immediate',0,NULL,'b0da91608fce43fdb93688089ef19afc','65947ffd4e364921a42c465d94a78c09',1459816164211,'2768fb08bd7c4eff90209d082ab4ff73',0),('b1cbb0f0229d4bb2a738d133927706cc','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'b1cbb0f0229d4bb2a738d133927706cc','65947ffd4e364921a42c465d94a78c09',1459816161684,'8159789da0a14cafbd09145afa025cd8',0),('b1ef64a27bdb4a20b29c4d3e8f5e0724',NULL,'<NULL>',NULL,'<NULL>','094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f',NULL,NULL,'094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','094308af1376466687416c49f1f6495f','immediate',0,NULL,'b1ef64a27bdb4a20b29c4d3e8f5e0724','65947ffd4e364921a42c465d94a78c09',1459816165623,'b62e1c7566d14267a62216d2aed227b6',0),('b34926556bb54f0d8bd017622663c164','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','dd528f792dd544938a2588848992e909','immediate',0,NULL,'b34926556bb54f0d8bd017622663c164','65947ffd4e364921a42c465d94a78c09',1459816163727,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('b715b3875c3a463f994dd18e5eff4aeb','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'b715b3875c3a463f994dd18e5eff4aeb','65947ffd4e364921a42c465d94a78c09',1459816164322,'35b82a4a0f7146248919176310137474',0),('b800af0b21164740a7a9390963220d03','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'b800af0b21164740a7a9390963220d03','65947ffd4e364921a42c465d94a78c09',1459816161687,'8159789da0a14cafbd09145afa025cd8',0),('b99f983592ec457f9886cd97dc382c5c',NULL,'<NULL>',NULL,'<NULL>','6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','6cd4d8196fe24d21acd51cdf8fcdb3cc','immediate',0,NULL,'b99f983592ec457f9886cd97dc382c5c','65947ffd4e364921a42c465d94a78c09',1459816164205,'2768fb08bd7c4eff90209d082ab4ff73',0),('ba0ac61a5beb473a8acfca8d5b2c0d8b','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'ba0ac61a5beb473a8acfca8d5b2c0d8b','65947ffd4e364921a42c465d94a78c09',1459816161405,'73cbab28d09f47459ae272f0fc2a3479',0),('baca64fe73ee434c9a6ef4de20e6e069','b92c64af9edd4b7493d8c4b2a936cbd8','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'<NULL>',NULL,'<NULL>','b92c64af9edd4b7493d8c4b2a936cbd8',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','b92c64af9edd4b7493d8c4b2a936cbd8','immediate',0,NULL,'baca64fe73ee434c9a6ef4de20e6e069','65947ffd4e364921a42c465d94a78c09',1459816162474,'b9307b3c26ab440d91b270b950336d12',0),('bc103885c6334db79046fc12fc74b448','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'bc103885c6334db79046fc12fc74b448','65947ffd4e364921a42c465d94a78c09',1459816163935,'4804a077ec2c43899a5d981c4d45375f',0),('bce05346f05d4df49de8fcea042e6348','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'bce05346f05d4df49de8fcea042e6348','65947ffd4e364921a42c465d94a78c09',1459816168416,'99ec6323827447ebb566a0adbdada197',0),('c401032eb4db451a8862c4b6e63d8568','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'c401032eb4db451a8862c4b6e63d8568','65947ffd4e364921a42c465d94a78c09',1459816165947,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('c5bd80fcfb054059a71b3e16a52d42e8','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'c5bd80fcfb054059a71b3e16a52d42e8','65947ffd4e364921a42c465d94a78c09',1459816163940,'4804a077ec2c43899a5d981c4d45375f',0),('c5e8de5aad6a40839cbc7632ad01464f','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'c5e8de5aad6a40839cbc7632ad01464f','65947ffd4e364921a42c465d94a78c09',1459816168133,'d3070a409e5149a0b7bfeb8222f313ab',0),('c60dbc1c55594bcaa9d7af5b8dea16a3','19faf0fca06b4aeb8a5cce52382a3f0e','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'<NULL>',NULL,'<NULL>','19faf0fca06b4aeb8a5cce52382a3f0e',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','19faf0fca06b4aeb8a5cce52382a3f0e','immediate',0,NULL,'c60dbc1c55594bcaa9d7af5b8dea16a3','65947ffd4e364921a42c465d94a78c09',1459816165854,'00618952cb8b4705b94cd916a6713a4e',0),('c6a6e98f433e440ba84073a400be5d47','dd528f792dd544938a2588848992e909','dd528f792dd544938a2588848992e909',NULL,'<NULL>',NULL,'<NULL>','dd528f792dd544938a2588848992e909',NULL,NULL,'dd528f792dd544938a2588848992e909','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','dd528f792dd544938a2588848992e909','immediate',0,NULL,'c6a6e98f433e440ba84073a400be5d47','65947ffd4e364921a42c465d94a78c09',1459816163715,'7bbeeff369ab4699bcbaf02e3beb0cd6',0),('c76dc621b71d45fe988692d9685e6dd1','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'c76dc621b71d45fe988692d9685e6dd1','65947ffd4e364921a42c465d94a78c09',1459816164320,'35b82a4a0f7146248919176310137474',0),('c7c31994b76f4f46a31d69676d82b01c',NULL,'<NULL>',NULL,'<NULL>','44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1',NULL,NULL,'44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','44824fdcdd0e435ab9eafc2a40e430c1','immediate',0,NULL,'c7c31994b76f4f46a31d69676d82b01c','65947ffd4e364921a42c465d94a78c09',1459816160942,'4f6e7d1adb7648b1a98d6a407eafb323',0),('cb5e528e574141c9921d5da55d385833',NULL,'<NULL>',NULL,'<NULL>','1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716',NULL,NULL,'1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','1730a44d087442cc96c2d8d63b655716','immediate',0,NULL,'cb5e528e574141c9921d5da55d385833','65947ffd4e364921a42c465d94a78c09',1459816161170,'e4639a3fb91d43a49bf595de9c390d53',0),('ce7adab6dcf64892a19e9de8adb4f862',NULL,'<NULL>',NULL,'<NULL>','cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,'cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','cb1bfad6c8ed424d902b65d9ec275df0','immediate',0,NULL,'ce7adab6dcf64892a19e9de8adb4f862','65947ffd4e364921a42c465d94a78c09',1459816167284,'9484aa1ec9af4b48b7e2db04840dd01e',0),('d0f9df5a4d714e279204b0973e174668','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','99d5358f26f74749904171eb52d12e5f','99d5358f26f74749904171eb52d12e5f','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'d0f9df5a4d714e279204b0973e174668','65947ffd4e364921a42c465d94a78c09',1459816161391,'73cbab28d09f47459ae272f0fc2a3479',0),('d1b58022bf214c7ab77b846cb8f74d52','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'d1b58022bf214c7ab77b846cb8f74d52','65947ffd4e364921a42c465d94a78c09',1459816161715,'8159789da0a14cafbd09145afa025cd8',0),('d4a3f3f190074ecba3b26f655ec0be10',NULL,'<NULL>',NULL,'<NULL>','d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d',NULL,NULL,'d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','d83a1feb851d4ede95786362de79547d','immediate',0,NULL,'d4a3f3f190074ecba3b26f655ec0be10','65947ffd4e364921a42c465d94a78c09',1459816158467,NULL,0),('d4a9ea3ec1fc4712993697ba861da25b','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','a9cce636abf44507876f639467f74174','immediate',0,NULL,'d4a9ea3ec1fc4712993697ba861da25b','65947ffd4e364921a42c465d94a78c09',1459816167384,'a194a2a1e2ad45e7b81b45c4f987e830',0),('d542d822383a4c1389b99791c11bdcbc',NULL,'<NULL>',NULL,'<NULL>','36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,'36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','36792aa7956240feb1bb6025c56ff2f3','immediate',0,NULL,'d542d822383a4c1389b99791c11bdcbc','65947ffd4e364921a42c465d94a78c09',1459816161050,'0564466782fa4b5fbe17c5861dbd2f23',0),('d58e67e646784b3da9e5b9584d4d6c92','35ee03902f9049fea8520a4c47e57b54','35ee03902f9049fea8520a4c47e57b54',NULL,'<NULL>',NULL,'<NULL>','35ee03902f9049fea8520a4c47e57b54',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','35ee03902f9049fea8520a4c47e57b54','immediate',0,NULL,'d58e67e646784b3da9e5b9584d4d6c92','65947ffd4e364921a42c465d94a78c09',1459816168582,'cc9ba9ab69e64d0c9c9ba96f0f506ce4',0),('d65ed00e0ca447c6a4b6580b0552b401','98e846065291427bb67c498d8e70d8ec','98e846065291427bb67c498d8e70d8ec',NULL,'<NULL>',NULL,'<NULL>','98e846065291427bb67c498d8e70d8ec',NULL,NULL,'98e846065291427bb67c498d8e70d8ec','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','98e846065291427bb67c498d8e70d8ec','immediate',0,NULL,'d65ed00e0ca447c6a4b6580b0552b401','65947ffd4e364921a42c465d94a78c09',1459816168124,'d3070a409e5149a0b7bfeb8222f313ab',0),('d99044b9212a4c7b9821a9391cc68b4f','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'d99044b9212a4c7b9821a9391cc68b4f','65947ffd4e364921a42c465d94a78c09',1459816161670,'8159789da0a14cafbd09145afa025cd8',0),('dadcc243bae64ae186c940d212033576',NULL,'<NULL>',NULL,'<NULL>','2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192',NULL,NULL,'2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','2eee186e51494f0a874fe61ff24b7192','immediate',0,NULL,'dadcc243bae64ae186c940d212033576','65947ffd4e364921a42c465d94a78c09',1459816168087,'129701637b9d4e1f9b0222cd9069d8d3',0),('dd53ebc4baee47bf8b130a5daed5b3e5','3e4973476a6e4351a925503a921ad728','3e4973476a6e4351a925503a921ad728',NULL,'<NULL>',NULL,'<NULL>','3e4973476a6e4351a925503a921ad728',NULL,NULL,'3e4973476a6e4351a925503a921ad728','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','3e4973476a6e4351a925503a921ad728','immediate',0,NULL,'dd53ebc4baee47bf8b130a5daed5b3e5','65947ffd4e364921a42c465d94a78c09',1459816168405,'99ec6323827447ebb566a0adbdada197',0),('de98d50e2bb141aa907e8585b5529320',NULL,'<NULL>',NULL,'<NULL>','d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d',NULL,NULL,'d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d','a9f4b02397d24462a45d981ade0c339e','a9f4b02397d24462a45d981ade0c339e','d83a1feb851d4ede95786362de79547d','immediate',0,NULL,'de98d50e2bb141aa907e8585b5529320','65947ffd4e364921a42c465d94a78c09',1459816158460,NULL,0),('e036f92ff5e3412fa1604e2e1f6cf425','51f5a5e597fc4028824384b06614aba2','51f5a5e597fc4028824384b06614aba2',NULL,'<NULL>',NULL,'<NULL>','51f5a5e597fc4028824384b06614aba2',NULL,NULL,'51f5a5e597fc4028824384b06614aba2','cd1c789d1a2e480384662de8de917ed1','cd1c789d1a2e480384662de8de917ed1','51f5a5e597fc4028824384b06614aba2','immediate',0,NULL,'e036f92ff5e3412fa1604e2e1f6cf425','65947ffd4e364921a42c465d94a78c09',1459816165937,'2addfdcfc0b843ab9bf3fa03fe141cc7',0),('e092bd0fef844bd3bace87613f24cc67',NULL,'<NULL>',NULL,'<NULL>','094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f',NULL,NULL,'094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','094308af1376466687416c49f1f6495f','immediate',0,NULL,'e092bd0fef844bd3bace87613f24cc67','65947ffd4e364921a42c465d94a78c09',1459816165614,'b62e1c7566d14267a62216d2aed227b6',0),('e35f77bea6ed4096b7694e63202ada32','05ed0d9e4c5e4024a75c08aa08717579','05ed0d9e4c5e4024a75c08aa08717579',NULL,'<NULL>',NULL,'<NULL>','05ed0d9e4c5e4024a75c08aa08717579',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579','30d6952ca2314c5c8297c5560f24940f','30d6952ca2314c5c8297c5560f24940f','05ed0d9e4c5e4024a75c08aa08717579','immediate',0,NULL,'e35f77bea6ed4096b7694e63202ada32','65947ffd4e364921a42c465d94a78c09',1459816164321,'35b82a4a0f7146248919176310137474',0),('e3a9ba677b8c44ffb299c1f9f97d5bbe',NULL,'<NULL>',NULL,'<NULL>','44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1',NULL,NULL,'44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1','a0f3df3f3afe4e28914131d26c413757','a0f3df3f3afe4e28914131d26c413757','44824fdcdd0e435ab9eafc2a40e430c1','immediate',0,NULL,'e3a9ba677b8c44ffb299c1f9f97d5bbe','65947ffd4e364921a42c465d94a78c09',1459816160937,'4f6e7d1adb7648b1a98d6a407eafb323',0),('e5b2d35695c24b9ebb6ba751aef33717','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'e5b2d35695c24b9ebb6ba751aef33717','65947ffd4e364921a42c465d94a78c09',1459816164109,'0865979fcb75478ea9394435359e8b9a',0),('e7c2526e00d54919a1145c36682d530d','a9cce636abf44507876f639467f74174','a9cce636abf44507876f639467f74174',NULL,'<NULL>',NULL,'<NULL>','a9cce636abf44507876f639467f74174',NULL,NULL,'a9cce636abf44507876f639467f74174','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','a9cce636abf44507876f639467f74174','immediate',0,NULL,'e7c2526e00d54919a1145c36682d530d','65947ffd4e364921a42c465d94a78c09',1459816167365,'a194a2a1e2ad45e7b81b45c4f987e830',0),('ea3a06edf3d442cbb8cd315405151a53',NULL,'<NULL>',NULL,'<NULL>','d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d',NULL,NULL,'d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','d83a1feb851d4ede95786362de79547d','immediate',0,NULL,'ea3a06edf3d442cbb8cd315405151a53','65947ffd4e364921a42c465d94a78c09',1459816158474,NULL,0),('ec9874a5d1674930a6f48e8fc282b088','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','3d4dfe7f92184f03801ba09f35992de3','3d4dfe7f92184f03801ba09f35992de3','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'ec9874a5d1674930a6f48e8fc282b088','65947ffd4e364921a42c465d94a78c09',1459816164093,'0865979fcb75478ea9394435359e8b9a',0),('ee35cad1b6a94be982bae96cab0aaac0','1f60e0aa563e441e86b646c79c66b6ff','1f60e0aa563e441e86b646c79c66b6ff',NULL,'<NULL>',NULL,'<NULL>','1f60e0aa563e441e86b646c79c66b6ff',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff','6f085ccfe46845c4b98d83edc6e7da49','6f085ccfe46845c4b98d83edc6e7da49','1f60e0aa563e441e86b646c79c66b6ff','immediate',0,NULL,'ee35cad1b6a94be982bae96cab0aaac0','65947ffd4e364921a42c465d94a78c09',1459816161400,'73cbab28d09f47459ae272f0fc2a3479',0),('eee962e9eab7440a9ad80b182c27f2be','c3540f2df6964cb9bbc9b974cf445d84','c3540f2df6964cb9bbc9b974cf445d84',NULL,'<NULL>',NULL,'<NULL>','c3540f2df6964cb9bbc9b974cf445d84',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','c3540f2df6964cb9bbc9b974cf445d84','immediate',0,NULL,'eee962e9eab7440a9ad80b182c27f2be','65947ffd4e364921a42c465d94a78c09',1459816161679,'8159789da0a14cafbd09145afa025cd8',0),('f284134cbe3e4788bca5b8f9f165617a',NULL,'<NULL>',NULL,'<NULL>','d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,'d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','d5248b39d72f4fdcb730d1be03de4fbc','immediate',0,NULL,'f284134cbe3e4788bca5b8f9f165617a','65947ffd4e364921a42c465d94a78c09',1459816161271,'d6b66eb39f3645a3a2703500fecb4a59',0),('f5822f5473c5419ab1dba778b2f80c10',NULL,'<NULL>',NULL,'<NULL>','44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1',NULL,NULL,'44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1','984bf86f08fc4d7f9b045f1b74f6f0cf','984bf86f08fc4d7f9b045f1b74f6f0cf','44824fdcdd0e435ab9eafc2a40e430c1','immediate',0,NULL,'f5822f5473c5419ab1dba778b2f80c10','65947ffd4e364921a42c465d94a78c09',1459816160954,'4f6e7d1adb7648b1a98d6a407eafb323',0),('f66192ef893049898c4e445ee046cf82','c4777fa00d2e4f7aabc2184cf6023770','c4777fa00d2e4f7aabc2184cf6023770',NULL,'<NULL>',NULL,'<NULL>','c4777fa00d2e4f7aabc2184cf6023770',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770','c4305e9f9a134e1998cf093f568003ed','c4305e9f9a134e1998cf093f568003ed','c4777fa00d2e4f7aabc2184cf6023770','immediate',0,NULL,'f66192ef893049898c4e445ee046cf82','65947ffd4e364921a42c465d94a78c09',1459816164079,'0865979fcb75478ea9394435359e8b9a',0),('f98cf0d9ab82471586ce4f086d1ac584','da7ae804604741feb591dd47b6f352be','da7ae804604741feb591dd47b6f352be',NULL,'<NULL>',NULL,'<NULL>','da7ae804604741feb591dd47b6f352be',NULL,NULL,'da7ae804604741feb591dd47b6f352be','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','da7ae804604741feb591dd47b6f352be','immediate',0,NULL,'f98cf0d9ab82471586ce4f086d1ac584','65947ffd4e364921a42c465d94a78c09',1459816162348,'98ba1ea840d5404299ad811e5e2f1da2',0),('fdc3368389344d02a0f5d03f25b4057e','2a9bd9fd21e34e56aca2c3f93bb68928','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'<NULL>',NULL,'<NULL>','2a9bd9fd21e34e56aca2c3f93bb68928',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928','4e9bb975b2cf43e79651b1e519070b2c','4e9bb975b2cf43e79651b1e519070b2c','2a9bd9fd21e34e56aca2c3f93bb68928','immediate',0,NULL,'fdc3368389344d02a0f5d03f25b4057e','65947ffd4e364921a42c465d94a78c09',1459816163941,'4804a077ec2c43899a5d981c4d45375f',0),('fdd94863198144f6b08fe3bd4cc1dc92',NULL,'<NULL>',NULL,'<NULL>','44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1',NULL,NULL,'44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1','11552e71132c4bd8a199d9d7418cbc97','11552e71132c4bd8a199d9d7418cbc97','44824fdcdd0e435ab9eafc2a40e430c1','immediate',0,NULL,'fdd94863198144f6b08fe3bd4cc1dc92','65947ffd4e364921a42c465d94a78c09',1459816160948,'4f6e7d1adb7648b1a98d6a407eafb323',0),('ff2c4c2169ec4d3fb48f268edbc4a222','af747ed516a548a6b22ca4020b5a67a0','af747ed516a548a6b22ca4020b5a67a0',NULL,'<NULL>',NULL,'<NULL>','af747ed516a548a6b22ca4020b5a67a0',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0','7bda5202f90744f7b121c9eb0240e576','7bda5202f90744f7b121c9eb0240e576','af747ed516a548a6b22ca4020b5a67a0','immediate',0,NULL,'ff2c4c2169ec4d3fb48f268edbc4a222','65947ffd4e364921a42c465d94a78c09',1459816167583,'9020c22117504dceb753bc010b2d0088',0);
/*!40000 ALTER TABLE `grouper_group_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_groups`
--

DROP TABLE IF EXISTS `grouper_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_groups` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_stem` varchar(40) COLLATE utf8_bin NOT NULL,
  `creator_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `modifier_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `modify_time` bigint(20) DEFAULT NULL,
  `last_membership_change` bigint(20) DEFAULT NULL,
  `last_imm_membership_change` bigint(20) DEFAULT NULL,
  `alternate_name` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `name` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `display_name` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `display_extension` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `type_of_group` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT 'group',
  `id_index` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id_index_idx` (`id_index`),
  UNIQUE KEY `group_parent_idx` (`parent_stem`,`extension`),
  UNIQUE KEY `group_name_idx` (`name`(255)),
  KEY `group_last_membership_idx` (`last_membership_change`),
  KEY `group_last_imm_membership_idx` (`last_imm_membership_change`),
  KEY `group_creator_idx` (`creator_id`),
  KEY `group_createtime_idx` (`create_time`),
  KEY `group_modifier_idx` (`modifier_id`),
  KEY `group_modifytime_idx` (`modify_time`),
  KEY `group_context_idx` (`context_id`),
  KEY `group_type_of_group_idx` (`type_of_group`),
  KEY `group_alternate_name_idx` (`alternate_name`(255)),
  KEY `group_parent_display_idx` (`parent_stem`,`display_extension`),
  KEY `group_display_name_idx` (`display_name`(255)),
  CONSTRAINT `fk_groups_creator_id` FOREIGN KEY (`creator_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_groups_modifier_id` FOREIGN KEY (`modifier_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_groups_parent_stem` FOREIGN KEY (`parent_stem`) REFERENCES `grouper_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_groups`
--

LOCK TABLES `grouper_groups` WRITE;
/*!40000 ALTER TABLE `grouper_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_groups_v`
--

DROP TABLE IF EXISTS `grouper_groups_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_groups_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_groups_v` (
  `EXTENSION` tinyint NOT NULL,
  `NAME` tinyint NOT NULL,
  `DISPLAY_EXTENSION` tinyint NOT NULL,
  `DISPLAY_NAME` tinyint NOT NULL,
  `DESCRIPTION` tinyint NOT NULL,
  `PARENT_STEM_NAME` tinyint NOT NULL,
  `TYPE_OF_GROUP` tinyint NOT NULL,
  `GROUP_ID` tinyint NOT NULL,
  `PARENT_STEM_ID` tinyint NOT NULL,
  `MODIFIER_SOURCE` tinyint NOT NULL,
  `MODIFIER_SUBJECT_ID` tinyint NOT NULL,
  `CREATOR_SOURCE` tinyint NOT NULL,
  `CREATOR_SUBJECT_ID` tinyint NOT NULL,
  `IS_COMPOSITE_OWNER` tinyint NOT NULL,
  `IS_COMPOSITE_FACTOR` tinyint NOT NULL,
  `CREATOR_ID` tinyint NOT NULL,
  `CREATE_TIME` tinyint NOT NULL,
  `MODIFIER_ID` tinyint NOT NULL,
  `MODIFY_TIME` tinyint NOT NULL,
  `HIBERNATE_VERSION_NUMBER` tinyint NOT NULL,
  `CONTEXT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_loader_log`
--

DROP TABLE IF EXISTS `grouper_loader_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_loader_log` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `job_name` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `started_time` datetime DEFAULT NULL,
  `ended_time` datetime DEFAULT NULL,
  `millis` int(11) DEFAULT NULL,
  `millis_get_data` int(11) DEFAULT NULL,
  `millis_load_data` int(11) DEFAULT NULL,
  `job_type` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `job_schedule_type` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `job_description` text COLLATE utf8_bin,
  `job_message` text COLLATE utf8_bin,
  `host` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `group_uuid` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `job_schedule_quartz_cron` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `job_schedule_interval_seconds` int(11) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `unresolvable_subject_count` int(11) DEFAULT NULL,
  `insert_count` int(11) DEFAULT NULL,
  `update_count` int(11) DEFAULT NULL,
  `delete_count` int(11) DEFAULT NULL,
  `total_count` int(11) DEFAULT NULL,
  `parent_job_name` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `parent_job_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `and_group_names` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `job_schedule_priority` int(11) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loader_context_idx` (`context_id`),
  KEY `grouper_loader_job_name_idx` (`job_name`(255),`status`,`ended_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_loader_log`
--

LOCK TABLES `grouper_loader_log` WRITE;
/*!40000 ALTER TABLE `grouper_loader_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_loader_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_members`
--

DROP TABLE IF EXISTS `grouper_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_members` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `subject_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `subject_source` varchar(255) COLLATE utf8_bin NOT NULL,
  `subject_type` varchar(255) COLLATE utf8_bin NOT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `sort_string0` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `sort_string1` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `sort_string2` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `sort_string3` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `sort_string4` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `search_string0` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `search_string1` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `search_string2` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `search_string3` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `search_string4` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(2048) COLLATE utf8_bin DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `member_subjectsourcetype_idx` (`subject_id`,`subject_source`,`subject_type`),
  KEY `member_subjectsource_idx` (`subject_source`),
  KEY `member_subjectid_idx` (`subject_id`),
  KEY `member_subjecttype_idx` (`subject_type`),
  KEY `member_sort_string0_idx` (`sort_string0`),
  KEY `member_sort_string1_idx` (`sort_string1`),
  KEY `member_sort_string2_idx` (`sort_string2`),
  KEY `member_sort_string3_idx` (`sort_string3`),
  KEY `member_sort_string4_idx` (`sort_string4`),
  KEY `member_context_idx` (`context_id`),
  KEY `member_name_idx` (`name`(255)),
  KEY `member_description_idx` (`description`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_members`
--

LOCK TABLES `grouper_members` WRITE;
/*!40000 ALTER TABLE `grouper_members` DISABLE KEYS */;
INSERT INTO `grouper_members` VALUES ('65947ffd4e364921a42c465d94a78c09','GrouperSystem','g:isa','application',0,'GrouperSysAdmin',NULL,NULL,NULL,NULL,'groupersysadmin,groupersystem',NULL,NULL,NULL,NULL,'GrouperSysAdmin','GrouperSysAdmin',NULL),('dd763c74578f453caaac27517173178f','GrouperAll','g:isa','application',0,'EveryEntity',NULL,NULL,NULL,NULL,'everyentity,grouperall',NULL,NULL,NULL,NULL,'EveryEntity','EveryEntity',NULL);
/*!40000 ALTER TABLE `grouper_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_memberships`
--

DROP TABLE IF EXISTS `grouper_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_memberships` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `field_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_attr_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `via_composite_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `enabled` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'T',
  `enabled_timestamp` bigint(20) DEFAULT NULL,
  `disabled_timestamp` bigint(20) DEFAULT NULL,
  `mship_type` varchar(32) COLLATE utf8_bin NOT NULL,
  `creator_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `create_time` bigint(20) NOT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `membership_uniq_idx` (`owner_id`,`member_id`,`field_id`),
  KEY `membership_owner_group_idx` (`owner_group_id`),
  KEY `membership_owner_stem_idx` (`owner_stem_id`),
  KEY `membership_owner_attr_idx` (`owner_attr_def_id`),
  KEY `membership_via_composite_idx` (`via_composite_id`),
  KEY `membership_member_cvia_idx` (`member_id`,`via_composite_id`),
  KEY `membership_gowner_member_idx` (`owner_group_id`,`member_id`,`field_id`),
  KEY `membership_sowner_member_idx` (`owner_stem_id`,`member_id`,`field_id`),
  KEY `membership_aowner_member_idx` (`owner_attr_def_id`,`member_id`,`field_id`),
  KEY `membership_enabled_idx` (`enabled`),
  KEY `membership_enabled_time_idx` (`enabled_timestamp`),
  KEY `membership_disabled_time_idx` (`disabled_timestamp`),
  KEY `membership_createtime_idx` (`create_time`),
  KEY `membership_creator_idx` (`creator_id`),
  KEY `membership_member_idx` (`member_id`),
  KEY `membership_member_list_idx` (`member_id`,`field_id`),
  KEY `membership_gowner_field_type_idx` (`owner_group_id`,`field_id`,`mship_type`),
  KEY `membership_sowner_field_type_idx` (`owner_stem_id`,`field_id`,`mship_type`),
  KEY `membership_type_idx` (`mship_type`),
  KEY `membership_context_idx` (`context_id`),
  KEY `groupmem_ownid_fieldid_idx` (`owner_id`,`field_id`),
  KEY `fk_membership_field_id` (`field_id`),
  CONSTRAINT `fk_membership_field_id` FOREIGN KEY (`field_id`) REFERENCES `grouper_fields` (`id`),
  CONSTRAINT `fk_memberships_comp_via_id` FOREIGN KEY (`via_composite_id`) REFERENCES `grouper_composites` (`id`),
  CONSTRAINT `fk_memberships_creator_id` FOREIGN KEY (`creator_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_memberships_group_owner_id` FOREIGN KEY (`owner_group_id`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_memberships_member_id` FOREIGN KEY (`member_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_memberships_stem_owner_id` FOREIGN KEY (`owner_stem_id`) REFERENCES `grouper_stems` (`id`),
  CONSTRAINT `fk_mship_attr_def_owner_id` FOREIGN KEY (`owner_attr_def_id`) REFERENCES `grouper_attribute_def` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_memberships`
--

LOCK TABLES `grouper_memberships` WRITE;
/*!40000 ALTER TABLE `grouper_memberships` DISABLE KEYS */;
INSERT INTO `grouper_memberships` VALUES ('0183ae81a9804e2ba7bd269344ceb9eb','65947ffd4e364921a42c465d94a78c09','c4777fa00d2e4f7aabc2184cf6023770','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164115,0,'0865979fcb75478ea9394435359e8b9a'),('0d63372c449c42259c2e345aa87e8d28','65947ffd4e364921a42c465d94a78c09','1730a44d087442cc96c2d8d63b655716','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'1730a44d087442cc96c2d8d63b655716',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816161200,0,'e4639a3fb91d43a49bf595de9c390d53'),('0ef478543f2a4735bf94ad80cdfa247d','dd763c74578f453caaac27517173178f','98e846065291427bb67c498d8e70d8ec','4e9bb975b2cf43e79651b1e519070b2c',NULL,NULL,'98e846065291427bb67c498d8e70d8ec',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816168171,0,NULL),('109f0358574544ee8f167a6dff1534c8','dd763c74578f453caaac27517173178f','dd528f792dd544938a2588848992e909','6f085ccfe46845c4b98d83edc6e7da49',NULL,NULL,'dd528f792dd544938a2588848992e909',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816163792,0,NULL),('1143dd90311d452bb41bd9885f7188c6','65947ffd4e364921a42c465d94a78c09','d5248b39d72f4fdcb730d1be03de4fbc','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'d5248b39d72f4fdcb730d1be03de4fbc',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816161293,0,'d6b66eb39f3645a3a2703500fecb4a59'),('1c187c48c9be45e884be9c19e9a87f29','65947ffd4e364921a42c465d94a78c09','c3540f2df6964cb9bbc9b974cf445d84','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'c3540f2df6964cb9bbc9b974cf445d84',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816161742,0,'8159789da0a14cafbd09145afa025cd8'),('2f7e066ed0384c18b85bc96acdc3c598','dd763c74578f453caaac27517173178f','c4777fa00d2e4f7aabc2184cf6023770','6f085ccfe46845c4b98d83edc6e7da49',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164146,0,NULL),('3b3a36463c06409eb6098006c0846044','65947ffd4e364921a42c465d94a78c09','da7ae804604741feb591dd47b6f352be','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'da7ae804604741feb591dd47b6f352be',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816162371,0,'98ba1ea840d5404299ad811e5e2f1da2'),('40724d2570b24e22b72383132addeb4a','dd763c74578f453caaac27517173178f','dd528f792dd544938a2588848992e909','4e9bb975b2cf43e79651b1e519070b2c',NULL,NULL,'dd528f792dd544938a2588848992e909',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816163774,0,NULL),('4e8d1000f8a445c4bf1226d0c1f8d46d','65947ffd4e364921a42c465d94a78c09','36792aa7956240feb1bb6025c56ff2f3','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'36792aa7956240feb1bb6025c56ff2f3',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816161078,0,'0564466782fa4b5fbe17c5861dbd2f23'),('6151aaab62814bfbb8ca9744a95a7428','65947ffd4e364921a42c465d94a78c09','51f5a5e597fc4028824384b06614aba2','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'51f5a5e597fc4028824384b06614aba2',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816165980,0,'2addfdcfc0b843ab9bf3fa03fe141cc7'),('67cf38884b204905ab933c08c230a1f3','65947ffd4e364921a42c465d94a78c09','98e846065291427bb67c498d8e70d8ec','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'98e846065291427bb67c498d8e70d8ec',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816168140,0,'d3070a409e5149a0b7bfeb8222f313ab'),('6d0a0572f1ce4db996e6fea57f2f4f4b','65947ffd4e364921a42c465d94a78c09','3e4973476a6e4351a925503a921ad728','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'3e4973476a6e4351a925503a921ad728',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816168423,0,'99ec6323827447ebb566a0adbdada197'),('70f397c88e7846aa89ee718e7f3568e8','65947ffd4e364921a42c465d94a78c09','cb1bfad6c8ed424d902b65d9ec275df0','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'cb1bfad6c8ed424d902b65d9ec275df0',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816167319,0,'9484aa1ec9af4b48b7e2db04840dd01e'),('8682332826634b61a40a70e810eed95e','65947ffd4e364921a42c465d94a78c09','b6bc2fcd772146ee970347e496538926','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'b6bc2fcd772146ee970347e496538926',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816163669,0,'7b21a0f6bac34729967562807de21d63'),('8c5ea395c4544f77b2f9e771b36e4f14','65947ffd4e364921a42c465d94a78c09','6cd4d8196fe24d21acd51cdf8fcdb3cc','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'6cd4d8196fe24d21acd51cdf8fcdb3cc',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164223,0,'2768fb08bd7c4eff90209d082ab4ff73'),('8d3df0547e994247879b71015bd78ca2','65947ffd4e364921a42c465d94a78c09','2a9bd9fd21e34e56aca2c3f93bb68928','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816163972,0,'4804a077ec2c43899a5d981c4d45375f'),('907dd06185a744da9854e1f17bbf5e46','65947ffd4e364921a42c465d94a78c09','2eee186e51494f0a874fe61ff24b7192','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'2eee186e51494f0a874fe61ff24b7192',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816168098,0,'129701637b9d4e1f9b0222cd9069d8d3'),('9577683b84054c3298fc0c1dcbed48fb','65947ffd4e364921a42c465d94a78c09','19faf0fca06b4aeb8a5cce52382a3f0e','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'19faf0fca06b4aeb8a5cce52382a3f0e',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816165880,0,'00618952cb8b4705b94cd916a6713a4e'),('9cf767efae1a40fbb83795fe2fb844e4','65947ffd4e364921a42c465d94a78c09','a9cce636abf44507876f639467f74174','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'a9cce636abf44507876f639467f74174',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816167405,0,'a194a2a1e2ad45e7b81b45c4f987e830'),('9de77a6bd3fc4df5af7af8fd8515915b','65947ffd4e364921a42c465d94a78c09','fc88a71ee4574ae7b0a550d72b5172d9','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'fc88a71ee4574ae7b0a550d72b5172d9',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816162289,0,'10e41282ff0b4434b2111890260d81e6'),('9e1fcd948b554547b466b0e41bacc012','65947ffd4e364921a42c465d94a78c09','af747ed516a548a6b22ca4020b5a67a0','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'af747ed516a548a6b22ca4020b5a67a0',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816167609,0,'9020c22117504dceb753bc010b2d0088'),('a017066ca9f34367a059896d7fcc9576','65947ffd4e364921a42c465d94a78c09','35ee03902f9049fea8520a4c47e57b54','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'35ee03902f9049fea8520a4c47e57b54',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816168613,0,'cc9ba9ab69e64d0c9c9ba96f0f506ce4'),('a05e9947e20e4f47a35e4a5f49271023','65947ffd4e364921a42c465d94a78c09','dd528f792dd544938a2588848992e909','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'dd528f792dd544938a2588848992e909',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816163748,0,'7bbeeff369ab4699bcbaf02e3beb0cd6'),('a6d997af2ca74e08bbeca5024d632129','65947ffd4e364921a42c465d94a78c09','05ed0d9e4c5e4024a75c08aa08717579','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'05ed0d9e4c5e4024a75c08aa08717579',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164340,0,'35b82a4a0f7146248919176310137474'),('a9e3b63922b94cb585c1638755168bbb','65947ffd4e364921a42c465d94a78c09','44824fdcdd0e435ab9eafc2a40e430c1','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'44824fdcdd0e435ab9eafc2a40e430c1',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816160982,0,'4f6e7d1adb7648b1a98d6a407eafb323'),('adabd5c25ccc45fa8115e808bc44a0ef','65947ffd4e364921a42c465d94a78c09','094308af1376466687416c49f1f6495f','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'094308af1376466687416c49f1f6495f',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816165644,0,'b62e1c7566d14267a62216d2aed227b6'),('b2c3650f51db4669adc839b366a1fe2f','65947ffd4e364921a42c465d94a78c09','240c728c9e2c42ccb4bd63fae71d8b28','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'240c728c9e2c42ccb4bd63fae71d8b28',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164277,0,'2d05ad7ebd794bb79815228acd5fed54'),('cc2794fc2094406b8ea78833a4daa2b1','65947ffd4e364921a42c465d94a78c09','47bf48f95b9a4c67855b091e3d1003de','984bf86f08fc4d7f9b045f1b74f6f0cf',NULL,'47bf48f95b9a4c67855b091e3d1003de',NULL,NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816160659,0,'ea8757bd8a5e4fcb8d05e62bd36a6da4'),('d4103d3531a849eeae7b0d96806246e6','dd763c74578f453caaac27517173178f','2a9bd9fd21e34e56aca2c3f93bb68928','4e9bb975b2cf43e79651b1e519070b2c',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164001,0,NULL),('d80f5b2c22e447d3a0c035a391b59aef','dd763c74578f453caaac27517173178f','2a9bd9fd21e34e56aca2c3f93bb68928','6f085ccfe46845c4b98d83edc6e7da49',NULL,NULL,'2a9bd9fd21e34e56aca2c3f93bb68928',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164021,0,NULL),('d8809bfac4ba4706849a3d3562d4228c','dd763c74578f453caaac27517173178f','98e846065291427bb67c498d8e70d8ec','6f085ccfe46845c4b98d83edc6e7da49',NULL,NULL,'98e846065291427bb67c498d8e70d8ec',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816168183,0,NULL),('e78d095e4b4b4643a7bb5fe6bbf89134','65947ffd4e364921a42c465d94a78c09','b92c64af9edd4b7493d8c4b2a936cbd8','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'b92c64af9edd4b7493d8c4b2a936cbd8',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816162517,0,'b9307b3c26ab440d91b270b950336d12'),('ed287e4ba015469f8f1a8babc2a896b0','dd763c74578f453caaac27517173178f','c4777fa00d2e4f7aabc2184cf6023770','4e9bb975b2cf43e79651b1e519070b2c',NULL,NULL,'c4777fa00d2e4f7aabc2184cf6023770',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816164138,0,NULL),('f2b8fc4b482f4cfb983fb2e2d693b177','65947ffd4e364921a42c465d94a78c09','1f60e0aa563e441e86b646c79c66b6ff','cd1c789d1a2e480384662de8de917ed1',NULL,NULL,'1f60e0aa563e441e86b646c79c66b6ff',NULL,'T',NULL,NULL,'immediate','65947ffd4e364921a42c465d94a78c09',1459816161471,0,'73cbab28d09f47459ae272f0fc2a3479');
/*!40000 ALTER TABLE `grouper_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_memberships_all_v`
--

DROP TABLE IF EXISTS `grouper_memberships_all_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_memberships_all_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_memberships_all_v` (
  `MEMBERSHIP_ID` tinyint NOT NULL,
  `IMMEDIATE_MEMBERSHIP_ID` tinyint NOT NULL,
  `GROUP_SET_ID` tinyint NOT NULL,
  `MEMBER_ID` tinyint NOT NULL,
  `FIELD_ID` tinyint NOT NULL,
  `IMMEDIATE_FIELD_ID` tinyint NOT NULL,
  `OWNER_ID` tinyint NOT NULL,
  `OWNER_ATTR_DEF_ID` tinyint NOT NULL,
  `OWNER_GROUP_ID` tinyint NOT NULL,
  `OWNER_STEM_ID` tinyint NOT NULL,
  `VIA_GROUP_ID` tinyint NOT NULL,
  `VIA_COMPOSITE_ID` tinyint NOT NULL,
  `DEPTH` tinyint NOT NULL,
  `MSHIP_TYPE` tinyint NOT NULL,
  `IMMEDIATE_MSHIP_ENABLED` tinyint NOT NULL,
  `IMMEDIATE_MSHIP_ENABLED_TIME` tinyint NOT NULL,
  `IMMEDIATE_MSHIP_DISABLED_TIME` tinyint NOT NULL,
  `GROUP_SET_PARENT_ID` tinyint NOT NULL,
  `MEMBERSHIP_CREATOR_ID` tinyint NOT NULL,
  `MEMBERSHIP_CREATE_TIME` tinyint NOT NULL,
  `GROUP_SET_CREATOR_ID` tinyint NOT NULL,
  `GROUP_SET_CREATE_TIME` tinyint NOT NULL,
  `HIBERNATE_VERSION_NUMBER` tinyint NOT NULL,
  `CONTEXT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_memberships_lw_v`
--

DROP TABLE IF EXISTS `grouper_memberships_lw_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_memberships_lw_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_memberships_lw_v` (
  `SUBJECT_ID` tinyint NOT NULL,
  `SUBJECT_SOURCE` tinyint NOT NULL,
  `GROUP_NAME` tinyint NOT NULL,
  `LIST_NAME` tinyint NOT NULL,
  `LIST_TYPE` tinyint NOT NULL,
  `GROUP_ID` tinyint NOT NULL,
  `MEMBER_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_memberships_v`
--

DROP TABLE IF EXISTS `grouper_memberships_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_memberships_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_memberships_v` (
  `GROUP_NAME` tinyint NOT NULL,
  `GROUP_DISPLAYNAME` tinyint NOT NULL,
  `STEM_NAME` tinyint NOT NULL,
  `STEM_DISPLAYNAME` tinyint NOT NULL,
  `SUBJECT_ID` tinyint NOT NULL,
  `SUBJECT_SOURCE` tinyint NOT NULL,
  `MEMBER_ID` tinyint NOT NULL,
  `LIST_TYPE` tinyint NOT NULL,
  `LIST_NAME` tinyint NOT NULL,
  `MEMBERSHIP_TYPE` tinyint NOT NULL,
  `COMPOSITE_PARENT_GROUP_NAME` tinyint NOT NULL,
  `DEPTH` tinyint NOT NULL,
  `CREATOR_SOURCE` tinyint NOT NULL,
  `CREATOR_SUBJECT_ID` tinyint NOT NULL,
  `MEMBERSHIP_ID` tinyint NOT NULL,
  `IMMEDIATE_MEMBERSHIP_ID` tinyint NOT NULL,
  `GROUP_SET_ID` tinyint NOT NULL,
  `STEM_ID` tinyint NOT NULL,
  `GROUP_ID` tinyint NOT NULL,
  `CREATE_TIME` tinyint NOT NULL,
  `CREATOR_ID` tinyint NOT NULL,
  `FIELD_ID` tinyint NOT NULL,
  `CONTEXT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_mship_attrdef_lw_v`
--

DROP TABLE IF EXISTS `grouper_mship_attrdef_lw_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_mship_attrdef_lw_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_mship_attrdef_lw_v` (
  `SUBJECT_ID` tinyint NOT NULL,
  `SUBJECT_SOURCE` tinyint NOT NULL,
  `ATTRIBUTE_DEF_NAME` tinyint NOT NULL,
  `LIST_NAME` tinyint NOT NULL,
  `LIST_TYPE` tinyint NOT NULL,
  `ATTRIBUTE_DEF_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_mship_stem_lw_v`
--

DROP TABLE IF EXISTS `grouper_mship_stem_lw_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_mship_stem_lw_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_mship_stem_lw_v` (
  `SUBJECT_ID` tinyint NOT NULL,
  `SUBJECT_SOURCE` tinyint NOT NULL,
  `STEM_NAME` tinyint NOT NULL,
  `LIST_NAME` tinyint NOT NULL,
  `LIST_TYPE` tinyint NOT NULL,
  `STEM_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_perms_all_v`
--

DROP TABLE IF EXISTS `grouper_perms_all_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_all_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_perms_all_v` (
  `role_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `role_display_name` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `membership_depth` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL,
  `assignment_notes` tinyint NOT NULL,
  `immediate_mship_enabled_time` tinyint NOT NULL,
  `immediate_mship_disabled_time` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_perms_assigned_role_v`
--

DROP TABLE IF EXISTS `grouper_perms_assigned_role_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_assigned_role_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_perms_assigned_role_v` (
  `role_name` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `role_display_name` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `assignment_notes` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_perms_role_subject_v`
--

DROP TABLE IF EXISTS `grouper_perms_role_subject_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_role_subject_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_perms_role_subject_v` (
  `role_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `role_display_name` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `membership_depth` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL,
  `assignment_notes` tinyint NOT NULL,
  `immediate_mship_enabled_time` tinyint NOT NULL,
  `immediate_mship_disabled_time` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_perms_role_v`
--

DROP TABLE IF EXISTS `grouper_perms_role_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_role_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_perms_role_v` (
  `role_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `attribute_def_name_disp_name` tinyint NOT NULL,
  `role_display_name` tinyint NOT NULL,
  `attribute_assign_delegatable` tinyint NOT NULL,
  `enabled` tinyint NOT NULL,
  `enabled_time` tinyint NOT NULL,
  `disabled_time` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `membership_depth` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL,
  `assignment_notes` tinyint NOT NULL,
  `immediate_mship_enabled_time` tinyint NOT NULL,
  `immediate_mship_disabled_time` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_pit_attr_asn_value_v`
--

DROP TABLE IF EXISTS `grouper_pit_attr_asn_value_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_attr_asn_value_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_pit_attr_asn_value_v` (
  `attribute_assign_value_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `attribute_assign_action_id` tinyint NOT NULL,
  `attribute_assign_type` tinyint NOT NULL,
  `owner_attribute_assign_id` tinyint NOT NULL,
  `owner_attribute_def_id` tinyint NOT NULL,
  `owner_group_id` tinyint NOT NULL,
  `owner_member_id` tinyint NOT NULL,
  `owner_membership_id` tinyint NOT NULL,
  `owner_stem_id` tinyint NOT NULL,
  `value_integer` tinyint NOT NULL,
  `value_floating` tinyint NOT NULL,
  `value_string` tinyint NOT NULL,
  `value_member_id` tinyint NOT NULL,
  `active` tinyint NOT NULL,
  `start_time` tinyint NOT NULL,
  `end_time` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_pit_attr_assn_actn`
--

DROP TABLE IF EXISTS `grouper_pit_attr_assn_actn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attr_assn_actn` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_def_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_attr_assn_act_start_idx` (`start_time`,`source_id`),
  KEY `pit_attr_asn_act_source_id_idx` (`source_id`),
  KEY `pit_attr_assn_act_def_id_idx` (`attribute_def_id`),
  KEY `pit_attr_assn_act_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_attr_assn_attr_def_id` FOREIGN KEY (`attribute_def_id`) REFERENCES `grouper_pit_attribute_def` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attr_assn_actn`
--

LOCK TABLES `grouper_pit_attr_assn_actn` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attr_assn_actn` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attr_assn_actn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_attr_assn_actn_set`
--

DROP TABLE IF EXISTS `grouper_pit_attr_assn_actn_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attr_assn_actn_set` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `depth` bigint(20) NOT NULL,
  `if_has_attr_assn_action_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_attr_assn_action_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_attr_assn_action_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_action_set_start_idx` (`start_time`,`source_id`),
  KEY `pit_action_set_source_id_idx` (`source_id`),
  KEY `pit_action_set_if_idx` (`if_has_attr_assn_action_id`),
  KEY `pit_action_set_then_idx` (`then_has_attr_assn_action_id`),
  KEY `pit_action_set_parent_idx` (`parent_attr_assn_action_id`),
  KEY `pit_action_set_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_attr_action_set_if` FOREIGN KEY (`if_has_attr_assn_action_id`) REFERENCES `grouper_pit_attr_assn_actn` (`id`),
  CONSTRAINT `fk_pit_attr_action_set_parent` FOREIGN KEY (`parent_attr_assn_action_id`) REFERENCES `grouper_pit_attr_assn_actn_set` (`id`),
  CONSTRAINT `fk_pit_attr_action_set_then` FOREIGN KEY (`then_has_attr_assn_action_id`) REFERENCES `grouper_pit_attr_assn_actn` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attr_assn_actn_set`
--

LOCK TABLES `grouper_pit_attr_assn_actn_set` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attr_assn_actn_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attr_assn_actn_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_attr_assn_value`
--

DROP TABLE IF EXISTS `grouper_pit_attr_assn_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attr_assn_value` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_assign_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `value_integer` bigint(20) DEFAULT NULL,
  `value_floating` double DEFAULT NULL,
  `value_string` text COLLATE utf8_bin,
  `value_member_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_attr_val_start_idx` (`start_time`,`source_id`),
  KEY `pit_attr_val_source_id_idx` (`source_id`),
  KEY `pit_attr_val_assign_idx` (`attribute_assign_id`),
  KEY `pit_attr_val_integer_idx` (`value_integer`),
  KEY `pit_attr_val_floating_idx` (`value_floating`),
  KEY `pit_attr_val_member_id_idx` (`value_member_id`),
  KEY `pit_attr_val_end_idx` (`end_time`),
  KEY `pit_attr_val_string_idx` (`value_string`(255)),
  CONSTRAINT `fk_pit_attr_assn_value_assn_id` FOREIGN KEY (`attribute_assign_id`) REFERENCES `grouper_pit_attribute_assign` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attr_assn_value`
--

LOCK TABLES `grouper_pit_attr_assn_value` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attr_assn_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attr_assn_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_attr_def_name`
--

DROP TABLE IF EXISTS `grouper_pit_attr_def_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attr_def_name` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_def_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_attr_def_name_start_idx` (`start_time`,`source_id`),
  KEY `pit_attrdef_name_srcid_idx` (`source_id`),
  KEY `pit_attr_def_name_stem_idx` (`stem_id`),
  KEY `pit_attr_def_name_def_idx` (`attribute_def_id`),
  KEY `pit_attr_def_name_end_idx` (`end_time`),
  KEY `pit_attr_def_name_name_idx` (`name`(255)),
  CONSTRAINT `fk_pit_attr_def_name_def_id` FOREIGN KEY (`attribute_def_id`) REFERENCES `grouper_pit_attribute_def` (`id`),
  CONSTRAINT `fk_pit_attr_def_name_stem` FOREIGN KEY (`stem_id`) REFERENCES `grouper_pit_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attr_def_name`
--

LOCK TABLES `grouper_pit_attr_def_name` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attr_def_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attr_def_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_attr_def_name_set`
--

DROP TABLE IF EXISTS `grouper_pit_attr_def_name_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attr_def_name_set` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `depth` bigint(20) NOT NULL,
  `if_has_attribute_def_name_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_attribute_def_name_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_attr_def_name_set_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_attr_def_name_set_strt_idx` (`start_time`,`source_id`),
  KEY `pit_attrdef_name_set_srcid_idx` (`source_id`),
  KEY `pit_attr_def_name_set_if_idx` (`if_has_attribute_def_name_id`),
  KEY `pit_attr_def_name_set_then_idx` (`then_has_attribute_def_name_id`),
  KEY `pit_attr_def_name_set_prnt_idx` (`parent_attr_def_name_set_id`),
  KEY `pit_attr_def_name_set_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_attr_def_name_if` FOREIGN KEY (`if_has_attribute_def_name_id`) REFERENCES `grouper_pit_attr_def_name` (`id`),
  CONSTRAINT `fk_pit_attr_def_name_set_parnt` FOREIGN KEY (`parent_attr_def_name_set_id`) REFERENCES `grouper_pit_attr_def_name_set` (`id`),
  CONSTRAINT `fk_pit_attr_def_name_then` FOREIGN KEY (`then_has_attribute_def_name_id`) REFERENCES `grouper_pit_attr_def_name` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attr_def_name_set`
--

LOCK TABLES `grouper_pit_attr_def_name_set` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attr_def_name_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attr_def_name_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_attribute_assign`
--

DROP TABLE IF EXISTS `grouper_pit_attribute_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attribute_assign` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_def_name_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_assign_action_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_assign_type` varchar(15) COLLATE utf8_bin NOT NULL,
  `owner_attribute_assign_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_attribute_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_member_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_membership_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `disallowed` varchar(1) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_attr_assn_start_idx` (`start_time`,`source_id`),
  KEY `pit_attr_assn_source_id_idx` (`source_id`),
  KEY `pit_attr_assn_action_idx` (`attribute_assign_action_id`),
  KEY `pit_attr_assn_type_idx` (`attribute_assign_type`),
  KEY `pit_attr_assn_def_name_idx` (`attribute_def_name_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_own_assn_idx` (`owner_attribute_assign_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_own_def_idx` (`owner_attribute_def_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_own_group_idx` (`owner_group_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_own_mem_idx` (`owner_member_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_own_mship_idx` (`owner_membership_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_own_stem_idx` (`owner_stem_id`,`attribute_assign_action_id`),
  KEY `pit_attr_assn_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_attr_assn_action_id` FOREIGN KEY (`attribute_assign_action_id`) REFERENCES `grouper_pit_attr_assn_actn` (`id`),
  CONSTRAINT `fk_pit_attr_assn_def_name_id` FOREIGN KEY (`attribute_def_name_id`) REFERENCES `grouper_pit_attr_def_name` (`id`),
  CONSTRAINT `fk_pit_attr_assn_owner_assn_id` FOREIGN KEY (`owner_attribute_assign_id`) REFERENCES `grouper_pit_attribute_assign` (`id`),
  CONSTRAINT `fk_pit_attr_assn_owner_def_id` FOREIGN KEY (`owner_attribute_def_id`) REFERENCES `grouper_pit_attribute_def` (`id`),
  CONSTRAINT `fk_pit_attr_assn_owner_grp_id` FOREIGN KEY (`owner_group_id`) REFERENCES `grouper_pit_groups` (`id`),
  CONSTRAINT `fk_pit_attr_assn_owner_mem_id` FOREIGN KEY (`owner_member_id`) REFERENCES `grouper_pit_members` (`id`),
  CONSTRAINT `fk_pit_attr_assn_owner_ms_id` FOREIGN KEY (`owner_membership_id`) REFERENCES `grouper_pit_memberships` (`id`),
  CONSTRAINT `fk_pit_attr_assn_owner_stem_id` FOREIGN KEY (`owner_stem_id`) REFERENCES `grouper_pit_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attribute_assign`
--

LOCK TABLES `grouper_pit_attribute_assign` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attribute_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attribute_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_attribute_def`
--

DROP TABLE IF EXISTS `grouper_pit_attribute_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_attribute_def` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `attribute_def_type` varchar(32) COLLATE utf8_bin NOT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_attribute_def_start_idx` (`start_time`,`source_id`),
  KEY `pit_attr_def_source_id_idx` (`source_id`),
  KEY `pit_attribute_def_parent_idx` (`stem_id`),
  KEY `pit_attribute_def_context_idx` (`context_id`),
  KEY `pit_attribute_def_type_idx` (`attribute_def_type`),
  KEY `pit_attribute_def_end_idx` (`end_time`),
  KEY `pit_attribute_def_name_idx` (`name`(255)),
  CONSTRAINT `fk_pit_attr_def_stem` FOREIGN KEY (`stem_id`) REFERENCES `grouper_pit_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_attribute_def`
--

LOCK TABLES `grouper_pit_attribute_def` WRITE;
/*!40000 ALTER TABLE `grouper_pit_attribute_def` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_attribute_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_fields`
--

DROP TABLE IF EXISTS `grouper_pit_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_fields` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(32) COLLATE utf8_bin NOT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_field_start_idx` (`start_time`,`source_id`),
  KEY `pit_field_source_id_idx` (`source_id`),
  KEY `pit_field_name_idx` (`name`),
  KEY `pit_field_context_idx` (`context_id`),
  KEY `pit_field_end_idx` (`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_fields`
--

LOCK TABLES `grouper_pit_fields` WRITE;
/*!40000 ALTER TABLE `grouper_pit_fields` DISABLE KEYS */;
INSERT INTO `grouper_pit_fields` VALUES ('1bc9f51971df4993a9dbc7e9dd33532c','7bda5202f90744f7b121c9eb0240e576','attrViewers','attributeDef','T',1459816158186000,NULL,'d5263d78c23b4eedbd036a2149205086',0),('2303b2f2444348e7966ce348eb658c62','fc3d2f92c17b4510a9864f89fd1f04c4','groupAttrReaders','access','T',1459816158030000,NULL,'b869aa8f5bcb49d9b3991d8916683875',0),('25486b856716415fbaab8e2d5b421c22','c4305e9f9a134e1998cf093f568003ed','attrDefAttrReaders','attributeDef','T',1459816158207000,NULL,'4476edf35ff543c1abdac2c03d68e986',0),('409cd73ec1b14562bf3ce3f587ab3d5e','984bf86f08fc4d7f9b045f1b74f6f0cf','stemmers','naming','T',1459816158290000,NULL,'243a0354c7b14540b6024a5d0405c21a',0),('42b933db7cb4406797e82c7699c4fe5b','cd1c789d1a2e480384662de8de917ed1','attrAdmins','attributeDef','T',1459816158074000,NULL,'80a32ac9b4374b90acaecbe3d1ca5d17',0),('43121ed70a544190aa43b3e819196bac','5cc53183805a46ee8b4d6795bf9548b6','optins','access','T',1459816157923000,NULL,'274e27eda91a48b6addc6aa49fe50a8a',0),('463734ced018486d80470d6f7950874f','76ae221cea544a4f807ac377e2effa8f','groupAttrUpdaters','access','T',1459816158044000,NULL,'4b0ae9a3ce024543b16d07c907e0ac50',0),('4d9ff7cffe244fce8a78a9bb08675c0e','3d4dfe7f92184f03801ba09f35992de3','attrOptins','attributeDef','T',1459816158118000,NULL,'f2cf26e0ad9f45b18680e8f76bf966c4',0),('615a03a6e27f49e79bfe6ae02c8ac451','4e9bb975b2cf43e79651b1e519070b2c','attrReaders','attributeDef','T',1459816158138000,NULL,'23fa33b4278c4d72b1e6023b98668a3d',0),('87a7c6d638214798821dccf47229f011','11552e71132c4bd8a199d9d7418cbc97','stemAttrUpdaters','naming','T',1459816158332000,NULL,'89e8281fe5ae408e8bd1730acae593bc',0),('8bbaf1cf26f240ac87a7d5be6969385d','2637cba4ab98462581efd051349db069','members','list','T',1459816157432000,NULL,'e7bcecb6566f419f9f687a57bfb1cdf1',0),('8d92195e19eb42c5b9bba0b5da3ee704','a0f3df3f3afe4e28914131d26c413757','creators','naming','T',1459816158272000,NULL,'0ae63d112bdd42918f051d25548340d0',0),('8eccb55d62cf41728c5cde153e7890c7','a9f4b02397d24462a45d981ade0c339e','stemAttrReaders','naming','T',1459816158310000,NULL,'74964979480f45a99af1f992e540767e',0),('9164fdfd8b0349b3b920a91d520ccbb1','0ad6ce292c314b10aa59cef878ab9a17','updaters','access','T',1459816157989000,NULL,'1b329515ee054ec783c15e0070025c83',0),('af24e59a77d54d1298100c1c95621bde','6ef6c29e94044581bdef90d074a04d45','readers','access','T',1459816157962000,NULL,'440b456172304e84a5d01c0fada7d5b1',0),('bb72e33bd54b4b7a8fc994af1f67a82f','5ea33c8d1890401cad243bb7b765d76b','optouts','access','T',1459816157893000,NULL,'6deb2d2beb9a477cb797e24e171a4afd',0),('c0e514507d584b98b293485d4514706e','6f085ccfe46845c4b98d83edc6e7da49','attrUpdaters','attributeDef','T',1459816158165000,NULL,'674c7aedfd90423f873527799b6786b3',0),('e1b0b44c742c410b87be9ab9f942fff4','2b05b3abce1e4d589fc89512f7d610d9','admins','access','T',1459816157865000,NULL,'71ee64b594a141f2b395ca39f83c7adf',0),('e41035e7d8ab462eb244c42cd03d761f','30d6952ca2314c5c8297c5560f24940f','attrDefAttrUpdaters','attributeDef','T',1459816158243000,NULL,'73c6f0ccacd04367ba9444f6f4f41037',0),('e5b3e6e114984749bba1c2f8fb8b5a4d','abbe645d24154daebb09dcf8c5940de1','viewers','access','T',1459816158015000,NULL,'225f02a0ebe148948eac60792e71d014',0),('f77037ef66b54d0cb916d69434faaf8b','99d5358f26f74749904171eb52d12e5f','attrOptouts','attributeDef','T',1459816158091000,NULL,'94b790939f37416c9d2b6e9cdc6fd923',0);
/*!40000 ALTER TABLE `grouper_pit_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_group_set`
--

DROP TABLE IF EXISTS `grouper_pit_group_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_group_set` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_attr_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `member_attr_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `field_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `member_field_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `depth` int(11) NOT NULL,
  `parent_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_gs_start_idx` (`start_time`,`source_id`),
  KEY `pit_gs_source_id_idx` (`source_id`),
  KEY `pit_gs_context_idx` (`context_id`),
  KEY `pit_gs_owner_attr_def_idx` (`owner_attr_def_id`),
  KEY `pit_gs_owner_group_idx` (`owner_group_id`),
  KEY `pit_gs_owner_stem_idx` (`owner_stem_id`),
  KEY `pit_gs_member_idx` (`member_id`),
  KEY `pit_gs_member_attr_def_idx` (`member_attr_def_id`),
  KEY `pit_gs_member_group_idx` (`member_group_id`),
  KEY `pit_gs_member_stem_idx` (`member_stem_id`),
  KEY `pit_gs_field_idx` (`field_id`),
  KEY `pit_gs_member_field_idx` (`member_field_id`),
  KEY `pit_gs_parent_idx` (`parent_id`),
  KEY `pit_gs_member_member_field_idx` (`member_id`,`member_field_id`),
  KEY `pit_gs_group_field_member_idx` (`owner_group_id`,`field_id`,`member_id`),
  KEY `pit_gs_owner_field_idx` (`owner_id`,`field_id`),
  KEY `pit_gs_owner_member_field_idx` (`owner_id`,`member_id`,`field_id`),
  KEY `pit_gs_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_gs_field_id` FOREIGN KEY (`field_id`) REFERENCES `grouper_pit_fields` (`id`),
  CONSTRAINT `fk_pit_gs_member_attrdef_id` FOREIGN KEY (`member_attr_def_id`) REFERENCES `grouper_pit_attribute_def` (`id`),
  CONSTRAINT `fk_pit_gs_member_field_id` FOREIGN KEY (`member_field_id`) REFERENCES `grouper_pit_fields` (`id`),
  CONSTRAINT `fk_pit_gs_member_group_id` FOREIGN KEY (`member_group_id`) REFERENCES `grouper_pit_groups` (`id`),
  CONSTRAINT `fk_pit_gs_member_stem_id` FOREIGN KEY (`member_stem_id`) REFERENCES `grouper_pit_stems` (`id`),
  CONSTRAINT `fk_pit_gs_owner_attrdef_id` FOREIGN KEY (`owner_attr_def_id`) REFERENCES `grouper_pit_attribute_def` (`id`),
  CONSTRAINT `fk_pit_gs_owner_group_id` FOREIGN KEY (`owner_group_id`) REFERENCES `grouper_pit_groups` (`id`),
  CONSTRAINT `fk_pit_gs_owner_stem_id` FOREIGN KEY (`owner_stem_id`) REFERENCES `grouper_pit_stems` (`id`),
  CONSTRAINT `fk_pit_gs_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `grouper_pit_group_set` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_group_set`
--

LOCK TABLES `grouper_pit_group_set` WRITE;
/*!40000 ALTER TABLE `grouper_pit_group_set` DISABLE KEYS */;
INSERT INTO `grouper_pit_group_set` VALUES ('35590267f9f04fd6ac80220d1b330761','30ab4725bcf14f5b8a4a1136223d93dc','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','8d92195e19eb42c5b9bba0b5da3ee704','8d92195e19eb42c5b9bba0b5da3ee704',0,'35590267f9f04fd6ac80220d1b330761','T',1459816158425000,NULL,NULL,0),('554c946679e24d838314fbfee1a6c07f','ea3a06edf3d442cbb8cd315405151a53','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','409cd73ec1b14562bf3ce3f587ab3d5e','409cd73ec1b14562bf3ce3f587ab3d5e',0,'554c946679e24d838314fbfee1a6c07f','T',1459816158425000,NULL,NULL,0),('6806d090e10940ad9d34a04312b64eaf','de98d50e2bb141aa907e8585b5529320','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','8eccb55d62cf41728c5cde153e7890c7','8eccb55d62cf41728c5cde153e7890c7',0,'6806d090e10940ad9d34a04312b64eaf','T',1459816158425000,NULL,NULL,0),('fbe6a6ea250e457b8cb0c60babd20575','d4a3f3f190074ecba3b26f655ec0be10','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','d2f1f40083cd4dc3bc348721d4b0fa1b',NULL,NULL,'d2f1f40083cd4dc3bc348721d4b0fa1b','87a7c6d638214798821dccf47229f011','87a7c6d638214798821dccf47229f011',0,'fbe6a6ea250e457b8cb0c60babd20575','T',1459816158425000,NULL,NULL,0);
/*!40000 ALTER TABLE `grouper_pit_group_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_groups`
--

DROP TABLE IF EXISTS `grouper_pit_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_groups` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_group_start_idx` (`start_time`,`source_id`),
  KEY `pit_group_source_id_idx` (`source_id`),
  KEY `pit_group_parent_idx` (`stem_id`),
  KEY `pit_group_context_idx` (`context_id`),
  KEY `pit_group_end_idx` (`end_time`),
  KEY `pit_group_name_idx` (`name`(255)),
  CONSTRAINT `fk_pit_group_stem` FOREIGN KEY (`stem_id`) REFERENCES `grouper_pit_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_groups`
--

LOCK TABLES `grouper_pit_groups` WRITE;
/*!40000 ALTER TABLE `grouper_pit_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_members`
--

DROP TABLE IF EXISTS `grouper_pit_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_members` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `subject_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `subject_source` varchar(255) COLLATE utf8_bin NOT NULL,
  `subject_type` varchar(255) COLLATE utf8_bin NOT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_member_start_idx` (`start_time`,`source_id`),
  KEY `pit_member_source_id_idx` (`source_id`),
  KEY `pit_member_subject_id_idx` (`subject_id`),
  KEY `pit_member_context_idx` (`context_id`),
  KEY `pit_member_end_idx` (`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_members`
--

LOCK TABLES `grouper_pit_members` WRITE;
/*!40000 ALTER TABLE `grouper_pit_members` DISABLE KEYS */;
INSERT INTO `grouper_pit_members` VALUES ('799e828855ad40ea84e0682fd654859b','dd763c74578f453caaac27517173178f','GrouperAll','g:isa','application','T',1459816157393000,NULL,NULL,0),('976761df3c8e4fdd9ae07c79da123354','65947ffd4e364921a42c465d94a78c09','GrouperSystem','g:isa','application','T',1459816157352000,NULL,NULL,0);
/*!40000 ALTER TABLE `grouper_pit_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_memberships`
--

DROP TABLE IF EXISTS `grouper_pit_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_memberships` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `owner_attr_def_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_group_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `owner_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `member_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `field_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_ms_start_idx` (`start_time`,`source_id`),
  KEY `pit_ms_source_id_idx` (`source_id`),
  KEY `pit_ms_context_idx` (`context_id`),
  KEY `pit_ms_owner_attr_def_idx` (`owner_attr_def_id`),
  KEY `pit_ms_owner_stem_idx` (`owner_stem_id`),
  KEY `pit_ms_owner_group_idx` (`owner_group_id`),
  KEY `pit_ms_member_idx` (`member_id`),
  KEY `pit_ms_field_idx` (`field_id`),
  KEY `pit_ms_owner_field_idx` (`owner_id`,`field_id`),
  KEY `pit_ms_owner_member_field_idx` (`owner_id`,`member_id`,`field_id`),
  KEY `pit_ms_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_ms_field_id` FOREIGN KEY (`field_id`) REFERENCES `grouper_pit_fields` (`id`),
  CONSTRAINT `fk_pit_ms_member_id` FOREIGN KEY (`member_id`) REFERENCES `grouper_pit_members` (`id`),
  CONSTRAINT `fk_pit_ms_owner_attrdef_id` FOREIGN KEY (`owner_attr_def_id`) REFERENCES `grouper_pit_attribute_def` (`id`),
  CONSTRAINT `fk_pit_ms_owner_group_id` FOREIGN KEY (`owner_group_id`) REFERENCES `grouper_pit_groups` (`id`),
  CONSTRAINT `fk_pit_ms_owner_stem_id` FOREIGN KEY (`owner_stem_id`) REFERENCES `grouper_pit_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_memberships`
--

LOCK TABLES `grouper_pit_memberships` WRITE;
/*!40000 ALTER TABLE `grouper_pit_memberships` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_pit_memberships_all_v`
--

DROP TABLE IF EXISTS `grouper_pit_memberships_all_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_memberships_all_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_pit_memberships_all_v` (
  `ID` tinyint NOT NULL,
  `MEMBERSHIP_ID` tinyint NOT NULL,
  `MEMBERSHIP_SOURCE_ID` tinyint NOT NULL,
  `GROUP_SET_ID` tinyint NOT NULL,
  `MEMBER_ID` tinyint NOT NULL,
  `FIELD_ID` tinyint NOT NULL,
  `MEMBERSHIP_FIELD_ID` tinyint NOT NULL,
  `OWNER_ID` tinyint NOT NULL,
  `OWNER_ATTR_DEF_ID` tinyint NOT NULL,
  `OWNER_GROUP_ID` tinyint NOT NULL,
  `OWNER_STEM_ID` tinyint NOT NULL,
  `GROUP_SET_ACTIVE` tinyint NOT NULL,
  `GROUP_SET_START_TIME` tinyint NOT NULL,
  `GROUP_SET_END_TIME` tinyint NOT NULL,
  `MEMBERSHIP_ACTIVE` tinyint NOT NULL,
  `MEMBERSHIP_START_TIME` tinyint NOT NULL,
  `MEMBERSHIP_END_TIME` tinyint NOT NULL,
  `DEPTH` tinyint NOT NULL,
  `GROUP_SET_PARENT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_pit_perms_all_v`
--

DROP TABLE IF EXISTS `grouper_pit_perms_all_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_perms_all_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_pit_perms_all_v` (
  `role_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `membership_depth` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `group_set_id` tinyint NOT NULL,
  `role_set_id` tinyint NOT NULL,
  `attribute_def_name_set_id` tinyint NOT NULL,
  `action_set_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL,
  `group_set_active` tinyint NOT NULL,
  `group_set_start_time` tinyint NOT NULL,
  `group_set_end_time` tinyint NOT NULL,
  `membership_active` tinyint NOT NULL,
  `membership_start_time` tinyint NOT NULL,
  `membership_end_time` tinyint NOT NULL,
  `role_set_active` tinyint NOT NULL,
  `role_set_start_time` tinyint NOT NULL,
  `role_set_end_time` tinyint NOT NULL,
  `action_set_active` tinyint NOT NULL,
  `action_set_start_time` tinyint NOT NULL,
  `action_set_end_time` tinyint NOT NULL,
  `attr_def_name_set_active` tinyint NOT NULL,
  `attr_def_name_set_start_time` tinyint NOT NULL,
  `attr_def_name_set_end_time` tinyint NOT NULL,
  `attribute_assign_active` tinyint NOT NULL,
  `attribute_assign_start_time` tinyint NOT NULL,
  `attribute_assign_end_time` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL,
  `action_source_id` tinyint NOT NULL,
  `role_source_id` tinyint NOT NULL,
  `attribute_def_name_source_id` tinyint NOT NULL,
  `attribute_def_source_id` tinyint NOT NULL,
  `member_source_id` tinyint NOT NULL,
  `membership_source_id` tinyint NOT NULL,
  `attribute_assign_source_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_pit_perms_role_subj_v`
--

DROP TABLE IF EXISTS `grouper_pit_perms_role_subj_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_perms_role_subj_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_pit_perms_role_subj_v` (
  `role_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `membership_depth` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `group_set_id` tinyint NOT NULL,
  `role_set_id` tinyint NOT NULL,
  `attribute_def_name_set_id` tinyint NOT NULL,
  `action_set_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL,
  `group_set_active` tinyint NOT NULL,
  `group_set_start_time` tinyint NOT NULL,
  `group_set_end_time` tinyint NOT NULL,
  `membership_active` tinyint NOT NULL,
  `membership_start_time` tinyint NOT NULL,
  `membership_end_time` tinyint NOT NULL,
  `role_set_active` tinyint NOT NULL,
  `role_set_start_time` tinyint NOT NULL,
  `role_set_end_time` tinyint NOT NULL,
  `action_set_active` tinyint NOT NULL,
  `action_set_start_time` tinyint NOT NULL,
  `action_set_end_time` tinyint NOT NULL,
  `attr_def_name_set_active` tinyint NOT NULL,
  `attr_def_name_set_start_time` tinyint NOT NULL,
  `attr_def_name_set_end_time` tinyint NOT NULL,
  `attribute_assign_active` tinyint NOT NULL,
  `attribute_assign_start_time` tinyint NOT NULL,
  `attribute_assign_end_time` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL,
  `action_source_id` tinyint NOT NULL,
  `role_source_id` tinyint NOT NULL,
  `attribute_def_name_source_id` tinyint NOT NULL,
  `attribute_def_source_id` tinyint NOT NULL,
  `member_source_id` tinyint NOT NULL,
  `membership_source_id` tinyint NOT NULL,
  `attribute_assign_source_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_pit_perms_role_v`
--

DROP TABLE IF EXISTS `grouper_pit_perms_role_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_perms_role_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_pit_perms_role_v` (
  `role_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `action` tinyint NOT NULL,
  `attribute_def_name_name` tinyint NOT NULL,
  `role_id` tinyint NOT NULL,
  `attribute_def_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `attribute_def_name_id` tinyint NOT NULL,
  `action_id` tinyint NOT NULL,
  `membership_depth` tinyint NOT NULL,
  `role_set_depth` tinyint NOT NULL,
  `attr_def_name_set_depth` tinyint NOT NULL,
  `attr_assign_action_set_depth` tinyint NOT NULL,
  `membership_id` tinyint NOT NULL,
  `group_set_id` tinyint NOT NULL,
  `role_set_id` tinyint NOT NULL,
  `attribute_def_name_set_id` tinyint NOT NULL,
  `action_set_id` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL,
  `permission_type` tinyint NOT NULL,
  `group_set_active` tinyint NOT NULL,
  `group_set_start_time` tinyint NOT NULL,
  `group_set_end_time` tinyint NOT NULL,
  `membership_active` tinyint NOT NULL,
  `membership_start_time` tinyint NOT NULL,
  `membership_end_time` tinyint NOT NULL,
  `role_set_active` tinyint NOT NULL,
  `role_set_start_time` tinyint NOT NULL,
  `role_set_end_time` tinyint NOT NULL,
  `action_set_active` tinyint NOT NULL,
  `action_set_start_time` tinyint NOT NULL,
  `action_set_end_time` tinyint NOT NULL,
  `attr_def_name_set_active` tinyint NOT NULL,
  `attr_def_name_set_start_time` tinyint NOT NULL,
  `attr_def_name_set_end_time` tinyint NOT NULL,
  `attribute_assign_active` tinyint NOT NULL,
  `attribute_assign_start_time` tinyint NOT NULL,
  `attribute_assign_end_time` tinyint NOT NULL,
  `disallowed` tinyint NOT NULL,
  `action_source_id` tinyint NOT NULL,
  `role_source_id` tinyint NOT NULL,
  `attribute_def_name_source_id` tinyint NOT NULL,
  `attribute_def_source_id` tinyint NOT NULL,
  `member_source_id` tinyint NOT NULL,
  `membership_source_id` tinyint NOT NULL,
  `attribute_assign_source_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_pit_role_set`
--

DROP TABLE IF EXISTS `grouper_pit_role_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_role_set` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `depth` bigint(20) NOT NULL,
  `if_has_role_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_role_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_role_set_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_rs_start_idx` (`start_time`,`source_id`),
  KEY `pit_rs_source_id_idx` (`source_id`),
  KEY `pit_rs_if_idx` (`if_has_role_id`),
  KEY `pit_rs_then_idx` (`then_has_role_id`),
  KEY `pit_rs_parent_idx` (`parent_role_set_id`),
  KEY `pit_rs_end_idx` (`end_time`),
  CONSTRAINT `fk_pit_role_if` FOREIGN KEY (`if_has_role_id`) REFERENCES `grouper_pit_groups` (`id`),
  CONSTRAINT `fk_pit_role_set_parent` FOREIGN KEY (`parent_role_set_id`) REFERENCES `grouper_pit_role_set` (`id`),
  CONSTRAINT `fk_pit_role_then` FOREIGN KEY (`then_has_role_id`) REFERENCES `grouper_pit_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_role_set`
--

LOCK TABLES `grouper_pit_role_set` WRITE;
/*!40000 ALTER TABLE `grouper_pit_role_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_pit_role_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_pit_stems`
--

DROP TABLE IF EXISTS `grouper_pit_stems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_pit_stems` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `source_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `name` varchar(1024) COLLATE utf8_bin NOT NULL,
  `parent_stem_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_bin NOT NULL,
  `start_time` bigint(20) NOT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pit_stem_start_idx` (`start_time`,`source_id`),
  KEY `pit_stem_source_id_idx` (`source_id`),
  KEY `pit_stem_parent_idx` (`parent_stem_id`),
  KEY `pit_stem_context_idx` (`context_id`),
  KEY `pit_stem_end_idx` (`end_time`),
  KEY `pit_stem_name_idx` (`name`(255)),
  CONSTRAINT `fk_pit_stem_parent` FOREIGN KEY (`parent_stem_id`) REFERENCES `grouper_pit_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_pit_stems`
--

LOCK TABLES `grouper_pit_stems` WRITE;
/*!40000 ALTER TABLE `grouper_pit_stems` DISABLE KEYS */;
INSERT INTO `grouper_pit_stems` VALUES ('d2f1f40083cd4dc3bc348721d4b0fa1b','d83a1feb851d4ede95786362de79547d',':',NULL,'T',1459816158425000,NULL,NULL,0);
/*!40000 ALTER TABLE `grouper_pit_stems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grouper_role_set`
--

DROP TABLE IF EXISTS `grouper_role_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_role_set` (
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `depth` bigint(20) NOT NULL,
  `if_has_role_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_role_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_role_set_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_set_unq_idx` (`parent_role_set_id`,`if_has_role_id`,`then_has_role_id`),
  KEY `role_set_ifhas_idx` (`if_has_role_id`),
  KEY `role_set_then_idx` (`then_has_role_id`),
  CONSTRAINT `fk_role_if` FOREIGN KEY (`if_has_role_id`) REFERENCES `grouper_groups` (`id`),
  CONSTRAINT `fk_role_set_parent` FOREIGN KEY (`parent_role_set_id`) REFERENCES `grouper_role_set` (`id`),
  CONSTRAINT `fk_role_then` FOREIGN KEY (`then_has_role_id`) REFERENCES `grouper_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_role_set`
--

LOCK TABLES `grouper_role_set` WRITE;
/*!40000 ALTER TABLE `grouper_role_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `grouper_role_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_role_set_v`
--

DROP TABLE IF EXISTS `grouper_role_set_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_role_set_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_role_set_v` (
  `if_has_role_name` tinyint NOT NULL,
  `then_has_role_name` tinyint NOT NULL,
  `depth` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_if_has_name` tinyint NOT NULL,
  `parent_then_has_name` tinyint NOT NULL,
  `id` tinyint NOT NULL,
  `if_has_role_id` tinyint NOT NULL,
  `then_has_role_id` tinyint NOT NULL,
  `parent_role_set_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_roles_v`
--

DROP TABLE IF EXISTS `grouper_roles_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_roles_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_roles_v` (
  `EXTENSION` tinyint NOT NULL,
  `NAME` tinyint NOT NULL,
  `DISPLAY_EXTENSION` tinyint NOT NULL,
  `DISPLAY_NAME` tinyint NOT NULL,
  `DESCRIPTION` tinyint NOT NULL,
  `PARENT_STEM_NAME` tinyint NOT NULL,
  `ROLE_ID` tinyint NOT NULL,
  `PARENT_STEM_ID` tinyint NOT NULL,
  `MODIFIER_SOURCE` tinyint NOT NULL,
  `MODIFIER_SUBJECT_ID` tinyint NOT NULL,
  `CREATOR_SOURCE` tinyint NOT NULL,
  `CREATOR_SUBJECT_ID` tinyint NOT NULL,
  `IS_COMPOSITE_OWNER` tinyint NOT NULL,
  `IS_COMPOSITE_FACTOR` tinyint NOT NULL,
  `CREATOR_ID` tinyint NOT NULL,
  `CREATE_TIME` tinyint NOT NULL,
  `MODIFIER_ID` tinyint NOT NULL,
  `MODIFY_TIME` tinyint NOT NULL,
  `HIBERNATE_VERSION_NUMBER` tinyint NOT NULL,
  `CONTEXT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rpt_composites_v`
--

DROP TABLE IF EXISTS `grouper_rpt_composites_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_composites_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rpt_composites_v` (
  `COMPOSITE_TYPE` tinyint NOT NULL,
  `THE_COUNT` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rpt_group_field_v`
--

DROP TABLE IF EXISTS `grouper_rpt_group_field_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_group_field_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rpt_group_field_v` (
  `GROUP_NAME` tinyint NOT NULL,
  `GROUP_DISPLAYNAME` tinyint NOT NULL,
  `FIELD_TYPE` tinyint NOT NULL,
  `FIELD_NAME` tinyint NOT NULL,
  `MEMBER_COUNT` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rpt_groups_v`
--

DROP TABLE IF EXISTS `grouper_rpt_groups_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_groups_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rpt_groups_v` (
  `GROUP_NAME` tinyint NOT NULL,
  `GROUP_DISPLAYNAME` tinyint NOT NULL,
  `TYPE_OF_GROUP` tinyint NOT NULL,
  `IMMEDIATE_MEMBERSHIP_COUNT` tinyint NOT NULL,
  `MEMBERSHIP_COUNT` tinyint NOT NULL,
  `ISA_COMPOSITE_FACTOR_COUNT` tinyint NOT NULL,
  `ISA_MEMBER_COUNT` tinyint NOT NULL,
  `GROUP_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rpt_members_v`
--

DROP TABLE IF EXISTS `grouper_rpt_members_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_members_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rpt_members_v` (
  `SUBJECT_ID` tinyint NOT NULL,
  `SUBJECT_SOURCE` tinyint NOT NULL,
  `MEMBERSHIP_COUNT` tinyint NOT NULL,
  `MEMBER_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rpt_roles_v`
--

DROP TABLE IF EXISTS `grouper_rpt_roles_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_roles_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rpt_roles_v` (
  `ROLE_NAME` tinyint NOT NULL,
  `ROLE_DISPLAYNAME` tinyint NOT NULL,
  `IMMEDIATE_MEMBERSHIP_COUNT` tinyint NOT NULL,
  `MEMBERSHIP_COUNT` tinyint NOT NULL,
  `ISA_COMPOSITE_FACTOR_COUNT` tinyint NOT NULL,
  `ISA_MEMBER_COUNT` tinyint NOT NULL,
  `ROLE_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rpt_stems_v`
--

DROP TABLE IF EXISTS `grouper_rpt_stems_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_stems_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rpt_stems_v` (
  `STEM_NAME` tinyint NOT NULL,
  `STEM_DISPLAYNAME` tinyint NOT NULL,
  `GROUP_IMMEDIATE_COUNT` tinyint NOT NULL,
  `STEM_IMMEDIATE_COUNT` tinyint NOT NULL,
  `GROUP_COUNT` tinyint NOT NULL,
  `STEM_COUNT` tinyint NOT NULL,
  `THIS_STEM_MEMBERSHIP_COUNT` tinyint NOT NULL,
  `CHILD_GROUP_MEMBERSHIP_COUNT` tinyint NOT NULL,
  `GROUP_MEMBERSHIP_COUNT` tinyint NOT NULL,
  `STEM_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_rules_v`
--

DROP TABLE IF EXISTS `grouper_rules_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_rules_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_rules_v` (
  `assigned_to_type` tinyint NOT NULL,
  `assigned_to_group_name` tinyint NOT NULL,
  `assigned_to_stem_name` tinyint NOT NULL,
  `assigned_to_member_subject_id` tinyint NOT NULL,
  `assigned_to_attribute_def_name` tinyint NOT NULL,
  `rule_check_type` tinyint NOT NULL,
  `rule_check_owner_id` tinyint NOT NULL,
  `rule_check_owner_name` tinyint NOT NULL,
  `rule_check_stem_scope` tinyint NOT NULL,
  `rule_check_arg0` tinyint NOT NULL,
  `rule_check_arg1` tinyint NOT NULL,
  `rule_if_condition_el` tinyint NOT NULL,
  `rule_if_condition_enum` tinyint NOT NULL,
  `rule_if_condition_enum_arg0` tinyint NOT NULL,
  `rule_if_condition_enum_arg1` tinyint NOT NULL,
  `rule_if_owner_id` tinyint NOT NULL,
  `rule_if_owner_name` tinyint NOT NULL,
  `rule_if_stem_scope` tinyint NOT NULL,
  `rule_then_el` tinyint NOT NULL,
  `rule_then_enum` tinyint NOT NULL,
  `rule_then_enum_arg0` tinyint NOT NULL,
  `rule_then_enum_arg1` tinyint NOT NULL,
  `rule_then_enum_arg2` tinyint NOT NULL,
  `rule_valid` tinyint NOT NULL,
  `rule_run_daemon` tinyint NOT NULL,
  `rule_act_as_subject_id` tinyint NOT NULL,
  `rule_act_as_subject_identifier` tinyint NOT NULL,
  `rule_act_as_subject_source_id` tinyint NOT NULL,
  `assignment_enabled` tinyint NOT NULL,
  `attribute_assign_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `grouper_service_role_v`
--

DROP TABLE IF EXISTS `grouper_service_role_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_service_role_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_service_role_v` (
  `service_role` tinyint NOT NULL,
  `group_name` tinyint NOT NULL,
  `name_of_service_def_name` tinyint NOT NULL,
  `subject_source_id` tinyint NOT NULL,
  `subject_id` tinyint NOT NULL,
  `field_name` tinyint NOT NULL,
  `name_of_service_def` tinyint NOT NULL,
  `group_display_name` tinyint NOT NULL,
  `group_id` tinyint NOT NULL,
  `service_def_id` tinyint NOT NULL,
  `service_name_id` tinyint NOT NULL,
  `member_id` tinyint NOT NULL,
  `field_id` tinyint NOT NULL,
  `display_name_of_service_name` tinyint NOT NULL,
  `service_stem_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_stem_set`
--

DROP TABLE IF EXISTS `grouper_stem_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_stem_set` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `if_has_stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `then_has_stem_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_stem_set_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `depth` bigint(20) NOT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stem_set_unq_idx` (`parent_stem_set_id`,`if_has_stem_id`,`then_has_stem_id`),
  KEY `stem_set_ifhas_idx` (`if_has_stem_id`),
  KEY `stem_set_then_idx` (`then_has_stem_id`),
  CONSTRAINT `fk_stem_set_if` FOREIGN KEY (`if_has_stem_id`) REFERENCES `grouper_stems` (`id`),
  CONSTRAINT `fk_stem_set_parent` FOREIGN KEY (`parent_stem_set_id`) REFERENCES `grouper_stem_set` (`id`),
  CONSTRAINT `fk_stem_set_then` FOREIGN KEY (`then_has_stem_id`) REFERENCES `grouper_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_stem_set`
--

LOCK TABLES `grouper_stem_set` WRITE;
/*!40000 ALTER TABLE `grouper_stem_set` DISABLE KEYS */;
INSERT INTO `grouper_stem_set` VALUES ('0aaeab565892449092ed20d3941612bb','b6bc2fcd772146ee970347e496538926','d83a1feb851d4ede95786362de79547d','1f0723e3289542be80aa42813b020185','effective',3,1459816163666,1459816163666,NULL,0),('0fe56dd386654314a1672e6292c25960','094308af1376466687416c49f1f6495f','1730a44d087442cc96c2d8d63b655716','a9ea67c9f6c947839bbe4f42fab3f8d2','immediate',1,1459816165630,1459816165630,NULL,0),('1587c4a2812f4582abc5868173d4ed41','fc88a71ee4574ae7b0a550d72b5172d9','fc88a71ee4574ae7b0a550d72b5172d9','1587c4a2812f4582abc5868173d4ed41','self',0,1459816162283,1459816162283,NULL,0),('1bed13ee00a048f8bf4af5a68e2005dd','2eee186e51494f0a874fe61ff24b7192','1730a44d087442cc96c2d8d63b655716','f3012c10514f4dc9839295f593126fc0','immediate',1,1459816168094,1459816168094,NULL,0),('1f0723e3289542be80aa42813b020185','b6bc2fcd772146ee970347e496538926','47bf48f95b9a4c67855b091e3d1003de','42d583fc7378416086b7b4d29712a7c3','effective',2,1459816163666,1459816163666,NULL,0),('26e9183fbb82435da321f4b7976c7082','fc88a71ee4574ae7b0a550d72b5172d9','1730a44d087442cc96c2d8d63b655716','1587c4a2812f4582abc5868173d4ed41','immediate',1,1459816162283,1459816162283,NULL,0),('2b83a6fca0154fdeb2ea8db078b727ca','b6bc2fcd772146ee970347e496538926','b6bc2fcd772146ee970347e496538926','2b83a6fca0154fdeb2ea8db078b727ca','self',0,1459816163666,1459816163666,NULL,0),('385030e03e0a453290661b748ca88314','fc88a71ee4574ae7b0a550d72b5172d9','d83a1feb851d4ede95786362de79547d','93c72c00e71f49f9bdca06f6a3afbeeb','effective',3,1459816162283,1459816162283,NULL,0),('392c427ea5794b6ea438a019134dd868','1730a44d087442cc96c2d8d63b655716','1730a44d087442cc96c2d8d63b655716','392c427ea5794b6ea438a019134dd868','self',0,1459816161190,1459816161190,NULL,0),('3a1999d97f4549efab441404fccf6872','2eee186e51494f0a874fe61ff24b7192','47bf48f95b9a4c67855b091e3d1003de','1bed13ee00a048f8bf4af5a68e2005dd','effective',2,1459816168094,1459816168094,NULL,0),('3d0196f403744881b4acae9b523d5090','47bf48f95b9a4c67855b091e3d1003de','47bf48f95b9a4c67855b091e3d1003de','3d0196f403744881b4acae9b523d5090','self',0,1459816160285,1459816160285,NULL,0),('3e35c5391c534890acd32e6362d91b3b','2eee186e51494f0a874fe61ff24b7192','d83a1feb851d4ede95786362de79547d','3a1999d97f4549efab441404fccf6872','effective',3,1459816168094,1459816168094,NULL,0),('42d583fc7378416086b7b4d29712a7c3','b6bc2fcd772146ee970347e496538926','1730a44d087442cc96c2d8d63b655716','2b83a6fca0154fdeb2ea8db078b727ca','immediate',1,1459816163666,1459816163666,NULL,0),('442c0c72900944d0a8a78c97c018e2b7','36792aa7956240feb1bb6025c56ff2f3','36792aa7956240feb1bb6025c56ff2f3','442c0c72900944d0a8a78c97c018e2b7','self',0,1459816161061,1459816161061,NULL,0),('5c90742378a74541b2b3c6bc4f0ff737','d5248b39d72f4fdcb730d1be03de4fbc','47bf48f95b9a4c67855b091e3d1003de','a4019c745983454b800eb6dc545d0349','effective',2,1459816161274,1459816161274,NULL,0),('5dae6b3197744983ae4afe85b629c23c','cb1bfad6c8ed424d902b65d9ec275df0','1730a44d087442cc96c2d8d63b655716','b9e0d0cb37b24d8e9427d4146c399871','immediate',1,1459816167304,1459816167304,NULL,0),('65b22ba78050490aa9f2536ce9fb8fcb','6cd4d8196fe24d21acd51cdf8fcdb3cc','47bf48f95b9a4c67855b091e3d1003de','efc4a6294a4848cd828bb9d824467f44','effective',2,1459816164214,1459816164214,NULL,0),('68c362b4c57a4610bfe23b9c1d5bcb30','1730a44d087442cc96c2d8d63b655716','47bf48f95b9a4c67855b091e3d1003de','392c427ea5794b6ea438a019134dd868','immediate',1,1459816161190,1459816161190,NULL,0),('703bcaacd97b425f86375b53394e46b1','36792aa7956240feb1bb6025c56ff2f3','d83a1feb851d4ede95786362de79547d','87244ae9265c4c5782eacabbe91cf68f','effective',3,1459816161061,1459816161061,NULL,0),('79e65f09894a455e857fd7791db4a579','d5248b39d72f4fdcb730d1be03de4fbc','d5248b39d72f4fdcb730d1be03de4fbc','79e65f09894a455e857fd7791db4a579','self',0,1459816161274,1459816161274,NULL,0),('7fd7bb7d7b3f4765873f45c1b58421ea','cb1bfad6c8ed424d902b65d9ec275df0','47bf48f95b9a4c67855b091e3d1003de','5dae6b3197744983ae4afe85b629c23c','effective',2,1459816167304,1459816167304,NULL,0),('808f091886354897b67f5c731c602210','1730a44d087442cc96c2d8d63b655716','d83a1feb851d4ede95786362de79547d','68c362b4c57a4610bfe23b9c1d5bcb30','effective',2,1459816161190,1459816161190,NULL,0),('87244ae9265c4c5782eacabbe91cf68f','36792aa7956240feb1bb6025c56ff2f3','47bf48f95b9a4c67855b091e3d1003de','d98d7cac9cc5409f8db55c8055a6b951','effective',2,1459816161061,1459816161061,NULL,0),('8a894ff9cf614694a8d0f907fddcdd3c','d5248b39d72f4fdcb730d1be03de4fbc','d83a1feb851d4ede95786362de79547d','5c90742378a74541b2b3c6bc4f0ff737','effective',3,1459816161274,1459816161274,NULL,0),('8b69c0c4609b487e8066fc1064f141ac','44824fdcdd0e435ab9eafc2a40e430c1','d83a1feb851d4ede95786362de79547d','f9e51c69e916474dacdfdd3ff6419dd4','effective',2,1459816160968,1459816160968,NULL,0),('93c72c00e71f49f9bdca06f6a3afbeeb','fc88a71ee4574ae7b0a550d72b5172d9','47bf48f95b9a4c67855b091e3d1003de','26e9183fbb82435da321f4b7976c7082','effective',2,1459816162283,1459816162283,NULL,0),('9eb6aa951a95430c9d1fdb7bd497b7a2','094308af1376466687416c49f1f6495f','d83a1feb851d4ede95786362de79547d','a38755fb97df4f86b68f2ff5a6df5f13','effective',3,1459816165630,1459816165630,NULL,0),('a1b8e8470c58444db69ec6cb852a41b0','6cd4d8196fe24d21acd51cdf8fcdb3cc','6cd4d8196fe24d21acd51cdf8fcdb3cc','a1b8e8470c58444db69ec6cb852a41b0','self',0,1459816164214,1459816164214,NULL,0),('a38755fb97df4f86b68f2ff5a6df5f13','094308af1376466687416c49f1f6495f','47bf48f95b9a4c67855b091e3d1003de','0fe56dd386654314a1672e6292c25960','effective',2,1459816165630,1459816165630,NULL,0),('a4019c745983454b800eb6dc545d0349','d5248b39d72f4fdcb730d1be03de4fbc','1730a44d087442cc96c2d8d63b655716','79e65f09894a455e857fd7791db4a579','immediate',1,1459816161274,1459816161274,NULL,0),('a9ea67c9f6c947839bbe4f42fab3f8d2','094308af1376466687416c49f1f6495f','094308af1376466687416c49f1f6495f','a9ea67c9f6c947839bbe4f42fab3f8d2','self',0,1459816165630,1459816165630,NULL,0),('b9e0d0cb37b24d8e9427d4146c399871','cb1bfad6c8ed424d902b65d9ec275df0','cb1bfad6c8ed424d902b65d9ec275df0','b9e0d0cb37b24d8e9427d4146c399871','self',0,1459816167304,1459816167304,NULL,0),('cf72c894803f4876afcbd9a2a575687d','6cd4d8196fe24d21acd51cdf8fcdb3cc','d83a1feb851d4ede95786362de79547d','65b22ba78050490aa9f2536ce9fb8fcb','effective',3,1459816164214,1459816164214,NULL,0),('d77c571f40bf4570b12fdc6bc5bf3531','44824fdcdd0e435ab9eafc2a40e430c1','44824fdcdd0e435ab9eafc2a40e430c1','d77c571f40bf4570b12fdc6bc5bf3531','self',0,1459816160968,1459816160968,NULL,0),('d98d7cac9cc5409f8db55c8055a6b951','36792aa7956240feb1bb6025c56ff2f3','44824fdcdd0e435ab9eafc2a40e430c1','442c0c72900944d0a8a78c97c018e2b7','immediate',1,1459816161061,1459816161061,NULL,0),('e35ed000169b422e9bf2338703391475','d83a1feb851d4ede95786362de79547d','d83a1feb851d4ede95786362de79547d','e35ed000169b422e9bf2338703391475','self',0,1459816158499,1459816158499,NULL,0),('ec26cf811bf24d9dbf8bd1bbb54bd926','47bf48f95b9a4c67855b091e3d1003de','d83a1feb851d4ede95786362de79547d','3d0196f403744881b4acae9b523d5090','immediate',1,1459816160285,1459816160285,NULL,0),('ee3938a9c1794a0eaa66aa8a07ee0b0b','cb1bfad6c8ed424d902b65d9ec275df0','d83a1feb851d4ede95786362de79547d','7fd7bb7d7b3f4765873f45c1b58421ea','effective',3,1459816167304,1459816167304,NULL,0),('efc4a6294a4848cd828bb9d824467f44','6cd4d8196fe24d21acd51cdf8fcdb3cc','1730a44d087442cc96c2d8d63b655716','a1b8e8470c58444db69ec6cb852a41b0','immediate',1,1459816164214,1459816164214,NULL,0),('f3012c10514f4dc9839295f593126fc0','2eee186e51494f0a874fe61ff24b7192','2eee186e51494f0a874fe61ff24b7192','f3012c10514f4dc9839295f593126fc0','self',0,1459816168094,1459816168094,NULL,0),('f9e51c69e916474dacdfdd3ff6419dd4','44824fdcdd0e435ab9eafc2a40e430c1','47bf48f95b9a4c67855b091e3d1003de','d77c571f40bf4570b12fdc6bc5bf3531','immediate',1,1459816160968,1459816160968,NULL,0);
/*!40000 ALTER TABLE `grouper_stem_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_stem_set_v`
--

DROP TABLE IF EXISTS `grouper_stem_set_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_stem_set_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_stem_set_v` (
  `if_has_stem_name` tinyint NOT NULL,
  `then_has_stem_name` tinyint NOT NULL,
  `depth` tinyint NOT NULL,
  `type` tinyint NOT NULL,
  `parent_if_has_name` tinyint NOT NULL,
  `parent_then_has_name` tinyint NOT NULL,
  `id` tinyint NOT NULL,
  `if_has_stem_id` tinyint NOT NULL,
  `then_has_stem_id` tinyint NOT NULL,
  `parent_stem_set_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_stems`
--

DROP TABLE IF EXISTS `grouper_stems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_stems` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `parent_stem` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `display_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `creator_id` varchar(40) COLLATE utf8_bin NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `modifier_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `modify_time` bigint(20) DEFAULT NULL,
  `display_extension` varchar(255) COLLATE utf8_bin NOT NULL,
  `extension` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `last_membership_change` bigint(20) DEFAULT NULL,
  `alternate_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  `context_id` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `id_index` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stem_name_idx` (`name`),
  UNIQUE KEY `stem_id_index_idx` (`id_index`),
  KEY `stem_alternate_name_idx` (`alternate_name`),
  KEY `stem_last_membership_idx` (`last_membership_change`),
  KEY `stem_createtime_idx` (`create_time`),
  KEY `stem_creator_idx` (`creator_id`),
  KEY `stem_dislpayextn_idx` (`display_extension`),
  KEY `stem_displayname_idx` (`display_name`),
  KEY `stem_extn_idx` (`extension`),
  KEY `stem_modifier_idx` (`modifier_id`),
  KEY `stem_modifytime_idx` (`modify_time`),
  KEY `stem_parent_idx` (`parent_stem`),
  KEY `stem_context_idx` (`context_id`),
  CONSTRAINT `fk_stems_creator_id` FOREIGN KEY (`creator_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_stems_modifier_id` FOREIGN KEY (`modifier_id`) REFERENCES `grouper_members` (`id`),
  CONSTRAINT `fk_stems_parent_stem` FOREIGN KEY (`parent_stem`) REFERENCES `grouper_stems` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_stems`
--

LOCK TABLES `grouper_stems` WRITE;
/*!40000 ALTER TABLE `grouper_stems` DISABLE KEYS */;
INSERT INTO `grouper_stems` VALUES ('094308af1376466687416c49f1f6495f','1730a44d087442cc96c2d8d63b655716','etc:attribute:loaderLdap','etc:attribute:loaderLdap','65947ffd4e364921a42c465d94a78c09',1459816165485,'65947ffd4e364921a42c465d94a78c09',1459816165659,'loaderLdap','loaderLdap','folder for built in Grouper loader ldap attributes',NULL,NULL,1,'d606df9bf9e346ff98ce07d7005f0135',10010),('1730a44d087442cc96c2d8d63b655716','47bf48f95b9a4c67855b091e3d1003de','etc:attribute','etc:attribute','65947ffd4e364921a42c465d94a78c09',1459816161154,NULL,0,'attribute','attribute',NULL,NULL,NULL,0,'e4639a3fb91d43a49bf595de9c390d53',10005),('2eee186e51494f0a874fe61ff24b7192','1730a44d087442cc96c2d8d63b655716','etc:attribute:entities','etc:attribute:entities','65947ffd4e364921a42c465d94a78c09',1459816168081,'65947ffd4e364921a42c465d94a78c09',1459816168103,'entities','entities','folder for built in Grouper entities attributes',NULL,NULL,1,'247582158264478682b29d418654f9bb',10012),('36792aa7956240feb1bb6025c56ff2f3','44824fdcdd0e435ab9eafc2a40e430c1','etc:legacy:attribute','etc:legacy:attribute','65947ffd4e364921a42c465d94a78c09',1459816161028,'65947ffd4e364921a42c465d94a78c09',1459816161100,'attribute','attribute','Folder for legacy attributes.  Do not delete.',NULL,NULL,1,'d8211cfa1a6b4abf99f5fab807eae57e',10004),('44824fdcdd0e435ab9eafc2a40e430c1','47bf48f95b9a4c67855b091e3d1003de','etc:legacy','etc:legacy','65947ffd4e364921a42c465d94a78c09',1459816160923,NULL,0,'legacy','legacy',NULL,NULL,NULL,0,'4f6e7d1adb7648b1a98d6a407eafb323',10003),('47bf48f95b9a4c67855b091e3d1003de','d83a1feb851d4ede95786362de79547d','etc','etc','65947ffd4e364921a42c465d94a78c09',1459816159685,NULL,0,'etc','etc',NULL,NULL,NULL,0,'ea8757bd8a5e4fcb8d05e62bd36a6da4',10002),('6cd4d8196fe24d21acd51cdf8fcdb3cc','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrLoader','etc:attribute:attrLoader','65947ffd4e364921a42c465d94a78c09',1459816164192,'65947ffd4e364921a42c465d94a78c09',1459816164231,'attrLoader','attrLoader','folder for built in Grouper loader attributes',NULL,NULL,1,'253f8398dd0643ba99472aad14409f41',10009),('b6bc2fcd772146ee970347e496538926','1730a44d087442cc96c2d8d63b655716','etc:attribute:permissionLimits','etc:attribute:permissionLimits','65947ffd4e364921a42c465d94a78c09',1459816163651,'65947ffd4e364921a42c465d94a78c09',1459816163689,'permissionLimits','permissionLimits','folder for built in Grouper permission limits',NULL,NULL,1,'1a1948141e0143c1a7a92641d494fe97',10008),('cb1bfad6c8ed424d902b65d9ec275df0','1730a44d087442cc96c2d8d63b655716','etc:attribute:userData','etc:attribute:userData','65947ffd4e364921a42c465d94a78c09',1459816167270,'65947ffd4e364921a42c465d94a78c09',1459816167348,'userData','userData','folder for built in Grouper user data attributes',NULL,NULL,1,'e7d2e5bb9a214c98afe09f3e43fdc45e',10011),('d5248b39d72f4fdcb730d1be03de4fbc','1730a44d087442cc96c2d8d63b655716','etc:attribute:attrExternalSubjectInvite','etc:attribute:attrExternalSubjectInvite','65947ffd4e364921a42c465d94a78c09',1459816161249,'65947ffd4e364921a42c465d94a78c09',1459816161308,'attrExternalSubjectInvite','attrExternalSubjectInvite','folder for built in external subject invite attributes, and holds the data via attributes for invites.  Dont delete this folder',NULL,NULL,1,'10df232bdb154681a373bf730966154f',10006),('d83a1feb851d4ede95786362de79547d',NULL,':',':','65947ffd4e364921a42c465d94a78c09',1459816158391,NULL,0,':',':',NULL,NULL,NULL,0,NULL,10000),('fc88a71ee4574ae7b0a550d72b5172d9','1730a44d087442cc96c2d8d63b655716','etc:attribute:rules','etc:attribute:rules','65947ffd4e364921a42c465d94a78c09',1459816162253,'65947ffd4e364921a42c465d94a78c09',1459816162311,'rules','rules','folder for built in Grouper rules attributes',NULL,NULL,1,'916b5eab7ecb4ee6a74c707c50586a5c',10007);
/*!40000 ALTER TABLE `grouper_stems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `grouper_stems_v`
--

DROP TABLE IF EXISTS `grouper_stems_v`;
/*!50001 DROP VIEW IF EXISTS `grouper_stems_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `grouper_stems_v` (
  `EXTENSION` tinyint NOT NULL,
  `NAME` tinyint NOT NULL,
  `DISPLAY_EXTENSION` tinyint NOT NULL,
  `DISPLAY_NAME` tinyint NOT NULL,
  `DESCRIPTION` tinyint NOT NULL,
  `PARENT_STEM_NAME` tinyint NOT NULL,
  `PARENT_STEM_DISPLAYNAME` tinyint NOT NULL,
  `CREATOR_SOURCE` tinyint NOT NULL,
  `CREATOR_SUBJECT_ID` tinyint NOT NULL,
  `MODIFIER_SOURCE` tinyint NOT NULL,
  `MODIFIER_SUBJECT_ID` tinyint NOT NULL,
  `CREATE_TIME` tinyint NOT NULL,
  `CREATOR_ID` tinyint NOT NULL,
  `STEM_ID` tinyint NOT NULL,
  `MODIFIER_ID` tinyint NOT NULL,
  `MODIFY_TIME` tinyint NOT NULL,
  `PARENT_STEM` tinyint NOT NULL,
  `HIBERNATE_VERSION_NUMBER` tinyint NOT NULL,
  `CONTEXT_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `grouper_table_index`
--

DROP TABLE IF EXISTS `grouper_table_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grouper_table_index` (
  `id` varchar(40) COLLATE utf8_bin NOT NULL,
  `type` varchar(32) COLLATE utf8_bin NOT NULL,
  `last_index_reserved` bigint(20) DEFAULT NULL,
  `created_on` bigint(20) DEFAULT NULL,
  `last_updated` bigint(20) DEFAULT NULL,
  `hibernate_version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `table_index_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grouper_table_index`
--

LOCK TABLES `grouper_table_index` WRITE;
/*!40000 ALTER TABLE `grouper_table_index` DISABLE KEYS */;
INSERT INTO `grouper_table_index` VALUES ('dc4598913f474da593f8f0fb92e9229c','attributeDef',10016,1459816161357,1459816168558,15),('f2af43480df4426c902e0ed342f785ae','stem',10012,1459816158412,1459816168082,11),('fc536cefdf4348f69239ac4e8f7ab0fc','attributeDefName',10107,1459816161603,1459816168792,106);
/*!40000 ALTER TABLE `grouper_table_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject` (
  `subjectId` varchar(255) COLLATE utf8_bin NOT NULL,
  `subjectTypeId` varchar(32) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`subjectId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjectattribute`
--

DROP TABLE IF EXISTS `subjectattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjectattribute` (
  `subjectId` varchar(255) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `value` varchar(255) COLLATE utf8_bin NOT NULL,
  `searchValue` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`subjectId`,`name`,`value`),
  UNIQUE KEY `searchattribute_id_name_idx` (`subjectId`,`name`),
  KEY `searchattribute_value_idx` (`value`),
  KEY `searchattribute_name_idx` (`name`),
  CONSTRAINT `fk_subjectattr_subjectid` FOREIGN KEY (`subjectId`) REFERENCES `subject` (`subjectId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjectattribute`
--

LOCK TABLES `subjectattribute` WRITE;
/*!40000 ALTER TABLE `subjectattribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `subjectattribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `grouper`
--

USE `grouper`;

--
-- Final view structure for view `grouper_attr_asn_asn_attrdef_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_asn_attrdef_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_attrdef_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_asn_attrdef_v` AS select `gad`.`name` AS `name_of_attr_def_assigned_to`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gad`.`id` AS `id_of_attr_def_assigned_to`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2` from ((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_attribute_def` `gad`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) where ((`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gad`.`id` = `gaa1`.`owner_attribute_def_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_asn_efmship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_asn_efmship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_efmship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_asn_efmship_v` AS select distinct `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gf`.`name` AS `list_name`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gg`.`id` AS `group_id`,`gm`.`id` AS `member_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2` from (((((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_groups` `gg`) join `grouper_memberships_all_v` `gmav`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) where ((`gaa1`.`owner_member_id` = `gmav`.`MEMBER_ID`) and (`gaa1`.`owner_group_id` = `gmav`.`OWNER_GROUP_ID`) and (`gaa2`.`owner_attribute_assign_id` = `gaa1`.`id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gmav`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gf`.`type` = 'list') and (`gaa1`.`owner_member_id` is not null) and (`gaa1`.`owner_group_id` is not null) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_asn_group_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_asn_group_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_group_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_asn_group_v` AS select `gg`.`name` AS `group_name`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gg`.`display_name` AS `group_display_name`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gg`.`id` AS `group_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2` from ((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_groups` `gg`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) where ((`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gg`.`id` = `gaa1`.`owner_group_id`) and isnull(`gaa1`.`owner_member_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_asn_member_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_asn_member_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_member_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_asn_member_v` AS select `gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gm`.`id` AS `member_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2` from ((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_members` `gm`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) where ((`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gm`.`id` = `gaa1`.`owner_member_id`) and isnull(`gaa1`.`owner_group_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_asn_mship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_asn_mship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_mship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_asn_mship_v` AS select `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gf`.`name` AS `list_name`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gg`.`id` AS `group_id`,`gms`.`id` AS `membership_id`,`gm`.`id` AS `member_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2` from (((((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_groups` `gg`) join `grouper_memberships` `gms`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) where ((`gaa1`.`owner_membership_id` = `gms`.`id`) and (`gaa2`.`owner_attribute_assign_id` = `gaa1`.`id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gms`.`field_id` = `gf`.`id`) and (`gms`.`member_id` = `gm`.`id`) and (`gms`.`owner_group_id` = `gg`.`id`) and (`gf`.`type` = 'list') and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_asn_stem_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_asn_stem_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_asn_stem_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_asn_stem_v` AS select `gs`.`name` AS `stem_name`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gs`.`display_name` AS `stem_display_name`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gs`.`id` AS `stem_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2` from ((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_stems` `gs`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) where ((`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gs`.`id` = `gaa1`.`owner_stem_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_attrdef_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_attrdef_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_attrdef_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_attrdef_v` AS select `gad_assigned_to`.`name` AS `name_of_attr_def_assigned_to`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def_assigned`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gad_assigned_to`.`id` AS `id_of_attr_def_assigned_to`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id` from ((((`grouper_attribute_assign` `gaa` join `grouper_attribute_def` `gad_assigned_to`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) where ((`gaa`.`owner_attribute_def_id` = `gad_assigned_to`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_efmship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_efmship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_efmship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_efmship_v` AS select distinct `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gg`.`display_name` AS `group_display_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gf`.`name` AS `list_name`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gg`.`id` AS `group_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gaaa`.`id` AS `action_id` from (((((((`grouper_attribute_assign` `gaa` join `grouper_memberships_all_v` `gmav`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_groups` `gg`) join `grouper_fields` `gf`) join `grouper_members` `gm`) join `grouper_attr_assign_action` `gaaa`) where ((`gaa`.`owner_group_id` = `gmav`.`OWNER_GROUP_ID`) and (`gaa`.`owner_member_id` = `gmav`.`MEMBER_ID`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gf`.`type` = 'list') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gaa`.`owner_member_id` is not null) and (`gaa`.`owner_group_id` is not null) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_group_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_group_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_group_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_group_v` AS select `gg`.`name` AS `group_name`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gg`.`display_name` AS `group_display_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gg`.`id` AS `group_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id` from ((((`grouper_attribute_assign` `gaa` join `grouper_groups` `gg`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) where ((`gaa`.`owner_group_id` = `gg`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and isnull(`gaa`.`owner_member_id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_member_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_member_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_member_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_member_v` AS select `gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gm`.`id` AS `member_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id` from ((((`grouper_attribute_assign` `gaa` join `grouper_members` `gm`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) where ((`gaa`.`owner_member_id` = `gm`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and isnull(`gaa`.`owner_group_id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_mship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_mship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_mship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_mship_v` AS select `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gf`.`name` AS `list_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gg`.`id` AS `group_id`,`gms`.`id` AS `membership_id`,`gm`.`id` AS `member_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id` from (((((((`grouper_attribute_assign` `gaa` join `grouper_groups` `gg`) join `grouper_memberships` `gms`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attr_assign_action` `gaaa`) where ((`gaa`.`owner_membership_id` = `gms`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gms`.`field_id` = `gf`.`id`) and (`gms`.`member_id` = `gm`.`id`) and (`gms`.`owner_group_id` = `gg`.`id`) and (`gf`.`type` = 'list') and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_asn_stem_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_asn_stem_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_asn_stem_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_asn_stem_v` AS select `gs`.`name` AS `stem_name`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gs`.`display_name` AS `stem_display_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gs`.`id` AS `stem_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id` from ((((`grouper_attribute_assign` `gaa` join `grouper_stems` `gs`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) where ((`gaa`.`owner_stem_id` = `gs`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_assn_action_set_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_assn_action_set_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_assn_action_set_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_assn_action_set_v` AS select `ifHas`.`name` AS `if_has_attr_assn_action_name`,`thenHas`.`name` AS `then_has_attr_assn_action_name`,`gaaas`.`depth` AS `depth`,`gaaas`.`type` AS `type`,`gaaaParentIfHas`.`name` AS `parent_if_has_name`,`gaaaParentThenHas`.`name` AS `parent_then_has_name`,`gaaas`.`id` AS `id`,`ifHas`.`id` AS `if_has_attr_assn_action_id`,`thenHas`.`id` AS `then_has_attr_assn_action_id`,`gaaas`.`parent_attr_assn_action_id` AS `parent_attr_assn_action_id` from (((((`grouper_attr_assign_action_set` `gaaas` join `grouper_attr_assign_action_set` `gaaasParent`) join `grouper_attr_assign_action` `gaaaParentIfHas`) join `grouper_attr_assign_action` `gaaaParentThenHas`) join `grouper_attr_assign_action` `ifHas`) join `grouper_attr_assign_action` `thenHas`) where ((`thenHas`.`id` = `gaaas`.`then_has_attr_assn_action_id`) and (`ifHas`.`id` = `gaaas`.`if_has_attr_assn_action_id`) and (`gaaas`.`parent_attr_assn_action_id` = `gaaasParent`.`id`) and (`gaaaParentIfHas`.`id` = `gaaasParent`.`if_has_attr_assn_action_id`) and (`gaaaParentThenHas`.`id` = `gaaasParent`.`then_has_attr_assn_action_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_def_name_set_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_def_name_set_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_def_name_set_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_def_name_set_v` AS select `ifHas`.`name` AS `if_has_attr_def_name_name`,`thenHas`.`name` AS `then_has_attr_def_name_name`,`gadns`.`depth` AS `depth`,`gadns`.`type` AS `type`,`gadnParentIfHas`.`name` AS `parent_if_has_name`,`gadnParentThenHas`.`name` AS `parent_then_has_name`,`gadns`.`id` AS `id`,`ifHas`.`id` AS `if_has_attr_def_name_id`,`thenHas`.`id` AS `then_has_attr_def_name_id`,`gadns`.`parent_attr_def_name_set_id` AS `parent_attr_def_name_set_id` from (((((`grouper_attribute_def_name_set` `gadns` join `grouper_attribute_def_name_set` `gadnsParent`) join `grouper_attribute_def_name` `gadnParentIfHas`) join `grouper_attribute_def_name` `gadnParentThenHas`) join `grouper_attribute_def_name` `ifHas`) join `grouper_attribute_def_name` `thenHas`) where ((`thenHas`.`id` = `gadns`.`then_has_attribute_def_name_id`) and (`ifHas`.`id` = `gadns`.`if_has_attribute_def_name_id`) and (`gadns`.`parent_attr_def_name_set_id` = `gadnsParent`.`id`) and (`gadnParentIfHas`.`id` = `gadnsParent`.`if_has_attribute_def_name_id`) and (`gadnParentThenHas`.`id` = `gadnsParent`.`then_has_attribute_def_name_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_attr_def_priv_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_attr_def_priv_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_attr_def_priv_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_attr_def_priv_v` AS select distinct `gm`.`subject_id` AS `subject_id`,`gm`.`subject_source` AS `subject_source_id`,`gf`.`name` AS `field_name`,`gad`.`name` AS `attribute_def_name`,`gad`.`description` AS `attribute_def_description`,`gad`.`attribute_def_type` AS `attribute_def_type`,`gad`.`stem_id` AS `attribute_def_stem_id`,`gad`.`id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gmav`.`FIELD_ID` AS `field_id`,`gmav`.`IMMEDIATE_MEMBERSHIP_ID` AS `immediate_membership_id`,`gmav`.`MEMBERSHIP_ID` AS `membership_id` from (((`grouper_memberships_all_v` `gmav` join `grouper_attribute_def` `gad`) join `grouper_fields` `gf`) join `grouper_members` `gm`) where ((`gmav`.`OWNER_ATTR_DEF_ID` = `gad`.`id`) and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`MEMBER_ID` = `gm`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_audit_entry_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_audit_entry_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_audit_entry_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_audit_entry_v` AS select `gae`.`created_on` AS `created_on`,`gat`.`audit_category` AS `audit_category`,`gat`.`action_name` AS `action_name`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gae`.`logged_in_member_id`)) AS `logged_in_subject_id`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gae`.`act_as_member_id`)) AS `act_as_subject_id`,`gat`.`label_string01` AS `label_string01`,`gae`.`string01` AS `string01`,`gat`.`label_string02` AS `label_string02`,`gae`.`string02` AS `string02`,`gat`.`label_string03` AS `label_string03`,`gae`.`string03` AS `string03`,`gat`.`label_string04` AS `label_string04`,`gae`.`string04` AS `string04`,`gat`.`label_string05` AS `label_string05`,`gae`.`string05` AS `string05`,`gat`.`label_string06` AS `label_string06`,`gae`.`string06` AS `string06`,`gat`.`label_string07` AS `label_string07`,`gae`.`string07` AS `string07`,`gat`.`label_string08` AS `label_string08`,`gae`.`string08` AS `string08`,`gat`.`label_int01` AS `label_int01`,`gae`.`int01` AS `int01`,`gat`.`label_int02` AS `label_int02`,`gae`.`int02` AS `int02`,`gat`.`label_int03` AS `label_int03`,`gae`.`int03` AS `int03`,`gat`.`label_int04` AS `label_int04`,`gae`.`int04` AS `int04`,`gat`.`label_int05` AS `label_int05`,`gae`.`int05` AS `int05`,`gae`.`context_id` AS `context_id`,`gae`.`grouper_engine` AS `grouper_engine`,`gae`.`description` AS `description`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gae`.`logged_in_member_id`)) AS `logged_in_source_id`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gae`.`act_as_member_id`)) AS `act_as_source_id`,`gae`.`logged_in_member_id` AS `logged_in_member_id`,`gae`.`act_as_member_id` AS `act_as_member_id`,`gat`.`id` AS `audit_type_id`,`gae`.`user_ip_address` AS `user_ip_address`,`gae`.`server_host` AS `server_host`,`gae`.`last_updated` AS `audit_entry_last_updated`,`gae`.`id` AS `audit_entry_id`,`gae`.`grouper_version` AS `grouper_version`,`gae`.`env_name` AS `env_name` from (`grouper_audit_type` `gat` join `grouper_audit_entry` `gae`) where (`gat`.`id` = `gae`.`audit_type_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_asn_attrdef_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_asn_attrdef_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_attrdef_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_asn_attrdef_v` AS select `gad`.`name` AS `name_of_attr_def_assigned_to`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gad`.`id` AS `id_of_attr_def_assigned_to`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2`,`gaav`.`id` AS `attribute_assign_value_id` from (((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_attribute_def` `gad`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa2`.`id`) and (`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gad`.`id` = `gaa1`.`owner_attribute_def_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_asn_efmship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_asn_efmship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_efmship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_asn_efmship_v` AS select distinct `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gf`.`name` AS `list_name`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gg`.`id` AS `group_id`,`gm`.`id` AS `member_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2`,`gaav`.`id` AS `attribute_assign_value_id` from ((((((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_groups` `gg`) join `grouper_memberships_all_v` `gmav`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa2`.`id`) and (`gaa1`.`owner_member_id` = `gmav`.`MEMBER_ID`) and (`gaa1`.`owner_group_id` = `gmav`.`OWNER_GROUP_ID`) and (`gaa2`.`owner_attribute_assign_id` = `gaa1`.`id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gmav`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gf`.`type` = 'list') and (`gaa1`.`owner_member_id` is not null) and (`gaa1`.`owner_group_id` is not null) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_asn_group_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_asn_group_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_group_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_asn_group_v` AS select `gg`.`name` AS `group_name`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gg`.`display_name` AS `group_display_name`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gg`.`id` AS `group_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2`,`gaav`.`id` AS `attribute_assign_value_id` from (((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_groups` `gg`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa2`.`id`) and (`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gg`.`id` = `gaa1`.`owner_group_id`) and isnull(`gaa1`.`owner_member_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_asn_member_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_asn_member_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_member_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_asn_member_v` AS select `gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gm`.`id` AS `member_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2`,`gaav`.`id` AS `attribute_assign_value_id` from (((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_members` `gm`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa2`.`id`) and (`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gm`.`id` = `gaa1`.`owner_member_id`) and isnull(`gaa1`.`owner_group_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_asn_mship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_asn_mship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_mship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_asn_mship_v` AS select `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gf`.`name` AS `list_name`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gg`.`id` AS `group_id`,`gms`.`id` AS `membership_id`,`gm`.`id` AS `member_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2`,`gaav`.`id` AS `attribute_assign_value_id` from ((((((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_groups` `gg`) join `grouper_memberships` `gms`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa2`.`id`) and (`gaa1`.`owner_membership_id` = `gms`.`id`) and (`gaa2`.`owner_attribute_assign_id` = `gaa1`.`id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gms`.`field_id` = `gf`.`id`) and (`gms`.`member_id` = `gm`.`id`) and (`gms`.`owner_group_id` = `gg`.`id`) and (`gf`.`type` = 'list') and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_asn_stem_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_asn_stem_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_asn_stem_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_asn_stem_v` AS select `gs`.`name` AS `stem_name`,`gaaa1`.`name` AS `action1`,`gaaa2`.`name` AS `action2`,`gadn1`.`name` AS `attribute_def_name_name1`,`gadn2`.`name` AS `attribute_def_name_name2`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gs`.`display_name` AS `stem_display_name`,`gadn1`.`display_name` AS `attribute_def_name_disp_name1`,`gadn2`.`display_name` AS `attribute_def_name_disp_name2`,`gad1`.`name` AS `name_of_attribute_def1`,`gad2`.`name` AS `name_of_attribute_def2`,`gaa1`.`notes` AS `attribute_assign_notes1`,`gaa2`.`notes` AS `attribute_assign_notes2`,`gaa2`.`enabled` AS `enabled2`,`gaa2`.`enabled_time` AS `enabled_time2`,`gaa2`.`disabled_time` AS `disabled_time2`,`gs`.`id` AS `stem_id`,`gaa1`.`id` AS `attribute_assign_id1`,`gaa2`.`id` AS `attribute_assign_id2`,`gadn1`.`id` AS `attribute_def_name_id1`,`gadn2`.`id` AS `attribute_def_name_id2`,`gad1`.`id` AS `attribute_def_id1`,`gad2`.`id` AS `attribute_def_id2`,`gaaa1`.`id` AS `action_id1`,`gaaa2`.`id` AS `action_id2`,`gaav`.`id` AS `attribute_assign_value_id` from (((((((((`grouper_attribute_assign` `gaa1` join `grouper_attribute_assign` `gaa2`) join `grouper_stems` `gs`) join `grouper_attribute_def_name` `gadn1`) join `grouper_attribute_def_name` `gadn2`) join `grouper_attribute_def` `gad1`) join `grouper_attribute_def` `gad2`) join `grouper_attr_assign_action` `gaaa1`) join `grouper_attr_assign_action` `gaaa2`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa2`.`id`) and (`gaa1`.`id` = `gaa2`.`owner_attribute_assign_id`) and (`gaa1`.`attribute_def_name_id` = `gadn1`.`id`) and (`gaa2`.`attribute_def_name_id` = `gadn2`.`id`) and (`gadn1`.`attribute_def_id` = `gad1`.`id`) and (`gadn2`.`attribute_def_id` = `gad2`.`id`) and (`gaa1`.`enabled` = 'T') and (`gs`.`id` = `gaa1`.`owner_stem_id`) and (`gaa1`.`attribute_assign_action_id` = `gaaa1`.`id`) and (`gaa2`.`attribute_assign_action_id` = `gaaa2`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_attrdef_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_attrdef_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_attrdef_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_attrdef_v` AS select `gad_assigned_to`.`name` AS `name_of_attr_def_assigned_to`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def_assigned`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gad_assigned_to`.`id` AS `id_of_attr_def_assigned_to`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id`,`gaav`.`id` AS `attribute_assign_value_id` from (((((`grouper_attribute_assign` `gaa` join `grouper_attribute_def` `gad_assigned_to`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`owner_attribute_def_id` = `gad_assigned_to`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_efmship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_efmship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_efmship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_efmship_v` AS select distinct `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gg`.`display_name` AS `group_display_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gf`.`name` AS `list_name`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gg`.`id` AS `group_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gaaa`.`id` AS `action_id`,`gaav`.`id` AS `attribute_assign_value_id` from ((((((((`grouper_attribute_assign` `gaa` join `grouper_memberships_all_v` `gmav`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_groups` `gg`) join `grouper_fields` `gf`) join `grouper_members` `gm`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`owner_group_id` = `gmav`.`OWNER_GROUP_ID`) and (`gaa`.`owner_member_id` = `gmav`.`MEMBER_ID`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gf`.`type` = 'list') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gaa`.`owner_member_id` is not null) and isnull(`gaa`.`owner_group_id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_group_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_group_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_group_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_group_v` AS select `gg`.`name` AS `group_name`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gg`.`display_name` AS `group_display_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gg`.`id` AS `group_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id`,`gaav`.`id` AS `attribute_assign_value_id` from (((((`grouper_attribute_assign` `gaa` join `grouper_groups` `gg`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`owner_group_id` = `gg`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and isnull(`gaa`.`owner_member_id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_member_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_member_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_member_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_member_v` AS select `gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gm`.`id` AS `member_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id`,`gaav`.`id` AS `attribute_assign_value_id` from (((((`grouper_attribute_assign` `gaa` join `grouper_members` `gm`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`owner_member_id` = `gm`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and isnull(`gaa`.`owner_group_id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_mship_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_mship_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_mship_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_mship_v` AS select `gg`.`name` AS `group_name`,`gm`.`subject_source` AS `source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gf`.`name` AS `list_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gg`.`id` AS `group_id`,`gms`.`id` AS `membership_id`,`gm`.`id` AS `member_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id`,`gaav`.`id` AS `attribute_assign_value_id` from ((((((((`grouper_attribute_assign` `gaa` join `grouper_groups` `gg`) join `grouper_memberships` `gms`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`owner_membership_id` = `gms`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gms`.`field_id` = `gf`.`id`) and (`gms`.`member_id` = `gm`.`id`) and (`gms`.`owner_group_id` = `gg`.`id`) and (`gf`.`type` = 'list') and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_aval_asn_stem_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_aval_asn_stem_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_aval_asn_stem_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_aval_asn_stem_v` AS select `gs`.`name` AS `stem_name`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gaav`.`value_string` AS `value_string`,`gaav`.`value_integer` AS `value_integer`,`gaav`.`value_floating` AS `value_floating`,`gaav`.`value_member_id` AS `value_member_id`,`gs`.`display_name` AS `stem_display_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gad`.`name` AS `name_of_attribute_def`,`gaa`.`notes` AS `attribute_assign_notes`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gs`.`id` AS `stem_id`,`gaa`.`id` AS `attribute_assign_id`,`gadn`.`id` AS `attribute_def_name_id`,`gad`.`id` AS `attribute_def_id`,`gaaa`.`id` AS `action_id`,`gaav`.`id` AS `attribute_assign_value_id` from (((((`grouper_attribute_assign` `gaa` join `grouper_stems` `gs`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def` `gad`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attribute_assign_value` `gaav`) where ((`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`owner_stem_id` = `gs`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gaa`.`attribute_assign_action_id` = `gaaa`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_change_log_entry_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_change_log_entry_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_change_log_entry_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_change_log_entry_v` AS select `gcle`.`created_on` AS `created_on`,`gclt`.`change_log_category` AS `change_log_category`,`gclt`.`action_name` AS `action_name`,`gcle`.`sequence_number` AS `sequence_number`,`gclt`.`label_string01` AS `label_string01`,`gcle`.`string01` AS `string01`,`gclt`.`label_string02` AS `label_string02`,`gcle`.`string02` AS `string02`,`gclt`.`label_string03` AS `label_string03`,`gcle`.`string03` AS `string03`,`gclt`.`label_string04` AS `label_string04`,`gcle`.`string04` AS `string04`,`gclt`.`label_string05` AS `label_string05`,`gcle`.`string05` AS `string05`,`gclt`.`label_string06` AS `label_string06`,`gcle`.`string06` AS `string06`,`gclt`.`label_string07` AS `label_string07`,`gcle`.`string07` AS `string07`,`gclt`.`label_string08` AS `label_string08`,`gcle`.`string08` AS `string08`,`gclt`.`label_string09` AS `label_string09`,`gcle`.`string09` AS `string09`,`gclt`.`label_string10` AS `label_string10`,`gcle`.`string10` AS `string10`,`gclt`.`label_string11` AS `label_string11`,`gcle`.`string11` AS `string11`,`gclt`.`label_string12` AS `label_string12`,`gcle`.`string12` AS `string12`,`gcle`.`context_id` AS `context_id`,`gcle`.`change_log_type_id` AS `change_log_type_id` from (`grouper_change_log_type` `gclt` join `grouper_change_log_entry` `gcle`) where (`gclt`.`id` = `gcle`.`change_log_type_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_composites_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_composites_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_composites_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_composites_v` AS select (select `gg`.`name` from `grouper_groups` `gg` where (`gg`.`id` = `gc`.`owner`)) AS `OWNER_GROUP_NAME`,`gc`.`type` AS `COMPOSITE_TYPE`,(select `gg`.`name` from `grouper_groups` `gg` where (`gg`.`id` = `gc`.`left_factor`)) AS `LEFT_FACTOR_GROUP_NAME`,(select `gg`.`name` from `grouper_groups` `gg` where (`gg`.`id` = `gc`.`right_factor`)) AS `RIGHT_FACTOR_GROUP_NAME`,(select `gg`.`display_name` from `grouper_groups` `gg` where (`gg`.`id` = `gc`.`owner`)) AS `OWNER_GROUP_DISPLAYNAME`,(select `gg`.`display_name` from `grouper_groups` `gg` where (`gg`.`id` = `gc`.`left_factor`)) AS `LEFT_FACTOR_GROUP_DISPLAYNAME`,(select `gg`.`display_name` from `grouper_groups` `gg` where (`gg`.`id` = `gc`.`right_factor`)) AS `RIGHT_FACTOR_GROUP_DISPLAYNAME`,`gc`.`owner` AS `owner_group_id`,`gc`.`left_factor` AS `LEFT_FACTOR_GROUP_ID`,`gc`.`right_factor` AS `RIGHT_FACTOR_GROUP_ID`,`gc`.`id` AS `COMPOSITE_ID`,`gc`.`create_time` AS `CREATE_TIME`,`gc`.`creator_id` AS `CREATOR_ID`,`gc`.`hibernate_version_number` AS `HIBERNATE_VERSION_NUMBER`,`gc`.`context_id` AS `CONTEXT_ID` from `grouper_composites` `gc` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_ext_subj_invite_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_ext_subj_invite_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_ext_subj_invite_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_ext_subj_invite_v` AS select (select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteUuid') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `invite_id`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteMemberId') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `invite_member_id`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteDate') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `invite_date`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectEmailAddress') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `email_address`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmailWhenRegistered') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `invite_email_when_registered`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteGroupUuids') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `invite_group_uuids`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `invite_expire_date`,(select `gaav`.`value_string` from (`grouper_attr_asn_asn_stem_v` `gaaasv` join `grouper_attribute_assign_value` `gaav`) where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteEmail') and (`gaav`.`attribute_assign_id` = `gaaasv`.`attribute_assign_id2`) and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `email_body`,(select `gaaasv`.`disabled_time2` from `grouper_attr_asn_asn_stem_v` `gaaasv` where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate') and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `expire_attr_expire_date`,(select `gaaasv`.`enabled2` from `grouper_attr_asn_asn_stem_v` `gaaasv` where ((`gaaasv`.`attribute_def_name_name2` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInviteExpireDate') and (`gaaasv`.`attribute_assign_id1` = `gaasv`.`attribute_assign_id`))) AS `expire_attr_enabled`,`gaasv`.`disabled_time` AS `assignment_expire_date`,`gaasv`.`enabled` AS `assignment_enabled`,`gaasv`.`attribute_assign_id` AS `attribute_assign_id` from `grouper_attr_asn_stem_v` `gaasv` where ((`gaasv`.`attribute_def_name_name` = 'etc:attribute:attrExternalSubjectInvite:externalSubjectInvite') and (`gaasv`.`enabled` = 'T')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_ext_subj_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_ext_subj_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_ext_subj_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_ext_subj_v` AS select `ges`.`uuid` AS `uuid`,`ges`.`name` AS `name`,`ges`.`identifier` AS `identifier`,`ges`.`description` AS `description`,`ges`.`institution` AS `institution`,`ges`.`email` AS `email`,`ges`.`search_string_lower` AS `search_string_lower` from `grouper_ext_subj` `ges` where (`ges`.`enabled` = 'T') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_groups_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_groups_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_groups_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_groups_v` AS select `gg`.`extension` AS `EXTENSION`,`gg`.`name` AS `NAME`,`gg`.`display_extension` AS `DISPLAY_EXTENSION`,`gg`.`display_name` AS `DISPLAY_NAME`,`gg`.`description` AS `DESCRIPTION`,`gs`.`name` AS `PARENT_STEM_NAME`,`gg`.`type_of_group` AS `TYPE_OF_GROUP`,`gg`.`id` AS `GROUP_ID`,`gs`.`id` AS `PARENT_STEM_ID`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`modifier_id`)) AS `MODIFIER_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`modifier_id`)) AS `MODIFIER_SUBJECT_ID`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`creator_id`)) AS `CREATOR_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`creator_id`)) AS `CREATOR_SUBJECT_ID`,(select distinct 'T' from `grouper_composites` `gc` where (`gc`.`owner` = `gg`.`id`)) AS `IS_COMPOSITE_OWNER`,(select distinct 'T' from `grouper_composites` `gc` where ((`gc`.`left_factor` = `gg`.`id`) or (`gc`.`right_factor` = `gg`.`id`))) AS `IS_COMPOSITE_FACTOR`,`gg`.`creator_id` AS `CREATOR_ID`,`gg`.`create_time` AS `CREATE_TIME`,`gg`.`modifier_id` AS `MODIFIER_ID`,`gg`.`modify_time` AS `MODIFY_TIME`,`gg`.`hibernate_version_number` AS `HIBERNATE_VERSION_NUMBER`,`gg`.`context_id` AS `CONTEXT_ID` from (`grouper_groups` `gg` join `grouper_stems` `gs`) where (`gg`.`parent_stem` = `gs`.`id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_memberships_all_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_memberships_all_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_memberships_all_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_memberships_all_v` AS select concat(`ms`.`id`,':',`gs`.`id`) AS `MEMBERSHIP_ID`,`ms`.`id` AS `IMMEDIATE_MEMBERSHIP_ID`,`gs`.`id` AS `GROUP_SET_ID`,`ms`.`member_id` AS `MEMBER_ID`,`gs`.`field_id` AS `FIELD_ID`,`ms`.`field_id` AS `IMMEDIATE_FIELD_ID`,`gs`.`owner_id` AS `OWNER_ID`,`gs`.`owner_attr_def_id` AS `OWNER_ATTR_DEF_ID`,`gs`.`owner_group_id` AS `OWNER_GROUP_ID`,`gs`.`owner_stem_id` AS `OWNER_STEM_ID`,`gs`.`via_group_id` AS `VIA_GROUP_ID`,`ms`.`via_composite_id` AS `VIA_COMPOSITE_ID`,`gs`.`depth` AS `DEPTH`,`gs`.`mship_type` AS `MSHIP_TYPE`,`ms`.`enabled` AS `IMMEDIATE_MSHIP_ENABLED`,`ms`.`enabled_timestamp` AS `IMMEDIATE_MSHIP_ENABLED_TIME`,`ms`.`disabled_timestamp` AS `IMMEDIATE_MSHIP_DISABLED_TIME`,`gs`.`parent_id` AS `GROUP_SET_PARENT_ID`,`ms`.`creator_id` AS `MEMBERSHIP_CREATOR_ID`,`ms`.`create_time` AS `MEMBERSHIP_CREATE_TIME`,`gs`.`creator_id` AS `GROUP_SET_CREATOR_ID`,`gs`.`create_time` AS `GROUP_SET_CREATE_TIME`,`ms`.`hibernate_version_number` AS `HIBERNATE_VERSION_NUMBER`,`ms`.`context_id` AS `CONTEXT_ID` from (`grouper_memberships` `ms` join `grouper_group_set` `gs`) where ((`ms`.`owner_id` = `gs`.`member_id`) and (`ms`.`field_id` = `gs`.`member_field_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_memberships_lw_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_memberships_lw_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_memberships_lw_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_memberships_lw_v` AS select distinct `gm`.`subject_id` AS `SUBJECT_ID`,`gm`.`subject_source` AS `SUBJECT_SOURCE`,`gg`.`name` AS `GROUP_NAME`,`gfl`.`name` AS `LIST_NAME`,`gfl`.`type` AS `LIST_TYPE`,`gg`.`id` AS `GROUP_ID`,`gm`.`id` AS `MEMBER_ID` from (((`grouper_memberships_all_v` `gms` join `grouper_members` `gm`) join `grouper_groups` `gg`) join `grouper_fields` `gfl`) where ((`gms`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gms`.`FIELD_ID` = `gfl`.`id`) and (`gms`.`MEMBER_ID` = `gm`.`id`) and (`gms`.`IMMEDIATE_MSHIP_ENABLED` = 'T')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_memberships_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_memberships_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_memberships_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_memberships_v` AS select (select `gg`.`name` from `grouper_groups` `gg` where (`gg`.`id` = `gms`.`OWNER_GROUP_ID`)) AS `GROUP_NAME`,(select `gg`.`display_name` from `grouper_groups` `gg` where (`gg`.`id` = `gms`.`OWNER_GROUP_ID`)) AS `GROUP_DISPLAYNAME`,(select `gs`.`name` from `grouper_stems` `gs` where (`gs`.`id` = `gms`.`OWNER_STEM_ID`)) AS `STEM_NAME`,(select `gs`.`display_name` from `grouper_stems` `gs` where (`gs`.`id` = `gms`.`OWNER_STEM_ID`)) AS `STEM_DISPLAYNAME`,`gm`.`subject_id` AS `SUBJECT_ID`,`gm`.`subject_source` AS `SUBJECT_SOURCE`,`gms`.`MEMBER_ID` AS `MEMBER_ID`,`gf`.`type` AS `LIST_TYPE`,`gf`.`name` AS `LIST_NAME`,`gms`.`MSHIP_TYPE` AS `MEMBERSHIP_TYPE`,(select `gg`.`name` from (`grouper_groups` `gg` join `grouper_composites` `gc`) where ((`gg`.`id` = `gms`.`VIA_COMPOSITE_ID`) and (`gg`.`id` = `gc`.`owner`))) AS `COMPOSITE_PARENT_GROUP_NAME`,`gms`.`DEPTH` AS `DEPTH`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gms`.`MEMBERSHIP_CREATOR_ID`)) AS `CREATOR_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gms`.`MEMBERSHIP_CREATOR_ID`)) AS `CREATOR_SUBJECT_ID`,`gms`.`MEMBERSHIP_ID` AS `MEMBERSHIP_ID`,`gms`.`IMMEDIATE_MEMBERSHIP_ID` AS `IMMEDIATE_MEMBERSHIP_ID`,`gms`.`GROUP_SET_ID` AS `GROUP_SET_ID`,(select `gs`.`id` from `grouper_stems` `gs` where (`gs`.`id` = `gms`.`OWNER_STEM_ID`)) AS `STEM_ID`,(select `gg`.`id` from `grouper_groups` `gg` where (`gg`.`id` = `gms`.`OWNER_GROUP_ID`)) AS `GROUP_ID`,`gms`.`MEMBERSHIP_CREATE_TIME` AS `CREATE_TIME`,`gms`.`MEMBERSHIP_CREATOR_ID` AS `CREATOR_ID`,`gms`.`FIELD_ID` AS `FIELD_ID`,`gms`.`CONTEXT_ID` AS `CONTEXT_ID` from ((`grouper_memberships_all_v` `gms` join `grouper_members` `gm`) join `grouper_fields` `gf`) where ((`gms`.`MEMBER_ID` = `gm`.`id`) and (`gms`.`FIELD_ID` = `gf`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_mship_attrdef_lw_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_mship_attrdef_lw_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_mship_attrdef_lw_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_mship_attrdef_lw_v` AS select distinct `gm`.`subject_id` AS `SUBJECT_ID`,`gm`.`subject_source` AS `SUBJECT_SOURCE`,`gad`.`name` AS `ATTRIBUTE_DEF_NAME`,`gfl`.`name` AS `LIST_NAME`,`gfl`.`type` AS `LIST_TYPE`,`gad`.`id` AS `ATTRIBUTE_DEF_ID` from (((`grouper_memberships_all_v` `gms` join `grouper_members` `gm`) join `grouper_attribute_def` `gad`) join `grouper_fields` `gfl`) where ((`gms`.`OWNER_ATTR_DEF_ID` = `gad`.`id`) and (`gms`.`FIELD_ID` = `gfl`.`id`) and (`gms`.`MEMBER_ID` = `gm`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_mship_stem_lw_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_mship_stem_lw_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_mship_stem_lw_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_mship_stem_lw_v` AS select distinct `gm`.`subject_id` AS `SUBJECT_ID`,`gm`.`subject_source` AS `SUBJECT_SOURCE`,`gs`.`name` AS `STEM_NAME`,`gfl`.`name` AS `LIST_NAME`,`gfl`.`type` AS `LIST_TYPE`,`gs`.`id` AS `STEM_ID` from (((`grouper_memberships_all_v` `gms` join `grouper_members` `gm`) join `grouper_stems` `gs`) join `grouper_fields` `gfl`) where ((`gms`.`OWNER_STEM_ID` = `gs`.`id`) and (`gms`.`FIELD_ID` = `gfl`.`id`) and (`gms`.`MEMBER_ID` = `gm`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_perms_all_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_perms_all_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_all_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_perms_all_v` AS select `grouper_perms_role_v`.`role_name` AS `role_name`,`grouper_perms_role_v`.`subject_source_id` AS `subject_source_id`,`grouper_perms_role_v`.`subject_id` AS `subject_id`,`grouper_perms_role_v`.`action` AS `action`,`grouper_perms_role_v`.`attribute_def_name_name` AS `attribute_def_name_name`,`grouper_perms_role_v`.`attribute_def_name_disp_name` AS `attribute_def_name_disp_name`,`grouper_perms_role_v`.`role_display_name` AS `role_display_name`,`grouper_perms_role_v`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`grouper_perms_role_v`.`enabled` AS `enabled`,`grouper_perms_role_v`.`enabled_time` AS `enabled_time`,`grouper_perms_role_v`.`disabled_time` AS `disabled_time`,`grouper_perms_role_v`.`role_id` AS `role_id`,`grouper_perms_role_v`.`attribute_def_id` AS `attribute_def_id`,`grouper_perms_role_v`.`member_id` AS `member_id`,`grouper_perms_role_v`.`attribute_def_name_id` AS `attribute_def_name_id`,`grouper_perms_role_v`.`action_id` AS `action_id`,`grouper_perms_role_v`.`membership_depth` AS `membership_depth`,`grouper_perms_role_v`.`role_set_depth` AS `role_set_depth`,`grouper_perms_role_v`.`attr_def_name_set_depth` AS `attr_def_name_set_depth`,`grouper_perms_role_v`.`attr_assign_action_set_depth` AS `attr_assign_action_set_depth`,`grouper_perms_role_v`.`membership_id` AS `membership_id`,`grouper_perms_role_v`.`attribute_assign_id` AS `attribute_assign_id`,`grouper_perms_role_v`.`permission_type` AS `permission_type`,`grouper_perms_role_v`.`assignment_notes` AS `assignment_notes`,`grouper_perms_role_v`.`immediate_mship_enabled_time` AS `immediate_mship_enabled_time`,`grouper_perms_role_v`.`immediate_mship_disabled_time` AS `immediate_mship_disabled_time`,`grouper_perms_role_v`.`disallowed` AS `disallowed` from `grouper_perms_role_v` union select `grouper_perms_role_subject_v`.`role_name` AS `role_name`,`grouper_perms_role_subject_v`.`subject_source_id` AS `subject_source_id`,`grouper_perms_role_subject_v`.`subject_id` AS `subject_id`,`grouper_perms_role_subject_v`.`action` AS `action`,`grouper_perms_role_subject_v`.`attribute_def_name_name` AS `attribute_def_name_name`,`grouper_perms_role_subject_v`.`attribute_def_name_disp_name` AS `attribute_def_name_disp_name`,`grouper_perms_role_subject_v`.`role_display_name` AS `role_display_name`,`grouper_perms_role_subject_v`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`grouper_perms_role_subject_v`.`enabled` AS `enabled`,`grouper_perms_role_subject_v`.`enabled_time` AS `enabled_time`,`grouper_perms_role_subject_v`.`disabled_time` AS `disabled_time`,`grouper_perms_role_subject_v`.`role_id` AS `role_id`,`grouper_perms_role_subject_v`.`attribute_def_id` AS `attribute_def_id`,`grouper_perms_role_subject_v`.`member_id` AS `member_id`,`grouper_perms_role_subject_v`.`attribute_def_name_id` AS `attribute_def_name_id`,`grouper_perms_role_subject_v`.`action_id` AS `action_id`,`grouper_perms_role_subject_v`.`membership_depth` AS `membership_depth`,`grouper_perms_role_subject_v`.`role_set_depth` AS `role_set_depth`,`grouper_perms_role_subject_v`.`attr_def_name_set_depth` AS `attr_def_name_set_depth`,`grouper_perms_role_subject_v`.`attr_assign_action_set_depth` AS `attr_assign_action_set_depth`,`grouper_perms_role_subject_v`.`membership_id` AS `membership_id`,`grouper_perms_role_subject_v`.`attribute_assign_id` AS `attribute_assign_id`,`grouper_perms_role_subject_v`.`permission_type` AS `permission_type`,`grouper_perms_role_subject_v`.`assignment_notes` AS `assignment_notes`,`grouper_perms_role_subject_v`.`immediate_mship_enabled_time` AS `immediate_mship_enabled_time`,`grouper_perms_role_subject_v`.`immediate_mship_disabled_time` AS `immediate_mship_disabled_time`,`grouper_perms_role_subject_v`.`disallowed` AS `disallowed` from `grouper_perms_role_subject_v` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_perms_assigned_role_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_perms_assigned_role_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_assigned_role_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_perms_assigned_role_v` AS select distinct `gr`.`name` AS `role_name`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gr`.`display_name` AS `role_display_name`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gr`.`id` AS `role_id`,`gadn`.`attribute_def_id` AS `attribute_def_id`,`gadn`.`id` AS `attribute_def_name_id`,`gaaa`.`id` AS `action_id`,`grs`.`depth` AS `role_set_depth`,`gadns`.`depth` AS `attr_def_name_set_depth`,`gaaas`.`depth` AS `attr_assign_action_set_depth`,`gaa`.`id` AS `attribute_assign_id`,`gaa`.`notes` AS `assignment_notes`,`gaa`.`disallowed` AS `disallowed`,'role' AS `permission_type` from (((((((`grouper_groups` `gr` join `grouper_role_set` `grs`) join `grouper_attribute_def` `gad`) join `grouper_attribute_assign` `gaa`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def_name_set` `gadns`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attr_assign_action_set` `gaaas`) where ((`grs`.`if_has_role_id` = `gr`.`id`) and (`gr`.`type_of_group` = 'role') and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gad`.`attribute_def_type` = 'perm') and (`gaa`.`owner_group_id` = `grs`.`then_has_role_id`) and (`gaa`.`attribute_def_name_id` = `gadns`.`if_has_attribute_def_name_id`) and (`gadn`.`id` = `gadns`.`then_has_attribute_def_name_id`) and (`gaa`.`attribute_assign_type` = 'group') and (`gaa`.`attribute_assign_action_id` = `gaaas`.`if_has_attr_assn_action_id`) and (`gaaa`.`id` = `gaaas`.`then_has_attr_assn_action_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_perms_role_subject_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_perms_role_subject_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_role_subject_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_perms_role_subject_v` AS select distinct `gr`.`name` AS `role_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gr`.`display_name` AS `role_display_name`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gr`.`id` AS `role_id`,`gadn`.`attribute_def_id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gadn`.`id` AS `attribute_def_name_id`,`gaaa`.`id` AS `action_id`,`gmav`.`DEPTH` AS `membership_depth`,-(1) AS `role_set_depth`,`gadns`.`depth` AS `attr_def_name_set_depth`,`gaaas`.`depth` AS `attr_assign_action_set_depth`,`gmav`.`MEMBERSHIP_ID` AS `membership_id`,`gaa`.`id` AS `attribute_assign_id`,'role_subject' AS `permission_type`,`gaa`.`notes` AS `assignment_notes`,`gmav`.`IMMEDIATE_MSHIP_ENABLED_TIME` AS `immediate_mship_enabled_time`,`gmav`.`IMMEDIATE_MSHIP_DISABLED_TIME` AS `immediate_mship_disabled_time`,`gaa`.`disallowed` AS `disallowed` from (((((((((`grouper_groups` `gr` join `grouper_memberships_all_v` `gmav`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_attribute_def` `gad`) join `grouper_attribute_assign` `gaa`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def_name_set` `gadns`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attr_assign_action_set` `gaaas`) where ((`gmav`.`OWNER_GROUP_ID` = `gr`.`id`) and (`gr`.`type_of_group` = 'role') and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gmav`.`OWNER_GROUP_ID` = `gaa`.`owner_group_id`) and (`gmav`.`MEMBER_ID` = `gaa`.`owner_member_id`) and (`gf`.`type` = 'list') and (`gf`.`name` = 'members') and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gad`.`attribute_def_type` = 'perm') and (`gaa`.`attribute_assign_type` = 'any_mem') and (`gaa`.`attribute_def_name_id` = `gadns`.`if_has_attribute_def_name_id`) and (`gadn`.`id` = `gadns`.`then_has_attribute_def_name_id`) and (`gaa`.`attribute_assign_action_id` = `gaaas`.`if_has_attr_assn_action_id`) and (`gaaa`.`id` = `gaaas`.`then_has_attr_assn_action_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_perms_role_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_perms_role_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_perms_role_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_perms_role_v` AS select distinct `gr`.`name` AS `role_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gadn`.`display_name` AS `attribute_def_name_disp_name`,`gr`.`display_name` AS `role_display_name`,`gaa`.`attribute_assign_delegatable` AS `attribute_assign_delegatable`,`gaa`.`enabled` AS `enabled`,`gaa`.`enabled_time` AS `enabled_time`,`gaa`.`disabled_time` AS `disabled_time`,`gr`.`id` AS `role_id`,`gadn`.`attribute_def_id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gadn`.`id` AS `attribute_def_name_id`,`gaaa`.`id` AS `action_id`,`gmav`.`DEPTH` AS `membership_depth`,`grs`.`depth` AS `role_set_depth`,`gadns`.`depth` AS `attr_def_name_set_depth`,`gaaas`.`depth` AS `attr_assign_action_set_depth`,`gmav`.`MEMBERSHIP_ID` AS `membership_id`,`gaa`.`id` AS `attribute_assign_id`,'role' AS `permission_type`,`gaa`.`notes` AS `assignment_notes`,`gmav`.`IMMEDIATE_MSHIP_ENABLED_TIME` AS `immediate_mship_enabled_time`,`gmav`.`IMMEDIATE_MSHIP_DISABLED_TIME` AS `immediate_mship_disabled_time`,`gaa`.`disallowed` AS `disallowed` from ((((((((((`grouper_groups` `gr` join `grouper_memberships_all_v` `gmav`) join `grouper_members` `gm`) join `grouper_fields` `gf`) join `grouper_role_set` `grs`) join `grouper_attribute_def` `gad`) join `grouper_attribute_assign` `gaa`) join `grouper_attribute_def_name` `gadn`) join `grouper_attribute_def_name_set` `gadns`) join `grouper_attr_assign_action` `gaaa`) join `grouper_attr_assign_action_set` `gaaas`) where ((`gmav`.`OWNER_GROUP_ID` = `gr`.`id`) and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gr`.`type_of_group` = 'role') and (`gf`.`type` = 'list') and (`gf`.`name` = 'members') and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`grs`.`if_has_role_id` = `gr`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gad`.`attribute_def_type` = 'perm') and (`gaa`.`owner_group_id` = `grs`.`then_has_role_id`) and (`gaa`.`attribute_def_name_id` = `gadns`.`if_has_attribute_def_name_id`) and (`gadn`.`id` = `gadns`.`then_has_attribute_def_name_id`) and (`gaa`.`attribute_assign_type` = 'group') and (`gaa`.`attribute_assign_action_id` = `gaaas`.`if_has_attr_assn_action_id`) and (`gaaa`.`id` = `gaaas`.`then_has_attr_assn_action_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_pit_attr_asn_value_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_pit_attr_asn_value_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_attr_asn_value_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_pit_attr_asn_value_v` AS select `gpaav`.`id` AS `attribute_assign_value_id`,`gpaa`.`id` AS `attribute_assign_id`,`gpaa`.`attribute_def_name_id` AS `attribute_def_name_id`,`gpaa`.`attribute_assign_action_id` AS `attribute_assign_action_id`,`gpaa`.`attribute_assign_type` AS `attribute_assign_type`,`gpaa`.`owner_attribute_assign_id` AS `owner_attribute_assign_id`,`gpaa`.`owner_attribute_def_id` AS `owner_attribute_def_id`,`gpaa`.`owner_group_id` AS `owner_group_id`,`gpaa`.`owner_member_id` AS `owner_member_id`,`gpaa`.`owner_membership_id` AS `owner_membership_id`,`gpaa`.`owner_stem_id` AS `owner_stem_id`,`gpaav`.`value_integer` AS `value_integer`,`gpaav`.`value_floating` AS `value_floating`,`gpaav`.`value_string` AS `value_string`,`gpaav`.`value_member_id` AS `value_member_id`,`gpaav`.`active` AS `active`,`gpaav`.`start_time` AS `start_time`,`gpaav`.`end_time` AS `end_time` from (`grouper_pit_attribute_assign` `gpaa` join `grouper_pit_attr_assn_value` `gpaav`) where (`gpaa`.`id` = `gpaav`.`attribute_assign_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_pit_memberships_all_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_pit_memberships_all_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_memberships_all_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_pit_memberships_all_v` AS select concat(`ms`.`id`,':',`gs`.`id`) AS `ID`,`ms`.`id` AS `MEMBERSHIP_ID`,`ms`.`source_id` AS `MEMBERSHIP_SOURCE_ID`,`gs`.`id` AS `GROUP_SET_ID`,`ms`.`member_id` AS `MEMBER_ID`,`gs`.`field_id` AS `FIELD_ID`,`ms`.`field_id` AS `MEMBERSHIP_FIELD_ID`,`gs`.`owner_id` AS `OWNER_ID`,`gs`.`owner_attr_def_id` AS `OWNER_ATTR_DEF_ID`,`gs`.`owner_group_id` AS `OWNER_GROUP_ID`,`gs`.`owner_stem_id` AS `OWNER_STEM_ID`,`gs`.`active` AS `GROUP_SET_ACTIVE`,`gs`.`start_time` AS `GROUP_SET_START_TIME`,`gs`.`end_time` AS `GROUP_SET_END_TIME`,`ms`.`active` AS `MEMBERSHIP_ACTIVE`,`ms`.`start_time` AS `MEMBERSHIP_START_TIME`,`ms`.`end_time` AS `MEMBERSHIP_END_TIME`,`gs`.`depth` AS `DEPTH`,`gs`.`parent_id` AS `GROUP_SET_PARENT_ID` from (`grouper_pit_memberships` `ms` join `grouper_pit_group_set` `gs`) where ((`ms`.`owner_id` = `gs`.`member_id`) and (`ms`.`field_id` = `gs`.`member_field_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_pit_perms_all_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_pit_perms_all_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_perms_all_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_pit_perms_all_v` AS select `grouper_pit_perms_role_v`.`role_name` AS `role_name`,`grouper_pit_perms_role_v`.`subject_source_id` AS `subject_source_id`,`grouper_pit_perms_role_v`.`subject_id` AS `subject_id`,`grouper_pit_perms_role_v`.`action` AS `action`,`grouper_pit_perms_role_v`.`attribute_def_name_name` AS `attribute_def_name_name`,`grouper_pit_perms_role_v`.`role_id` AS `role_id`,`grouper_pit_perms_role_v`.`attribute_def_id` AS `attribute_def_id`,`grouper_pit_perms_role_v`.`member_id` AS `member_id`,`grouper_pit_perms_role_v`.`attribute_def_name_id` AS `attribute_def_name_id`,`grouper_pit_perms_role_v`.`action_id` AS `action_id`,`grouper_pit_perms_role_v`.`membership_depth` AS `membership_depth`,`grouper_pit_perms_role_v`.`role_set_depth` AS `role_set_depth`,`grouper_pit_perms_role_v`.`attr_def_name_set_depth` AS `attr_def_name_set_depth`,`grouper_pit_perms_role_v`.`attr_assign_action_set_depth` AS `attr_assign_action_set_depth`,`grouper_pit_perms_role_v`.`membership_id` AS `membership_id`,`grouper_pit_perms_role_v`.`group_set_id` AS `group_set_id`,`grouper_pit_perms_role_v`.`role_set_id` AS `role_set_id`,`grouper_pit_perms_role_v`.`attribute_def_name_set_id` AS `attribute_def_name_set_id`,`grouper_pit_perms_role_v`.`action_set_id` AS `action_set_id`,`grouper_pit_perms_role_v`.`attribute_assign_id` AS `attribute_assign_id`,`grouper_pit_perms_role_v`.`permission_type` AS `permission_type`,`grouper_pit_perms_role_v`.`group_set_active` AS `group_set_active`,`grouper_pit_perms_role_v`.`group_set_start_time` AS `group_set_start_time`,`grouper_pit_perms_role_v`.`group_set_end_time` AS `group_set_end_time`,`grouper_pit_perms_role_v`.`membership_active` AS `membership_active`,`grouper_pit_perms_role_v`.`membership_start_time` AS `membership_start_time`,`grouper_pit_perms_role_v`.`membership_end_time` AS `membership_end_time`,`grouper_pit_perms_role_v`.`role_set_active` AS `role_set_active`,`grouper_pit_perms_role_v`.`role_set_start_time` AS `role_set_start_time`,`grouper_pit_perms_role_v`.`role_set_end_time` AS `role_set_end_time`,`grouper_pit_perms_role_v`.`action_set_active` AS `action_set_active`,`grouper_pit_perms_role_v`.`action_set_start_time` AS `action_set_start_time`,`grouper_pit_perms_role_v`.`action_set_end_time` AS `action_set_end_time`,`grouper_pit_perms_role_v`.`attr_def_name_set_active` AS `attr_def_name_set_active`,`grouper_pit_perms_role_v`.`attr_def_name_set_start_time` AS `attr_def_name_set_start_time`,`grouper_pit_perms_role_v`.`attr_def_name_set_end_time` AS `attr_def_name_set_end_time`,`grouper_pit_perms_role_v`.`attribute_assign_active` AS `attribute_assign_active`,`grouper_pit_perms_role_v`.`attribute_assign_start_time` AS `attribute_assign_start_time`,`grouper_pit_perms_role_v`.`attribute_assign_end_time` AS `attribute_assign_end_time`,`grouper_pit_perms_role_v`.`disallowed` AS `disallowed`,`grouper_pit_perms_role_v`.`action_source_id` AS `action_source_id`,`grouper_pit_perms_role_v`.`role_source_id` AS `role_source_id`,`grouper_pit_perms_role_v`.`attribute_def_name_source_id` AS `attribute_def_name_source_id`,`grouper_pit_perms_role_v`.`attribute_def_source_id` AS `attribute_def_source_id`,`grouper_pit_perms_role_v`.`member_source_id` AS `member_source_id`,`grouper_pit_perms_role_v`.`membership_source_id` AS `membership_source_id`,`grouper_pit_perms_role_v`.`attribute_assign_source_id` AS `attribute_assign_source_id` from `grouper_pit_perms_role_v` union select `grouper_pit_perms_role_subj_v`.`role_name` AS `role_name`,`grouper_pit_perms_role_subj_v`.`subject_source_id` AS `subject_source_id`,`grouper_pit_perms_role_subj_v`.`subject_id` AS `subject_id`,`grouper_pit_perms_role_subj_v`.`action` AS `action`,`grouper_pit_perms_role_subj_v`.`attribute_def_name_name` AS `attribute_def_name_name`,`grouper_pit_perms_role_subj_v`.`role_id` AS `role_id`,`grouper_pit_perms_role_subj_v`.`attribute_def_id` AS `attribute_def_id`,`grouper_pit_perms_role_subj_v`.`member_id` AS `member_id`,`grouper_pit_perms_role_subj_v`.`attribute_def_name_id` AS `attribute_def_name_id`,`grouper_pit_perms_role_subj_v`.`action_id` AS `action_id`,`grouper_pit_perms_role_subj_v`.`membership_depth` AS `membership_depth`,`grouper_pit_perms_role_subj_v`.`role_set_depth` AS `role_set_depth`,`grouper_pit_perms_role_subj_v`.`attr_def_name_set_depth` AS `attr_def_name_set_depth`,`grouper_pit_perms_role_subj_v`.`attr_assign_action_set_depth` AS `attr_assign_action_set_depth`,`grouper_pit_perms_role_subj_v`.`membership_id` AS `membership_id`,`grouper_pit_perms_role_subj_v`.`group_set_id` AS `group_set_id`,`grouper_pit_perms_role_subj_v`.`role_set_id` AS `role_set_id`,`grouper_pit_perms_role_subj_v`.`attribute_def_name_set_id` AS `attribute_def_name_set_id`,`grouper_pit_perms_role_subj_v`.`action_set_id` AS `action_set_id`,`grouper_pit_perms_role_subj_v`.`attribute_assign_id` AS `attribute_assign_id`,`grouper_pit_perms_role_subj_v`.`permission_type` AS `permission_type`,`grouper_pit_perms_role_subj_v`.`group_set_active` AS `group_set_active`,`grouper_pit_perms_role_subj_v`.`group_set_start_time` AS `group_set_start_time`,`grouper_pit_perms_role_subj_v`.`group_set_end_time` AS `group_set_end_time`,`grouper_pit_perms_role_subj_v`.`membership_active` AS `membership_active`,`grouper_pit_perms_role_subj_v`.`membership_start_time` AS `membership_start_time`,`grouper_pit_perms_role_subj_v`.`membership_end_time` AS `membership_end_time`,`grouper_pit_perms_role_subj_v`.`role_set_active` AS `role_set_active`,`grouper_pit_perms_role_subj_v`.`role_set_start_time` AS `role_set_start_time`,`grouper_pit_perms_role_subj_v`.`role_set_end_time` AS `role_set_end_time`,`grouper_pit_perms_role_subj_v`.`action_set_active` AS `action_set_active`,`grouper_pit_perms_role_subj_v`.`action_set_start_time` AS `action_set_start_time`,`grouper_pit_perms_role_subj_v`.`action_set_end_time` AS `action_set_end_time`,`grouper_pit_perms_role_subj_v`.`attr_def_name_set_active` AS `attr_def_name_set_active`,`grouper_pit_perms_role_subj_v`.`attr_def_name_set_start_time` AS `attr_def_name_set_start_time`,`grouper_pit_perms_role_subj_v`.`attr_def_name_set_end_time` AS `attr_def_name_set_end_time`,`grouper_pit_perms_role_subj_v`.`attribute_assign_active` AS `attribute_assign_active`,`grouper_pit_perms_role_subj_v`.`attribute_assign_start_time` AS `attribute_assign_start_time`,`grouper_pit_perms_role_subj_v`.`attribute_assign_end_time` AS `attribute_assign_end_time`,`grouper_pit_perms_role_subj_v`.`disallowed` AS `disallowed`,`grouper_pit_perms_role_subj_v`.`action_source_id` AS `action_source_id`,`grouper_pit_perms_role_subj_v`.`role_source_id` AS `role_source_id`,`grouper_pit_perms_role_subj_v`.`attribute_def_name_source_id` AS `attribute_def_name_source_id`,`grouper_pit_perms_role_subj_v`.`attribute_def_source_id` AS `attribute_def_source_id`,`grouper_pit_perms_role_subj_v`.`member_source_id` AS `member_source_id`,`grouper_pit_perms_role_subj_v`.`membership_source_id` AS `membership_source_id`,`grouper_pit_perms_role_subj_v`.`attribute_assign_source_id` AS `attribute_assign_source_id` from `grouper_pit_perms_role_subj_v` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_pit_perms_role_subj_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_pit_perms_role_subj_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_perms_role_subj_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_pit_perms_role_subj_v` AS select distinct `gr`.`name` AS `role_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gr`.`id` AS `role_id`,`gadn`.`attribute_def_id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gadn`.`id` AS `attribute_def_name_id`,`gaaa`.`id` AS `action_id`,`gmav`.`DEPTH` AS `membership_depth`,-(1) AS `role_set_depth`,`gadns`.`depth` AS `attr_def_name_set_depth`,`gaaas`.`depth` AS `attr_assign_action_set_depth`,`gmav`.`MEMBERSHIP_ID` AS `membership_id`,`gmav`.`GROUP_SET_ID` AS `group_set_id`,`grs`.`id` AS `role_set_id`,`gadns`.`id` AS `attribute_def_name_set_id`,`gaaas`.`id` AS `action_set_id`,`gaa`.`id` AS `attribute_assign_id`,'role_subject' AS `permission_type`,`gmav`.`GROUP_SET_ACTIVE` AS `group_set_active`,`gmav`.`GROUP_SET_START_TIME` AS `group_set_start_time`,`gmav`.`GROUP_SET_END_TIME` AS `group_set_end_time`,`gmav`.`MEMBERSHIP_ACTIVE` AS `membership_active`,`gmav`.`MEMBERSHIP_START_TIME` AS `membership_start_time`,`gmav`.`MEMBERSHIP_END_TIME` AS `membership_end_time`,`grs`.`active` AS `role_set_active`,`grs`.`start_time` AS `role_set_start_time`,`grs`.`end_time` AS `role_set_end_time`,`gaaas`.`active` AS `action_set_active`,`gaaas`.`start_time` AS `action_set_start_time`,`gaaas`.`end_time` AS `action_set_end_time`,`gadns`.`active` AS `attr_def_name_set_active`,`gadns`.`start_time` AS `attr_def_name_set_start_time`,`gadns`.`end_time` AS `attr_def_name_set_end_time`,`gaa`.`active` AS `attribute_assign_active`,`gaa`.`start_time` AS `attribute_assign_start_time`,`gaa`.`end_time` AS `attribute_assign_end_time`,`gaa`.`disallowed` AS `disallowed`,`gaaa`.`source_id` AS `action_source_id`,`gr`.`source_id` AS `role_source_id`,`gadn`.`source_id` AS `attribute_def_name_source_id`,`gad`.`source_id` AS `attribute_def_source_id`,`gm`.`source_id` AS `member_source_id`,`gmav`.`MEMBERSHIP_SOURCE_ID` AS `membership_source_id`,`gaa`.`source_id` AS `attribute_assign_source_id` from ((((((((((`grouper_pit_groups` `gr` join `grouper_pit_memberships_all_v` `gmav`) join `grouper_pit_members` `gm`) join `grouper_pit_fields` `gf`) join `grouper_pit_role_set` `grs`) join `grouper_pit_attribute_def` `gad`) join `grouper_pit_attribute_assign` `gaa`) join `grouper_pit_attr_def_name` `gadn`) join `grouper_pit_attr_def_name_set` `gadns`) join `grouper_pit_attr_assn_actn` `gaaa`) join `grouper_pit_attr_assn_actn_set` `gaaas`) where ((`gmav`.`OWNER_GROUP_ID` = `gr`.`id`) and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gmav`.`OWNER_GROUP_ID` = `gaa`.`owner_group_id`) and (`gmav`.`MEMBER_ID` = `gaa`.`owner_member_id`) and (`gf`.`type` = 'list') and (`gf`.`name` = 'members') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gad`.`attribute_def_type` = 'perm') and (`gaa`.`attribute_assign_type` = 'any_mem') and (`gaa`.`attribute_def_name_id` = `gadns`.`if_has_attribute_def_name_id`) and (`gadn`.`id` = `gadns`.`then_has_attribute_def_name_id`) and (`gaa`.`attribute_assign_action_id` = `gaaas`.`if_has_attr_assn_action_id`) and (`gaaa`.`id` = `gaaas`.`then_has_attr_assn_action_id`) and (`grs`.`if_has_role_id` = `gr`.`id`) and (`grs`.`depth` = '0')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_pit_perms_role_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_pit_perms_role_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_pit_perms_role_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_pit_perms_role_v` AS select distinct `gr`.`name` AS `role_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gaaa`.`name` AS `action`,`gadn`.`name` AS `attribute_def_name_name`,`gr`.`id` AS `role_id`,`gadn`.`attribute_def_id` AS `attribute_def_id`,`gm`.`id` AS `member_id`,`gadn`.`id` AS `attribute_def_name_id`,`gaaa`.`id` AS `action_id`,`gmav`.`DEPTH` AS `membership_depth`,`grs`.`depth` AS `role_set_depth`,`gadns`.`depth` AS `attr_def_name_set_depth`,`gaaas`.`depth` AS `attr_assign_action_set_depth`,`gmav`.`MEMBERSHIP_ID` AS `membership_id`,`gmav`.`GROUP_SET_ID` AS `group_set_id`,`grs`.`id` AS `role_set_id`,`gadns`.`id` AS `attribute_def_name_set_id`,`gaaas`.`id` AS `action_set_id`,`gaa`.`id` AS `attribute_assign_id`,'role' AS `permission_type`,`gmav`.`GROUP_SET_ACTIVE` AS `group_set_active`,`gmav`.`GROUP_SET_START_TIME` AS `group_set_start_time`,`gmav`.`GROUP_SET_END_TIME` AS `group_set_end_time`,`gmav`.`MEMBERSHIP_ACTIVE` AS `membership_active`,`gmav`.`MEMBERSHIP_START_TIME` AS `membership_start_time`,`gmav`.`MEMBERSHIP_END_TIME` AS `membership_end_time`,`grs`.`active` AS `role_set_active`,`grs`.`start_time` AS `role_set_start_time`,`grs`.`end_time` AS `role_set_end_time`,`gaaas`.`active` AS `action_set_active`,`gaaas`.`start_time` AS `action_set_start_time`,`gaaas`.`end_time` AS `action_set_end_time`,`gadns`.`active` AS `attr_def_name_set_active`,`gadns`.`start_time` AS `attr_def_name_set_start_time`,`gadns`.`end_time` AS `attr_def_name_set_end_time`,`gaa`.`active` AS `attribute_assign_active`,`gaa`.`start_time` AS `attribute_assign_start_time`,`gaa`.`end_time` AS `attribute_assign_end_time`,`gaa`.`disallowed` AS `disallowed`,`gaaa`.`source_id` AS `action_source_id`,`gr`.`source_id` AS `role_source_id`,`gadn`.`source_id` AS `attribute_def_name_source_id`,`gad`.`source_id` AS `attribute_def_source_id`,`gm`.`source_id` AS `member_source_id`,`gmav`.`MEMBERSHIP_SOURCE_ID` AS `membership_source_id`,`gaa`.`source_id` AS `attribute_assign_source_id` from ((((((((((`grouper_pit_groups` `gr` join `grouper_pit_memberships_all_v` `gmav`) join `grouper_pit_members` `gm`) join `grouper_pit_fields` `gf`) join `grouper_pit_role_set` `grs`) join `grouper_pit_attribute_def` `gad`) join `grouper_pit_attribute_assign` `gaa`) join `grouper_pit_attr_def_name` `gadn`) join `grouper_pit_attr_def_name_set` `gadns`) join `grouper_pit_attr_assn_actn` `gaaa`) join `grouper_pit_attr_assn_actn_set` `gaaas`) where ((`gmav`.`OWNER_GROUP_ID` = `gr`.`id`) and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gf`.`type` = 'list') and (`gf`.`name` = 'members') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`grs`.`if_has_role_id` = `gr`.`id`) and (`gadn`.`attribute_def_id` = `gad`.`id`) and (`gad`.`attribute_def_type` = 'perm') and (`gaa`.`owner_group_id` = `grs`.`then_has_role_id`) and (`gaa`.`attribute_def_name_id` = `gadns`.`if_has_attribute_def_name_id`) and (`gadn`.`id` = `gadns`.`then_has_attribute_def_name_id`) and (`gaa`.`attribute_assign_type` = 'group') and (`gaa`.`attribute_assign_action_id` = `gaaas`.`if_has_attr_assn_action_id`) and (`gaaa`.`id` = `gaaas`.`then_has_attr_assn_action_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_role_set_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_role_set_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_role_set_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_role_set_v` AS select `ifHas`.`name` AS `if_has_role_name`,`thenHas`.`name` AS `then_has_role_name`,`grs`.`depth` AS `depth`,`grs`.`type` AS `type`,`grParentIfHas`.`name` AS `parent_if_has_name`,`grParentThenHas`.`name` AS `parent_then_has_name`,`grs`.`id` AS `id`,`ifHas`.`id` AS `if_has_role_id`,`thenHas`.`id` AS `then_has_role_id`,`grs`.`parent_role_set_id` AS `parent_role_set_id` from (((((`grouper_role_set` `grs` join `grouper_role_set` `grsParent`) join `grouper_groups` `grParentIfHas`) join `grouper_groups` `grParentThenHas`) join `grouper_groups` `ifHas`) join `grouper_groups` `thenHas`) where ((`thenHas`.`id` = `grs`.`then_has_role_id`) and (`ifHas`.`id` = `grs`.`if_has_role_id`) and (`grs`.`parent_role_set_id` = `grsParent`.`id`) and (`grParentIfHas`.`id` = `grsParent`.`if_has_role_id`) and (`grParentThenHas`.`id` = `grsParent`.`then_has_role_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_roles_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_roles_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_roles_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_roles_v` AS select `gg`.`extension` AS `EXTENSION`,`gg`.`name` AS `NAME`,`gg`.`display_extension` AS `DISPLAY_EXTENSION`,`gg`.`display_name` AS `DISPLAY_NAME`,`gg`.`description` AS `DESCRIPTION`,`gs`.`name` AS `PARENT_STEM_NAME`,`gg`.`id` AS `ROLE_ID`,`gs`.`id` AS `PARENT_STEM_ID`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`modifier_id`)) AS `MODIFIER_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`modifier_id`)) AS `MODIFIER_SUBJECT_ID`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`creator_id`)) AS `CREATOR_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gg`.`creator_id`)) AS `CREATOR_SUBJECT_ID`,(select distinct 'T' from `grouper_composites` `gc` where (`gc`.`owner` = `gg`.`id`)) AS `IS_COMPOSITE_OWNER`,(select distinct 'T' from `grouper_composites` `gc` where ((`gc`.`left_factor` = `gg`.`id`) or (`gc`.`right_factor` = `gg`.`id`))) AS `IS_COMPOSITE_FACTOR`,`gg`.`creator_id` AS `CREATOR_ID`,`gg`.`create_time` AS `CREATE_TIME`,`gg`.`modifier_id` AS `MODIFIER_ID`,`gg`.`modify_time` AS `MODIFY_TIME`,`gg`.`hibernate_version_number` AS `HIBERNATE_VERSION_NUMBER`,`gg`.`context_id` AS `CONTEXT_ID` from (`grouper_groups` `gg` join `grouper_stems` `gs`) where ((`gg`.`parent_stem` = `gs`.`id`) and (`gg`.`type_of_group` = 'role')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rpt_composites_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rpt_composites_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_composites_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rpt_composites_v` AS select `gc`.`type` AS `COMPOSITE_TYPE`,count(0) AS `THE_COUNT` from `grouper_composites` `gc` group by `gc`.`type` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rpt_group_field_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rpt_group_field_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_group_field_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rpt_group_field_v` AS select `gg`.`name` AS `GROUP_NAME`,`gg`.`display_name` AS `GROUP_DISPLAYNAME`,`gf`.`type` AS `FIELD_TYPE`,`gf`.`name` AS `FIELD_NAME`,count(distinct `gms`.`MEMBER_ID`) AS `MEMBER_COUNT` from ((`grouper_memberships_all_v` `gms` join `grouper_groups` `gg`) join `grouper_fields` `gf`) where ((`gms`.`FIELD_ID` = `gf`.`id`) and (`gg`.`id` = `gms`.`OWNER_GROUP_ID`)) group by `gg`.`name`,`gg`.`display_name`,`gf`.`type`,`gf`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rpt_groups_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rpt_groups_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_groups_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rpt_groups_v` AS select `gg`.`name` AS `GROUP_NAME`,`gg`.`display_name` AS `GROUP_DISPLAYNAME`,`gg`.`type_of_group` AS `TYPE_OF_GROUP`,(select count(distinct `gms`.`MEMBER_ID`) from `grouper_memberships_all_v` `gms` where ((`gms`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gms`.`MSHIP_TYPE` = 'immediate'))) AS `IMMEDIATE_MEMBERSHIP_COUNT`,(select count(distinct `gms`.`MEMBER_ID`) from `grouper_memberships_all_v` `gms` where (`gms`.`OWNER_GROUP_ID` = `gg`.`id`)) AS `MEMBERSHIP_COUNT`,(select count(0) from `grouper_composites` `gc` where ((`gc`.`left_factor` = `gg`.`id`) or (`gc`.`right_factor` = `gg`.`id`))) AS `ISA_COMPOSITE_FACTOR_COUNT`,(select count(distinct `gms`.`OWNER_GROUP_ID`) from (`grouper_memberships_all_v` `gms` join `grouper_members` `gm`) where ((`gm`.`subject_id` = `gg`.`id`) and (`gms`.`MEMBER_ID` = `gm`.`id`))) AS `ISA_MEMBER_COUNT`,`gg`.`id` AS `GROUP_ID` from `grouper_groups` `gg` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rpt_members_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rpt_members_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_members_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rpt_members_v` AS select `gm`.`subject_id` AS `SUBJECT_ID`,`gm`.`subject_source` AS `SUBJECT_SOURCE`,(select count(distinct `gms`.`owner_group_id`) from `grouper_memberships` `gms` where (`gms`.`member_id` = `gm`.`id`)) AS `MEMBERSHIP_COUNT`,`gm`.`id` AS `MEMBER_ID` from `grouper_members` `gm` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rpt_roles_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rpt_roles_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_roles_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rpt_roles_v` AS select `gg`.`name` AS `ROLE_NAME`,`gg`.`display_name` AS `ROLE_DISPLAYNAME`,(select count(distinct `gms`.`MEMBER_ID`) from `grouper_memberships_all_v` `gms` where ((`gms`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gms`.`MSHIP_TYPE` = 'immediate'))) AS `IMMEDIATE_MEMBERSHIP_COUNT`,(select count(distinct `gms`.`MEMBER_ID`) from `grouper_memberships_all_v` `gms` where (`gms`.`OWNER_GROUP_ID` = `gg`.`id`)) AS `MEMBERSHIP_COUNT`,(select count(0) from `grouper_composites` `gc` where ((`gc`.`left_factor` = `gg`.`id`) or (`gc`.`right_factor` = `gg`.`id`))) AS `ISA_COMPOSITE_FACTOR_COUNT`,(select count(distinct `gms`.`OWNER_GROUP_ID`) from (`grouper_memberships_all_v` `gms` join `grouper_members` `gm`) where ((`gm`.`subject_id` = `gg`.`id`) and (`gms`.`MEMBER_ID` = `gm`.`id`))) AS `ISA_MEMBER_COUNT`,`gg`.`id` AS `ROLE_ID` from `grouper_groups` `gg` where (`gg`.`type_of_group` = 'role') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rpt_stems_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rpt_stems_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rpt_stems_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rpt_stems_v` AS select `gs`.`name` AS `STEM_NAME`,`gs`.`display_name` AS `STEM_DISPLAYNAME`,(select count(0) from `grouper_groups` `gg` where (`gg`.`parent_stem` = `gs`.`id`)) AS `GROUP_IMMEDIATE_COUNT`,(select count(0) from `grouper_stems` `gs2` where (`gs`.`id` = `gs2`.`parent_stem`)) AS `STEM_IMMEDIATE_COUNT`,(select count(0) from `grouper_groups` `gg` where (`gg`.`name` like concat(`gs`.`name`,'%'))) AS `GROUP_COUNT`,(select count(0) from `grouper_stems` `gs2` where (`gs2`.`name` like concat(`gs`.`name`,'%'))) AS `STEM_COUNT`,(select count(distinct `gm`.`MEMBER_ID`) from `grouper_memberships_all_v` `gm` where (`gm`.`OWNER_STEM_ID` = `gs`.`id`)) AS `THIS_STEM_MEMBERSHIP_COUNT`,(select count(distinct `gm`.`MEMBER_ID`) from (`grouper_memberships_all_v` `gm` join `grouper_groups` `gg`) where ((`gg`.`parent_stem` = `gs`.`id`) and (`gm`.`OWNER_STEM_ID` = `gg`.`id`))) AS `CHILD_GROUP_MEMBERSHIP_COUNT`,(select count(distinct `gm`.`MEMBER_ID`) from (`grouper_memberships_all_v` `gm` join `grouper_groups` `gg`) where ((`gm`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gg`.`name` like concat(`gs`.`name`,'%')))) AS `GROUP_MEMBERSHIP_COUNT`,`gs`.`id` AS `STEM_ID` from `grouper_stems` `gs` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_rules_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_rules_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_rules_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_rules_v` AS select `main_gaa`.`attribute_assign_type` AS `assigned_to_type`,(select `gg`.`name` from `grouper_groups` `gg` where (`gg`.`id` = `main_gaa`.`owner_group_id`)) AS `assigned_to_group_name`,(select `gs`.`name` from `grouper_stems` `gs` where (`gs`.`id` = `main_gaa`.`owner_stem_id`)) AS `assigned_to_stem_name`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `main_gaa`.`owner_member_id`)) AS `assigned_to_member_subject_id`,(select `gad`.`name` from `grouper_attribute_def` `gad` where (`gad`.`id` = `main_gaa`.`owner_attribute_def_id`)) AS `assigned_to_attribute_def_name`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleCheckType') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_check_type`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleCheckOwnerId') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_check_owner_id`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleCheckOwnerName') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_check_owner_name`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleCheckStemScope') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_check_stem_scope`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleCheckArg0') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_check_arg0`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleCheckArg1') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_check_arg1`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfConditionEl') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_condition_el`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfConditionEnum') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_condition_enum`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfConditionEnumArg0') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_condition_enum_arg0`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfConditionEnumArg1') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_condition_enum_arg1`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfOwnerId') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_owner_id`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfOwnerName') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_owner_name`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleIfStemScope') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_if_stem_scope`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleThenEl') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_then_el`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleThenEnum') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_then_enum`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleThenEnumArg0') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_then_enum_arg0`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleThenEnumArg1') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_then_enum_arg1`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleThenEnumArg2') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_then_enum_arg2`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleValid') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_valid`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleRunDaemon') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_run_daemon`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleActAsSubjectId') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_act_as_subject_id`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleActAsSubjectIdentifier') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_act_as_subject_identifier`,(select `gaav`.`value_string` from ((`grouper_attribute_assign` `gaa` join `grouper_attribute_assign_value` `gaav`) join `grouper_attribute_def_name` `gadn`) where ((`gadn`.`name` = 'etc:attribute:rules:ruleActAsSubjectSourceId') and (`gaav`.`attribute_assign_id` = `gaa`.`id`) and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gaa`.`owner_attribute_assign_id` = `main_gaa`.`id`) and (`gaa`.`enabled` = 'T'))) AS `rule_act_as_subject_source_id`,`main_gaa`.`enabled` AS `assignment_enabled`,`main_gaa`.`id` AS `attribute_assign_id` from (`grouper_attribute_assign` `main_gaa` join `grouper_attribute_def_name` `main_gadn`) where ((`main_gadn`.`name` = 'etc:attribute:rules:rule') and (`main_gaa`.`attribute_def_name_id` = `main_gadn`.`id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_service_role_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_service_role_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_service_role_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_service_role_v` AS select distinct (case `gf`.`name` when 'admins' then 'admin' when 'updaters' then 'admin' when 'members' then 'user' end) AS `service_role`,`gg`.`name` AS `group_name`,`gadn`.`name` AS `name_of_service_def_name`,`gm`.`subject_source` AS `subject_source_id`,`gm`.`subject_id` AS `subject_id`,`gf`.`name` AS `field_name`,`gad`.`name` AS `name_of_service_def`,`gg`.`display_name` AS `group_display_name`,`gg`.`id` AS `group_id`,`gad`.`id` AS `service_def_id`,`gadn`.`id` AS `service_name_id`,`gm`.`id` AS `member_id`,`gf`.`id` AS `field_id`,`gadn`.`display_name` AS `display_name_of_service_name`,`gaa`.`owner_stem_id` AS `service_stem_id` from (((((((`grouper_attribute_def_name` `gadn` join `grouper_attribute_def` `gad`) join `grouper_groups` `gg`) join `grouper_memberships_all_v` `gmav`) join `grouper_attribute_assign` `gaa`) join `grouper_stem_set` `gss`) join `grouper_members` `gm`) join `grouper_fields` `gf`) where ((`gadn`.`attribute_def_id` = `gad`.`id`) and (`gad`.`attribute_def_type` = 'service') and (`gaa`.`attribute_def_name_id` = `gadn`.`id`) and (`gad`.`assign_to_stem` = 'T') and (`gmav`.`FIELD_ID` = `gf`.`id`) and (`gmav`.`IMMEDIATE_MSHIP_ENABLED` = 'T') and (`gmav`.`OWNER_GROUP_ID` = `gg`.`id`) and (`gaa`.`owner_stem_id` = `gss`.`then_has_stem_id`) and (`gg`.`parent_stem` = `gss`.`if_has_stem_id`) and (`gaa`.`enabled` = 'T') and (`gmav`.`MEMBER_ID` = `gm`.`id`) and (`gf`.`name` in ('admins','members','readers','updaters'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_stem_set_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_stem_set_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_stem_set_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_stem_set_v` AS select `ifHas`.`name` AS `if_has_stem_name`,`thenHas`.`name` AS `then_has_stem_name`,`gss`.`depth` AS `depth`,`gss`.`type` AS `type`,`gsParentIfHas`.`name` AS `parent_if_has_name`,`gsParentThenHas`.`name` AS `parent_then_has_name`,`gss`.`id` AS `id`,`ifHas`.`id` AS `if_has_stem_id`,`thenHas`.`id` AS `then_has_stem_id`,`gss`.`parent_stem_set_id` AS `parent_stem_set_id` from (((((`grouper_stem_set` `gss` join `grouper_stem_set` `gssParent`) join `grouper_stems` `gsParentIfHas`) join `grouper_stems` `gsParentThenHas`) join `grouper_stems` `ifHas`) join `grouper_stems` `thenHas`) where ((`thenHas`.`id` = `gss`.`then_has_stem_id`) and (`ifHas`.`id` = `gss`.`if_has_stem_id`) and (`gss`.`parent_stem_set_id` = `gssParent`.`id`) and (`gsParentIfHas`.`id` = `gssParent`.`if_has_stem_id`) and (`gsParentThenHas`.`id` = `gssParent`.`then_has_stem_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `grouper_stems_v`
--

/*!50001 DROP TABLE IF EXISTS `grouper_stems_v`*/;
/*!50001 DROP VIEW IF EXISTS `grouper_stems_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`grouper`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `grouper_stems_v` AS select `gs`.`extension` AS `EXTENSION`,`gs`.`name` AS `NAME`,`gs`.`display_extension` AS `DISPLAY_EXTENSION`,`gs`.`display_name` AS `DISPLAY_NAME`,`gs`.`description` AS `DESCRIPTION`,(select `gs_parent`.`name` from `grouper_stems` `gs_parent` where (`gs_parent`.`id` = `gs`.`parent_stem`)) AS `PARENT_STEM_NAME`,(select `gs_parent`.`display_name` from `grouper_stems` `gs_parent` where (`gs_parent`.`id` = `gs`.`parent_stem`)) AS `PARENT_STEM_DISPLAYNAME`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gs`.`creator_id`)) AS `CREATOR_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gs`.`creator_id`)) AS `CREATOR_SUBJECT_ID`,(select `gm`.`subject_source` from `grouper_members` `gm` where (`gm`.`id` = `gs`.`modifier_id`)) AS `MODIFIER_SOURCE`,(select `gm`.`subject_id` from `grouper_members` `gm` where (`gm`.`id` = `gs`.`modifier_id`)) AS `MODIFIER_SUBJECT_ID`,`gs`.`create_time` AS `CREATE_TIME`,`gs`.`creator_id` AS `CREATOR_ID`,`gs`.`id` AS `STEM_ID`,`gs`.`modifier_id` AS `MODIFIER_ID`,`gs`.`modify_time` AS `MODIFY_TIME`,`gs`.`parent_stem` AS `PARENT_STEM`,`gs`.`hibernate_version_number` AS `HIBERNATE_VERSION_NUMBER`,`gs`.`context_id` AS `CONTEXT_ID` from `grouper_stems` `gs` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-05  0:56:44
